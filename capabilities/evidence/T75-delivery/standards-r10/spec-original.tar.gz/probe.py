from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,tempfile
repo=Path('/home/ubuntu/IdeaProjects/open-pdf');base=Path(tempfile.mkdtemp(prefix='t75-spec-content.'));shutil.copy2(__file__,base/'probe.py')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
script=repo/'scripts/t13-program-standards.py';expected_sha='bc3c0d80637ff19f65aa7c2183a1d326d8ec524fcb38700797a395d3a5e32118';assert sha(script)==expected_sha
observer=base/'observer.py';shutil.copy2(script,observer)
identities={str(p):sha(p) for p in [script,repo/'scripts/qpdf-pin.properties',repo/'scripts/container-bin/qpdf',repo/'scripts/t13-qpdf-runtime.sha256',repo/'.build-cache/qpdf/12.4.0/bin/qpdf',repo/'.build-cache/qpdf/12.4.0/lib/libqpdf.so.30.4.0']};(base/'identities-before.json').write_text(json.dumps(identities,indent=2))
inputs=base/'inputs';inputs.mkdir();outputs=base/'observations';outputs.mkdir();rows=[]
def stream(data,extra=b''):
    return b'<< /Length '+str(len(data)).encode()+b' '+extra+b' >>\nstream\n'+data+b'\nendstream'
def document(page=b'/F 10 Tf BT (A) Tj ET',glyph=b'500 0 0 0 400 600 d1 0 0 400 600 re f',fontname=b'/F',page_resources=None,form=b'',form_resources=b'/Resources << >>',nested=b'',nested_resources=b'/Resources << >>',version=b'2.0'):
    resources=page_resources if page_resources is not None else b'<< /Font << '+fontname+b' 5 0 R >> /XObject << /A 7 0 R >> >>'
    objects=[b'<< /Type /Catalog /Pages 2 0 R >>',b'<< /Type /Pages /Count 1 /Kids [3 0 R] >>',b'<< /Type /Page /Parent 2 0 R /MediaBox [0 0 200 200] /Resources '+resources+b' /Contents 4 0 R >>',stream(page),b'<< /Type /Font /Subtype /Type3 /FontBBox [0 0 400 600] /FontMatrix [.001 0 0 .001 0 0] /CharProcs << /A 6 0 R >> /Encoding << /Type /Encoding /Differences [65 /A] >> /FirstChar 65 /LastChar 65 /Widths [500] /Resources << >> >>',stream(glyph),stream(form,b'/Type /XObject /Subtype /Form /BBox [0 0 200 200] '+form_resources),stream(nested,b'/Type /XObject /Subtype /Form /BBox [0 0 200 200] '+nested_resources)]
    result=b'%PDF-'+version+b'\n%\xe2\xe3\xcf\xd3\n';offsets=[0]
    for n,obj in enumerate(objects,1):offsets.append(len(result));result+=str(n).encode()+b' 0 obj\n'+obj+b'\nendobj\n'
    start=len(result);result+=b'xref\n0 '+str(len(objects)+1).encode()+b'\n0000000000 65535 f \n'+b''.join(('%010d 00000 n \n'%p).encode() for p in offsets[1:])+b'trailer\n<< /Size '+str(len(objects)+1).encode()+b' /Root 1 0 R >>\nstartxref\n'+str(start).encode()+b'\n%%EOF\n';return result

def run(name,body,expected,authority):
    pdf=inputs/(name+'.pdf');pdf.write_bytes(body);out=outputs/name;cmd=[sys.executable,str(observer),str(repo),str(pdf),'content',str(out)];env=os.environ.copy();env.pop('QPDF_CACHE_DIRECTORY',None)
    p=subprocess.run(cmd,env=env,capture_output=True,text=True,timeout=40);props=dict(line.split('=',1) for line in (out/'result.properties').read_text().splitlines()) if (out/'result.properties').exists() else {}
    row={'case':name,'argv':cmd,'input':str(pdf),'input-sha256':sha(pdf),'expected':expected,'authority':authority,'exit-code':p.returncode,'result':props.get('standards'),'properties':props,'output':str(out),'matched':props.get('standards')==expected};rows.append(row)
    (base/(name+'.command.json')).write_text(json.dumps(row,indent=2));(base/(name+'.stdout.txt')).write_text(p.stdout);(base/(name+'.stderr.txt')).write_text(p.stderr);print(json.dumps({k:row[k] for k in ['case','expected','result','matched']}),flush=True)
run('baseline',document(),'pass','ISO 32000-1 Tables 105,107,112,113')
for name,content,expected in [('q-crosses-marked',b'q /Span <<>> BDC Q EMC','fail'),('marked-crosses-q',b'/Span <<>> BDC q EMC Q','fail'),('q-outside-marked',b'q /Span <<>> BDC EMC Q','pass'),('q-inside-marked',b'/Span <<>> BDC q Q EMC','pass')]:run(name,document(page=content),expected,'PDF2 errata 7.8.2: all matched pairs shall be properly nested')
for name,content in [('curly-name-tag',b'/{S} <<>> BDC EMC'),('curly-name-key',b'/S << /{key} 1 >> BDC EMC'),('encoded-curly-name-tag',b'/#7BS#7D <<>> BDC EMC')]:run(name,document(page=content),'pass','PDF2 errata 7.2.2 Table2 footnote: curly braces delimit only Type4 calculator functions')
for name,fontname in [('ascii-escaped-font',b'/F#41'),('utf8-escaped-font',b'/F#C3#A9'),('latin1-escaped-font',b'/F#E9'),('highbyte-escaped-font',b'/F#FF')]:run(name,document(page=fontname+b' 10 Tf BT(A)Tj ET',fontname=fontname),'pass','ISO 32000-1 7.3.5: identical decoded name bytes identify the same resource')
for name,res,expected in [('form-local-resources',b'/Resources << /Font << /F 5 0 R >> >>','pass'),('form-missing-resources',b'','fail'),('form-empty-resources',b'/Resources << >>','fail')]:run(name,document(page=b'/A Do',form=b'/F 10 Tf BT(A)Tj ET',form_resources=res),expected,'PDF2 errata 7.8.3/8.10.2 Table93: all named Form resources must be local')
run('form-inherited-font-state',document(page=b'/F 10 Tf /A Do',form=b'BT(A)Tj ET',form_resources=b''),'pass','ISO 8.10.2: Form inherits graphics state; no directly named font lookup in Form')
run('nested-form-caller-resource',document(page=b'/A Do',page_resources=b'<< /XObject << /A 7 0 R >> >>',form=b'/B Do',form_resources=b'/Resources << /Font << /F 5 0 R >> /XObject << /B 8 0 R >> >>',nested=b'/F 10 Tf BT(A)Tj ET',nested_resources=b''),'fail','PDF2 7.8.3 forbids inheriting named Form resources from its caller')
for name,glyph,expected in [('d1-reversed-both',b'500 0 400 600 0 0 d1 0 0 400 600 re f','fail'),('d1-reversed-x',b'500 0 400 0 0 600 d1 0 0 400 600 re f','fail'),('d1-bounds-outside',b'500 0 0 0 399 600 d1 0 0 400 600 re f','fail'),('d1-negative-rectangle',b'500 0 0 0 400 600 d1 400 600 -400 -600 re f','pass')]:run(name,document(glyph=glyph),expected,'ISO1 Table113 / PDF2 Table111: llx/lly lower-left and urx/ury upper-right; ink enclosed')
# Small exact-bound controls exercise traversal admission without expanding review into other predicates.
for number,expected in [(127,'pass'),(128,'indeterminate')]:
    run('form-occurrences-'+str(number),document(page=b'/A Do\n'*number,form=b'',form_resources=b'/Resources << >>'),expected,'Contract: total content stream occurrences at most 128, including page stream')
after={p:sha(Path(p)) for p in identities};(base/'identities-after.json').write_text(json.dumps(after,indent=2));(base/'summary.json').write_text(json.dumps({'directory':str(base),'observer-sha256':sha(observer),'source-unchanged':after[str(script)]==identities[str(script)],'identities-unchanged':after==identities,'rows':rows},indent=2));print(str(base),flush=True)
