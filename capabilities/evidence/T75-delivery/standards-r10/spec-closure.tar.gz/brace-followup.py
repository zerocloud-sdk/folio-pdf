from pathlib import Path
import ast,hashlib,json,os,subprocess,sys
base=Path(__file__).parent;repo=Path('/home/ubuntu/IdeaProjects/open-pdf')
node=ast.parse((base/'probe.py').read_text());defs=[item for item in node.body if isinstance(item,ast.FunctionDef) and item.name in ('stream','document')]
namespace={};exec(compile(ast.Module(body=defs,type_ignores=[]),str(base/'probe.py'),'exec'),namespace)
document=namespace['document'];observer=base/'observer.py'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(observer)=='e8e63757169a2ea91edd660a3fb867ead726c6605c26f203b5acb4484d5abec5'
rows=[]
for name,called in [('escaped-dictionary-raw-curly-content',b'/{F}'),('escaped-dictionary-escaped-curly-content',b'/#7BF#7D')]:
 pdf=base/'inputs'/(name+'.pdf');pdf.write_bytes(document(fontname=b'/#7BF#7D',page=called+b' 10 Tf BT(A)Tj ET'))
 out=base/'observations'/name;cmd=[sys.executable,str(observer),str(repo),str(pdf),'content',str(out)];env=os.environ.copy();env.pop('QPDF_CACHE_DIRECTORY',None)
 proc=subprocess.run(cmd,env=env,capture_output=True,text=True,timeout=40);props=dict(line.split('=',1) for line in (out/'result.properties').read_text().splitlines())
 row={'case':name,'argv':cmd,'cwd':os.getcwd(),'input':str(pdf),'input-sha256':sha(pdf),'observer-sha256':sha(observer),'expected':'pass','result':props['standards'],'matched':props['standards']=='pass','exit-code':proc.returncode,'properties':props,'output':str(out)}
 (base/(name+'.command.json')).write_text(json.dumps(row,indent=2));(base/(name+'.stdout.txt')).write_text(proc.stdout);(base/(name+'.stderr.txt')).write_text(proc.stderr);rows.append(row);print(json.dumps(row),flush=True)
(base/'brace-followup-summary.json').write_text(json.dumps(rows,indent=2))
assessment={'scope':'Incremental content closure, not final #75 review','original-findings':'All four closed; all 23 retained original PDFs observed as expected, with d1 reversed corners retaining previous nonfinding assessment','required-sources':'All five pass','new-adjacent-tool-boundary':{'case':'curly-resource-name','result':'indeterminate','reason':'Pinned qpdf12.4.0 emits warnings for raw braces in a PDF resource dictionary, despite PDF2 7.2.2 corrected lexical semantics; observer does not misreport a standard violation or PASS','classification':'Tool coverage boundary, not a product or observer correctness finding'},'brace-followup':'Escaped dictionary keys, with either raw or escaped braces in the content Name, both pass','version-note':'Crossed q/Q and marked pairs are explicitly forbidden by approved PDF2 7.8.2. The raw1.7 probe also fails under current content profile; this may be stated only as PDF2 qualification policy unless a base1.7 rule is established. No required-PDF2 behavior gap found.','source-identity':'e8e63757169a2ea91edd660a3fb867ead726c6605c26f203b5acb4484d5abec5','initial-batch-tool-identities-unchanged':True}
(base/'assessment.json').write_text(json.dumps(assessment,indent=2));print(str(base/'assessment.json'))
