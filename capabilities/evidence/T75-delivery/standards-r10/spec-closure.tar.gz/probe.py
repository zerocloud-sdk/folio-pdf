from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,tempfile
repo=Path('/home/ubuntu/IdeaProjects/open-pdf')
prior=Path('/tmp/t75-spec-content.llnxqpvl')
base=Path(tempfile.mkdtemp(prefix='t75-spec-content-closure.'))
shutil.copy2(__file__,base/'probe.py')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
script=repo/'scripts/t13-program-standards.py'
expected_sha='e8e63757169a2ea91edd660a3fb867ead726c6605c26f203b5acb4484d5abec5'
assert sha(script)==expected_sha
observer=base/'observer.py';shutil.copy2(script,observer)
identity_paths=[script,repo/'scripts/qpdf-pin.properties',repo/'scripts/container-bin/qpdf',repo/'scripts/t13-qpdf-runtime.sha256',repo/'.build-cache/qpdf/12.4.0/bin/qpdf',repo/'.build-cache/qpdf/12.4.0/lib/libqpdf.so.30.4.0']
identities={str(p):sha(p) for p in identity_paths}
for line in (repo/'scripts/t13-qpdf-runtime.sha256').read_text().splitlines():
    expected,relative=line.split('  ',1);path=repo/'.build-cache/qpdf/12.4.0'/relative
    identities[str(path)]=sha(path);assert identities[str(path)]==expected
(base/'identities-before.json').write_text(json.dumps(identities,indent=2))
inputs=base/'inputs';inputs.mkdir();outputs=base/'observations';outputs.mkdir();rows=[]
print(str(base),flush=True)
def stream(data,extra=b''):
    return b'<< /Length '+str(len(data)).encode()+b' '+extra+b' >>\nstream\n'+data+b'\nendstream'
def document(page=b'/F 10 Tf BT (A) Tj ET',glyph=b'500 0 0 0 400 600 d1 0 0 400 600 re f',fontname=b'/F',page_resources=None,form=b'',form_resources=b'/Resources << >>',nested=b'',nested_resources=b'/Resources << >>',version=b'2.0',catalog_version=None):
    resources=page_resources if page_resources is not None else b'<< /Font << '+fontname+b' 5 0 R >> /XObject << /A 7 0 R >> >>'
    catalog_extra=b'' if catalog_version is None else b' /Version /'+catalog_version
    objects=[b'<< /Type /Catalog /Pages 2 0 R'+catalog_extra+b' >>',b'<< /Type /Pages /Count 1 /Kids [3 0 R] >>',b'<< /Type /Page /Parent 2 0 R /MediaBox [0 0 200 200] /Resources '+resources+b' /Contents 4 0 R >>',stream(page),b'<< /Type /Font /Subtype /Type3 /FontBBox [0 0 400 600] /FontMatrix [.001 0 0 .001 0 0] /CharProcs << /A 6 0 R >> /Encoding << /Type /Encoding /Differences [65 /A] >> /FirstChar 65 /LastChar 65 /Widths [500] /Resources << >> >>',stream(glyph),stream(form,b'/Type /XObject /Subtype /Form /BBox [0 0 200 200] '+form_resources),stream(nested,b'/Type /XObject /Subtype /Form /BBox [0 0 200 200] '+nested_resources)]
    result=b'%PDF-'+version+b'\n%\xe2\xe3\xcf\xd3\n';offsets=[0]
    for n,obj in enumerate(objects,1):offsets.append(len(result));result+=str(n).encode()+b' 0 obj\n'+obj+b'\nendobj\n'
    start=len(result);result+=b'xref\n0 '+str(len(objects)+1).encode()+b'\n0000000000 65535 f \n'+b''.join(('%010d 00000 n \n'%p).encode() for p in offsets[1:])+b'trailer\n<< /Size '+str(len(objects)+1).encode()+b' /Root 1 0 R >>\nstartxref\n'+str(start).encode()+b'\n%%EOF\n';return result

def run(name,body,expected,authority,origin=None):
    pdf=inputs/(name+'.pdf');pdf.write_bytes(body);out=outputs/name
    cmd=[sys.executable,str(observer),str(repo),str(pdf),'content',str(out)]
    env=os.environ.copy();env.pop('QPDF_CACHE_DIRECTORY',None)
    p=subprocess.run(cmd,env=env,capture_output=True,text=True,timeout=40)
    props=dict(line.split('=',1) for line in (out/'result.properties').read_text().splitlines()) if (out/'result.properties').exists() else {}
    row={'case':name,'argv':cmd,'cwd':os.getcwd(),'input':str(pdf),'input-sha256':sha(pdf),'expected':expected,'authority':authority,'exit-code':p.returncode,'result':props.get('standards'),'properties':props,'output':str(out),'matched':props.get('standards')==expected}
    if origin:row['original']=str(origin);row['original-sha256']=sha(origin);assert row['input-sha256']==row['original-sha256']
    rows.append(row)
    (base/(name+'.command.json')).write_text(json.dumps(row,indent=2));(base/(name+'.stdout.txt')).write_text(p.stdout);(base/(name+'.stderr.txt')).write_text(p.stderr)
    print(json.dumps({k:row[k] for k in ['case','expected','result','matched']}),flush=True)

old=json.loads((prior/'summary.json').read_text())
for row in old['rows']:
    name=row['case'];source=Path(row['input']);expected=row['expected']
    if name in ('d1-reversed-both','d1-reversed-x'):expected='pass'
    run(name,source.read_bytes(),expected,'Original review authority; reversed d1 corners retain previous nonfinding assessment',source)
for name,declared,called,expected in [
 ('utf8-cannot-alias-latin1',b'/F#C3#A9',b'/F#E9','fail'),
 ('latin1-cannot-alias-utf8',b'/F#E9',b'/F#C3#A9','fail'),
 ('raw-utf8-matches-escaped',b'/F\xc3\xa9',b'/F#c3#a9','pass'),
 ('raw-latin1-matches-escaped',b'/F\xe9',b'/F#e9','pass'),
 ('raw-highbyte-matches-escaped',b'/F\xff',b'/F#ff','pass'),
 ('curly-resource-name',b'/{F}',b'/#7BF#7D','pass')]:
    run(name,document(fontname=declared,page=called+b' 10 Tf BT(A)Tj ET'),expected,'ISO1 7.3.5: byte identity, no Unicode equivalence')
for category in ('XObject','Properties'):
    for name,declared,called,expected in [
      ('utf8',b'/R#C3#A9',b'/R#c3#a9','pass'),
      ('binary',b'/R#FF',b'/R#ff','pass'),
      ('distinct',b'/R#C3#A9',b'/R#E9','fail')]:
        value=b'7 0 R' if category=='XObject' else b'<< /ActualText (A) /MCID 0 >>'
        resource=b'<< /'+category.encode()+b' << '+declared+b' '+value+b' >> >>'
        body=called+b' Do' if category=='XObject' else b'/Span '+called+b' BDC EMC'
        run(category.lower()+'-'+name,document(page=body,page_resources=resource),expected,'ISO1 7.3.5 original resource bytes, 7.8.3 resource category binding')
for name,header,catalog,expected in [
 ('legacy-form-resource-inheritance',b'1.7',None,'indeterminate'),
 ('legacy-form-with-catalog2',b'1.7',b'2.0','fail'),
 ('header2-with-lower-catalog',b'2.0',b'1.7','fail'),
 ('legacy-same-catalog',b'1.7',b'1.7','indeterminate')]:
    run(name,document(page=b'/A Do',form=b'/F 10 Tf BT(A)Tj ET',form_resources=b'',version=header,catalog_version=catalog),expected,'PDF2 7.8.3/Table93; effective max(header,Catalog Version); older inherited names unqualified')
for name,header,catalog,resource in [
 ('legacy-inherited-font-only',b'1.7',None,b''),
 ('catalog2-inherited-font-only',b'1.7',b'2.0',b''),
 ('pdf2-empty-form-resources-font-only',b'2.0',None,b'/Resources << >>'),
 ('pdf2-null-form-resources-font-only',b'2.0',None,b'/Resources null')]:
    run(name,document(page=b'/F 10 Tf /A Do',form=b'BT(A)Tj ET',form_resources=resource,version=header,catalog_version=catalog),'pass','ISO1 8.10.2 and PDF2 Table93: current selected font is graphics state, not named resource lookup')
run('pdf2-null-form-resources-named-font',document(page=b'/A Do',form=b'/F 10 Tf BT(A)Tj ET',form_resources=b'/Resources null'),'fail','PDF2 Table93 requires local named font')
run('nested-graphics-text-marked',document(page=b'q BT /Span <<>> BDC EMC ET Q'),'pass','PDF2 7.8.2 proper nesting')
run('form-independent-marked-context',document(page=b'q /Span <<>> BDC /A Do EMC Q',form=b'q /Span <<>> BDC EMC Q'),'pass','ISO1 14.6 page and Form marked-content contexts are distinct')
run('form-cannot-close-caller-save',document(page=b'q /A Do Q',form=b'Q'),'fail','ISO1 8.10.2 / PDF2 7.8.2: Form executes independently balanced saved state')
run('legacy-crossed-pairs-policy',document(page=b'q /Span <<>> BDC Q EMC',version=b'1.7'),'fail','Observation only: current PDF2 qualification policy; does not establish base PDF1.7 invalidity')
for source in sorted((repo/'capabilities/profiles/T13-text/fixtures').glob('*.pdf')):
    if source.name in ('nested-split-type3.pdf','marked-structure.pdf','embedded-font-kinds.pdf','embedded-font-inheritance.pdf','uncertain-geometry.pdf'):
        run('source-'+source.stem,source.read_bytes(),'pass','Required corpus remains within qualified content profile',source)
after={p:sha(Path(p)) for p in identities};(base/'identities-after.json').write_text(json.dumps(after,indent=2))
summary={'directory':str(base),'scope':'Content incremental closure only; not final #75 or broad conformance review','observer-sha256':sha(observer),'source-unchanged':after[str(script)]==identities[str(script)],'identities-unchanged':after==identities,'rows':rows}
(base/'summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps({'directory':str(base),'total':len(rows),'matched':sum(r['matched'] for r in rows),'identities-unchanged':after==identities}),flush=True)
