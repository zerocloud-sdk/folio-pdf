from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time
ROOT=Path('/home/ubuntu/IdeaProjects/open-pdf');HERE=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert sha(HERE/'observer.py')=='bc3c0d80637ff19f65aa7c2183a1d326d8ec524fcb38700797a395d3a5e32118'
ENV=dict(os.environ);ENV.pop('QPDF_CACHE_DIRECTORY',None)
files=[HERE/'observer.py',HERE/'contract.md',Path(sys.executable).resolve(),ROOT/'.build-cache/qpdf/12.4.0/bin/qpdf']+[ROOT/'scripts'/x for x in ['qpdf-pin.properties','container-bin/qpdf','t13-qpdf-runtime.sha256']]
for line in (ROOT/'scripts/t13-qpdf-runtime.sha256').read_text().splitlines():files.append(ROOT/'.build-cache/qpdf/12.4.0'/line.split('  ',1)[1])
identities={str(p):sha(p) for p in files};rows=[]
def pdf(content=b'BT /F1 10 Tf (A) Tj ET',name=b'F1',glyph=b'500 0 0 0 400 600 d1 0 0 400 600 re f',bbox=b'0 0 400 600'):
 def stream(data):return b'<< /Length '+str(len(data)).encode()+b' >>\nstream\n'+data+b'\nendstream'
 objects=[b'<</Type/Catalog/Pages 2 0 R>>',b'<</Type/Pages/Kids[3 0 R]/Count 1>>',b'<</Type/Page/Parent 2 0 R/MediaBox[0 0 100 100]/Resources<</Font<</'+name+b' 5 0 R>>>>/Contents 4 0 R>>',stream(content),b'<</Type/Font/Subtype/Type3/FontBBox['+bbox+b']/FontMatrix[.001 0 0 .001 0 0]/CharProcs<</A 6 0 R>>/Encoding<</Type/Encoding/Differences[65/A]>>/FirstChar 65/LastChar 65/Widths[500]/Resources<<>>>>',stream(glyph)]
 data=bytearray(b'%PDF-2.0\n');offsets=[0]
 for i,body in enumerate(objects,1):offsets.append(len(data));data.extend(str(i).encode()+b' 0 obj\n'+body+b'\nendobj\n')
 xref=len(data);data.extend(b'xref\n0 '+str(len(offsets)).encode()+b'\n0000000000 65535 f \n')
 for off in offsets[1:]:data.extend(('%010d 00000 n \n'%off).encode())
 data.extend(b'trailer\n<</Size '+str(len(offsets)).encode()+b'/Root 1 0 R>>\nstartxref\n'+str(xref).encode()+b'\n%%EOF\n');return data

def run(label,data,scope='content'):
 path=HERE/(label+'.pdf');path.write_bytes(data);out=HERE/(label+'-output');args=[sys.executable,str(HERE/'observer.py'),str(ROOT),str(path),scope,str(out)];started=time.monotonic()
 with (HERE/(label+'.stdout')).open('wb') as stdout,(HERE/(label+'.stderr')).open('wb') as stderr:
  p=subprocess.run(args,cwd=HERE,env=ENV,stdout=stdout,stderr=stderr,timeout=40)
 props=out/'result.properties';result=dict(line.split('=',1) for line in props.read_text().splitlines() if line and not line.startswith(('#','!'))) if props.exists() else None
 row={'label':label,'command':args,'cwd':str(HERE),'exit':p.returncode,'elapsed':time.monotonic()-started,'input-sha256':sha(path),'result':result,'files':{str(f.relative_to(out)):sha(f) for f in out.iterdir() if f.is_file()}}
 rows.append(row);(HERE/(label+'-result.json')).write_text(json.dumps(row,indent=2)+'\n');print(label,p.returncode,result.get('standards') if result else None,result.get('finding') if result else None,flush=True)

original=(ROOT/'capabilities/profiles/T13-text/fixtures/nested-split-type3.pdf').read_bytes()
for label,name in [('ascii',b'XX'),('utf8',b'\xc3\xa9')]:
 before=b'/Leaf 9 0 R';after=b'/'+name+b' 9 0 R';data=original.replace(before,after.ljust(len(before)))
 before=b'/Leaf Do';after=b'/'+name+b' Do';data=data.replace(before,after.ljust(len(before)))
 assert len(data)==len(original)
 run('form-name-'+label,data)
 leaf=b'0 0 1 rg BT /F1 10 Tf (A) Tj ET\n'
 before=b'/Matrix [2 0 0 1 5 10] /Resources << /Font << /F1 6 0 R >> >>'
 after=b'/Resources<</Font<</F1 6 0 R>>/Properties<</'+name+b'<</Alt(x)>>>>>>'
 assert len(after)<=len(before)
 data=original.replace(before,after.ljust(len(before))).replace(leaf,(b'/S/'+name+b' BDC EMC').ljust(len(leaf)))
 assert len(data)==len(original)
 run('properties-name-'+label,data)
(HERE/'resource-name-results.json').write_text(json.dumps(rows,indent=2)+'\n')
