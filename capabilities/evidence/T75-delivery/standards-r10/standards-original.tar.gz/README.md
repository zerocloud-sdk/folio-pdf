# Independent bounded Standards review: PDF content and Type3 program qualification

Review scope: the frozen bc3c0d80637ff19f65aa7c2183a1d326d8ec524fcb38700797a395d3a5e32118 observer's PDF Tokens mode, check_content and check_type3_programs. observer.py and contract.md preserve that implementation and its declared qualification scope. No implementation or Maven action was taken. The old qpdf, font and CMap modules were not re-reviewed; only an actual default PostScript CMap regression control was run.

## Hard finding: PDF resource names disagree with qpdf JSON names

Tokens returns a Name decoded with Latin-1 at source line 207. The three content resource lookup sites compare that directly to qpdf JSON keys at lines 1065, 1074 and 1105. The actual qpdf JSON represents valid UTF-8 names as Unicode strings (the fixture's two bytes c3 a9 become /é), while non-UTF-8 names use its serialized n:/#e9 form. The PDF lexical Name retains different text, so existing resources are reported missing.

Six literal public controls reproduce false FAIL: utf8-name, byte-name, escaped-utf8-name and escaped-byte-name select an existing font; form-name-utf8 selects an existing Form; properties-name-utf8 selects an existing property list. Their actual qpdf.json files retain the real keys. ASCII Font/Form/Properties controls and a #28 escaped delimiter name all PASS. The contract at docs/t13-certification.md:341-346 claims PDF lexical objects and active resource lookup without an ASCII-only name exclusion. Normalize PDF/qpdf name identities to the same bytes at the resource lookup boundary; preserve distinct PostScript semantics.

## Judgement call

Possible Duplicated Code: check_type3_programs.numbers and check_content.numeric repeat the same PDF number predicate (int excluding bool, or finite Decimal) at lines 936-937 and 1006-1007. A shared private predicate is a small useful cleanup. The two state machines have different responsibilities and do not need to be combined.

## Other controls and explicit probe correction

Exactly 100000 content tokens PASS and 100001 return INDETERMINATE. Direct-container depth 32 PASS and 33 return INDETERMINATE. A Type3 exact fractional .1+.2 within .3 bound PASS, while .29 is FAIL. The default PostScript inherited CMap Source control PASS. Reversed d1 coordinates were an exploratory observation only; no finding is asserted from that case.

The initial label tokens-at-limit was miscounted: its 99995 nulls plus direct dictionary/name/BDC/EMC tokens exceed 100000. It correctly returned INDETERMINATE and is not claimed to be a boundary positive. The corrected independent boundary-probe.py uses exactly 50000 q/Q pairs and retains the original run alongside the corrected 100000/100001 pair.

## Evidence and provenance

probe.py independently authors small six-object PDFs with exact stream Lengths and xrefs. Font name and Type3 controls are original authoring. resource-name-probe.py uses length-preserving modifications of the project-owned nested-split-type3 Source for Form/Properties names; its ASCII twins validate the setup. No product or generator implementation is imported. The default PS case is the unchanged project-owned embedded-font-inheritance Source. review-reference.json records the local public ISO reference consulted for the non-finding reversed rectangle question.

Every launch uses a subprocess argument array and an independent 40-second timeout. All 21 public CLI processes exit normally. results.json, boundary-results.json, resource-name-results.json and per-case files retain exact commands, PDFs, actual qpdf output, result properties, timings and identities. identity.json/identity-final.json show the frozen observer, Python executable, pin/wrapper/binary and all 11 runtime files unchanged. Every public record binds the exact input and script SHA.

This is an incremental Standards report; it does not claim general PDF conformance or final T13/#75 completion.
