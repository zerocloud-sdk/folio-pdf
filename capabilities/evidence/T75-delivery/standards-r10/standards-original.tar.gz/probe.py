from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time
ROOT=Path('/home/ubuntu/IdeaProjects/open-pdf');HERE=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert sha(HERE/'observer.py')=='bc3c0d80637ff19f65aa7c2183a1d326d8ec524fcb38700797a395d3a5e32118'
ENV=dict(os.environ);ENV.pop('QPDF_CACHE_DIRECTORY',None)
files=[HERE/'observer.py',HERE/'contract.md',Path(sys.executable).resolve(),ROOT/'.build-cache/qpdf/12.4.0/bin/qpdf']+[ROOT/'scripts'/x for x in ['qpdf-pin.properties','container-bin/qpdf','t13-qpdf-runtime.sha256']]
for line in (ROOT/'scripts/t13-qpdf-runtime.sha256').read_text().splitlines():files.append(ROOT/'.build-cache/qpdf/12.4.0'/line.split('  ',1)[1])
identities={str(p):sha(p) for p in files};rows=[]
def pdf(content=b'BT /F1 10 Tf (A) Tj ET',name=b'F1',glyph=b'500 0 0 0 400 600 d1 0 0 400 600 re f',bbox=b'0 0 400 600'):
 def stream(data):return b'<< /Length '+str(len(data)).encode()+b' >>\nstream\n'+data+b'\nendstream'
 objects=[b'<</Type/Catalog/Pages 2 0 R>>',b'<</Type/Pages/Kids[3 0 R]/Count 1>>',b'<</Type/Page/Parent 2 0 R/MediaBox[0 0 100 100]/Resources<</Font<</'+name+b' 5 0 R>>>>/Contents 4 0 R>>',stream(content),b'<</Type/Font/Subtype/Type3/FontBBox['+bbox+b']/FontMatrix[.001 0 0 .001 0 0]/CharProcs<</A 6 0 R>>/Encoding<</Type/Encoding/Differences[65/A]>>/FirstChar 65/LastChar 65/Widths[500]/Resources<<>>>>',stream(glyph)]
 data=bytearray(b'%PDF-2.0\n');offsets=[0]
 for i,body in enumerate(objects,1):offsets.append(len(data));data.extend(str(i).encode()+b' 0 obj\n'+body+b'\nendobj\n')
 xref=len(data);data.extend(b'xref\n0 '+str(len(offsets)).encode()+b'\n0000000000 65535 f \n')
 for off in offsets[1:]:data.extend(('%010d 00000 n \n'%off).encode())
 data.extend(b'trailer\n<</Size '+str(len(offsets)).encode()+b'/Root 1 0 R>>\nstartxref\n'+str(xref).encode()+b'\n%%EOF\n');return data

def run(label,data,scope='content'):
 path=HERE/(label+'.pdf');path.write_bytes(data);out=HERE/(label+'-output');args=[sys.executable,str(HERE/'observer.py'),str(ROOT),str(path),scope,str(out)];started=time.monotonic()
 with (HERE/(label+'.stdout')).open('wb') as stdout,(HERE/(label+'.stderr')).open('wb') as stderr:
  p=subprocess.run(args,cwd=HERE,env=ENV,stdout=stdout,stderr=stderr,timeout=40)
 props=out/'result.properties';result=dict(line.split('=',1) for line in props.read_text().splitlines() if line and not line.startswith(('#','!'))) if props.exists() else None
 row={'label':label,'command':args,'cwd':str(HERE),'exit':p.returncode,'elapsed':time.monotonic()-started,'input-sha256':sha(path),'result':result,'files':{str(f.relative_to(out)):sha(f) for f in out.iterdir() if f.is_file()}}
 rows.append(row);(HERE/(label+'-result.json')).write_text(json.dumps(row,indent=2)+'\n');print(label,p.returncode,result.get('standards') if result else None,result.get('finding') if result else None,flush=True)

run('ascii-name',pdf())
for label,name in [('utf8-name',b'\xc3\xa9'),('byte-name',b'\xe9'),('escaped-utf8-name',b'#c3#a9'),('escaped-byte-name',b'#e9'),('name-delimiter',b'#28')]:
 run(label,pdf(b'BT /'+name+b' 10 Tf (A) Tj ET',name=name))
run('missing-font',pdf(b'BT /Lost 10 Tf (A) Tj ET'))
run('fractional-type3-bounds',pdf(glyph=b'500 0 0 0 .3 600 d1 .1 0 .2 600 re f'))
run('fractional-type3-too-small',pdf(glyph=b'500 0 0 0 .29 600 d1 .1 0 .2 600 re f'))
run('reversed-d1-bounds',pdf(glyph=b'500 0 400 600 0 0 d1 0 0 400 600 re f'))
run('tokens-at-limit',pdf(content=b' '.join([b'null']*99995)+b' /S << /X 0 >> BDC EMC'))
run('tokens-over-limit',pdf(content=b'q Q '*50001))
run('default-ps-regression',(ROOT/'capabilities/profiles/T13-text/fixtures/embedded-font-inheritance.pdf').read_bytes(),scope='cmaps')
after={str(p):sha(p) for p in files};(HERE/'identity.json').write_text(json.dumps({'before':identities,'after':after,'unchanged':identities==after,'probe-sha256':sha(Path(__file__))},indent=2)+'\n');(HERE/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(HERE,'identities unchanged',identities==after,flush=True)
