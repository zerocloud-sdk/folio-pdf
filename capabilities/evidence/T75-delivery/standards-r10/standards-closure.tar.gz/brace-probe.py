from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time
ROOT=Path('/home/ubuntu/IdeaProjects/open-pdf');HERE=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert sha(HERE/'observer.py')=='e8e63757169a2ea91edd660a3fb867ead726c6605c26f203b5acb4484d5abec5'
ENV=dict(os.environ);ENV.pop('QPDF_CACHE_DIRECTORY',None)
files=[HERE/'observer.py',HERE/'contract.md',Path(sys.executable).resolve(),ROOT/'.build-cache/qpdf/12.4.0/bin/qpdf']+[ROOT/'scripts'/x for x in ['qpdf-pin.properties','container-bin/qpdf','t13-qpdf-runtime.sha256']]
for line in (ROOT/'scripts/t13-qpdf-runtime.sha256').read_text().splitlines():files.append(ROOT/'.build-cache/qpdf/12.4.0'/line.split('  ',1)[1])
identities={str(p):sha(p) for p in files};rows=[]
def pdf(content=b'BT /F1 10 Tf (A) Tj ET',name=b'F1',glyph=b'500 0 0 0 400 600 d1 0 0 400 600 re f',bbox=b'0 0 400 600'):
 def stream(data):return b'<< /Length '+str(len(data)).encode()+b' >>\nstream\n'+data+b'\nendstream'
 objects=[b'<</Type/Catalog/Pages 2 0 R>>',b'<</Type/Pages/Kids[3 0 R]/Count 1>>',b'<</Type/Page/Parent 2 0 R/MediaBox[0 0 100 100]/Resources<</Font<</'+name+b' 5 0 R>>>>/Contents 4 0 R>>',stream(content),b'<</Type/Font/Subtype/Type3/FontBBox['+bbox+b']/FontMatrix[.001 0 0 .001 0 0]/CharProcs<</A 6 0 R>>/Encoding<</Type/Encoding/Differences[65/A]>>/FirstChar 65/LastChar 65/Widths[500]/Resources<<>>>>',stream(glyph)]
 data=bytearray(b'%PDF-2.0\n');offsets=[0]
 for i,body in enumerate(objects,1):offsets.append(len(data));data.extend(str(i).encode()+b' 0 obj\n'+body+b'\nendobj\n')
 xref=len(data);data.extend(b'xref\n0 '+str(len(offsets)).encode()+b'\n0000000000 65535 f \n')
 for off in offsets[1:]:data.extend(('%010d 00000 n \n'%off).encode())
 data.extend(b'trailer\n<</Size '+str(len(offsets)).encode()+b'/Root 1 0 R>>\nstartxref\n'+str(xref).encode()+b'\n%%EOF\n');return data

def run(label,data,scope='content'):
 path=HERE/(label+'.pdf');path.write_bytes(data);out=HERE/(label+'-output');args=[sys.executable,str(HERE/'observer.py'),str(ROOT),str(path),scope,str(out)];started=time.monotonic()
 with (HERE/(label+'.stdout')).open('wb') as stdout,(HERE/(label+'.stderr')).open('wb') as stderr:
  p=subprocess.run(args,cwd=HERE,env=ENV,stdout=stdout,stderr=stderr,timeout=40)
 props=out/'result.properties';result=dict(line.split('=',1) for line in props.read_text().splitlines() if line and not line.startswith(('#','!'))) if props.exists() else None
 row={'label':label,'command':args,'cwd':str(HERE),'exit':p.returncode,'elapsed':time.monotonic()-started,'input-sha256':sha(path),'result':result,'files':{str(f.relative_to(out)):sha(f) for f in out.iterdir() if f.is_file()}}
 rows.append(row);(HERE/(label+'-result.json')).write_text(json.dumps(row,indent=2)+'\n');print(label,p.returncode,result.get('standards') if result else None,result.get('finding') if result else None,flush=True)


run('font-braces-declared-escaped-content-raw',pdf(b'BT /{F} 10 Tf (A) Tj ET',name=b'#7bF#7d'))
run('font-braces-declared-escaped-content-escaped',pdf(b'BT /#7bF#7d 10 Tf (A) Tj ET',name=b'#7bF#7d'))
(HERE/'brace-results.json').write_text(json.dumps(rows,indent=2)+'\n')
