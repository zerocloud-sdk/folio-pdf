# Independent bounded CONTENT review closure

Frozen observer SHA: e8e63757169a2ea91edd660a3fb867ead726c6605c26f203b5acb4484d5abec5. The live observer was copied unchanged to observer.py and all actual public CLIs executed that retained copy. contract.md preserves the contemporary limited contract. No repository implementation edit or Maven/build command was performed. Overall review baseline remains 5b1603c435f11c40368f75b7b9a2777c9c5e9761.

## Closed hard finding

The exact six original false-FAIL PDFs from /tmp/t75-content-standards-review-x3jqpxui now PASS: raw UTF-8 font name, non-UTF-8 byte font name, both corresponding #xx spellings, UTF-8 Form name and UTF-8 Properties name. ASCII counterparts continue to PASS. Graph.resource compares original bytes across qpdf Unicode and n:/ serialized-name forms.

Nine adjacent negative controls retain FAIL instead of conflating distinct bytes: UTF-8 versus the single-byte spelling and its reverse in all three resource families; mojibake UTF-8 versus the original UTF-8 spelling for Font and Form; composed versus decomposed Unicode bytes for Font. The missing-font original negative remains FAIL. Every result contains the exact requested input SHA.

## Closed heuristic / direct lexical controls

The duplicated numeric predicate has been replaced by pdf_number and is shared by the content and Type3 validation sites. Boolean font-size and glyph-width operands remain FAIL; the prior Type3 exact .1+.2/.3 case remains PASS and the .29 box remains FAIL. This small extraction resolves the previous possible Duplicated Code; the two state machines remain appropriately separate.

The default PostScript CMap inheritance Source remains PASS. For the directly adjacent PDF brace lexing change, raw and escaped brace content names both PASS when the resource dictionary spells its name with #7b/#7d. Two earlier probes wrote literal brace bytes in the resource dictionary itself; pinned qpdf warns while parsing those dictionary objects, so the observer returns INDETERMINATE before content qualification. Those actual results and stderr are retained, not labeled as passing content tests or implementation defects.

## Evidence and provenance

probe.py and brace-probe.py retain exact subprocess argument arrays and original authoring. Every run has an independent 40-second timeout; all 28 complete normally. results.json, brace-results.json and individual result JSON files retain commands, exact inputs/outputs, findings and timing. Output directories preserve actual qpdf JSON, raw stdout/stderr and public properties. identity.json and identity-final.json bind the retained observer, Python executable, qpdf binary/wrapper/pin and all 11 declared runtime library files; all checked identities are unchanged. validation.txt records the literal outcome assertions.

Original six defect PDFs and related numeric/ASCII controls are copied byte-for-byte from the prior independent review. New byte-distinction controls use the same independent six-object authoring or same-length edits of the project-owned nested-split-type3 Source; no product or generator implementation is imported. The two script sources and their APIs are not altered by these probes.

This closes only the owned incremental CONTENT name finding and numeric duplication judgement, including direct neighboring name/lexical controls. It is not a final clean review of #75 or general PDF conformance.
