from pathlib import Path
import hashlib, json, os, shutil, subprocess, sys, tempfile

root = Path('/home/ubuntu/IdeaProjects/open-pdf')
base = Path(tempfile.mkdtemp(prefix='t75-content-review-observations-'))
observer = base / 'observer.py'
shutil.copy2(root / 'scripts/t13-program-standards.py', observer)
shutil.copy2(__file__, base / 'record.py')
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
authority = root / 'capabilities/profiles/T13-standards'
shutil.copy2(authority / 'content-controls.json', base / 'catalog.json')
cases = [('source-' + path.stem, path, 'pass', None) for path in sorted(
    (root / 'capabilities/profiles/T13-text/fixtures').glob('*.pdf'))]
cases += [(name, authority / entry['path'], 'fail', entry['rule']) for name, entry in
          json.loads((base / 'catalog.json').read_text()).items()]
assert len(cases) == 60
rows = []
env = os.environ.copy(); env.pop('QPDF_CACHE_DIRECTORY', None)
for name, source, expected, rule in cases:
    directory = base / name; directory.mkdir()
    pdf = directory / 'input.pdf'; shutil.copy2(source, pdf)
    args = [sys.executable, str(observer), str(root), str(pdf), 'content', str(directory / 'observation')]
    result = subprocess.run(args, capture_output=True, text=True, timeout=40, env=env)
    (directory / 'stdout.txt').write_text(result.stdout); (directory / 'stderr.txt').write_text(result.stderr)
    values = dict(line.split('=', 1) for line in (directory / 'observation/result.properties').read_text().splitlines())
    row = {'case': name, 'argv': args, 'input-sha256': sha(pdf), 'observer-sha256': sha(observer),
           'expected': expected, 'expected-rule': rule, 'exit': result.returncode, 'result': values}
    row['matched'] = result.returncode == 0 and values['standards'] == expected and (
        rule is None or values.get('rule') == rule) and values['input-sha256'] == sha(pdf) and values['observer-sha256'] == sha(observer)
    (directory / 'command.json').write_text(json.dumps(row, indent=2) + '\n'); rows.append(row)
    print(name + ' ' + str(row['matched']), flush=True)
(base / 'summary.json').write_text(json.dumps({'observer-sha256': sha(observer), 'rows': rows,
    'all-matched': all(row['matched'] for row in rows)}, indent=2) + '\n')
assert all(row['matched'] for row in rows)
print(base, flush=True)
