#!/usr/bin/env python3
"""Preserve all six superseded r3 raw trees without changing their live originals."""
from datetime import datetime,timezone
import hashlib,importlib.util,json
from pathlib import Path
ROOT=Path('/home/ubuntu/IdeaProjects/open-pdf')
SOURCE=ROOT/'capabilities/evidence/T75-foundation-20260913-r3'
DEST=ROOT/'capabilities/evidence/T75-delivery/final-certification-r3'
OBLIGATIONS=('text','transactions','values','pages','metadata','annotations')
for o in OBLIGATIONS:
    for suffix in ('.tar.xz','-archive-identity.json'):
        assert not (DEST/('historical-raw-'+o+suffix)).exists(),o+suffix
spec=importlib.util.spec_from_file_location('retain',ROOT/'capabilities/evidence/T75-delivery/recorder-r4/retain-programs.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.destination=DEST
receipts=[]
for obligation in OBLIGATIONS:
    src=SOURCE/obligation
    for p in src.rglob('*'):
        assert not p.is_symlink(),p
        if p.is_file():assert p.suffix not in ('.class','.jar','.pyc','.zip'),p
    print(datetime.now(timezone.utc).isoformat(),'Archiving',obligation,flush=True)
    identity=m.archive('historical-raw-'+obligation,src)
    target=DEST/('historical-raw-'+obligation+'-archive-identity.json')
    with target.open('x') as out:out.write(json.dumps(identity,separators=(',',':'))+'\n')
    receipts.append({'obligation':obligation,'archive':identity['archive'],'archive-sha256':identity['sha256'],'archive-bytes':(DEST/identity['archive']).stat().st_size,'members':len(identity['members']),'member-identities':target.name,'member-identities-sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'member-identities-bytes':target.stat().st_size})
    print(datetime.now(timezone.utc).isoformat(),'Retained',receipts[-1],flush=True)
with (DEST/'historical-raw-retention-receipt.json').open('x') as out:
    out.write(json.dumps({'recorded-utc':datetime.now(timezone.utc).isoformat(),'original-root':str(SOURCE),'scope':'All superseded r3 raw originals; each archived member compared byte-for-byte with its still-existing source. Live original files were not removed or changed by this command.','archives':receipts},indent=2)+'\n')
print('All six historical raw trees retained; original live paths remain untouched.',flush=True)
