#!/usr/bin/env python3
"""Preserve the completed serial command and check its final publication snapshot."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile

ROOT=Path('/home/ubuntu/IdeaProjects/open-pdf')
DEST=ROOT/'capabilities/evidence/T75-delivery/final-certification-r3'
LIVE=ROOT/'capabilities/evidence/T75-foundation-20260913-r3'
PREFIX=Path('/tmp/t75-final-certification-refresh-queue-r3')
CANDIDATE='e2dd9ebbeae5668ccc8e2985ccd8af17c8921d1ec5e12e0c913cbd1fa00dfbd6'
CONTRACT='3de508f79fcbef7258feee8abc013d6f02b000840cac1cb263cb0d6f927b8f2b'
OBLIGATIONS=('text','transactions','values','pages','metadata','annotations')
name='completed-queue'
for filename in (name+'.tar.xz',name+'-archive-identity.json',name+'-command.json',name+'-result.json',name+'-command.log',name+'-receipt.json'):
    assert not (DEST/filename).exists(),filename
original=Path(tempfile.mkdtemp(prefix='t75-final-completed-queue-r3-'))
copies=[]
def copy(source,target):
    data=source.read_bytes()
    with (original/target).open('xb') as stream: stream.write(data)
    assert (original/target).read_bytes()==data
    copies.append({'original':str(source),'copy':target,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
    return data
for suffix,target in (('-command.json','command.json'),('-result.json','result.json'),('.log','command.log')):
    copy(Path(str(PREFIX)+suffix),target)
result=json.loads((original/'result.json').read_bytes());assert result['returncode']==0
for source in (Path('/tmp/t75-run-retained.py'),Path('/tmp/t75-certification-refresh-queue-r3.py'),Path(__file__)):
    copy(source,source.name)
authority=json.loads(copy(ROOT/'capabilities/foundation-evidence.yaml','authority-at-completion-retention.yaml'))
counts=Counter(c['obligation'] for c in authority['certifications'])
assert counts=={obligation:8 for obligation in OBLIGATIONS}
results=[]
record_identities=[]
for obligation in OBLIGATIONS:
    observed=json.loads(copy(LIVE/obligation/'observed-index.json',obligation+'-observed-index.json'))
    assert [c for c in authority['certifications'] if c['obligation']==obligation]==observed['certifications']
    actual=json.loads(copy(Path('/tmp/t75-final-'+obligation+'-certify-r3-result.json'),obligation+'-actual-result.json'))
    assert actual['returncode']==0
    results.append({'obligation':obligation,'actual-result':actual})
    for major in (8,11,17,21):
        for execution in ('IN_PROCESS','HARDENED_WORKER'):
            scope=LIVE/obligation/('jdk'+str(major)+'-'+execution.lower())
            for chain in ('syntax','standards','semantic','visual'):
                p=scope/(chain+'.yaml'); data=p.read_bytes(); rec=json.loads(data)
                expected={'obligation':obligation,'execution-profile':execution,'chain':chain,'result':'pass','candidate-sha256':CANDIDATE,'contract-sha256':CONTRACT}
                assert all(rec.get(k)==v for k,v in expected.items()),str(p)
                record_identities.append({'path':str(p.relative_to(ROOT)),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
assert len(record_identities)==192
receipt={'recorded-utc':datetime.now(timezone.utc).isoformat(),'scope':'Completed actual serial queue; text was already running when this queue started. Queue waited for its real exit before five serial refreshes. This does not claim the queue launched text.','actual-queue-result':result,'candidate':CANDIDATE,'contract':CONTRACT,'published-tuples':48,'published-obligation-counts':dict(counts),'every-published-subset-equals-own-observed-index':True,'matching-pass-records':192,'record-identities':record_identities,'actual-certifier-results':results,'copies':copies,'retention-snapshot-scope':'Dated observation after all six actual commands completed; original raw evidence remains at referenced live paths.'}
with (original/'receipt.json').open('x') as out: out.write(json.dumps(receipt,indent=2)+'\n')
for p in original.rglob('*'):
    assert not p.is_symlink(),p
    if p.is_file():
        assert p.suffix not in ('.class','.jar','.pyc','.zip'),p
        assert not p.read_bytes().startswith(b'\x7fELF'),p
spec=importlib.util.spec_from_file_location('retain',ROOT/'capabilities/evidence/T75-delivery/recorder-r4/retain-programs.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);module.destination=DEST
identity=module.archive(name,original)
with (DEST/(name+'-archive-identity.json')).open('x') as out: out.write(json.dumps(identity,indent=2)+'\n')
for source,target in (('command.json','-command.json'),('result.json','-result.json'),('command.log','-command.log'),('receipt.json','-receipt.json')):
    with (DEST/(name+target)).open('xb') as out: out.write((original/source).read_bytes())
    assert (DEST/(name+target)).read_bytes()==(original/source).read_bytes()
with Path('/tmp/t75-final-completed-queue-r3-original-path.txt').open('x') as out: out.write(str(original)+'\n')
print('Actual queue exit 0; all 48 exact published tuples and 192 PASS records; original',original)
