#!/usr/bin/env python3
"""Continue authorized certification serially after the actual text run exits."""
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/home/ubuntu/IdeaProjects/open-pdf')
OUTPUT = ROOT / 'capabilities/evidence/T75-foundation-20260913-r3'
CANDIDATE = 'e2dd9ebbeae5668ccc8e2985ccd8af17c8921d1ec5e12e0c913cbd1fa00dfbd6'
CONTRACT = '3de508f79fcbef7258feee8abc013d6f02b000840cac1cb263cb0d6f927b8f2b'
COUNTS = {'text': 126, 'transactions': 34, 'values': 83, 'pages': 65,
          'metadata': 73, 'annotations': 47}
HELPER = ROOT / '.build-cache/harfbuzz/10.2.0-final/bin/folio-harfbuzz'


def completed(obligation):
    prefix = Path('/tmp/t75-final-' + obligation + '-certify-r3')
    result = json.loads(Path(str(prefix) + '-result.json').read_text())
    if result['returncode'] != 0:
        raise RuntimeError(obligation + ' actual command did not pass')
    directory = OUTPUT / obligation
    observed = json.loads((directory / 'observed-index.json').read_text())
    if len(observed['certifications']) != 8:
        raise RuntimeError(obligation + ' did not publish eight actual tuples')
    for major in (8, 11, 17, 21):
        for execution in ('IN_PROCESS', 'HARDENED_WORKER'):
            scope = directory / ('jdk' + str(major) + '-' + execution.lower())
            tests = (scope / 'contract-tests.txt').read_text()
            if 'OK (' + str(COUNTS[obligation]) + ' tests)' not in tests:
                raise RuntimeError(str(scope) + ' incomplete contract suite')
            for chain in ('syntax', 'standards', 'semantic', 'visual'):
                record = json.loads((scope / (chain + '.yaml')).read_text())
                expected = {'obligation': obligation, 'execution-profile': execution,
                            'chain': chain, 'result': 'pass',
                            'candidate-sha256': CANDIDATE, 'contract-sha256': CONTRACT}
                if any(record.get(key) != value for key, value in expected.items()):
                    raise RuntimeError(str(scope) + ' mismatched chain identity or result')
    print(datetime.now(timezone.utc).isoformat(), obligation,
          'actual exit 0; eight tuples and 32 matching PASS records retained', flush=True)


os.chdir(ROOT)
environment = dict(os.environ)
environment['FOLIO_HARFBUZZ_HELPER'] = str(HELPER)
text_result = Path('/tmp/t75-final-text-certify-r3-result.json')
print('Waiting for the already-running text certification actual result.', flush=True)
while True:
    try:
        json.loads(text_result.read_text())
        break
    except (FileNotFoundError, json.JSONDecodeError):
        time.sleep(5)
completed('text')
for obligation in ('transactions', 'values', 'pages', 'metadata', 'annotations'):
    command = [sys.executable, '/tmp/t75-run-retained.py', '--name',
               '/tmp/t75-final-' + obligation + '-certify-r3', '--',
               sys.executable, 'scripts/t03-foundation.py', 'certify',
               'capabilities/evidence/T75-foundation-20260913-r3/' + obligation,
               '--obligation', obligation]
    print('Starting', obligation, 'on the same staged candidate.', flush=True)
    subprocess.run(command, cwd=ROOT, env=environment, check=True)
    completed(obligation)
print('All six actual certification commands completed successfully.', flush=True)
