#!/usr/bin/env python3
"""Run the final existing inventory commands and explicitly observe all six rows."""
from collections import Counter
from datetime import datetime, timezone
import hashlib, importlib.util, json, os, re, subprocess, tempfile
from pathlib import Path
import yaml
ROOT=Path('/home/ubuntu/IdeaProjects/open-pdf');os.chdir(ROOT)
OBLIGATIONS=('text','transactions','values','pages','metadata','annotations')
result=json.loads(Path('/tmp/t75-final-certification-refresh-queue-r4b-result.json').read_bytes())
assert result['returncode']==0
frozen=json.loads((ROOT/'capabilities/evidence/T75-delivery/final-validation-r4/source-and-contract-inputs.json').read_bytes())
spec=importlib.util.spec_from_file_location('final_inventory_existing_identity_capture',ROOT/'scripts/t03-foundation.py')
foundation=importlib.util.module_from_spec(spec);spec.loader.exec_module(foundation)
contract=yaml.safe_load((ROOT/'capabilities/foundation-release.yaml').read_bytes())
assert foundation.capture_build_inputs(ROOT,contract)==frozen
results=[]
for action in ('generate','validate','check'):
 prefix='/tmp/t75-final-inventory-'+action+'-r4'
 subprocess.run(['python3','-B','/tmp/t75-run-retained.py','--name',prefix,'--','./scripts/inventory',action],cwd=ROOT,check=True)
 actual=json.loads(Path(prefix+'-result.json').read_bytes());assert actual['returncode']==0
 results.append(actual)
assert foundation.capture_build_inputs(ROOT,contract)==frozen
view=ROOT/'docs/generated/foundation-readiness.md';data=view.read_text();rows={}
for obligation in OBLIGATIONS:
 matches=re.findall(r'^\| \[`'+re.escape(obligation)+r'`\].*$',data,re.M)
 assert len(matches)==1,(obligation,len(matches))
 row=matches[0];print(row,flush=True)
 assert row.endswith('| satisfied |'),(obligation,'Required final readiness is not satisfied')
 rows[obligation]=row
authority=json.loads((ROOT/'capabilities/foundation-evidence.yaml').read_bytes())
assert Counter(c['obligation'] for c in authority['certifications'])=={name:8 for name in OBLIGATIONS}
for name in OBLIGATIONS:
 own=json.loads((ROOT/'capabilities/evidence/T75-foundation-20260914-r4'/name/'observed-index.json').read_bytes())
 assert [c for c in authority['certifications'] if c['obligation']==name]==own['certifications']
original=Path(tempfile.mkdtemp(prefix='t75-final-inventory-r4-observed-'))
identities=[]
for src,name in ((view,'foundation-readiness.md'),(ROOT/'capabilities/foundation-evidence.yaml','foundation-evidence.yaml'),(ROOT/'capabilities/evidence/T75-delivery/final-validation-r4/source-and-contract-inputs.json','source-and-contract-inputs.json')):
 raw=src.read_bytes()
 with (original/name).open('xb') as out:out.write(raw)
 assert (original/name).read_bytes()==raw
 identities.append({'original':str(src),'copy':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
receipt={'recorded-utc':datetime.now(timezone.utc).isoformat(),'scope':'Final existing inventory generate, validate and check commands plus explicit all-six satisfied observations; independent final review and Git delivery remain separate.','actual-child-results':results,'source-and-contract-inputs-unchanged':True,'all-six-required-rows-satisfied':rows,'authority-tuples':48,'all-six-authority-subsets-match-own-indexes':True,'copies':identities,'overall-readiness-boundary':'No claim of global Foundation readiness; unrelated obligations may keep the overall result NOT READY.'}
with (original/'receipt.json').open('x') as out:out.write(json.dumps(receipt,indent=2)+'\n')
with Path('/tmp/t75-final-inventory-r4-original-path.txt').open('x') as out:out.write(str(original)+'\n')
print('All three actual inventory commands exited 0; all six required rows satisfied; originals:',original,flush=True)
