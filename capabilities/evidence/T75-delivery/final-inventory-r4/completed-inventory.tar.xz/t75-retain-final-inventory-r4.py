from pathlib import Path
from datetime import datetime, timezone
import hashlib, importlib.util, json, tempfile

root = Path('/home/ubuntu/IdeaProjects/open-pdf')
dest = root / 'capabilities/evidence/T75-delivery/final-inventory-r4'
name = 'completed-inventory'
for suffix in ('.tar.xz', '-archive-identity.json', '-receipt.json'):
    assert not (dest / (name + suffix)).exists(), suffix
observed = Path(Path('/tmp/t75-final-inventory-r4-original-path.txt').read_text().strip())
receipt = json.loads((observed / 'receipt.json').read_bytes())
assert receipt['source-and-contract-inputs-unchanged']
assert receipt['authority-tuples'] == 48 and receipt['all-six-authority-subsets-match-own-indexes']
assert set(receipt['all-six-required-rows-satisfied']) == {'text', 'transactions', 'values', 'pages', 'metadata', 'annotations'}
assert all(row.endswith('| satisfied |') for row in receipt['all-six-required-rows-satisfied'].values())
original = Path(tempfile.mkdtemp(prefix='t75-final-inventory-r4-retained-'))
copies = []
def copy(source, target):
    data = source.read_bytes()
    with (original / target).open('xb') as out:
        out.write(data)
    assert (original / target).read_bytes() == data
    copies.append({'original': str(source), 'copy': target, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})

prefixes = [Path('/tmp/t75-final-inventory-queue-r4')]
prefixes += [Path('/tmp/t75-final-inventory-' + action + '-r4') for action in ('generate', 'validate', 'check')]
for prefix in prefixes:
    actual = json.loads(Path(str(prefix) + '-result.json').read_bytes())
    assert actual['returncode'] == 0, str(prefix)
    for suffix in ('-command.json', '-result.json', '.log'):
        source = Path(str(prefix) + suffix)
        copy(source, source.name)
for source in sorted(observed.iterdir()):
    assert source.is_file() and not source.is_symlink(), source
    copy(source, source.name)
for source in (Path('/tmp/t75-run-retained.py'), Path('/tmp/t75-run-final-inventory-r4.py'), Path(__file__)):
    copy(source, source.name)
retention = {'recorded-utc': datetime.now(timezone.utc).isoformat(), 'scope': 'Completed actual generate, validate and check, with unchanged frozen inputs and explicit all-six satisfied rows. Final independent staged-index review and delivery are separate.', 'actual-queue-returncode': 0, 'actual-child-returncodes': [0, 0, 0], 'observed-original': str(observed), 'copies': copies}
with (original / 'retention-receipt.json').open('x') as out:
    out.write(json.dumps(retention, indent=2) + '\n')
dest.mkdir(exist_ok=True)
spec = importlib.util.spec_from_file_location('retain', root / 'capabilities/evidence/T75-delivery/recorder-r4/retain-programs.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
module.destination = dest
identity = module.archive(name, original)
with (dest / (name + '-archive-identity.json')).open('x') as out:
    out.write(json.dumps(identity, indent=2) + '\n')
for source in sorted(original.iterdir()):
    if source.name.endswith('.json') or source.name.endswith('.log') or source.name == 'foundation-readiness.md':
        target = source.name if source.name != 'receipt.json' else name + '-receipt.json'
        with (dest / target).open('xb') as out:
            out.write(source.read_bytes())
        assert (dest / target).read_bytes() == source.read_bytes()
with Path('/tmp/t75-final-inventory-r4-retained-original-path.txt').open('x') as out:
    out.write(str(original) + '\n')
print(json.dumps({'original': str(original), 'members': len(identity['members']), 'sha256': identity['sha256'], 'actual-queue-returncode': 0, 'all-six-required-rows-satisfied': True}))
