#!/usr/bin/env bash
set -euo pipefail

script_directory=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
repository_root=$(cd -- "${script_directory}/.." && pwd)
podman_command=${PODMAN_COMMAND:-podman}

if ! command -v "${podman_command}" >/dev/null 2>&1; then
    echo "Podman is required to run the local JDK matrix." >&2
    exit 1
fi

native_helper=${FOLIO_HARFBUZZ_HELPER:-}
if [[ "${native_helper}" != /* || ! -x "${native_helper}" ]]; then
    echo "Set FOLIO_HARFBUZZ_HELPER to the absolute bin/folio-harfbuzz path from scripts/install-harfbuzz.py." >&2
    exit 2
fi
native_installation=$(cd -- "$(dirname -- "${native_helper}")/.." && pwd)
if [[ ! -f "${native_installation}/installation.json" \
        || ! "${native_installation}/bin/folio-harfbuzz" -ef "${native_helper}" ]]; then
    echo "The JDK matrix requires the complete explicit native installation directory." >&2
    exit 2
fi

if (( $# == 0 )); then
    jdk_versions=(8 11 17 21)
else
    jdk_versions=("$@")
fi

mkdir -p "${repository_root}/.build-cache/maven/repository"

# The Foundation authority pins both the Ubuntu release and the actual JDK build.
# A floating *-jdk tag can move to another OS release without changing its name.
environment_listing=$("${repository_root}/scripts/inventory" environments)

for jdk_version in "${jdk_versions[@]}"; do
    case "${jdk_version}" in
        8|11|17|21) ;;
        *)
            echo "Unsupported matrix JDK: ${jdk_version}" >&2
            exit 2
            ;;
    esac

    image=
    while read -r marker profile_jdk profile_image remainder; do
        if [[ "${marker}" == FOUNDATION_ENVIRONMENT && "${profile_jdk}" == "${jdk_version}" ]]; then
            image=${profile_image}
        fi
    done <<< "${environment_listing}"
    if [[ "${image}" != *@sha256:* ]]; then
        echo "No immutable Foundation environment is declared for JDK ${jdk_version}." >&2
        exit 2
    fi
    echo "==> Verifying Folio PDF on JDK ${jdk_version} (${image})"
    "${podman_command}" run --rm \
        --userns=keep-id \
        --volume "${repository_root}:/workspace:Z" \
        --volume "${native_installation}:/folio-harfbuzz:ro,Z" \
        --workdir /workspace \
        --env MAVEN_USER_HOME=/workspace/.build-cache/maven \
        --env FOLIO_HARFBUZZ_HELPER=/folio-harfbuzz/bin/folio-harfbuzz \
        "${image}" \
        sh -c 'PATH=/workspace/scripts/container-bin:"${PATH}"; export PATH; exec ./mvnw "$@"' \
        folio-pdf-matrix \
        -B -ntp \
        -Dmaven.repo.local=/workspace/.build-cache/maven/repository \
        verify
done
