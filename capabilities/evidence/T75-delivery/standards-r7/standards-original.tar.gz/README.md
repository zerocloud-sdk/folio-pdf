# Incremental independent Standards review

This is bounded probe evidence for the font increment since standards-r6, not full T13 qualification.

Authoring uses only Python standard-library byte operations on the repository-owned original font/PDF. It imports neither observer internals nor corpus generator functions. The initial authoring attempt asserted a single UTF-16 byte substring but the original shares/prefixes name storage; it stopped before running any CLI. The retained probe corrects that mistake by selecting the explicit Windows nameID 6 record. No invalid initial result is used as evidence.

The corrected independent probe alters only the Windows (platform 3, encoding 1, language 0x409) PostScript name record, then recomputes every table checksum and head.checkSumAdjustment. The qpdf-decoded FontFile2 object 23 confirms Macintosh ID6 = FolioT13Rectangle and Windows ID6 = FolioT13RectanglX. The new observer returns PASS. Apple TrueType name table states that all PostScript names in a font must be identical; OpenType recommendations likewise require the Macintosh/Windows pair to match.

Sources:
- https://developer.apple.com/fonts/TrueType-Reference-Manual/RM06/Chap6name.html (name ID 6)
- https://learn.microsoft.com/en-us/typography/opentype/spec/recom (name table)
- docs/t13-certification.md (undetected controls cannot pass)

All five actual CLI results, complete commands, input/checker/qpdf identities and timings are in results.json. Original and shared valid descriptor controls pass; changed second descriptor fails font-program-name; valid but unsupported vlineto is indeterminate. Every invocation returned 0 and retained result.properties, raw qpdf.json and stdout/stderr.

Reproduce the name finding with a fresh output path:

```
python3 /home/ubuntu/IdeaProjects/open-pdf/scripts/t13-program-standards.py /home/ubuntu/IdeaProjects/open-pdf /tmp/t75-font-outline-name-review-tl0gh21j/conflicting-platform-postscript-names.pdf fonts /tmp/t75-font-names-fresh-output
```

To re-author and rerun all variants, copy probe.py into a fresh directory and run it there. No product or shared target edits were made, and no Maven command was run.
