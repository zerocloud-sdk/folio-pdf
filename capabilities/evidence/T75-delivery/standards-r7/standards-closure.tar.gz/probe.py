from pathlib import Path
import hashlib,json,re,struct,subprocess,sys,time
ROOT=Path('/home/ubuntu/IdeaProjects/open-pdf')
HERE=Path(__file__).resolve().parent
SCRIPT=ROOT/'scripts/t13-program-standards.py'
SOURCE=ROOT/'capabilities/profiles/T13-text/fixtures/embedded-font-kinds.pdf'
ORIGINAL=SOURCE.read_bytes()
FONT=(ROOT/'capabilities/profiles/T13-fonts/FolioT13Rectangle.ttf').read_bytes()
CFF=(ROOT/'capabilities/profiles/T13-fonts/FolioT13Rectangle.cff').read_bytes()
OBSERVER_SHA=hashlib.sha256(SCRIPT.read_bytes()).hexdigest()

def checksum(data):
    return sum(x[0] for x in struct.iter_unpack('>I',data+b'\0'*(-len(data)%4)))&0xffffffff

def fixed_checksums(data):
    result=bytearray(data)
    entries=[]
    for i in range(int.from_bytes(result[4:6],'big')):
        location=12+16*i
        tag,old,start,length=struct.unpack_from('>4sIII',result,location)
        entries.append((location,tag,start,length))
        if tag==b'head': head=start
    result[head+8:head+12]=b'\0'*4
    for location,tag,start,length in entries:
        struct.pack_into('>I',result,location+4,checksum(result[start:start+length]))
    struct.pack_into('>I',result,head+8,(0xb1b0afba-checksum(result))&0xffffffff)
    assert checksum(result)==0xb1b0afba
    return bytes(result)

def serialize(objects):
    result=bytearray(b'%PDF-2.0\n')
    offsets=[0]
    for n,body in enumerate(objects,1):
        offsets.append(len(result))
        result.extend(str(n).encode()+b' 0 obj\n'+body+b'\nendobj\n')
    xref=len(result)
    result.extend(b'xref\n0 '+str(len(offsets)).encode()+b'\n0000000000 65535 f \n')
    for offset in offsets[1:]: result.extend(('%010d 00000 n \n'%offset).encode())
    result.extend(b'trailer\n<< /Size '+str(len(offsets)).encode()+b' /Root 1 0 R >>\nstartxref\n'+str(xref).encode()+b'\n%%EOF\n')
    return bytes(result)

def names_conflict():
    data=bytearray(FONT)
    windows='FolioT13Rectangle'.encode('utf-16-be')
    at=None
    for i in range(int.from_bytes(data[4:6],'big')):
        tag,check,start,length=struct.unpack_from('>4sIII',data,12+16*i)
        if tag!=b'name': continue
        fmt,count,strings=struct.unpack_from('>3H',data,start)
        for j in range(count):
            platform,encoding,language,nid,size,offset=struct.unpack_from('>6H',data,start+6+12*j)
            if (platform,encoding,language,nid)==(3,1,0x409,6):
                assert at is None and size==len(windows)
                at=start+strings+offset
    assert at is not None and data[at:at+len(windows)]==windows
    data[at+len(windows)-1]=ord('X')
    changed=fixed_checksums(data)
    assert len(changed)==len(FONT)
    return ORIGINAL.replace(FONT.hex().encode(),changed.hex().encode())

def shared_descriptor(bad):
    matches=re.findall(rb'(?m)^([0-9]+) 0 obj\n(.*?)\nendobj\n',ORIGINAL,re.S)
    assert [int(n) for n,b in matches]==list(range(1,26))
    objects=[b for n,b in matches]
    assert objects[5].count(b'/FontDescriptor 12 0 R')==1
    objects[5]=objects[5].replace(b'/FontDescriptor 12 0 R',b'/FontDescriptor 26 0 R')
    descriptor=objects[11]
    if bad:
        descriptor=descriptor.replace(b'/FontName /FolioT13RectangleCFF',b'/FontName /DifferentFont')
        objects[5]=objects[5].replace(b'/BaseFont /FolioT13RectangleCFF',b'/BaseFont /DifferentFont')
    objects.append(descriptor)
    return serialize(objects)

def unqualified_operator():
    glyph=bytes.fromhex('f8888b16f824f8ecfc24060e')
    assert CFF.count(glyph)==1
    changed=CFF.replace(glyph,glyph[:-2]+b'\x07'+glyph[-1:])
    return ORIGINAL.replace(CFF.hex().encode(),changed.hex().encode())

variants=[('original',ORIGINAL),('shared-program-valid',shared_descriptor(False)),
          ('shared-program-wrong-second-name',shared_descriptor(True)),
          ('conflicting-platform-postscript-names',names_conflict()),
          ('unsupported-valid-vlineto',unqualified_operator())]
records=[]
for label,data in variants:
    pdf=HERE/(label+'.pdf');pdf.write_bytes(data)
    output=HERE/label
    start=time.monotonic()
    command=[sys.executable,str(SCRIPT),str(ROOT),str(pdf),'fonts',str(output)]
    proc=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=40)
    (HERE/(label+'.stdout')).write_bytes(proc.stdout)
    (HERE/(label+'.stderr')).write_bytes(proc.stderr)
    props=output/'result.properties'
    observed=dict(line.split('=',1) for line in props.read_text().splitlines()) if props.exists() else None
    if observed:
        assert observed['input-sha256']==hashlib.sha256(data).hexdigest()
        assert observed['observer-sha256']==OBSERVER_SHA
        assert observed['qpdf-json-sha256']==hashlib.sha256((output/'qpdf.json').read_bytes()).hexdigest()
    record=dict(label=label,command=command,exit=proc.returncode,elapsed=round(time.monotonic()-start,3),result=observed)
    records.append(record)
    print(json.dumps(record),flush=True)
assert OBSERVER_SHA==hashlib.sha256(SCRIPT.read_bytes()).hexdigest()
(HERE/'results.json').write_text(json.dumps(records,indent=2)+'\n')
