print('profile=T13-text-logical-structure\nstandards=pass')
