# Program recorder incremental Standards review

Review scope: the new program-standards recorder in frozen snapshot `/tmp/t75-recorder-publication-closure-snapshot.nx040d50`, against overall baseline `5b1603c435f11c40368f75b7b9a2777c9c5e9761`. This is not final #75 or full PDF certification. No Native implementation was consulted as an oracle. No Maven, product changes, whole class trees, or ELF copies. Every run uses the frozen classpath; every staged observer is copied from the frozen source (22c7aa62e8719bc586b2da6ca52fd51e9a16b750cda5545bddfc19b42ad76618). True qpdf/runtime/fontTools paths are read-only references with hashes.

## Actual observations

15 public Java CLI executions: one normal PASS42/165; one known illegal CMap candidate FAIL42/165; thirteen mismatch controls INDETERMINATE with zero qualified rules. The ten ordinary failure controls cover missing/substituted observer, changed whole profile/runtime manifest, missing real qpdf installation/control, late observer change, replaced staged PDF, late retained raw qpdf report change, and a missing already-used negative PDF. The latter two ran all 165 controls before aggregate verification rejected the retained artifacts. The other three controls expose the single publication boundary finding below.

The normal candidate passed all eight scopes. Every one of the 165 controls has its fixed PDF hash, expected scope and failed rule. Its manifest contains 1207 entries; every expected digest and the exact 42-rule union were independently verified (`genuine-manifest-validation.json`). All 1087 frozen source/class/jar identities and fourteen true tool/runtime files match before/after. `all-observations.json` and per-case JSON bind commands, cwd, input hashes, mutations, root identities, and outputs. Raw stdout, stderr, producer receipts, qpdf JSON and complete output directories remain retained.

## Hard finding: producer publication follows links

Frozen `t13-program-standards.py:1642-1644` records a digest and uses `(output / name).write_bytes(data)`. Preplanting `input/cmaps/qpdf.json` or `result.properties` symlinks causes real Java CLI runs to overwrite a reviewer-owned target outside the output directory with 7649 or 823 bytes respectively. Replacing the freshly created scope directory with a symlink also writes all five raw artifacts outside the output directory. Original marker bytes, event timing, target hashes and complete reports are retained in the three `raw-*-symlink` cases. Java later rejects each case as INDETERMINATE0, so these are **not false-PASS observations**; the external writes have already occurred.

This violates the frozen contract (`t13-certification.md:461-467`) that producer bytes bind retained files and final publication refuses existing files and symbolic links. The parent accepted the finding and is repairing the live implementation; that new implementation is not reviewed in this archive.

## Judgement call

Possible Duplicated Code: `T13DeclarationStandards.java:105-108` and `T13ProgramStandards.java:115-118` repeat the same manifest/write/optional-verify/hash-binding sequence. The synchronized fix makes a package-local RetainedEvidence publication helper a concrete small refactor; the callers can continue to own their verdict and coverage decisions. This is a heuristic, not a documented hard violation. Parent accepted it for the next snapshot.

Repository standards applied: CONTRIBUTING clean-room provenance and independent public evidence seam, CONTEXT Acceptance Evidence, ADR-0029/0035/0040, and the frozen bounded recorder contract. No pending unrelated PDF qualification work is reported as an implementation defect. Historical publication closure evidence is `/tmp/t75-final-publication-standards-closure-im7abh1b` and remains separate.
