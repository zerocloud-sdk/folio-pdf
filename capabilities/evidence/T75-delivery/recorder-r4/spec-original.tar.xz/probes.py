from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time
B=Path(__file__).resolve().parent;SEED=B/'seed-root';CP=(B/'classpath.txt').read_text().strip()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def props(p):return dict(l.split('=',1) for l in Path(p).read_text().splitlines() if '=' in l and not l.startswith('#'))
def manifest(root):return {str(p.relative_to(root)):({'link':str(p.readlink())} if p.is_symlink() else {'sha256':sha(p)}) for p in root.rglob('*') if p.is_symlink() or p.is_file()}
def run(name,mode='none',source='marked-structure'):
 c=B/name;c.mkdir();root=c/'root';shutil.copytree(SEED,root,symlinks=True);inp=c/'input.pdf';shutil.copy2(B/'inputs'/f'{source}.pdf',inp);shutil.copy2(inp,c/'input-original.pdf');o=c/'out'
 pfile=root/'capabilities/profiles/T13-standards/program-qualification.properties';p=props(pfile);prefix='negative.cmaps.cmap-block-count.';control=(pfile.parent/p[prefix+'path']).resolve()
 mutation={};before=sha(inp)
 def change(path,data=None):
  mutation['path']=str(path);mutation['before_sha256']=sha(path) if path.is_file() else None
  if path.is_file():shutil.copy2(path,c/'changed-file-original')
  if data is None:path.unlink()
  else:path.write_bytes(data)
  mutation['after_sha256']=sha(path) if path.is_file() else None
 if mode=='profile-rules':change(pfile,pfile.read_bytes().replace(b'fonts.font-program-units,',b''))
 elif mode=='missing-control':change(control)
 elif mode=='changed-control':change(control,inp.read_bytes())
 elif mode=='spoof-observer':change(root/'scripts/t13-program-standards.py',b"print('profile=T13-text-logical-structure\\nstandards=pass\\nproducer=qualified')\n")
 elif mode=='missing-qpdf':(root/'.build-cache/qpdf').unlink();mutation['removed_link']='.build-cache/qpdf'
 elif mode=='changed-wrapper':
  f=root/'scripts/container-bin/qpdf';change(f,f.read_bytes()+b'\n# retained real version; altered tool bytes\n')
 elif mode=='missing-wheel':(root/'.build-cache/t75-fonttools-4.59.2').unlink();mutation['removed_link']='.build-cache/t75-fonttools-4.59.2'
 (c/'root-identities-before.json').write_text(json.dumps(manifest(root),indent=2)+'\n')
 env=os.environ.copy();env.pop('QPDF_CACHE_DIRECTORY',None)
 argv=['java','-cp',CP,'net.zerocloud.pdf.acceptance.T13EvidenceCommand','program-standards',str(root),str(inp),str(o)]
 (c/'argv.json').write_text(json.dumps(argv,indent=2)+'\n');(c/'environment.json').write_text(json.dumps({'QPDF_CACHE_DIRECTORY':'unset','java_classpath_sha256':sha(B/'classpath.txt')},indent=2)+'\n')
 t=time.monotonic();proc=subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env)
 if mode.startswith('late-') or mode.startswith('link-'):
  trigger=o/'input' if mode=='link-output-dir' else o/'input/cmaps' if mode.startswith('link-') else o/'input/content'
  while not trigger.is_dir():
   if proc.poll() is not None:raise RuntimeError('No trigger before exit')
   if time.monotonic()-t>90:raise RuntimeError('No trigger')
   time.sleep(.0005)
  mutation['trigger']=str(trigger)
  if mode=='link-output-dir':
   external=c/'external-scope';file=o/'input/cmaps';file.symlink_to(external,target_is_directory=True);mutation['path']=str(file);mutation['outside_directory']=str(external);mutation['outside_existed_before']=external.exists()
  elif mode=='link-hard-json':
   outside=c/'outside-original.txt';outside.write_bytes(b'Independent external original bytes; do not overwrite.\n');file=o/'input/cmaps/qpdf.json';os.link(outside,file);mutation['path']=str(file);mutation['outside']=str(outside);mutation['outside_before_sha256']=sha(outside);mutation['inode']=outside.stat().st_ino
  elif mode in ['link-qpdf-json','link-producer-report']:
   file=o/'input/cmaps'/('qpdf.json' if mode=='link-qpdf-json' else 'result.properties');file.symlink_to(inp);mutation['path']=str(file);mutation['target']=str(inp);mutation['target_before_sha256']=before
  elif mode=='late-report':
   f=o/'input/cmaps/result.properties';change(f,f.read_bytes()+b'producer=qualified\n')
  elif mode=='late-qpdf-json':change(o/'input/cmaps/qpdf.json',b'{}\n')
  elif mode=='late-original-input':change(inp,inp.read_bytes()+b'\n% original source changed after first observation\n')
  elif mode=='late-control-source':change(control,inp.read_bytes())
  elif mode=='late-observer':
   f=root/'scripts/t13-program-standards.py';change(f,f.read_bytes()+b'\n# observer identity changed after first observation\n')
 stdout,stderr=proc.communicate(timeout=420);(c/'stdout.txt').write_bytes(stdout);(c/'stderr.txt').write_bytes(stderr)
 r=props(o/'result.properties') if (o/'result.properties').is_file() and not (o/'result.properties').is_symlink() else {}
 if 'outside' in mutation:mutation['outside_after_sha256']=sha(mutation['outside']);mutation['outside_unchanged']=mutation['outside_before_sha256']==mutation['outside_after_sha256']
 if 'outside_directory' in mutation:mutation['outside_files_after']=manifest(Path(mutation['outside_directory'])) if Path(mutation['outside_directory']).is_dir() else {}
 result={'name':name,'mode':mode,'source':source,'exit':proc.returncode,'seconds':time.monotonic()-t,'input_before_sha256':before,'input_after_sha256':sha(inp),'input_unchanged':before==sha(inp),'mutation':mutation,'result':r,'verdict':r.get('program-standards'),'rules':r.get('qualified-rule-count'),'controls':r.get('negative-control-count')}
 (c/'run.json').write_text(json.dumps(result,indent=2)+'\n');(c/'root-identities-after.json').write_text(json.dumps(manifest(root),indent=2)+'\n');(c/'output-identities.json').write_text(json.dumps(manifest(o),indent=2)+'\n')
 print(json.dumps({k:result[k] for k in ['name','mode','exit','seconds','verdict','rules','controls','input_unchanged']}),flush=True)
if __name__=='__main__':run(*sys.argv[1:])
