# Bounded program-recorder Spec review

One P1 publication finding; no new rule/receipt binding finding. Not the final #75 gate, and no PDF predicates were re-reviewed.

Frozen t13-program-standards.py:1642–1644 still uses Path.write_bytes. Two actual Java CLI probes preseed qpdf.json or the producer result.properties as a symlink to the caller input: each overwrites that PDF before final INDETERMINATE/0/0. A hardlinked qpdf.json overwrites an independent outside file and the aggregate still returns PASS/42/165. A scope-directory link is followed by main's output.resolve() (line 1753), producing five files outside the requested output before rejection. These four variants violate frozen contract lines 461–467, particularly “final file publication refuses existing files and symbolic links”. Exclusive publication must apply to the Python producer and checks must retain the original output spelling before resolving links.

17 actual CLI calls retained: 2 PASS (normal baseline plus the hardlink defect) and 15 INDETERMINATE. Normal baseline actually runs all 8 scopes and 165 fixed controls, with each control failing on its exact declared rule; union exactly 42. Its 1207-file manifest has no missing, duplicate or mismatched entry. Initial missing/changed rule profile, controls, tool/wrapper, wheel, fake producer and later observer/control changes all reject. Original Source and retained JSON/report changes also cannot pass.

All 1,087 frozen source/class/JAR entries and the isolated seed root are unchanged. No classes or ELF binaries were copied. Every argv, original input, changed input, control, producer report, manifest, private-root identity and exact source identity is retained/referenced here. The hardlink's original sentinel literal is reconstructed from the recorded probe and matches its contemporaneous pre-change digest.

Separate declaration final-publication closure is CLEAN: 5/5 actual observations, three final symlink names rejected without outside changes, normal PASS/334 and missing retained control IND/0. Its distinct report is /tmp/t75-spec-publication-closure.c2xv1l06/assessment.json. Previous reports remain unchanged.
