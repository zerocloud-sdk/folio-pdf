# Program producer publication Standards closure

Incremental #75 only; fixed baseline 5b1603c435f11c40368f75b7b9a2777c9c5e9761. The complete source/class snapshot is externally referenced at /tmp/t75-program-publication-closure-snapshot.jsm71bxq. Every actual CLI uses that frozen classpath and a private staged copy of observer SHA653633a52a8ff973914af14495fc2a9fd9dc989ccec9da94064fcd8a2e430766. No live observer is executed; no Maven, product modifications, class-tree or ELF copies. True qpdf/runtime/wheel resources are read-only referenced and hashed.

## Closed findings

The original producer problem is closed for the five direct public controls: qpdf.json symlink to the independent input; result.properties symlink to an unrelated marker; qpdf.json hardlink to the independent input; a preplanted scope directory link; and replacement of the running scope directory with a link. All five Java invocations return INDETERMINATE0, and target/input bytes and external directory entries remain unchanged. The new Python writer uses exclusive creation and checks output ancestors; it retains private bounded qpdf descriptors.

The manifest Duplicated Code judgement is closed. Both Java callers now use the package-local RetainedEvidence.publishManifest helper, while retaining their verdict/coverage decisions. Actual program PASS42/165 and declaration PASS334 have 1207 and 686 manifest entries respectively; all hashes match. A preplanted final declaration manifest symlink is rejected with nonzero exit and its external target remains empty. Late replacement of an already-consumed qpdf.json and deletion of an already-used negative PDF both run all 165 controls but finish INDETERMINATE with zero qualified rules.

## One adjacent hard finding remains in this snapshot

Replacing output/input with a directory symlink after Java creates it causes Python to reject the path before producing raw reports. However T13ProgramStandards.java:123 then creates the absent child output directory, and :125 writes its process.txt through that linked parent. RetainedEvidence.java:65-68 checks only the local root input/cmaps and descendants, missing the linked parent input.

The real public CLI case running-input-ancestor-symlink leaves the input PDF and existing external marker unchanged but creates external cmaps/process.txt (its bytes show Python correctly rejected the path). The result is INDETERMINATE0, **not a false PASS**. The external directory before/after inventories, exact command, timing, raw stderr, and process report are preserved. This is the same documented no-link publication boundary in frozen t13-certification.md:461-467; validation must precede child-directory creation as well as file writing. The parent accepted the finding and will supply a new snapshot; that fix is not reviewed here.

## Counts and identities

Eleven real Java CLI invocations: nine program runs (one PASS42/165, eight INDETERMINATE0) and two declaration runs (PASS334, rejected final publication). All 1088 frozen source/class/jar identities and fourteen true tool/runtime identities match before/after. Full commands, input bytes, stdout/stderr, producer receipts, manifests, and resource inventories are retained. No new actionable smell beyond the closed manifest duplication was identified. This is neither full PDF conformance nor the final #75 gate.
