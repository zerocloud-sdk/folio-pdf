# Program publication closure — bounded Spec review

Original four cases closed; one adjacent Java publication gap remains. This is not the final #75 gate.

All original file-symlink, hardlink and scope-directory-symlink probes now return INDETERMINATE/0/0, preserving the input and external targets. Replacing the scope directory itself after qpdf version publication also leaves the external directory unchanged.

However, replacing the scope's parent out/input with a link (before the Python scope starts, or after its qpdf-version.txt is published) makes Python correctly reject, then Java T13ProgramStandards.java:123–125 creates the missing scope directory and writes cmaps/process.txt externally. RetainedEvidence.java:65–68 stops ancestor checking at its per-scope root, omitting the linked parent. Both actual public CLI calls finish IND/0/0 but have the forbidden side effect. Validate the full path before fallback directory creation and failure-report publication.

11 actual CLI invocations: 1 PASS, 10 INDETERMINATE. Nine complete outcomes match; two reveal this one remaining P1 boundary. The positive runs all 8 scopes, 165 exact-rule negative controls and 42 unique rules, with its 1207 manifest entries verified. Late retained-report, retained-JSON and Source changes all reject without qualified coverage.

All 1088 frozen source/class/JAR identities and the read-only seed root match before and after. No classes or ELF copied. Commands, original inputs, outputs, displaced directories, external markers/process files, identities, source references and raw runs are retained here. Prior review reports remain unchanged.
