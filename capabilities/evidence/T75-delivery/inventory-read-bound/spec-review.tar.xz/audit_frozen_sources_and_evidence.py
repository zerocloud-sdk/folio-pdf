#!/usr/bin/env python3
"""Independent, read-only source/evidence audit; writes only this review packet."""
import collections
import hashlib
import json
import pathlib
import re
import xml.etree.ElementTree as ET
import yaml

OUT = pathlib.Path(__file__).resolve().parent
REPO = pathlib.Path('/home/ubuntu/IdeaProjects/open-pdf')
FROZEN = pathlib.Path('/tmp/t75-inventory-read-bound-review-freeze-j1zhjsip')
ORIGINAL = pathlib.Path('/tmp/t75-inventory-read-bound-r3-original-pxr5ql8l')

def sha(data):
    return hashlib.sha256(data).hexdigest()

def write_json(name, value):
    with (OUT / name).open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')

snapshots = []
for root, label in [(FROZEN, 'frozen'), (ORIGINAL, 'original')]:
    for source in sorted(root.rglob('*')):
        if not source.is_file():
            continue
        data = source.read_bytes()
        relative = pathlib.Path('snapshots') / label / source.relative_to(root)
        target = OUT / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as stream:
            stream.write(data)
        assert target.read_bytes() == data
        snapshots.append({'original':str(source), 'copy':str(relative), 'bytes':len(data), 'sha256':sha(data)})
write_json('snapshotted-original-inputs.json', snapshots)

deltas = json.loads((FROZEN / 'five-file-source-delta.json').read_text())
frozen_identity = []
for item in deltas:
    path = item['path']
    old = (FROZEN / 'before' / path).read_bytes()
    frozen = (FROZEN / 'source' / path).read_bytes()
    live = (REPO / path).read_bytes()
    assert sha(old) == item['r3-sha256'], path
    assert sha(frozen) == item['current-sha256'], path
    assert frozen == live, path
    assert len(live) == item['bytes'], path
    frozen_identity.append({'path':path, 'before_sha256':sha(old), 'frozen_and_live_sha256':sha(live), 'bytes':len(live)})
write_json('five-file-source-identity-audit.json', frozen_identity)

loader = getattr(yaml, 'CSafeLoader', yaml.SafeLoader)
evidence_path = ORIGINAL / 'capabilities/foundation-evidence.yaml'
evidence = yaml.load(evidence_path.read_text(), Loader=loader)
source_changes = []
for item in evidence['candidate']['inputs']:
    path = item['path']
    live_sha = sha((REPO / path).read_bytes())
    if live_sha != item['sha256']:
        source_changes.append({'path':path, 'r3_sha256':item['sha256'], 'live_sha256':live_sha})
assert {item['path'] for item in source_changes} == {item['path'] for item in deltas}
write_json('r3-candidate-input-change-audit.json', source_changes)

rows = []
standard_records = []
for certification in evidence['certifications']:
    for ref in certification['records']:
        path = REPO / ref['path']
        data = path.read_bytes()
        assert sha(data) == ref['sha256'], ref['path']
        parsed = yaml.load(data, Loader=loader)
        row = {'path':ref['path'], 'bytes':len(data), 'sha256':sha(data),
               'obligation':certification['obligation'], 'environment':certification['environment'],
               'execution_profile':certification['execution-profile'], 'chain':parsed['chain'],
               'result':parsed['result'], 'negative_control_count':len(parsed['negative-controls'])}
        rows.append(row)
        if certification['obligation'] == 'text' and parsed['chain'] == 'standards':
            assert 3_000_000 < len(data) <= 16 * 1024 * 1024, ref['path']
            assert len(data.decode('utf-8')) > 3_000_000, ref['path']
            standard_records.append(row)
assert len(evidence['certifications']) == 48
assert len(rows) == 192
assert len(standard_records) == 8
assert all(row['result'] == 'pass' for row in rows)
write_json('real-chain-record-identities-and-sizes.json', rows)
write_json('eight-real-text-standards-records.json', standard_records)

commands = []
for result_file in sorted(ORIGINAL.rglob('*-result.json')):
    result = json.loads(result_file.read_text())
    command_file = result_file.with_name(result_file.name.replace('-result.json','-command.json'))
    commands.append({'relative_path':str(result_file.relative_to(ORIGINAL)), 'result':result,
                     'command':json.loads(command_file.read_text()) if command_file.exists() else None})
write_json('original-process-receipts-audit.json', commands)

suites = []
for xml in sorted((ORIGINAL/'complete-inventory-module-verify').glob('TEST-*.xml')):
    root = ET.parse(xml).getroot()
    suites.append({key:root.attrib[key] for key in ['name','tests','failures','errors','skipped','time']})
assert sum(int(suite['tests']) for suite in suites) == 17
assert all(int(suite[key]) == 0 for suite in suites for key in ['failures','errors','skipped'])
write_json('complete-module-xml-audit.json', suites)

post = (ORIGINAL/'actual-records-read-after-fix/foundation-readiness.md').read_text()
pre = (ORIGINAL/'docs/generated/foundation-readiness.md').read_text()
prefix = '- Blocker: '
errors = sorted(set(line[len(prefix):] for line in post.splitlines() if line.startswith(prefix) and 'stale or mismatched artifact identity' in line))
expected = sorted('stale or mismatched artifact identity ' + item['path'] for item in deltas)
assert errors == expected, errors
assert 'cannot read YAML' not in post
original_yaml_errors = sorted(set(line for line in pre.splitlines() if 'cannot read YAML' in line))
assert len(original_yaml_errors) == 8
summary = {'snapshotted_files':len(snapshots), 'frozen_and_live_identities_match':True,
           'changed_r3_candidate_inputs':len(source_changes), 'r3_candidate_input_count':len(evidence['candidate']['inputs']),
           'historical_r3_tuple_count':len(evidence['certifications']), 'historical_r3_chain_count':len(rows),
           'historical_r3_chain_results':dict(collections.Counter(row['result'] for row in rows)),
           'text_standards_records':standard_records, 'original_unique_yaml_errors':len(original_yaml_errors),
           'postfix_unique_yaml_errors':0, 'postfix_stale_source_errors':errors, 'module_suites':suites,
           'scope':'Identity/size/retention audit of historical r3 observations; not recertification or final candidate approval.'}
write_json('audit-summary.json', summary)
print(json.dumps(summary,indent=2))
