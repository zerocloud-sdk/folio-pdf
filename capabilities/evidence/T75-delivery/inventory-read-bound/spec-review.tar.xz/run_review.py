#!/usr/bin/env python3
"""Retain each original read-only review command and its complete outputs."""
import datetime
import hashlib
import json
import pathlib
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parent
label = sys.argv[1]
argv = sys.argv[2:]
if not label or '/' in label or not argv:
    raise SystemExit('usage: run_review.py LABEL COMMAND [ARG...]')
prefix = ROOT / label
command_file = prefix.with_suffix('.command.json')
with command_file.open('x') as handle:
    json.dump({'argv': argv, 'cwd': '/home/ubuntu/IdeaProjects/open-pdf'}, handle, indent=2)
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
completed = subprocess.run(argv, cwd='/home/ubuntu/IdeaProjects/open-pdf', stdout=subprocess.PIPE, stderr=subprocess.PIPE)
ended = datetime.datetime.now(datetime.timezone.utc).isoformat()
for suffix, data in [('.stdout', completed.stdout), ('.stderr', completed.stderr)]:
    with prefix.with_suffix(suffix).open('xb') as handle:
        handle.write(data)
with prefix.with_suffix('.result.json').open('x') as handle:
    json.dump({'started_utc': started, 'ended_utc': ended, 'returncode': completed.returncode,
               'stdout_bytes': len(completed.stdout), 'stderr_bytes': len(completed.stderr),
               'stdout_sha256': hashlib.sha256(completed.stdout).hexdigest(),
               'stderr_sha256': hashlib.sha256(completed.stderr).hexdigest()}, handle, indent=2)
sys.stdout.buffer.write(completed.stdout)
sys.stderr.buffer.write(completed.stderr)
print('\n[retained exit status: %s]' % completed.returncode)
raise SystemExit(completed.returncode)
