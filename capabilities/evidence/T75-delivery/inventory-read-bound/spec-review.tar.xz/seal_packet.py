#!/usr/bin/env python3
"""Seal all original review material, excluding only the manifest itself."""
import datetime
import hashlib
import json
from pathlib import Path
import sys

root = Path(__file__).resolve().parent
prefix = root/'036-seal'
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
with prefix.with_suffix('.command.json').open('x') as stream:
    json.dump({'argv':[sys.executable,str(Path(__file__).resolve())],
               'cwd':str(Path.cwd())},stream,indent=2)
report = root/'report.md'
receipt = root/'receipt.md'
assert len(report.read_text().split()) < 400
snapshots = json.loads((root/'snapshotted-original-inputs.json').read_text())
for row in snapshots:
    data = (root/row['copy']).read_bytes()
    assert len(data) == row['bytes']
    assert hashlib.sha256(data).hexdigest() == row['sha256']
output = json.dumps({'report':str(report),'report_sha256':hashlib.sha256(report.read_bytes()).hexdigest(),
                    'receipt':str(receipt),'receipt_sha256':hashlib.sha256(receipt.read_bytes()).hexdigest(),
                    'report_words':len(report.read_text().split()),'verified_snapshot_files':len(snapshots)},indent=2)+'\n'
with prefix.with_suffix('.stdout').open('x') as stream:
    stream.write(output)
with prefix.with_suffix('.stderr').open('x') as stream:
    pass
with prefix.with_suffix('.result.json').open('x') as stream:
    json.dump({'started_utc':started,'ended_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
               'returncode':0,'stdout_sha256':hashlib.sha256(output.encode()).hexdigest(),
               'stderr_sha256':hashlib.sha256(b'').hexdigest()},stream,indent=2)
files=[]
for path in sorted(root.rglob('*')):
    if path.is_file() and path.name != 'file-sha256-manifest.json':
        assert not path.is_symlink()
        data=path.read_bytes()
        files.append({'path':str(path.relative_to(root)),'bytes':len(data),
                      'sha256':hashlib.sha256(data).hexdigest()})
manifest=root/'file-sha256-manifest.json'
with manifest.open('x') as stream:
    json.dump({'schema-version':1,'excluded':['file-sha256-manifest.json'],'file-count':len(files),'files':files},stream,indent=2)
    stream.write('\n')
for row in files:
    assert hashlib.sha256((root/row['path']).read_bytes()).hexdigest() == row['sha256']
sys.stdout.write(output)
