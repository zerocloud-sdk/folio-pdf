#!/usr/bin/env python3
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
REPO = Path('/home/ubuntu/IdeaProjects/open-pdf')
rows = json.loads((OUT/'five-file-source-identity-audit.json').read_text())
changes = {row['path']:row for row in json.loads((OUT/'r3-candidate-input-change-audit.json').read_text())}
index = json.loads((OUT/'snapshots/frozen/r3-source-and-contract-inputs.json').read_text())
recorded = {row['path']:row['sha256'] for row in index['inputs']}
for row in rows:
    assert row['before_sha256'] == changes[row['path']]['r3_sha256'] == recorded[row['path']], row['path']
    assert hashlib.sha256((REPO/row['path']).read_bytes()).hexdigest() == row['frozen_and_live_sha256'], row['path']
contract_changes = []
for row in index['contract-inputs']:
    actual = hashlib.sha256((REPO/row['path']).read_bytes()).hexdigest()
    if actual != row['sha256']:
        contract_changes.append({'path':row['path'],'recorded':row['sha256'],'actual':actual})
assert not contract_changes, contract_changes
receipt = {'source_input_count':len(index['inputs']), 'contract_input_count':len(index['contract-inputs']),
           'reviewed_old_identities_match_independently_retained_r3_inputs':True,
           'reviewed_current_identities_still_match_frozen_source':True,
           'changed_source_inputs':sorted(changes), 'changed_contract_inputs':contract_changes}
with (OUT/'final-source-identity-audit.json').open('x') as stream:
    json.dump(receipt,stream,indent=2)
    stream.write('\n')
print(json.dumps(receipt,indent=2))
