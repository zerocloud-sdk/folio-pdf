#!/usr/bin/env python3
"""Finish audit after correcting reviewer-only global-diagnostic extraction."""
import collections
import json
import pathlib

OUT = pathlib.Path(__file__).resolve().parent
ORIGINAL = OUT / 'snapshots' / 'original'
post = (ORIGINAL / 'actual-records-read-after-fix/foundation-readiness.md').read_text()
pre = (ORIGINAL / 'docs/generated/foundation-readiness.md').read_text()
deltas = json.loads((OUT/'five-file-source-identity-audit.json').read_text())
source_changes = json.loads((OUT/'r3-candidate-input-change-audit.json').read_text())
rows = json.loads((OUT/'real-chain-record-identities-and-sizes.json').read_text())
standards = json.loads((OUT/'eight-real-text-standards-records.json').read_text())
suites = json.loads((OUT/'complete-module-xml-audit.json').read_text())
snapshots = json.loads((OUT/'snapshotted-original-inputs.json').read_text())
prefix = 'stale or mismatched artifact identity '
errors = sorted({prefix + line.split(prefix, 1)[1] for line in post.splitlines() if prefix in line})
expected = sorted(prefix + item['path'] for item in deltas)
assert errors == expected, errors
assert 'cannot read YAML' not in post
original_yaml_errors = sorted({line for line in pre.splitlines() if 'cannot read YAML' in line})
assert len(original_yaml_errors) == 8
assert {item['path'] for item in source_changes} == {item['path'] for item in deltas}
assert len(rows) == 192 and len(standards) == 8
summary = {'snapshotted_files':len(snapshots), 'frozen_and_live_identities_match':True,
           'changed_r3_candidate_inputs':len(source_changes),
           'historical_r3_chain_count':len(rows),
           'historical_r3_chain_results':dict(collections.Counter(row['result'] for row in rows)),
           'text_standards_min_bytes':min(row['bytes'] for row in standards),
           'text_standards_max_bytes':max(row['bytes'] for row in standards),
           'text_standards_negative_controls_per_record':sorted({row['negative_control_count'] for row in standards}),
           'original_unique_yaml_errors':len(original_yaml_errors),
           'postfix_unique_yaml_errors':0, 'postfix_stale_source_errors':errors,
           'module_suites':suites,
           'reviewer_helper_correction': '021 failed only because the reviewer looked for obligation Blocker lines; the five source errors are global lines. Original script, exit 1 and diagnostic preserved. This corrected audit uses the diagnostic text itself.',
           'scope':'Identity/size/retention audit of historical r3 observations; not recertification or final candidate approval.'}
with (OUT / 'audit-summary.json').open('x') as stream:
    json.dump(summary, stream, indent=2)
    stream.write('\n')
print(json.dumps(summary,indent=2))
