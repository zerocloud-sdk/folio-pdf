from pathlib import Path
import re
p=Path('docs/generated/foundation-readiness.md')
data=p.read_text()
match=re.search(r'^\| \[`text`\].*$',data,re.M)
assert match,'Missing text readiness row'
print(match.group(),flush=True)
failures=[line for line in data.splitlines() if 'Blocker:' in line and 'exceeds the limit: 3000000 code points' in line]
print('Exact YAML bound diagnostics:',len(failures),flush=True)
for line in failures:print(line,flush=True)
assert match.group().endswith('| satisfied |'),'Required text certification is blocked in the generated view'
