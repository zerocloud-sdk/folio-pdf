import datetime, hashlib, json, pathlib, subprocess, sys
p=pathlib.Path(__file__).resolve().parent
label=sys.argv[1]
argv=sys.argv[2:]
def exclusive(path, content):
    with path.open('xb') as f: f.write(content)
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
exclusive(p/(label+'.command.json'),(json.dumps({'argv':argv,'cwd':'/home/ubuntu/IdeaProjects/open-pdf','started_utc':started},indent=2)+'\n').encode())
r=subprocess.run(argv,cwd='/home/ubuntu/IdeaProjects/open-pdf',capture_output=True)
exclusive(p/(label+'.stdout'),r.stdout)
exclusive(p/(label+'.stderr'),r.stderr)
exclusive(p/(label+'.result.json'),(json.dumps({'exit_code':r.returncode,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stdout_sha256':hashlib.sha256(r.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(r.stderr).hexdigest()},indent=2)+'\n').encode())
sys.stdout.buffer.write(r.stdout)
sys.stderr.buffer.write(r.stderr)
print('\n[retained result: '+label+', exit '+str(r.returncode)+']',flush=True)
sys.exit(r.returncode)
