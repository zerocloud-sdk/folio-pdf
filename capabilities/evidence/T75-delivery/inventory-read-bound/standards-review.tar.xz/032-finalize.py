import datetime,hashlib,json,pathlib,sys
root=pathlib.Path(__file__).resolve().parent
outside=root.parent/(root.name+"-finalize")
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(path,data):
    with path.open("xb") as f:f.write(data)
command={"argv":[sys.executable,str(pathlib.Path(__file__).resolve())],"cwd":str(pathlib.Path.cwd()),"started_utc":started,"final_stdout":str(outside)+".stdout","final_stderr":str(outside)+".stderr","final_result":str(outside)+".result.json","note":"Final manifest identity and its original command output are adjacent external seal files to avoid a circular manifest reference."}
write(root/"032-finalize.command.json",(json.dumps(command,indent=2)+"\n").encode())
try:
    copied=json.loads((root/"validation-history-copy.json").read_text())
    assert all(hashlib.sha256((root/r["retained_path"]).read_bytes()).hexdigest()==r["sha256"] for r in copied)
    rows=[]
    for path in sorted(root.rglob("*")):
        if not path.is_file():continue
        assert path.name!="SHA256SUMS"
        rows.append((hashlib.sha256(path.read_bytes()).hexdigest(),str(path.relative_to(root))))
    write(root/"SHA256SUMS","".join(sha+"  "+name+"\n" for sha,name in rows).encode())
    assert all(hashlib.sha256((root/name).read_bytes()).hexdigest()==sha for sha,name in rows)
    assert set(name for sha,name in rows)=={str(path.relative_to(root)) for path in root.rglob("*") if path.is_file() and path.name!="SHA256SUMS"}
    stdout=(json.dumps({"packet":str(root),"manifest_members":len(rows),"all_members_verified":True,"sha256":{name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in ["standards-report.md","detailed-receipt.json","SHA256SUMS"]}},indent=2)+"\n").encode()
    stderr=b""
    result={"exit_code":0,"completed_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"manifest_members":len(rows),"manifest_sha256":hashlib.sha256((root/"SHA256SUMS").read_bytes()).hexdigest(),"stdout_sha256":hashlib.sha256(stdout).hexdigest(),"stderr_sha256":hashlib.sha256(stderr).hexdigest()}
except Exception as error:
    stdout=b""
    stderr=(repr(error)+"\n").encode()
    result={"exit_code":1,"completed_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"error":repr(error)}
write(pathlib.Path(str(outside)+".stdout"),stdout)
write(pathlib.Path(str(outside)+".stderr"),stderr)
write(pathlib.Path(str(outside)+".result.json"),(json.dumps(result,indent=2)+"\n").encode())
sys.stdout.buffer.write(stdout)
sys.stderr.buffer.write(stderr)
sys.exit(result["exit_code"])
