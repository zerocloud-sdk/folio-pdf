import json, subprocess, sys
from pathlib import Path
command = json.loads((Path(__file__).parent / "full-worker-command.json").read_text())
sys.exit(subprocess.call(command))
