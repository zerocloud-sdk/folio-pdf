import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import org.junit.internal.TextListener;
import org.junit.runner.Description;
import org.junit.runner.JUnitCore;
import org.junit.runner.Request;
import org.junit.runner.Result;
import org.junit.runner.manipulation.Filter;
public final class T75SelectedMethods {
    public static void main(String[] args) throws Exception {
        final Set<String> names = new HashSet<String>(Arrays.asList(args).subList(1, args.length));
        Request request = Request.aClass(Class.forName(args[0])).filterWith(new Filter() {
            public boolean shouldRun(Description description) {
                return !description.isTest() || names.contains(description.getMethodName());
            }
            public String describe() { return names.toString(); }
        });
        JUnitCore core = new JUnitCore();
        core.addListener(new TextListener(System.out));
        Result result = core.run(request);
        System.exit(result.wasSuccessful() && result.getRunCount() == names.size() ? 0 : 1);
    }
}
