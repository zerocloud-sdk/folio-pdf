import org.junit.internal.TextListener;
import org.junit.runner.JUnitCore;
import org.junit.runner.Request;
import org.junit.runner.Result;
public final class T75SingleMethod {
    public static void main(String[] args) throws Exception {
        JUnitCore core = new JUnitCore();
        core.addListener(new TextListener(System.out));
        long start = System.nanoTime();
        Result result = core.run(Request.method(Class.forName(args[0]), args[1]));
        System.out.println("Actual method elapsed milliseconds: " + ((System.nanoTime() - start) / 1000000));
        System.exit(result.wasSuccessful() ? 0 : 1);
    }
}
