Closed: the frozen observer-budget adjustment matches the approved Spec; no actionable finding remains in this bounded change.

The Goal requires “Refresh invalidated certifications” while prohibiting “additional functionality in those tickets” (original-goal.txt:131–133), and requires full verify/matrix (103–104). The 16-file diff changes only 15 observation allowances, comments and PROVENANCE. Expected behavior, failure assertions, product FontLimits/CompositionLimits and the other extraction bounds remain intact. This is required revalidation within #75.

The governing rule is “For each distinct selected font dictionary” with Identity-H requiring 65,538 entries plus other costs (docs/t13-certification.md:131–156). The existing residual allowances remain available for nodes, codespaces and metrics. The revised multipliers agree with selected dictionaries:

- Two for font/layout, Unicode and shaping consumer observers; one shared Session font for barcode consumers.
- Two for T24–T27 acceptance; T25 still asserts one or two embedded subsets according to fallback, while T27’s repeated flows/flushes share unshaped Session fonts (T25ParagraphSemanticAssertions:98–104; T27TableProducts:52–84,141–151).
- Eight for T29 acceptance’s four command-local font pairs; one for all T30 barcode labels. Unchanged T28 acceptance retains 500000.

The original full-build failure and seven acceptance RED failures are preserved. Completed evidence now includes FontLoading 22 GREEN, seven acceptance checks GREEN, and all 394 consumer tests GREEN with zero failures, errors or skips; the complete consumer log reports BUILD SUCCESS, 12:10. Acceptance controls remain active in T24–T27 and T29. T29/T30 product checks exercise both actual Native modes; T30’s second selected check validates the independently positioned reference. I do not label these two T30 checks as its separate negative-control test.

The minimal GREEN and final acceptance sources differ only by comments. All 16 frozen identities were checked, with 25 inspected source/context copies retained; the explicit SHA-256 manifest is inspected-source-sha256.json. Completed logs and original history have a separate evidence manifest. The prior appearance closures remain unchanged. This closes the observer issue only: full verification, JDK matrix and final candidate certification remain separate pending gates. I ran no project tests, probes or mutations.
