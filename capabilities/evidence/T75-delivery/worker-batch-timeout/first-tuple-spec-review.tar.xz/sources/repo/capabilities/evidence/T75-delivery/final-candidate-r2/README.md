# T75 final candidate, second staging

The unsigned local candidate and acceptance harness were rebuilt successfully
after the final appearance and observer-budget review closures. The actual
stage command returned zero. `build-inputs.json` binds 1,933 source inputs,
23 artifacts, 30 contract inputs and the acceptance harness. The source and
contract inputs match the completed host verification and four-JDK matrix.

`staged-build.tar.xz` retains the original build log, exact commands, build
inputs, actual command exit record and the external command-retention wrapper.
Every archived member was compared byte-for-byte with its original source;
`original-archive-identities.json` records those identities.

This stage supersedes the first candidate retained in `../final-candidate`.
Actual text and refreshed prior-obligation certification is collected under
`../../T75-foundation-20260913-r2`; staging itself is not certification.
