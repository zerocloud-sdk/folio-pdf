"""Verify and collect the T13 recorder's original, separate evidence chains."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import re

PROFILE = 'T13-text-logical-structure'
PRODUCTS = ('nested-split-type3', 'marked-structure', 'embedded-font-kinds',
            'embedded-font-inheritance', 'uncertain-geometry')
CHAINS = ('syntax', 'standards', 'semantic', 'visual')
DECLARATION_PROFILES = {
    'pdfcpu': 'dcf92c9e8ab6a48fea9d581c99cfed86dc993d74e3a8de5cb6e9ae1da919f707',
    'arlington-core': '178df803628eb17a0e6a87e9c9faac441373edbc60db115cba8e71dbb0d6d586',
    'arlington-fonts': '7c4889c2f294cc4094bacc9dfd8af59642e183b3153de6c1b31f30429f253852',
    'arlington-text': '41e5d9fd856574038ac59ce7e26c4a96f6a28ab78599b7d5f6c9afca723555bf',
    'arlington-cid': 'd358219f7da9c26bb85e0a211c88c6f7ae9e00eac2423eda763f6321418181dd',
    'arlington-descriptors': '92e09969447f8384d0a0c9b693f9fc8f17261e02582b93b6bccd361503224a95',
    'arlington-cmaps': '3382bf1a8b36dd513873a17b7d9c460384c1a9e34250af3b8465245a19b5a369'}
DECLARATION_RULES_SHA256 = '98e35f2d6c7201bd0fe1c86452ec5f9497f19e4ca58b9d19b7b8b1ca3bece8bd'


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def properties(path):
    # Recorder Properties.store escapes values but never continues a physical line.
    def unescape(value):
        return re.sub(r'\\(u[0-9a-fA-F]{4}|.)', lambda match:
            chr(int(match[1][1:], 16)) if match[1].startswith('u') and len(match[1]) == 5
            else {'t': '\t', 'n': '\n', 'r': '\r', 'f': '\f'}.get(match[1], match[1]), value)
    values = {}
    for line in path.read_text(encoding='utf-8').splitlines():
        if not line or line.startswith(('#', '!')):
            continue
        key, separator, value = line.partition('=')
        if not separator or key in values:
            raise ValueError('Invalid or duplicate T13 report property: ' + str(path))
        values[key] = unescape(value)
    return values


def require(values, expected, description):
    if any(values.get(key) != value for key, value in expected.items()):
        raise ValueError('Incomplete or inconsistent T13 ' + description)


def retained(directory, result):
    """Consume the original producer receipt; never replace it with later hashes."""
    manifest = directory / 'retained-files.sha256'
    if manifest.stat().st_size > 16 * 1024 * 1024 \
            or digest(manifest) != result.get('retained-files-sha256'):
        raise ValueError('T13 retained manifest identity mismatch: ' + str(directory))
    entries = {}
    for line in manifest.read_text().splitlines():
        match = re.fullmatch(r'([0-9a-f]{64})  (.+)', line)
        if not match:
            raise ValueError('Invalid T13 retained manifest entry')
        value, name = match.groups()
        relative = PurePosixPath(name)
        if relative.is_absolute() or '..' in relative.parts or relative.as_posix() != name \
                or name in entries:
            raise ValueError('Invalid or duplicate T13 retained path')
        entries[name] = value
    files = {}
    for path in directory.rglob('*'):
        if path.is_symlink():
            raise ValueError('T13 evidence contains a symbolic link')
        if path.is_file() and path not in (manifest, directory / 'result.properties'):
            files[path.relative_to(directory).as_posix()] = path
    if set(files) != set(entries):
        raise ValueError('Incomplete T13 original retained receipt: ' + str(directory))
    for name, path in files.items():
        if digest(path) != entries[name]:
            raise ValueError('T13 artifact changed after observation: ' + str(path))
    return sorted(files.values()) + [manifest, directory / 'result.properties']


def declarations(root, directory, input_hash):
    authority = root / 'capabilities/profiles/T13-standards'
    catalog = authority / 'required-rules.txt'
    if digest(catalog) != DECLARATION_RULES_SHA256:
        raise ValueError('T13 declaration rule authority changed')
    expected_rules = set(catalog.read_text().splitlines())
    result = properties(directory / 'result.properties')
    require(result, {'profile': PROFILE, 'input-sha256': input_hash,
        'standards-scope': 'declarations-only', 'declarations': 'pass',
        'qualified-rule-count': '334', 'covered-rules': ','.join(sorted(expected_rules)),
        'required-rules-sha256': DECLARATION_RULES_SHA256}, 'qualified declarations')
    retained(directory, result)
    if digest(directory / 'extraction.pdf') != input_hash:
        raise ValueError('T13 declaration input identity mismatch')
    identities = {'required-rules-sha256': DECLARATION_RULES_SHA256}
    observed_rules = set()
    for group, profile_hash in DECLARATION_PROFILES.items():
        profile_path = authority / (group + '.properties')
        if digest(profile_path) != profile_hash:
            raise ValueError('T13 declaration profile changed: ' + group)
        profile = properties(profile_path)
        rules = profile['required-rules'].split(',')
        if observed_rules.intersection(rules):
            raise ValueError('Duplicate T13 declaration rule assignment')
        observed_rules.update(rules)
        pin_name = 't13-arlington' if group.startswith('arlington') else 'pdfcpu'
        pin_path = root / 'scripts' / (pin_name + '-pin.properties')
        expected_pin = ('e00f7b42bd5712f45b346bba68061fc89ac64888bc35c6b4a32f043784900c8b'
                        if pin_name == 't13-arlington' else
                        '21c58822196a4123561cac927e1f8ba487e6581ba8f488d5b7f40ba949429fc8')
        if digest(pin_path) != expected_pin:
            raise ValueError('T13 declaration tool pin changed')
        pin = properties(pin_path)
        identities.update({'profile.' + group + '.sha256': profile_hash,
                           pin_name + '.pin-sha256': expected_pin,
                           pin_name + '.executable-sha256': pin['sha256']})
        if pin_name == 't13-arlington':
            for kind in ('model', 'patch'):
                identities[pin_name + '.' + kind + '-sha256'] = pin[kind + '-sha256']
        observed = properties(directory / group / 'standards.properties')
        require(observed, {'result': 'pass', 'profile': PROFILE, 'input-sha256': input_hash,
            'covered-rules': ','.join(rules), 'pin-sha256': expected_pin,
            'profile-sha256': profile_hash, 'executable-sha256': pin['sha256'],
            'model-sha256': pin.get('model-sha256', 'none'),
            'patch-sha256': pin.get('patch-sha256', 'none')}, 'checker ' + group)
        findings = (directory / group / 'findings.txt').read_text().splitlines()
        for rule in rules:
            key = 'negative.' + rule
            control = directory / group / ('control-' + rule + '.pdf')
            raw = directory / group / ('negative-' + rule + '.txt')
            expected = profile[key + '.sha256']
            if digest(control) != expected or digest(authority / profile[key + '.path']) != expected \
                    or ('Negative control ' + rule + ' sha256=' + expected + ' detected=true') not in findings \
                    or profile[key + '.finding'] not in raw.read_text():
                raise ValueError('Missing qualified T13 declaration control: ' + rule)
    if observed_rules != expected_rules:
        raise ValueError('Incomplete T13 declaration rule union')
    for phase in ('before', 'after'):
        path = directory / ('identities-' + phase + '.properties')
        if properties(path) != identities or digest(path) != result.get('identities-' + phase + '-sha256'):
            raise ValueError('T13 declaration authority identity mismatch: ' + phase)


def collect_reports(root, run, execution):
    result = properties(run / 'result.properties')
    require(result, dict(dict.fromkeys(CHAINS, 'pass'), **{
        'profile': PROFILE, 'phase': 'certification', 'native-execution-profile': execution,
        'facade-execution-profile': 'IN_PROCESS'}), 'whole-corpus result')
    all_files = retained(run, result)
    authority = root / 'capabilities/profiles/T13-text'
    if digest(authority / 'corpus.json') != 'fb348a2b139df12b93633cbf9c999490c584030aebeacc9b95bff57c9982707f' \
            or digest(authority / 'corpus.properties') != '2b6ebdd09f9ee86bae7c60e3916f82feb8ba413aab6b4d1465c53823646b79d1':
        raise ValueError('T13 frozen corpus identity mismatch')
    corpus = json.loads((authority / 'corpus.json').read_text())
    expected_values = properties(authority / 'corpus.properties')
    for source in corpus['sources'].values():
        if digest(authority / source['path']) != source['sha256']:
            raise ValueError('T13 frozen Source identity mismatch')
    require(properties(run / 'products.properties'), {'phase': 'products-only',
        'native-execution-profile': execution, 'facade-execution-profile': 'IN_PROCESS'}, 'product generation')

    def reference(path):
        path.resolve(strict=True).relative_to(root.resolve())
        return {'path': path.relative_to(root).as_posix(), 'sha256': digest(path)}

    negative = properties(run / 'negative/result.properties')
    require(negative, dict(dict.fromkeys(CHAINS, 'fail'), **{
        'profile': PROFILE, 'native-execution-profile': execution}), 'negative controls')
    retained(run / 'negative', negative)
    reports = {chain: {'chain': chain, 'result': 'pass', 'products': [],
                       'findings': [], 'negative-controls': []} for chain in CHAINS}
    for api in ('native', 'facade'):
        for index, product in enumerate(PRODUCTS):
            directory = run / (api + '-' + product)
            observed = properties(directory / 'result.properties')
            mode = execution if api == 'native' else 'IN_PROCESS'
            required = CHAINS if index < 3 else CHAINS[:3]
            pdf = directory / 'extraction.pdf'
            require(observed, {'profile': PROFILE, 'product': product,
                'execution-profile': mode, 'input-sha256': digest(pdf),
                'required-chains': ','.join(sorted(required)),
                'qualified-standard-rule-count': '376'}, 'product ' + directory.name)
            retained(directory, observed)
            declarations(root, directory / 'declarations', digest(pdf))
            require(properties(directory / 'publication.properties'), {
                'execution-profile': mode, 'target-name': 'target', 'status': 'COMMITTED',
                'partial-output-possible': 'false', 'source-preserved': 'pass', 'reopened': 'pass',
                'source-sha256': corpus['sources'][product]['sha256'],
                'output-sha256': digest(pdf)}, directory.name + ' Publication Receipt')
            prefix = 'products.' + product + '.extraction.'
            expected = {key[len(prefix):]: value for key, value in expected_values.items()
                        if key.startswith(prefix)}
            for name in ('observation.properties', 'reopened.properties'):
                if properties(directory / name) != expected:
                    raise ValueError('T13 detached public values disagree with the frozen corpus: '
                                     + directory.name + '/' + name)
            for chain in CHAINS:
                verdict = 'pass' if chain in required else 'not-required'
                require(observed, {chain: verdict}, directory.name + ' ' + chain)
                require(result, {api + '.' + product + '.' + chain: verdict}, 'aggregate ' + chain)
                if chain not in required:
                    continue
                report = reports[chain]
                report['products'].append(reference(pdf))
                folders = ('declarations', 'programs') if chain == 'standards' else (chain,)
                report['findings'].extend(reference(path) for path in all_files
                    if any(path.is_relative_to(directory / folder) for folder in folders))
                if chain == 'standards':
                    report['negative-controls'].extend(reference(path) for path in all_files
                        if path.is_relative_to(directory / 'declarations')
                        and path.name.startswith(('negative-', 'control-')))
                report['findings'].extend(reference(directory / name)
                                          for name in ('result.properties', 'retained-files.sha256'))
                if chain == 'semantic':
                    report['findings'].extend(reference(directory / name) for name in (
                        'publication.properties', 'observation.properties', 'reopened.properties'))
    for chain, report in reports.items():
        report['negative-controls'].extend(reference(path) for path in all_files
            if path.is_relative_to(run / 'negative' / chain))
        report['negative-controls'].extend(reference(run / 'negative' / name)
                                          for name in ('result.properties', 'retained-files.sha256'))
        report['findings'].extend(reference(run / name)
                                 for name in ('result.properties', 'retained-files.sha256', 'products.properties'))
    return reports
