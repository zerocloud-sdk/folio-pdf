本轮只读增量复核：原 edge-only 冒充 missing-glyph 的 finding 已闭合，但新增解码器尚有两项相邻问题；不是 #75 最终门禁。

硬要求 P1：[源码 611](/tmp/t75-foundation-raster-closure-snapshot.eg0v16j1/t13_foundation_reports.py:611) 的 ancillary 放行会接受并忽略 `tRNS`。保留正确 RGB 采样、加入透明色声明的控制仍可通过 696 的比较，实际透明度却与固定 opaque 控制不同；原生产者比较的是 ImageIO 完整 [getRGB 值 31](/tmp/t75-recorder-retention-closure-snapshot.v_o9y88v/T13FontRasterAgreement.java:31)。这违反 [CONTEXT 405](/home/ubuntu/IdeaProjects/open-pdf/CONTEXT.md:405) 的真实独立证据要求及 [冻结合同 461](/tmp/t75-recorder-retention-closure-snapshot.v_o9y88v/t13-certification.md:461) 的原始栅格身份约束。应在当前 RGB8 opaque 范围明确拒绝 `tRNS`。此结论来自源码控制流，尚未运行新回归。

判断项 P2：[源码 614](/tmp/t75-foundation-raster-closure-snapshot.eg0v16j1/t13_foundation_reports.py:614) 的 `b'IDAT' in chunks` 对每个 IDAT 重扫完整历史。在 4 MiB 内，17 万个空 ancillary 块后接 17 万个空 IDAT，块开销仅 4,080,000 字节，却导致约 289 亿次比较。建议仅保存 `seen_idat` 与 `previous_kind`，保留连续性检查。这是具体资源/性能判断，并非仓库明文编码规则；没有运行压力探针。完整 smell baseline 未发现其他值得本轮增加的重构。

其余新增边界经源码核对：尺寸/色型固定、CRC 和块终止检查、inflate 精确长度及尾数据拒绝、五种过滤器恢复、完整指定像素变更比较。原 P1 的真实 RED 与 27.399 秒单项 GREEN 完整保留。7 项快照 SHA 全部匹配；实际 collector 的 10/10/10/6 结果 JSON 与上一轮已核验 19,700 文件的 JSON 逐字相同。

没有执行 CLI、Maven、资格程序、变更探针或实现编辑。旧 16 项虽 OK，但使用混合源码，不能证明当前快照；新的 17 项仍待完成。[inspection.json](/tmp/t75-foundation-raster-standards-readonly-ghnatkcp/inspection.json) 保存身份、方法及推导。
