CLEAN for the original Foundation collector R1 receipt P1 and the ownership/index correction. No remaining finding within this bounded closure.

The Goal requires rejection of “mismatched identities.” `t13_foundation_reports.py:79–120` now retains the original digest index, parses only verified bytes, and exports those indexed identities. The complete file tree is checked again before return (307), closing the previous adoption of later hashes. Existing public RED/GREEN logs record rejection of the same late-generation-receipt condition; I did not rerun it.

The three parent-owned generation records are excluded only from the combined child's coverage comparison (122–131, 267–268). They remain mandatory in the root index, verified reads, final tree check, publication disposition and exact detached/reopened value checks (270–281). No other child files are exempted.

Independent read-only inspection of the retained actual IN_PROCESS collection verified 19,698 manifest entries plus the root result/manifest: 19,700 files, no omissions or digest mismatches. All 26,473 exported reference instances (19,700 unique paths) match the original digest index. Every product child differs from root ownership by exactly observation, reopened and publication records. Product grouping remains 10 syntax / 10 standards / 10 semantic / 6 visual. The staged run's root receipt equals the original retained run's receipt.

Method: frozen-source inspection and hashing existing artifacts only; zero new CLI, Maven or mutation/ownership probes. All 22 snapshot identities match. Existing logs record 5 protocol tests passing after the receipt fix, 6 after declaration-process checks, 6 after ownership correction, and 29 prior Foundation tests. Synthetic protocol tests are not PDF/tool qualification. The retained actual collector result is an inspected parent execution, not a new independent run.

Detailed syntax/program/semantic/visual collector validation remains explicitly pending. This closure does not certify those TODOs, all eight final environments, or final #75 completion. See `inspection.json` for exact sources, existing logs, artifact identities and inspected counts.
