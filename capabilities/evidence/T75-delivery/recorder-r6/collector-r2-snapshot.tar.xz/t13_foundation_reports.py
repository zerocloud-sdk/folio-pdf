"""Verify and collect the T13 recorder's original, separate evidence chains."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import re

PROFILE = 'T13-text-logical-structure'
PRODUCTS = ('nested-split-type3', 'marked-structure', 'embedded-font-kinds',
            'embedded-font-inheritance', 'uncertain-geometry')
CHAINS = ('syntax', 'standards', 'semantic', 'visual')
DECLARATION_PROFILES = {
    'pdfcpu': 'dcf92c9e8ab6a48fea9d581c99cfed86dc993d74e3a8de5cb6e9ae1da919f707',
    'arlington-core': '178df803628eb17a0e6a87e9c9faac441373edbc60db115cba8e71dbb0d6d586',
    'arlington-fonts': '7c4889c2f294cc4094bacc9dfd8af59642e183b3153de6c1b31f30429f253852',
    'arlington-text': '41e5d9fd856574038ac59ce7e26c4a96f6a28ab78599b7d5f6c9afca723555bf',
    'arlington-cid': 'd358219f7da9c26bb85e0a211c88c6f7ae9e00eac2423eda763f6321418181dd',
    'arlington-descriptors': '92e09969447f8384d0a0c9b693f9fc8f17261e02582b93b6bccd361503224a95',
    'arlington-cmaps': '3382bf1a8b36dd513873a17b7d9c460384c1a9e34250af3b8465245a19b5a369'}
DECLARATION_RULES_SHA256 = '98e35f2d6c7201bd0fe1c86452ec5f9497f19e4ca58b9d19b7b8b1ca3bece8bd'
PDFCPU_NOTICE = '''***************************** Disclaimer ****************************
* PDF 2.0 features are supported on a need basis.                   *
* (See ISO 32000:2 6.3.2 Conformance of PDF processors)             *
* At the moment pdfcpu ships with basic PDF 2.0 support.            *
* Please let us know which feature you would like to see supported, *
* provide a sample PDF file and create an issue:                    *
* https://github.com/pdfcpu/pdfcpu/issues/new/choose                *
* Thank you for using pdfcpu <3                                     *
*********************************************************************'''


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def properties(path):
    return parse_properties(path.read_bytes())


def parse_properties(data):
    # Recorder Properties.store escapes values but never continues a physical line.
    def unescape(value):
        return re.sub(r'\\(u[0-9a-fA-F]{4}|.)', lambda match:
            chr(int(match[1][1:], 16)) if match[1].startswith('u') and len(match[1]) == 5
            else {'t': '\t', 'n': '\n', 'r': '\r', 'f': '\f'}.get(match[1], match[1]), value)
    values = {}
    for line in data.decode('utf-8').splitlines():
        if not line or line.startswith(('#', '!')):
            continue
        key, separator, value = line.partition('=')
        if not separator or key in values:
            raise ValueError('Invalid or duplicate T13 report property: ' + key)
        values[key] = unescape(value)
    return values


def require(values, expected, description):
    if any(values.get(key) != value for key, value in expected.items()):
        raise ValueError('Incomplete or inconsistent T13 ' + description)


def manifest_entries(directory, data):
    if len(data) > 16 * 1024 * 1024:
        raise ValueError('T13 retained manifest exceeds its bound')
    entries = {}
    for line in data.decode('utf-8').splitlines():
        match = re.fullmatch(r'([0-9a-f]{64})  (.+)', line)
        if not match:
            raise ValueError('Invalid T13 retained manifest entry')
        value, name = match.groups()
        relative = PurePosixPath(name)
        if relative.is_absolute() or '..' in relative.parts or relative.as_posix() != name \
                or directory / name in entries:
            raise ValueError('Invalid or duplicate T13 retained path')
        entries[directory / name] = value
    return entries


class RetainedFiles:
    """An index of original producer hashes and verified reads for one collection."""

    def __init__(self, directory):
        self.directory = directory
        record = directory / 'result.properties'
        result_bytes = record.read_bytes()
        self.result = parse_properties(result_bytes)
        manifest = directory / 'retained-files.sha256'
        data = manifest.read_bytes()
        if hashlib.sha256(data).hexdigest() != self.result.get('retained-files-sha256'):
            raise ValueError('T13 retained manifest identity mismatch')
        self.expected = manifest_entries(directory, data)
        self.expected.update({record: hashlib.sha256(result_bytes).hexdigest(),
                              manifest: hashlib.sha256(data).hexdigest()})
        self.trees = {}
        for path in sorted(self.expected):
            for parent in path.parents:
                if not parent.is_relative_to(directory):
                    break
                self.trees.setdefault(parent, []).append(path)
        self.verify()

    def read(self, path):
        if path not in self.expected or path.resolve(strict=True) != path:
            raise ValueError('Unretained or linked T13 artifact: ' + str(path))
        data = path.read_bytes()
        if hashlib.sha256(data).hexdigest() != self.expected[path]:
            raise ValueError('T13 artifact changed after observation: ' + str(path))
        return data

    def properties(self, path):
        return parse_properties(self.read(path))

    def text(self, path):
        return self.read(path).decode('utf-8')

    def under(self, directory):
        return self.trees.get(directory, ())

    def reference(self, root, path):
        return {'path': path.relative_to(root).as_posix(), 'sha256': self.expected[path]}

    def manifest(self, directory, result, parent_owned=()):
        path = directory / 'retained-files.sha256'
        if self.expected[path] != result.get('retained-files-sha256'):
            raise ValueError('T13 child manifest identity mismatch')
        entries = manifest_entries(directory, self.read(path))
        excluded = {path, directory / 'result.properties'}
        excluded.update(directory / name for name in parent_owned)
        expected = {file: self.expected[file] for file in self.under(directory) if file not in excluded}
        if entries != expected:
            raise ValueError('Incomplete T13 original retained receipt: ' + str(directory))

    def verify(self):
        actual = set()
        for path in self.directory.rglob('*'):
            if path.is_symlink():
                raise ValueError('T13 evidence contains a symbolic link')
            if path.is_file():
                actual.add(path)
        if actual != set(self.expected):
            raise ValueError('Incomplete T13 original retained receipt')
        for path in self.expected:
            self.read(path)


def declarations(root, directory, input_hash, files):
    authority = root / 'capabilities/profiles/T13-standards'
    catalog = authority / 'required-rules.txt'
    if digest(catalog) != DECLARATION_RULES_SHA256:
        raise ValueError('T13 declaration rule authority changed')
    expected_rules = set(catalog.read_text().splitlines())
    result = files.properties(directory / 'result.properties')
    require(result, {'profile': PROFILE, 'input-sha256': input_hash,
        'standards-scope': 'declarations-only', 'declarations': 'pass',
        'qualified-rule-count': '334', 'covered-rules': ','.join(sorted(expected_rules)),
        'required-rules-sha256': DECLARATION_RULES_SHA256}, 'qualified declarations')
    files.manifest(directory, result)
    if files.expected[directory / 'extraction.pdf'] != input_hash:
        raise ValueError('T13 declaration input identity mismatch')
    identities = {'required-rules-sha256': DECLARATION_RULES_SHA256}
    observed_rules = set()
    for group, profile_hash in DECLARATION_PROFILES.items():
        profile_path = authority / (group + '.properties')
        if digest(profile_path) != profile_hash:
            raise ValueError('T13 declaration profile changed: ' + group)
        profile = properties(profile_path)
        rules = profile['required-rules'].split(',')
        if observed_rules.intersection(rules):
            raise ValueError('Duplicate T13 declaration rule assignment')
        observed_rules.update(rules)
        pin_name = 't13-arlington' if group.startswith('arlington') else 'pdfcpu'
        pin_path = root / 'scripts' / (pin_name + '-pin.properties')
        expected_pin = ('e00f7b42bd5712f45b346bba68061fc89ac64888bc35c6b4a32f043784900c8b'
                        if pin_name == 't13-arlington' else
                        '21c58822196a4123561cac927e1f8ba487e6581ba8f488d5b7f40ba949429fc8')
        if digest(pin_path) != expected_pin:
            raise ValueError('T13 declaration tool pin changed')
        pin = properties(pin_path)
        identities.update({'profile.' + group + '.sha256': profile_hash,
                           pin_name + '.pin-sha256': expected_pin,
                           pin_name + '.executable-sha256': pin['sha256']})
        if pin_name == 't13-arlington':
            for kind in ('model', 'patch'):
                identities[pin_name + '.' + kind + '-sha256'] = pin[kind + '-sha256']
        observed = files.properties(directory / group / 'standards.properties')
        require(observed, {'result': 'pass', 'profile': PROFILE, 'input-sha256': input_hash,
            'covered-rules': ','.join(rules), 'pin-sha256': expected_pin,
            'profile-sha256': profile_hash, 'executable-sha256': pin['sha256'],
            'model-sha256': pin.get('model-sha256', 'none'),
            'patch-sha256': pin.get('patch-sha256', 'none')}, 'checker ' + group)
        raw_findings = files.text(directory / group / 'findings.txt')
        version, separator, validation = raw_findings.partition('\nValidation exit: ')
        if not version.startswith('Version exit: 0\n') or pin['version'] not in version \
                or not separator or not validation.startswith('0\n'):
            raise ValueError('Incomplete T13 declaration process observation: ' + group)
        positive = validation[2:].partition('\nNegative control ')[0].strip()
        if group == 'pdfcpu':
            completed = re.fullmatch(r'validating\(mode=strict\) [^\r\n]+ \.\.\.\n\n'
                                     + re.escape(PDFCPU_NOTICE) + r'\nvalidation ok', positive) is not None
        else:
            completed = (' BEGIN - TestGrammar ' in positive and '\nEND\n' in positive
                         and positive.endswith('DONE - 1 files processed')
                         and 'Error:' not in positive and 'Warning:' not in positive)
        if not completed:
            raise ValueError('Incomplete T13 positive declaration validation: ' + group)
        findings = raw_findings.splitlines()
        for rule in rules:
            key = 'negative.' + rule
            control = directory / group / ('control-' + rule + '.pdf')
            raw = directory / group / ('negative-' + rule + '.txt')
            negative = files.text(raw)
            detected = (negative.startswith('exit=1\n') and
                        ('validation error:' in negative or 'validation error (obj#:' in negative)
                        if group == 'pdfcpu' else
                        negative.startswith('exit=0\n') and '\nError: ' in negative)
            expected = profile[key + '.sha256']
            if files.expected[control] != expected or digest(authority / profile[key + '.path']) != expected \
                    or ('Negative control ' + rule + ' sha256=' + expected + ' detected=true') not in findings \
                    or not detected or profile[key + '.finding'] not in negative:
                raise ValueError('Missing qualified T13 declaration control: ' + rule)
    if observed_rules != expected_rules:
        raise ValueError('Incomplete T13 declaration rule union')
    for phase in ('before', 'after'):
        path = directory / ('identities-' + phase + '.properties')
        if files.properties(path) != identities or files.expected[path] != result.get('identities-' + phase + '-sha256'):
            raise ValueError('T13 declaration authority identity mismatch: ' + phase)


def collect_reports(root, run, execution):
    files = RetainedFiles(run)
    result = files.result
    require(result, dict(dict.fromkeys(CHAINS, 'pass'), **{
        'profile': PROFILE, 'phase': 'certification', 'native-execution-profile': execution,
        'facade-execution-profile': 'IN_PROCESS'}), 'whole-corpus result')
    authority = root / 'capabilities/profiles/T13-text'
    if digest(authority / 'corpus.json') != 'fb348a2b139df12b93633cbf9c999490c584030aebeacc9b95bff57c9982707f' \
            or digest(authority / 'corpus.properties') != '2b6ebdd09f9ee86bae7c60e3916f82feb8ba413aab6b4d1465c53823646b79d1':
        raise ValueError('T13 frozen corpus identity mismatch')
    corpus = json.loads((authority / 'corpus.json').read_text())
    expected_values = properties(authority / 'corpus.properties')
    for source in corpus['sources'].values():
        if digest(authority / source['path']) != source['sha256']:
            raise ValueError('T13 frozen Source identity mismatch')
    require(files.properties(run / 'products.properties'), {'phase': 'products-only',
        'native-execution-profile': execution, 'facade-execution-profile': 'IN_PROCESS'}, 'product generation')

    def reference(path):
        return files.reference(root, path)

    negative = files.properties(run / 'negative/result.properties')
    require(negative, dict(dict.fromkeys(CHAINS, 'fail'), **{
        'profile': PROFILE, 'native-execution-profile': execution}), 'negative controls')
    files.manifest(run / 'negative', negative)
    reports = {chain: {'chain': chain, 'result': 'pass', 'products': [],
                       'findings': [], 'negative-controls': []} for chain in CHAINS}
    for api in ('native', 'facade'):
        for index, product in enumerate(PRODUCTS):
            directory = run / (api + '-' + product)
            observed = files.properties(directory / 'result.properties')
            mode = execution if api == 'native' else 'IN_PROCESS'
            required = CHAINS if index < 3 else CHAINS[:3]
            pdf = directory / 'extraction.pdf'
            require(observed, {'profile': PROFILE, 'product': product,
                'execution-profile': mode, 'input-sha256': files.expected[pdf],
                'required-chains': ','.join(sorted(required)),
                'qualified-standard-rule-count': '376'}, 'product ' + directory.name)
            files.manifest(directory, observed, (
                'observation.properties', 'reopened.properties', 'publication.properties'))
            declarations(root, directory / 'declarations', files.expected[pdf], files)
            require(files.properties(directory / 'publication.properties'), {
                'execution-profile': mode, 'target-name': 'target', 'status': 'COMMITTED',
                'partial-output-possible': 'false', 'source-preserved': 'pass', 'reopened': 'pass',
                'source-sha256': corpus['sources'][product]['sha256'],
                'output-sha256': files.expected[pdf]}, directory.name + ' Publication Receipt')
            prefix = 'products.' + product + '.extraction.'
            expected = {key[len(prefix):]: value for key, value in expected_values.items()
                        if key.startswith(prefix)}
            for name in ('observation.properties', 'reopened.properties'):
                if files.properties(directory / name) != expected:
                    raise ValueError('T13 detached public values disagree with the frozen corpus: '
                                     + directory.name + '/' + name)
            for chain in CHAINS:
                verdict = 'pass' if chain in required else 'not-required'
                require(observed, {chain: verdict}, directory.name + ' ' + chain)
                require(result, {api + '.' + product + '.' + chain: verdict}, 'aggregate ' + chain)
                if chain not in required:
                    continue
                report = reports[chain]
                report['products'].append(reference(pdf))
                folders = ('declarations', 'programs') if chain == 'standards' else (chain,)
                report['findings'].extend(reference(path) for folder in folders
                                          for path in files.under(directory / folder))
                if chain == 'standards':
                    report['negative-controls'].extend(reference(path) for path in files.under(directory / 'declarations')
                        if path.name.startswith(('negative-', 'control-')))
                report['findings'].extend(reference(directory / name)
                                          for name in ('result.properties', 'retained-files.sha256'))
                if chain == 'semantic':
                    report['findings'].extend(reference(directory / name) for name in (
                        'publication.properties', 'observation.properties', 'reopened.properties'))
    for chain, report in reports.items():
        report['negative-controls'].extend(reference(path) for path in files.under(run / 'negative' / chain))
        report['negative-controls'].extend(reference(run / 'negative' / name)
                                          for name in ('result.properties', 'retained-files.sha256'))
        report['findings'].extend(reference(run / name)
                                 for name in ('result.properties', 'retained-files.sha256', 'products.properties'))
    files.verify()
    return reports
