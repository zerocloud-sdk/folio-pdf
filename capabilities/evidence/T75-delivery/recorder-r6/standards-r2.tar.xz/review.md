Read-only incremental Standards closure: the two original R1 P1 findings are closed; one new P2 remains in the index refactor.

**Hard finding — P2:** `t13_foundation_reports.py:91–93` accepts root-manifest entries, then `self.expected.update(...)` silently overwrites any declared digest for `result.properties` or `retained-files.sha256`. A malformed original receipt naming either reserved file with an incorrect digest therefore loses that conflicting expectation instead of being rejected. R1’s exact file/entry comparison rejected these entries. Reject both reserved names before adding the two separately captured root identities. This violates the producer-digest/identity-consistency requirement in frozen `t13-certification.md:461–480` and goal lines 92–93. This conclusion is from source inspection; no malformed fixture was created or executed.

Original closures:

- `RetainedFiles.read/reference` (102–120) checks the same bytes it parses and exports original expected digests; `collect_reports:307` revalidates the complete tree. The retained late-generation-record RED/GREEN documents rejection of the previously adopted change.
- Declaration positives now require successful process and completion envelopes (192–205), and negatives require the qualified exit/error combination (211–220). The existing four public process controls cover both exit-137 cases, a failed positive validation and incomplete Arlington completion.

The ownership adjustment is appropriately narrow: only observation/reopened/publication records are parent-owned (267–268). They remain required and verified by the whole receipt and public-value checks. All 30 such existing records match their parent digests and are absent from the combined child receipts.

Judgment-call smell: the principal repeated-work issue is closed. Two intentional whole-tree verifications and indexed subtree access replace 22 scans and 50 whole-list filters; exported references no longer rehash files.

Method and completed evidence: no new CLI, mutation probes or Maven. Frozen identity checks all match. Read-only checks of the retained actual collector JSON found 26,473 references to all 19,700 files, with no conflicting, missing or changed digests; product counts are 10/10/10/6. Existing logs report six collector tests passing in 83.988s and 29 previous Foundation regressions passing in 7.308s; these were not rerun. Remaining chain details and the final #75 gate are outside this closure.

`inspection.json` preserves checked identities, original log contents and artifact-reference counts.
