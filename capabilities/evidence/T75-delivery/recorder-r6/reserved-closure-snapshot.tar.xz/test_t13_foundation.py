"""Exercise the public Foundation CLI for the frozen extraction obligation."""
import json
import hashlib
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import time
import unittest
import yaml

ROOT = Path(__file__).resolve().parents[2]
PRODUCTS = ('nested-split-type3', 'marked-structure', 'embedded-font-kinds',
            'embedded-font-inheritance', 'uncertain-geometry')
CHAINS = ('syntax', 'standards', 'semantic', 'visual')
DECLARATIONS = ('pdfcpu', 'arlington-core', 'arlington-fonts', 'arlington-text',
                'arlington-cid', 'arlington-descriptors', 'arlington-cmaps')
PDFCPU_NOTICE = '''***************************** Disclaimer ****************************
* PDF 2.0 features are supported on a need basis.                   *
* (See ISO 32000:2 6.3.2 Conformance of PDF processors)             *
* At the moment pdfcpu ships with basic PDF 2.0 support.            *
* Please let us know which feature you would like to see supported, *
* provide a sample PDF file and create an issue:                    *
* https://github.com/pdfcpu/pdfcpu/issues/new/choose                *
* Thank you for using pdfcpu <3                                     *
*********************************************************************'''


def write(path, text):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def props(path, values):
    write(path, ''.join(key + '=' + str(value) + '\n' for key, value in values.items()))


def read_props(path):
    return dict(line.split('=', 1) for line in path.read_text().splitlines()
                if line and not line.startswith('#') and '=' in line)


def seal(directory):
    """Publish a collector protocol receipt, not a tool qualification result."""
    manifest = directory / 'retained-files.sha256'
    result = directory / 'result.properties'
    excluded = {manifest, result}
    if read_props(result).get('product') in PRODUCTS:
        # The whole-run product producer owns these three files; the combined
        # chain receipt in the same directory owns only its own observations.
        excluded.update(directory / name for name in (
            'observation.properties', 'reopened.properties', 'publication.properties'))
    files = sorted(path for path in directory.rglob('*')
                   if path.is_file() and path not in excluded)
    write(manifest, ''.join(digest(path) + '  ' + path.relative_to(directory).as_posix() + '\n'
                           for path in files))
    lines = [line for line in result.read_text().splitlines()
             if not line.startswith('retained-files-sha256=')]
    result.write_text('\n'.join(lines) + '\nretained-files-sha256=' + digest(manifest) + '\n')


class T13FoundationTest(unittest.TestCase):
    def cli(self, root, *arguments):
        return subprocess.run(['/usr/bin/python3', str(ROOT / 'scripts/t03-foundation.py'),
                               *arguments, '--root', str(root), '--obligation', 'text'],
                              capture_output=True, text=True, timeout=30)

    def report_fixture(self, root):
        # Deliberately synthetic public collector protocol, never independent PDF evidence.
        run = root / 'run'
        for profile in ('T13-text', 'T13-fonts', 'T13-standards'):
            shutil.copytree(ROOT / 'capabilities/profiles' / profile,
                            root / 'capabilities/profiles' / profile)
        corpus = json.loads((root / 'capabilities/profiles/T13-text/corpus.json').read_text())
        flat = (root / 'capabilities/profiles/T13-text/corpus.properties').read_text().splitlines()
        for name in ('pdfcpu-pin.properties', 't13-arlington-pin.properties'):
            write(root / 'scripts' / name, (ROOT / 'scripts' / name).read_text())
        overall = dict.fromkeys(CHAINS, 'pass')
        overall.update({'profile': 'T13-text-logical-structure', 'phase': 'certification',
                        'native-execution-profile': 'HARDENED_WORKER',
                        'facade-execution-profile': 'IN_PROCESS'})
        for api in ('native', 'facade'):
            for index, product in enumerate(PRODUCTS):
                directory = run / (api + '-' + product)
                required = CHAINS if index < 3 else CHAINS[:3]
                pdf = directory / 'extraction.pdf'
                write(pdf, 'collector protocol ' + api + '-' + product)
                mode = 'HARDENED_WORKER' if api == 'native' else 'IN_PROCESS'
                source = corpus['sources'][product]
                props(directory / 'publication.properties', {
                    'execution-profile': mode, 'target-name': 'target', 'status': 'COMMITTED',
                    'partial-output-possible': 'false', 'source-preserved': 'pass', 'reopened': 'pass',
                    'source-sha256': source['sha256'], 'output-sha256': digest(pdf)})
                prefix = 'products.' + product + '.extraction.'
                observation = '\n'.join(line[len(prefix):] for line in flat if line.startswith(prefix)) + '\n'
                for name in ('observation.properties', 'reopened.properties'):
                    write(directory / name, observation)
                observed = {'profile': 'T13-text-logical-structure', 'product': product,
                            'input-sha256': digest(pdf), 'execution-profile': mode,
                            'required-chains': ','.join(sorted(required)),
                            'qualified-standard-rule-count': '376'}
                for chain in CHAINS:
                    verdict = 'pass' if chain in required else 'not-required'
                    observed[chain] = verdict
                    overall[api + '.' + product + '.' + chain] = verdict
                    if chain in required:
                        for folder in (('declarations', 'programs') if chain == 'standards' else (chain,)):
                            write(directory / folder / (chain + '.txt'), 'original protocol observation\n')
                props(directory / 'result.properties', observed)
                self.declaration_fixture(root, directory / 'declarations', pdf)
                seal(directory)
        props(run / 'products.properties', {'phase': 'products-only',
              'native-execution-profile': 'HARDENED_WORKER', 'facade-execution-profile': 'IN_PROCESS'})
        props(run / 'negative/result.properties', dict(dict.fromkeys(CHAINS, 'fail'), **{
            'profile': 'T13-text-logical-structure', 'native-execution-profile': 'HARDENED_WORKER'}))
        for chain in CHAINS:
            write(run / 'negative' / chain / 'raw.txt', 'original detected protocol defect\n')
        seal(run / 'negative')
        props(run / 'result.properties', overall)
        seal(run)
        return run

    def declaration_fixture(self, root, directory, pdf):
        authority = root / 'capabilities/profiles/T13-standards'
        identities = {'required-rules-sha256': digest(authority / 'required-rules.txt')}
        for group in DECLARATIONS:
            profile_path = authority / (group + '.properties')
            profile = read_props(profile_path)
            pin_name = 't13-arlington' if group.startswith('arlington') else 'pdfcpu'
            pin_path = root / 'scripts' / (pin_name + '-pin.properties')
            pin = read_props(pin_path)
            identities['profile.' + group + '.sha256'] = digest(profile_path)
            identities[pin_name + '.pin-sha256'] = digest(pin_path)
            identities[pin_name + '.executable-sha256'] = pin['sha256']
            if pin_name == 't13-arlington':
                for kind in ('model', 'patch'):
                    identities[pin_name + '.' + kind + '-sha256'] = pin[kind + '-sha256']
            props(directory / group / 'standards.properties', {
                'result': 'pass', 'profile': 'T13-text-logical-structure',
                'covered-rules': profile['required-rules'], 'input-sha256': digest(pdf),
                'executable-sha256': pin['sha256'], 'pin-sha256': digest(pin_path),
                'model-sha256': pin.get('model-sha256', 'none'),
                'patch-sha256': pin.get('patch-sha256', 'none'),
                'profile-sha256': digest(profile_path)})
            positive = ('validating(mode=strict) extraction.pdf ...\n\n' + PDFCPU_NOTICE + '\nvalidation ok'
                        if group == 'pdfcpu' else
                        'Processing extraction.pdf BEGIN - TestGrammar version\nInfo: checked\nEND\n\nDONE - 1 files processed')
            findings = ['Version exit: 0\nversion: ' + pin['version'] + '\nValidation exit: 0\n' + positive]
            for rule in profile['required-rules'].split(','):
                key = 'negative.' + rule
                source = authority / profile[key + '.path']
                if not source.is_file():
                    source.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copyfile(ROOT / 'capabilities/profiles/T13-standards' / profile[key + '.path'], source)
                shutil.copyfile(source, directory / group / ('control-' + rule + '.pdf'))
                write(directory / group / ('negative-' + rule + '.txt'),
                      ('exit=1\nvalidation error: ' if group == 'pdfcpu' else 'exit=0\nError: ')
                      + profile[key + '.finding'] + '\n')
                findings.append('Negative control ' + rule + ' sha256=' + profile[key + '.sha256'] + ' detected=true')
            write(directory / group / 'findings.txt', '\n'.join(findings) + '\n')
        for name in ('identities-before.properties', 'identities-after.properties'):
            props(directory / name, identities)
        shutil.copyfile(pdf, directory / 'extraction.pdf')
        props(directory / 'result.properties', {
            'profile': 'T13-text-logical-structure', 'standards-scope': 'declarations-only',
            'input-sha256': digest(pdf), 'declarations': 'pass', 'qualified-rule-count': '334',
            'covered-rules': ','.join(sorted((authority / 'required-rules.txt').read_text().splitlines())),
            'required-rules-sha256': digest(authority / 'required-rules.txt'),
            'identities-before-sha256': digest(directory / 'identities-before.properties'),
            'identities-after-sha256': digest(directory / 'identities-after.properties')})
        seal(directory)

    def test_public_collect_preserves_required_chain_products_and_original_artifact_receipts(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            run = self.report_fixture(root)
            command = ('collect', 'run', '--execution-profile', 'HARDENED_WORKER')
            completed = self.cli(root, *command)
            self.assertEqual(0, completed.returncode, completed.stderr)
            reports = json.loads(completed.stdout)
            self.assertEqual(set(CHAINS), set(reports))
            self.assertEqual(10, len(reports['syntax']['products']))
            self.assertEqual(10, len(reports['standards']['products']))
            self.assertEqual(10, len(reports['semantic']['products']))
            self.assertEqual(6, len(reports['visual']['products']))
            self.assertIn('run/native-marked-structure/semantic/semantic.txt',
                          {item['path'] for item in reports['semantic']['findings']})
            self.assertIn('run/negative/visual/raw.txt',
                          {item['path'] for item in reports['visual']['negative-controls']})
            report = run / 'native-marked-structure/semantic/semantic.txt'
            report.write_text('changed after original observation\n')
            self.assertNotEqual(0, self.cli(root, *command).returncode)
            self.assertNotEqual(0, self.cli(root, 'collect', 'run').returncode)

    def test_public_collect_requires_successful_publication_and_exact_detached_reopened_values(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            run = self.report_fixture(root)
            command = ('collect', 'run', '--execution-profile', 'HARDENED_WORKER')
            self.assertEqual(0, self.cli(root, *command).returncode)
            substitutions = (
                ('publication.properties', 'status=COMMITTED', 'status=ROLLED_BACK'),
                ('publication.properties', 'source-preserved=pass', 'source-preserved=fail'),
                ('publication.properties', 'execution-profile=IN_PROCESS', 'execution-profile=HARDENED_WORKER'),
                ('observation.properties', 'pages.0.text=A AA', 'pages.0.text=A  AA'),
                ('reopened.properties', 'pages.0.items.0.source=41', 'pages.0.items.0.source=42'))
            directory = run / 'facade-uncertain-geometry'
            for name, before, after in substitutions:
                path = directory / name
                original = path.read_text()
                self.assertIn(before, original)
                path.write_text(original.replace(before, after))
                seal(directory)
                seal(run)
                self.assertNotEqual(0, self.cli(root, *command).returncode, name + ': ' + before)
                path.write_text(original)
                seal(directory)
                seal(run)

    def test_public_collect_requires_every_qualified_declaration_and_detected_original_control(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            run = self.report_fixture(root)
            command = ('collect', 'run', '--execution-profile', 'HARDENED_WORKER')
            self.assertEqual(0, self.cli(root, *command).returncode)
            directory = run / 'native-marked-structure/declarations'
            for name, before, after in (
                    ('arlington-cmaps/standards.properties', 'covered-rules=cmap-encoding-name-name,', 'covered-rules='),
                    ('arlington-cmaps/standards.properties', 'executable-sha256=', 'missing-executable='),
                    ('arlington-cmaps/findings.txt', 'detected=true', 'detected=false'),
                    ('arlington-cmaps/negative-cmap-encoding-name-name.txt', 'Error: wrong type:', 'No error:')):
                path = directory / name
                original = path.read_text()
                self.assertIn(before, original)
                path.write_text(original.replace(before, after))
                for parent in (directory, directory.parent, run):
                    seal(parent)
                self.assertNotEqual(0, self.cli(root, *command).returncode, name)
                path.write_text(original)
                for parent in (directory, directory.parent, run):
                    seal(parent)

    def test_public_collect_does_not_adopt_a_late_changed_generation_receipt(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            run = self.report_fixture(root)
            # The authority is read after the run's original manifest. Its access
            # time coordinates this test-owned file edit at the public CLI boundary.
            anchor = root / 'capabilities/profiles/T13-text/corpus.json'
            os.utime(anchor, ns=(0, anchor.stat().st_mtime_ns))
            command = ['/usr/bin/python3', str(ROOT / 'scripts/t03-foundation.py'),
                       'collect', 'run', '--execution-profile', 'HARDENED_WORKER',
                       '--root', str(root), '--obligation', 'text']
            process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            changed = False
            try:
                deadline = time.monotonic() + 30
                while process.poll() is None and time.monotonic() < deadline:
                    if anchor.stat().st_atime_ns != 0:
                        with (run / 'products.properties').open('a') as receipt:
                            receipt.write('# changed after original receipt verification\n')
                        changed = True
                        break
                    time.sleep(0.001)
                stdout, stderr = process.communicate(timeout=30)
            finally:
                if process.poll() is None:
                    process.kill()
                    process.communicate()
            self.assertTrue(changed, 'The original generation receipt must actually change during collection')
            self.assertNotEqual(0, process.returncode,
                                'The collector adopted changed producer bytes as passing evidence: ' + stderr)

    def test_public_collect_requires_completed_declaration_processes_for_qualification(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            run = self.report_fixture(root)
            command = ('collect', 'run', '--execution-profile', 'HARDENED_WORKER')
            self.assertEqual(0, self.cli(root, *command).returncode)
            directory = run / 'native-marked-structure/declarations'
            for name, before, after in (
                    ('pdfcpu/negative-catalog-type.txt', 'exit=1', 'exit=137'),
                    ('arlington-cmaps/negative-cmap-encoding-name-name.txt', 'exit=0', 'exit=137'),
                    ('pdfcpu/findings.txt', 'Validation exit: 0', 'Validation exit: 137'),
                    ('arlington-cmaps/findings.txt', 'DONE - 1 files processed', 'interrupted')):
                path = directory / name
                original = path.read_text()
                self.assertIn(before, original)
                path.write_text(original.replace(before, after))
                for parent in (directory, directory.parent, run):
                    seal(parent)
                self.assertNotEqual(0, self.cli(root, *command).returncode, name)
                path.write_text(original)
                for parent in (directory, directory.parent, run):
                    seal(parent)

    def test_public_collect_rejects_self_referential_original_manifest_entries(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            run = self.report_fixture(root)
            command = ('collect', 'run', '--execution-profile', 'HARDENED_WORKER')
            self.assertEqual(0, self.cli(root, *command).returncode)
            manifest = run / 'retained-files.sha256'
            record = run / 'result.properties'
            original_manifest = manifest.read_text()
            original_record = read_props(record)
            for name in ('result.properties', 'retained-files.sha256'):
                manifest.write_text(original_manifest + '0' * 64 + '  ' + name + '\n')
                props(record, dict(original_record, **{'retained-files-sha256': digest(manifest)}))
                self.assertNotEqual(0, self.cli(root, *command).returncode,
                                    'Conflicting original receipt was silently overwritten: ' + name)
                manifest.write_text(original_manifest)
                props(record, original_record)

    def test_public_plan_binds_all_eight_native_combinations_and_actual_facade_mode(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            helper = root / 'helper'
            helper.write_text('#!/bin/sh\nexit 0\n')
            helper.chmod(0o700)
            (root / 'capabilities').mkdir()
            (root / 'capabilities/foundation-release.yaml').write_text(yaml.safe_dump({
                'release': '0.1.0', 'required-artifacts': [], 'environments': 'capabilities/environments.yaml'}))
            shutil.copyfile(ROOT / 'capabilities/foundation-environments.yaml', root / 'capabilities/environments.yaml')
            (root / 'target/foundation-0.1.0').mkdir(parents=True)
            (root / 'target/foundation-0.1.0/build-inputs.json').write_text(json.dumps({'harness': []}))
            result = subprocess.run(['/usr/bin/python3', str(ROOT / 'scripts/t03-foundation.py'),
                                     'plan', 'plan', '--root', str(root), '--obligation', 'text'],
                                    env=dict(os.environ, FOLIO_HARFBUZZ_HELPER=str(helper)),
                                    capture_output=True, text=True, timeout=30)
            self.assertEqual(0, result.returncode, result.stderr)
            plan = json.loads((root / 'plan/plan.json').read_text())
            self.assertEqual('unverified-plan', plan['status'])
            self.assertEqual(8, len(plan['executions']))
            tools = {tool['id']: tool for tool in plan['tools']}
            self.assertEqual('scripts/t13-arlington-pin.properties', tools['arlington-t13-r1']['pin'])
            self.assertEqual('project-test', tools['folio-pdf-t13']['kind'])
            self.assertEqual({'syntax', 'standards', 'semantic'}, set(tools['qpdf']['chains']))
            for index, execution in enumerate(plan['executions']):
                mode = 'IN_PROCESS' if index % 2 == 0 else 'HARDENED_WORKER'
                self.assertEqual(118, execution['required-test-count'])
                self.assertIn('-Dfolio.t13.executionProfile=' + mode, execution['java-options'])
                self.assertIn('net.zerocloud.pdf.acceptance.T13EvidenceCommand', execution['recorder-command'])
                self.assertIn('net.zerocloud.pdf.consumer.TextStructureExtractionWorkflowTest',
                              execution['contract-tests-command'])
                self.assertIn('net.zerocloud.pdf.itext7.consumer.TextStructureFacadeTest',
                              execution['contract-tests-command'])
                self.assertIn('Stable Facade execution is IN_PROCESS', execution['settings']['providers'])
            for path in ('capabilities/profiles/T13-text', 'capabilities/profiles/T13-fonts',
                         'capabilities/profiles/T13-standards', 'scripts/t13-arlington-pin.properties',
                         'scripts/t13-program-standards.py', 'scripts/t13-semantics.py',
                         'scripts/t13-qpdf-runtime.sha256', 'scripts/t13_foundation_reports.py'):
                self.assertIn(path, plan['configuration-paths'])
