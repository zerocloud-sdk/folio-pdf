# Bounded Spec closure — retained declaration evidence

CLEAN for the single P1 finding and immediate neighbours; not the final #75 gate.

All five original mutations now produce INDETERMINATE/0, including replacing the first raw negative report before the first group returns. The new producer-side retained-byte identities close that timing gap. Five adjacent controls (changed findings, deleted/changed identities-before, deleted negative output, equal-byte control symlink) also produce INDETERMINATE/0.

17 actual public CLI invocations all match their expected outcomes: 5 PASS, 11 INDETERMINATE, 1 FAIL. Each PDF2 positive qualifies exactly 334 unique rules and exports a verified complete 686-file retained manifest. The original PDF1.7 nested case stays outside the fixed PDF2 profile (IND/274); its authored PDF2 positive passes. Actual invalid annotation Contents remains FAIL/0. Three separate exported-manifest replay checks detect deletion/change of the manifest and changed declarations text; these are not additional CLI executions.

The 1,082 frozen source/class/JAR identities, classpath and 966-file read-only seed tool/profile/model root match before and after. No classes or ELF binaries were copied into this closure directory. Every input, argv, output, original changed artifact, result and identity is retained or referenced by exact path plus SHA. See assessment.json, snapshot-identities.json, identity-final-check.json, probes.py and the per-case run.json files.
