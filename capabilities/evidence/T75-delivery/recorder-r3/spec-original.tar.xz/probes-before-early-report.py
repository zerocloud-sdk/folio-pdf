from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time,threading
BASE=Path(__file__).resolve().parent
CP=(BASE/'classpath.txt').read_text().strip()
SEED=BASE/'root'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def props(p):return dict(x.split('=',1) for x in Path(p).read_text().splitlines() if x and not x.startswith('#') and '=' in x)
def manifest(r):return {str(p.relative_to(r)):sha(p) for p in r.rglob('*') if p.is_file()}
def run(name,mode='none',source='marked-structure'):
 case=BASE/name;case.mkdir();root=case/'root';shutil.copytree(SEED,root)
 inp=root/'capabilities/profiles/T13-text/fixtures'/f'{source}.pdf';out=case/'out';mutation={}
 target_profile=root/'capabilities/profiles/T13-standards/pdfcpu.properties';pp=props(target_profile)
 control=(target_profile.parent/pp['negative.annotation-contents-string.path']).resolve()
 original=case/'input-original.pdf';shutil.copy2(inp,original)
 def change(path,data=None):
  mutation['path']=str(path);mutation['before_sha256']=sha(path) if path.is_file() else None
  if path.is_file():shutil.copy2(path,case/'changed-file-original')
  if data is None:path.unlink()
  else:path.write_bytes(data)
  mutation['after_sha256']=sha(path) if path.is_file() else None
  mutation['time']=time.monotonic()
 if mode=='missing-source-control':change(control)
 elif mode=='replaced-source-control':change(control,inp.read_bytes())
 elif mode=='initial-pin':
  pin=root/'scripts/pdfcpu-pin.properties';change(pin,pin.read_bytes()+b'\ntimeout-ms=10001\n')
 elif mode=='initial-binary':
  exe=root/'.build-cache/pdfcpu/0.15.0/pdfcpu';change(exe,exe.read_bytes()+b'\x00')
 elif mode=='initial-model':
  model=root/'.build-cache/arlington/t13-r1/tsv/latest/Catalog.tsv';change(model,model.read_bytes()+b'\n')
 elif mode=='initial-patch':
  patch=root/'build-tools/acceptance/arlington/t13-r1.patch';change(patch,patch.read_bytes()+b'\n')
 elif mode=='initial-rules':
  auth=root/'capabilities/profiles/T13-standards/required-rules.txt';change(auth,auth.read_bytes()+b'new-rule\n')
 elif mode=='invalid-input':
  # Original control already has the independently qualified annotation Contents type defect.
  inp.write_bytes(control.read_bytes());shutil.copy2(inp,original)
 (case/'identities-before.json').write_text(json.dumps(manifest(root),indent=2)+'\n')
 argv=['java','-cp',CP,'net.zerocloud.pdf.acceptance.T13EvidenceCommand','declaration-standards',str(root),str(inp),str(out)]
 (case/'argv.json').write_text(json.dumps(argv,indent=2)+'\n')
 start=time.monotonic();proc=subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 late=mode.startswith('late-')
 if late:
  try:
   # Second group creation establishes that the aggregate already read first-group reports.
   trigger=out/'arlington-core'
   while not trigger.is_dir():
    if proc.poll() is not None:raise RuntimeError('process finished before second group')
    if time.monotonic()-start>60:raise RuntimeError('no second group')
    time.sleep(.002)
   mutation['trigger']=str(trigger);mutation['first_group_result']=props(out/'pdfcpu/standards.properties')
   if mode=='late-control-delete':change(out/'pdfcpu/control-annotation-contents-string.pdf')
   elif mode=='late-control-replace':change(out/'pdfcpu/control-annotation-contents-string.pdf',inp.read_bytes())
   elif mode=='late-negative-delete':change(out/'pdfcpu/negative-annotation-contents-string.txt')
   elif mode=='late-negative-replace':change(out/'pdfcpu/negative-annotation-contents-string.txt',b'exit=0\nvalidation ok\n')
   elif mode=='late-report-delete':change(out/'pdfcpu/standards.properties')
   elif mode=='late-binary':
    x=root/'.build-cache/pdfcpu/0.15.0/pdfcpu';change(x,x.read_bytes()+b'\x00')
   elif mode=='late-pin':
    x=root/'scripts/pdfcpu-pin.properties';change(x,x.read_bytes()+b'\ntimeout-ms=10001\n')
   elif mode=='late-input':change(inp,inp.read_bytes()+b'\n% independent source change\n')
   elif mode=='late-copy':
    x=out/'extraction.pdf';change(x,x.read_bytes()+b'\n% independent retained source change\n')
  except Exception as e:mutation['error']=repr(e)
 stdout,stderr=proc.communicate(timeout=180)
 (case/'stdout.txt').write_bytes(stdout);(case/'stderr.txt').write_bytes(stderr)
 result=props(out/'result.properties') if (out/'result.properties').exists() else {}
 record={'case':name,'mode':mode,'source':source,'exit':proc.returncode,'seconds':time.monotonic()-start,'input_sha256':sha(original),'declarations':result.get('declarations'),'qualified_rule_count':result.get('qualified-rule-count'),'mutation':mutation,'result':result}
 (case/'run.json').write_text(json.dumps(record,indent=2)+'\n');(case/'identities-after.json').write_text(json.dumps(manifest(root),indent=2)+'\n');(case/'output-identities.json').write_text(json.dumps(manifest(out),indent=2)+'\n')
 print(json.dumps({k:record[k] for k in ['case','mode','exit','seconds','declarations','qualified_rule_count']}),flush=True)
 return record
if __name__=='__main__':run(*sys.argv[1:])
