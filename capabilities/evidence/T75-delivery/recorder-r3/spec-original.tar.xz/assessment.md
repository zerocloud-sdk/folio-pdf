# Incremental Spec review — declaration standards

One P1 finding, five independent actual CLI reproductions. This is not the final #75 gate.

The exact frozen seven-group union contains 334 unique rules (60+24+8+81+50+94+17); all 334 fixed source-control hashes agree. All 1,084 frozen source/class/JAR identities and the unmodified seed tool/model/profile root remained unchanged.

`T13DeclarationStandards.java:62–90` reads a group once, then only rechecks input and tool/authority identities. `StandardsEvidenceCommand.java:116–152` does not bind the persisted raw negative report to the actual observation after it is written. Five probes finish `declarations=pass`, `qualified-rule-count=334` despite a retained control PDF being deleted/replaced, a negative report being changed to `exit=0 / validation ok`, or an entire group record being deleted. The fifth probe modifies the first negative report while that group is still running, before its standards.properties exists; first hashing files only at group return would absorb those altered bytes.

This conflicts with the Objective's retained-control requirement and frozen contract lines 333–339. Actual output identities must be bound when produced and reverified, including a verifiable downstream manifest, before publishing PASS.

21 actual CLI invocations: 16 expected outcomes, 5 false PASS variants of this one issue. Observed: 10 PASS, 10 INDETERMINATE, 1 FAIL. Four original PDF2 Sources and the explicitly authored PDF2 nested positive pass. The unchanged PDF1.7 nested source is correctly outside this fixed PDF2 publication qualification (IND/274). Initial missing controls/tool identity mismatches, late binary/pin/input/copy changes, and a genuine invalid PDF produce safe non-PASS outcomes.

Every argv, input, original changed artifact, raw report, before/after root identities and frozen source identity is retained under this directory. See `assessment.json`, `rule-union.json`, `identity-final-check.json`, `probes.py`, and per-case `run.json`. No repository edits, Maven, or Native oracle.
