package net.zerocloud.pdf.acceptance;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import org.junit.Rule;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.rules.TemporaryFolder;

/** Qualifies actual independent font checks using original legal and illegal PDFs. */
@Category(IndependentTools.class)
public final class T13StandardsQualificationTest {
    @Rule public final TemporaryFolder temporary = new TemporaryFolder();

    @Test
    public void declarationRecorderRejectsWholePinChangesAfterItsGroupHasFinished() throws Exception {
        changedAfterFirstGroup(false);
    }

    @Test
    public void declarationRecorderRejectsBinaryChangesAfterItsGroupHasFinished() throws Exception {
        changedAfterFirstGroup(true);
    }

    private void changedAfterFirstGroup(boolean binary) throws Exception {
        Path root = Paths.get(System.getProperty("repositoryRoot")).toAbsolutePath();
        Path staged = declarationRoot(root, binary ? "late-binary" : "late-pin");
        final Path changed;
        if (binary) {
            Files.delete(staged.resolve(".build-cache"));
            Files.createDirectory(staged.resolve(".build-cache"));
            Files.createSymbolicLink(staged.resolve(".build-cache/arlington"), root.resolve(".build-cache/arlington"));
            changed = staged.resolve(".build-cache/pdfcpu/0.15.0/pdfcpu");
            Files.createDirectories(changed.getParent());
            Files.copy(root.resolve(".build-cache/pdfcpu/0.15.0/pdfcpu"), changed, java.nio.file.StandardCopyOption.COPY_ATTRIBUTES);
        } else {
            changed = staged.resolve("scripts/pdfcpu-pin.properties");
        }
        Path output = staged.resolve("observation");
        java.util.concurrent.FutureTask<Void> mutation = new java.util.concurrent.FutureTask<Void>(() -> {
            long deadline = System.nanoTime() + java.util.concurrent.TimeUnit.SECONDS.toNanos(30);
            while (!Files.isRegularFile(output.resolve("pdfcpu/standards.properties"))) {
                if (System.nanoTime() >= deadline) { throw new AssertionError("No completed pdfcpu observation"); }
                Thread.sleep(5);
            }
            Files.write(changed, binary ? new byte[] {0} : "\ntimeout-ms=11000\n".getBytes(StandardCharsets.US_ASCII),
                    java.nio.file.StandardOpenOption.APPEND);
            return null;
        });
        Thread writer = new Thread(mutation, "t13-declaration-authority-control");
        writer.start();
        try {
            T13EvidenceCommand.main(new String[] {"declaration-standards", staged.toString(),
                root.resolve("capabilities/profiles/T13-text/fixtures/marked-structure.pdf").toString(), output.toString()});
        } finally {
            mutation.get(35, java.util.concurrent.TimeUnit.SECONDS);
        }
        PinProperties result = PinProperties.load(output.resolve("result.properties"), "Late changed T13 authority");
        assertEquals("indeterminate", result.required("declarations"));
        assertEquals("0", result.required("qualified-rule-count"));
    }

    @Test
    public void declarationRecorderRejectsChangedWholeToolPinsEvenWithTheGenuineCheckers() throws Exception {
        Path root = Paths.get(System.getProperty("repositoryRoot")).toAbsolutePath();
        for (String name : new String[] {"pdfcpu", "t13-arlington"}) {
            Path staged = declarationRoot(root, "changed-" + name);
            Path pin = staged.resolve("scripts/" + name + "-pin.properties");
            Files.write(pin, (new String(Files.readAllBytes(pin), StandardCharsets.US_ASCII)
                    + "\ntimeout-ms=11000\n").getBytes(StandardCharsets.US_ASCII));
            Path output = staged.resolve("observation");
            T13EvidenceCommand.main(new String[] {"declaration-standards", staged.toString(),
                root.resolve("capabilities/profiles/T13-text/fixtures/marked-structure.pdf").toString(), output.toString()});
            PinProperties result = PinProperties.load(output.resolve("result.properties"), "Changed T13 pin");
            assertEquals(name, "indeterminate", result.required("declarations"));
        }
    }

    private Path declarationRoot(Path root, String name) throws Exception {
        Path base = Paths.get(System.getProperty("folio.t13.declarationControls", temporary.getRoot().toString()));
        Files.createDirectories(base);
        Path staged = Files.createDirectory(base.resolve(name));
        for (String link : new String[] {"capabilities", "build-tools", ".build-cache"}) {
            Files.createSymbolicLink(staged.resolve(link), root.resolve(link));
        }
        Files.createDirectory(staged.resolve("scripts"));
        for (String pin : new String[] {"pdfcpu", "t13-arlington"}) {
            Files.copy(root.resolve("scripts/" + pin + "-pin.properties"), staged.resolve("scripts/" + pin + "-pin.properties"));
        }
        return staged;
    }

    @Test
    public void declarationRecorderQualifiesTheExactRuleUnionWithEveryActualNegativeControl() throws Exception {
        Path root = Paths.get(System.getProperty("repositoryRoot")).toAbsolutePath();
        Path input = root.resolve("capabilities/profiles/T13-text/fixtures/marked-structure.pdf");
        Path output = Paths.get(System.getProperty("folio.t13.declarationOutput",
                temporary.getRoot().toPath().resolve("declarations").toString()));
        T13EvidenceCommand.main(new String[] {"declaration-standards", root.toString(), input.toString(), output.toString()});
        PinProperties result = PinProperties.load(output.resolve("result.properties"), "T13 declaration union");
        assertEquals("pass", result.required("declarations"));
        assertEquals("declarations-only", result.required("standards-scope"));
        assertEquals("334", result.required("qualified-rule-count"));
        assertEquals(EvidenceFiles.sha256(input), result.required("input-sha256"));
        assertEquals(EvidenceFiles.sha256(input), EvidenceFiles.sha256(output.resolve("extraction.pdf")));
        java.util.Set<String> observed = new java.util.TreeSet<String>();
        for (String group : new String[] {"pdfcpu", "arlington-core", "arlington-fonts", "arlington-text",
                "arlington-cid", "arlington-descriptors", "arlington-cmaps"}) {
            Path directory = output.resolve(group);
            PinProperties record = PinProperties.load(directory.resolve("standards.properties"), "T13 " + group);
            assertEquals("pass", record.required("result"));
            assertEquals(EvidenceFiles.sha256(input), record.required("input-sha256"));
            assertEquals(EvidenceFiles.sha256(root.resolve("capabilities/profiles/T13-standards/" + group + ".properties")),
                    record.required("profile-sha256"));
            assertEquals(EvidenceFiles.sha256(root.resolve("scripts/" + (group.startsWith("arlington") ? "t13-arlington" : group)
                    + "-pin.properties")), record.required("pin-sha256"));
            for (String rule : record.required("covered-rules").split(",")) {
                assertTrue("Duplicate rule " + rule, observed.add(rule));
                assertTrue(Files.size(directory.resolve("control-" + rule + ".pdf")) > 0);
                assertTrue(Files.size(directory.resolve("negative-" + rule + ".txt")) > 0);
            }
        }
        assertEquals(new java.util.TreeSet<String>(Files.readAllLines(
                root.resolve("capabilities/profiles/T13-standards/required-rules.txt"), StandardCharsets.US_ASCII)), observed);
        assertEquals(334, observed.size());
    }

    @Test
    public void glyphQualificationAcceptsLegalTokensAndPrecisionAndRefusesUnobservedMappings() throws Exception {
        Path root = Paths.get(System.getProperty("repositoryRoot")).toAbsolutePath();
        Path records = Paths.get(System.getProperty("folio.t13.glyphStandardsOutput",
                temporary.getRoot().toPath().resolve("glyph-boundaries").toString()));
        Files.createDirectory(records);
        for (String kind : new String[] {"delimiter", "fractional", "comments", "base-encoding",
                "empty-differences", "unmapped-glyph", "numeric-range"}) {
            Path input = root.resolve("capabilities/profiles/T13-standards/fixtures/glyph-boundary-" + kind + ".pdf");
            Path output = records.resolve(kind);
            StandardsEvidenceCommand.main(new String[] {output.toString(), root.resolve("scripts/t13-arlington-pin.properties").toString(),
                root.resolve("capabilities/profiles/T13-standards/arlington-text.properties").toString(), input.toString()});
            PinProperties result = PinProperties.load(output.resolve("standards.properties"), "T13 glyph boundaries");
            String expected = "delimiter".equals(kind) || "fractional".equals(kind) || "comments".equals(kind) ? "pass" : "indeterminate";
            assertEquals(new String(Files.readAllBytes(output.resolve("findings.txt")), StandardCharsets.UTF_8),
                    expected, result.required("result"));
            assertEquals(EvidenceFiles.sha256(input), result.required("input-sha256"));
        }
    }

    @Test
    public void allOriginalCasesQualifyTheirSharedPageFormStreamAndAnnotationRules() throws Exception {
        Path root = Paths.get(System.getProperty("repositoryRoot")).toAbsolutePath();
        Path records = Paths.get(System.getProperty("folio.t13.coreStandardsOutput",
                temporary.getRoot().toPath().resolve("core").toString()));
        Files.createDirectory(records);
        for (String product : T13Corpus.PRODUCTS) {
            Path input = root.resolve("capabilities/profiles/T13-text/fixtures/" + product + ".pdf");
            if ("nested-split-type3".equals(product)) {
                input = root.resolve("capabilities/profiles/T13-standards/fixtures/positive-pdf20-nested-split-type3.pdf");
            }
            for (String checker : new String[] {"pdfcpu", "arlington-core", "arlington-text", "arlington-cid", "arlington-descriptors", "arlington-cmaps"}) {
                Path output = records.resolve(product + "-" + checker);
                Path pin = root.resolve("scripts/" + (checker.startsWith("arlington") ? "t13-arlington" : checker)
                        + "-pin.properties");
                Path profile = root.resolve("capabilities/profiles/T13-standards/" + checker + ".properties");
                StandardsEvidenceCommand.main(new String[] {output.toString(), pin.toString(), profile.toString(), input.toString()});
                PinProperties result = PinProperties.load(output.resolve("standards.properties"), "T13 core rules");
                assertEquals(new String(Files.readAllBytes(output.resolve("findings.txt")), StandardCharsets.UTF_8),
                        "pass", result.required("result"));
                assertEquals("T13-text-logical-structure", result.required("profile"));
                assertEquals(EvidenceFiles.sha256(input), result.required("input-sha256"));
            }
        }
    }

    @Test
    public void originalEmbeddedFontsAndInheritedCMapsQualifyEveryOwningFontAndVerticalWidths() throws Exception {
        Path root = Paths.get(System.getProperty("repositoryRoot")).toAbsolutePath();
        Path pin = root.resolve(System.getProperty("folio.t13.arlingtonPin", "scripts/t13-arlington-pin.properties"));
        Path profile = root.resolve("capabilities/profiles/T13-standards/arlington-fonts.properties");
        Path records = Paths.get(System.getProperty("folio.t13.fontStandardsOutput",
                temporary.getRoot().toPath().resolve("standards").toString()));
        Files.createDirectory(records);
        for (String kind : new String[] {"direct", "inherited", "named-type3", "unnamed-type3",
                "font-name-only-type3", "descriptor-name-only-type3"}) {
            Path input = root.resolve("capabilities/profiles/T13-standards/fixtures/positive-" + kind + "-fonts.pdf");
            Path output = records.resolve(kind);
            StandardsEvidenceCommand.main(new String[] {output.toString(), pin.toString(), profile.toString(), input.toString()});
            PinProperties result = PinProperties.load(output.resolve("standards.properties"), "T13 original fonts");
            assertEquals(new String(Files.readAllBytes(output.resolve("findings.txt")), StandardCharsets.UTF_8),
                    "pass", result.required("result"));
            assertEquals("T13-text-logical-structure", result.required("profile"));
            assertEquals(EvidenceFiles.sha256(input), result.required("input-sha256"));
            assertEquals(8, result.required("covered-rules").split(",").length);
            for (String rule : result.required("covered-rules").split(",")) {
                assertTrue(Files.size(output.resolve("control-" + rule + ".pdf")) > 0);
                assertTrue(Files.size(output.resolve("negative-" + rule + ".txt")) > 0);
            }
        }
    }
}
