# Retained-artifact Standards closure and adjacent publication finding

This is a bounded incremental #75 Standards review, not the final clean-context gate. Overall baseline remains `5b1603c435f11c40368f75b7b9a2777c9c5e9761`. Only Java sources and the execution classpath from `/tmp/t75-declaration-retained-closure-snapshot.0_arb179` were used. The frozen manifest's 1082 file identities and classpath were checked before/after. No Maven, implementation edits or Native oracle. Whole class trees and ELF files were not copied: the archive references the immutable classpath and genuine tools by original path and SHA. Real cache/model/pin files were untouched.

## Original P1 closure

The original late replacement of `pdfcpu/control-annotation-contents-string.pdf` now returns INDETERMINATE with zero qualified rules. The same replacement during the first group's negative-control loop is also detected. Early and late negative-report changes, control deletion, group-record deletion, findings changes and identities-before changes all return INDETERMINATE0. Same-byte control-file and completed-group-directory symlinks are rejected, as is a preplanted identities-after symlink. Expected negative PDF hashes come from the fixed profile, and report expectations come from producer strings, avoiding a late snapshot of already-modified bytes.

The normal genuine run still returns PASS334. Its producer manifest has 686 expected files; all listed bytes and the top-level manifest digest independently match, with no links. The original retained-PDF/report P1 is closed by these observations. Historical evidence under `/tmp/t75-declaration-standards-review-wjysmimc` remains untouched.

## Separate adjacent hard finding

Final publication is still outside the validated writer boundary. During the first group's completion, the reviewer preplanted either `declarations.txt` or `retained-files.sha256` as a symlink to a fresh empty file elsewhere in this review's own /tmp directory. Both actual CLI executions return PASS334 and write the summary/manifest into that outside target. This is not a transient byte-hash mismatch: the 686 expected file bytes and manifest digest match in both cases. The issue is bypassing the regular-file/NOFOLLOW and output-directory boundary.

`T13DeclarationStandards.java:94` verifies the retained map before the final summary is added at line 104 and before the manifest is written at line 106. `RetainedEvidence.write` follows the supplied link when writing; its regular-file/link checks happen only in verify. The declarations file therefore never reaches those checks, and the manifest uses EvidenceFiles.write directly. The identical preplanted identities-after control is correctly rejected because it is added before verify; this isolates the terminal-publication gap. Apply the same safe writer boundary to the final summary/manifest and final result publication before reporting success. The parent independently reports a corresponding result.properties variant; that third variant was not executed by this reviewer and is not included in the actual count.

See `preplanted-declarations-symlink-result.json` and `preplanted-manifest-symlink-result.json` for exact argv/cwd, event timing, link target and all output identities. The outside targets are private review files retained in this archive; no real external artifact was overwritten. Ordinary retained files and directories with the same bytes are rejected when they become links, confirming this inconsistency is confined to the last publication stage.

No new actionable heuristic smell is reported. The existing repo provenance and Acceptance Evidence standards, frozen contract's retained-control/identity requirements, ADR-0029/0035/0040 and full code-review smell baseline were applied.

## Actual observations and reproduction

Fourteen actual public CLI executions completed: one normal PASS334, eleven expected INDETERMINATE0 mutation/link controls, and two adjacent publication-gap PASS334 observations. All process exits are zero. all-observations.json preserves every command, cwd, input SHA, event, runtime result, resource identity and output identity. All PDFs, raw group reports, findings, identities and manifests remain at the corresponding *-output path. `manifest-verification.json` records the independent byte/link checks rather than implying every failure case should have a valid manifest.

`probes.py` and `adjacent_probes.py` are independent Python stdlib public-CLI drivers. Their case roots copy only the small fixed profiles/pins/patch/fixtures and reference the real `.build-cache` read-only through a link. External tools are never mutated. The classpath directly references the frozen directory. Original PDF inputs are byte copies of the project's hash-pinned original fixtures; neither driver imports the product or generator. To rerun a command, use a new output directory and new private root. Do not reuse or delete previous evidence.
