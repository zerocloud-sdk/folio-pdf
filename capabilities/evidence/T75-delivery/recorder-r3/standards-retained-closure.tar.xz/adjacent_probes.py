from pathlib import Path
import json,shutil
from probes import HERE,ROWS,run,replace,identities
def directory_link(out,source,label):
 path=out/'pdfcpu';target=HERE/(label+'-external-group');before=identities(path);path.rename(target);path.symlink_to(target,target_is_directory=True);return {'path':str(path),'symlink-target':str(target),'unchanged-files':before}
run('same-bytes-group-directory-symlink',directory_link)
run('preplanted-manifest-symlink',replace('retained-files.sha256',link=True))
(HERE/'adjacent-results.json').write_text(json.dumps(ROWS,indent=2)+'\n')
