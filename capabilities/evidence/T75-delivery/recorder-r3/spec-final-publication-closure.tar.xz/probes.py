from pathlib import Path
import hashlib,json,subprocess,sys,time
B=Path(__file__).resolve().parent;ROOT=Path(json.loads((B/'context.json').read_text())['root']);CP=(B/'classpath.txt').read_text().strip()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def run(name,mode):
 c=B/name;c.mkdir();o=c/'out';i=B/'input.pdf';target=c/'outside.txt';target.write_bytes(b'Original independent outside target; must remain unchanged.\n');before=sha(target)
 a=['java','-cp',CP,'net.zerocloud.pdf.acceptance.T13EvidenceCommand','declaration-standards',str(ROOT),str(i),str(o)]
 (c/'argv.json').write_text(json.dumps(a,indent=2)+'\n');t=time.monotonic();p=subprocess.Popen(a,stdout=subprocess.PIPE,stderr=subprocess.PIPE);mut={}
 if mode!='positive':
  trigger=o/'arlington-core'
  while not trigger.is_dir():
   if p.poll() is not None:raise RuntimeError('No trigger')
   if time.monotonic()-t>60:raise RuntimeError('Timed out awaiting trigger')
   time.sleep(.002)
  if mode=='missing-control':
   file=o/'pdfcpu/control-annotation-contents-string.pdf';mut={'path':str(file),'before_sha256':sha(file)};file.unlink()
  else:
   file=o/mode;file.symlink_to(target);mut={'path':str(file),'target':str(target)}
 x,y=p.communicate(timeout=120);(c/'stdout.txt').write_bytes(x);(c/'stderr.txt').write_bytes(y)
 result={}
 if (o/'result.properties').is_file() and not (o/'result.properties').is_symlink():result=dict(l.split('=',1) for l in (o/'result.properties').read_text().splitlines() if '=' in l and not l.startswith('#'))
 r={'name':name,'mode':mode,'exit':p.returncode,'seconds':time.monotonic()-t,'mutation':mut,'external_sha_before':before,'external_sha_after':sha(target),'external_unchanged':before==sha(target),'result':result,'input_sha256':sha(i)}
 (c/'run.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'name':name,'exit':p.returncode,'verdict':result.get('declarations'),'count':result.get('qualified-rule-count'),'external_unchanged':r['external_unchanged']}),flush=True)
if __name__=='__main__':run(*sys.argv[1:])
