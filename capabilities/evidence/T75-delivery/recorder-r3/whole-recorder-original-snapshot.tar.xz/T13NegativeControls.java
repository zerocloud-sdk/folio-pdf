package net.zerocloud.pdf.acceptance;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;
import net.zerocloud.pdf.WorkflowExecutionProfile;

/** Actual document defects observed against unchanged original expectations. */
final class T13NegativeControls {
    private T13NegativeControls() { }

    static Properties record(Path root, Path output, WorkflowExecutionProfile execution, String release) throws Exception {
        T13Corpus corpus = new T13Corpus(root);
        Properties result = new Properties();
        result.setProperty("profile", T13Corpus.PROFILE);
        result.setProperty("native-execution-profile", execution.name());
        Path syntax = Files.createDirectory(output.resolve("syntax"));
        Path truncated = syntax.resolve("extraction.pdf");
        Files.write(truncated, "%PDF-2.0\n1 0 obj\n".getBytes(StandardCharsets.US_ASCII));
        Properties syntaxResult = T13IndependentEvidence.recordSyntax(root, truncated, syntax, release);
        T13EvidenceCommand.save(syntax.resolve("result.properties"), syntaxResult);
        result.setProperty("syntax", syntaxResult.getProperty("syntax"));

        Path standards = Files.createDirectory(output.resolve("standards"));
        Path malformed = standards.resolve("extraction.pdf");
        String original = new String(Files.readAllBytes(corpus.source("marked-structure")), StandardCharsets.ISO_8859_1);
        String catalog = "/Type /Catalog";
        if (!original.contains(catalog) || original.indexOf(catalog) != original.lastIndexOf(catalog)) {
            throw new IOException("T13 standards control does not identify one Catalog declaration");
        }
        Files.write(malformed, original.replace(catalog, "/Type /Bogus  ").getBytes(StandardCharsets.ISO_8859_1));
        Properties standardsResult = T13DeclarationStandards.record(root, malformed, standards);
        T13EvidenceCommand.save(standards.resolve("result.properties"), standardsResult);
        result.setProperty("standards", standardsResult.getProperty("declarations"));

        Path semantic = Files.createDirectory(output.resolve("semantic"));
        Properties semanticResult = semantic(root, semantic, execution);
        T13EvidenceCommand.save(semantic.resolve("result.properties"), semanticResult);
        result.setProperty("semantic", semanticResult.getProperty("semantic"));
        Path visual = Files.createDirectory(output.resolve("visual"));
        Properties visualResult = visual(root, visual, release);
        T13EvidenceCommand.save(visual.resolve("result.properties"), visualResult);
        result.setProperty("visual", visualResult.getProperty("visual"));
        corpus.verifySources();
        return result;
    }

    static Properties semantic(Path root, Path output, WorkflowExecutionProfile execution) throws Exception {
        T13Corpus corpus = new T13Corpus(root);
        Properties result = new Properties();
        result.setProperty("profile", T13Corpus.PROFILE);
        result.setProperty("native-execution-profile", execution.name());
        boolean positive = true;
        for (String product : T13Corpus.PRODUCTS) {
            Path directory = Files.createDirectory(output.resolve("positive-" + product));
            Path input = directory.resolve("extraction.pdf");
            Files.copy(corpus.source(product), input);
            Properties observed = T13ExtractionSemantics.inspect(root, input, product, directory, execution);
            T13EvidenceCommand.save(directory.resolve("result.properties"), observed);
            result.setProperty("positive." + product, observed.getProperty("semantic"));
            positive &= "pass".equals(observed.getProperty("semantic"));
        }
        result.setProperty("positive", positive ? "pass" : "indeterminate");
        String[][] controls = {
            {"contents-order", "nested-split-type3", "/Contents [4 0 R 5 0 R]", "/Contents [5 0 R 4 0 R]"},
            {"form-position", "nested-split-type3", "/Matrix [2 0 0 1 5 10]", "/Matrix [2 0 0 1 6 10]"},
            {"font-width", "nested-split-type3", "/Widths [500]", "/Widths [600]"},
            {"replacement", "marked-structure", "/ActualText (Outer)", "/ActualText (Other)"},
            {"alternate", "marked-structure", "/Alt (PageAlt)", "/Alt (PageBad)"},
            {"language", "marked-structure", "/Lang (fr)", "/Lang (de)"},
            {"mcr", "marked-structure", "/Stm 7 0 R /MCID 0", "/Stm 7 0 R /MCID 1"},
            {"parent-tree", "marked-structure", "/Nums [0 [10 0 R] 1 [10 0 R] 2 10 0 R]",
                    "/Nums [0 [11 0 R] 1 [10 0 R] 2 10 0 R]"},
            {"object-reference", "marked-structure", "/Obj 12 0 R", "/Obj 11 0 R"},
            {"role-target", "marked-structure", "/Intermediate [/Document 15 0 R]", "/Intermediate [/Document 14 0 R]"},
            {"empty-replacement", "marked-structure", "/ActualText ()", "              "},
            {"namespace-reference", "marked-structure", "/S /Span /NS 15 0 R", "/S /Span /NS 14 0 R"}
        };
        boolean effective = positive;
        for (String[] control : controls) {
            Path directory = Files.createDirectory(output.resolve(control[0]));
            Path input = directory.resolve("extraction.pdf");
            String original = new String(Files.readAllBytes(corpus.source(control[1])), StandardCharsets.ISO_8859_1);
            if (control[2].length() != control[3].length() || !original.contains(control[2])
                    || original.indexOf(control[2]) != original.lastIndexOf(control[2])) {
                throw new IOException("T13 semantic control does not identify one fixed source mutation: " + control[0]);
            }
            Files.write(input, original.replace(control[2], control[3]).getBytes(StandardCharsets.ISO_8859_1));
            Properties observed = T13ExtractionSemantics.inspect(root, input, control[1], directory, execution);
            T13EvidenceCommand.save(directory.resolve("result.properties"), observed);
            result.setProperty(control[0], observed.getProperty("semantic"));
            effective &= "fail".equals(observed.getProperty("semantic"));
        }
        corpus.verifySources();
        result.setProperty("control-count", Integer.toString(controls.length));
        result.setProperty("semantic", effective ? "fail" : "indeterminate");
        return result;
    }

    static Properties visual(Path root, Path output, String release) throws Exception {
        T13Corpus corpus = new T13Corpus(root);
        String product = "nested-split-type3";
        Path source = root.resolve("capabilities/profiles/T13-text")
                .resolve(corpus.expected("sources." + product + ".path"));
        String sourceHash = EvidenceFiles.sha256(source);
        Properties result = new Properties();
        result.setProperty("profile", T13Corpus.PROFILE);
        result.setProperty("source-sha256", sourceHash);
        Path positive = Files.createDirectory(output.resolve("positive"));
        Properties baseline = T13IndependentEvidence.recordVisual(root, source, product, positive, release);
        T13EvidenceCommand.save(positive.resolve("result.properties"), baseline);
        result.setProperty("positive", baseline.getProperty("visual"));
        boolean effective = "pass".equals(baseline.getProperty("visual"));
        Path fontPositive = Files.createDirectory(output.resolve("positive-embedded-font-kinds"));
        Properties fonts = T13IndependentEvidence.recordVisual(root, corpus.source("embedded-font-kinds"),
                "embedded-font-kinds", fontPositive, release);
        T13EvidenceCommand.save(fontPositive.resolve("result.properties"), fonts);
        result.setProperty("positive.embedded-font-kinds", fonts.getProperty("visual"));
        effective &= "pass".equals(fonts.getProperty("visual"));
        result.setProperty("positive", effective ? "pass" : "indeterminate");
        String[][] controls = {
            {"glyph-ink", "nested-split-type3", "0 0 400 600 re f", "0 0 300 600 re f"},
            {"form-position", "nested-split-type3", "/Matrix [2 0 0 1 5 10]", "/Matrix [2 0 0 1 6 10]"},
            {"simple-font-position", "embedded-font-kinds", "1 0 0 1 10 20 Tm", "1 0 0 1 11 20 Tm"},
            {"vertical-font-position", "embedded-font-kinds", "1 0 0 1 40 80 Tm", "1 0 0 1 41 80 Tm"}
        };
        for (String[] control : controls) {
            String original = new String(Files.readAllBytes(corpus.source(control[1])), StandardCharsets.ISO_8859_1);
            if (control[2].length() != control[3].length() || !original.contains(control[2])
                    || original.indexOf(control[2]) != original.lastIndexOf(control[2])) {
                throw new IOException("T13 visual control does not identify one fixed source mutation");
            }
            Path directory = Files.createDirectory(output.resolve(control[0]));
            Path defect = directory.resolve("extraction.pdf");
            Files.write(defect, original.replace(control[2], control[3]).getBytes(StandardCharsets.ISO_8859_1));
            Properties observed = T13IndependentEvidence.recordVisual(root, defect, control[1], directory, release);
            T13EvidenceCommand.save(directory.resolve("result.properties"), observed);
            String verdict = observed.getProperty("visual");
            result.setProperty(control[0], verdict);
            effective &= "fail".equals(verdict);
        }
        corpus.verifySources();
        result.setProperty("control-count", Integer.toString(controls.length));
        result.setProperty("visual", effective ? "fail" : "indeterminate");
        return result;
    }
}
