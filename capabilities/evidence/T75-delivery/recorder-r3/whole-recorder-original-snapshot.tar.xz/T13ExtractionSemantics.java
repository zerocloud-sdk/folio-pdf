package net.zerocloud.pdf.acceptance;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Properties;
import net.zerocloud.pdf.DocumentFailure;
import net.zerocloud.pdf.DocumentSource;
import net.zerocloud.pdf.DocumentWorkflow;
import net.zerocloud.pdf.PdfOutputPolicy;
import net.zerocloud.pdf.PdfVersion;
import net.zerocloud.pdf.SaveMode;
import net.zerocloud.pdf.TextStructureExtraction;
import net.zerocloud.pdf.WorkflowExecutionProfile;
import net.zerocloud.pdf.WorkflowOutcome;
import net.zerocloud.pdf.WorkflowRequest;
import net.zerocloud.pdf.query.ExtractTextAndStructure;

/** Independent decoded-graph preservation paired with complete public extraction values. */
final class T13ExtractionSemantics {
    private static final String OBSERVER_SHA256 = "42bc5271c3f2e9d3b8c91eb4873f60ec4943dbcb6dc2a5f010c0fc1f88d94d2a";
    private static final String SCOPE = "independent-qpdf-decoded-graph-preservation";

    private T13ExtractionSemantics() { }

    static Properties inspect(Path root, Path input, String product, Path output, WorkflowExecutionProfile execution)
            throws IOException, InterruptedException {
        T13Corpus corpus = new T13Corpus(root);
        Properties expected = corpus.extraction(product);
        String exactHash = EvidenceFiles.sha256(input);
        Properties result = new Properties();
        result.setProperty("profile", T13Corpus.PROFILE);
        result.setProperty("input-sha256", exactHash);
        result.setProperty("semantic-scope", SCOPE);
        result.setProperty("semantic", "indeterminate");
        result.setProperty("execution-profile", "unavailable");
        result.setProperty("public-observation", "indeterminate");
        Path observer = root.resolve("scripts/t13-semantics.py");
        Path python = Paths.get("/usr/bin/python3.12");
        try {
            if (!OBSERVER_SHA256.equals(EvidenceFiles.sha256(observer))) {
                throw new IOException("Qualified T13 semantic observer identity mismatch");
            }
            ProcessResult command = ExternalProcess.run(python, output, 120000, 1 << 20,
                    observer.toString(), root.toString(), input.toString(), product, output.resolve("qpdf").toString());
            EvidenceFiles.write(output.resolve("semantic-command.txt"), "observer: scripts/t13-semantics.py\n"
                    + "input exact SHA-256: " + exactHash + "\nexit-code: " + command.exitCode + "\n" + command.combinedOutput());
            if (command.exitCode != 0) { throw new IOException("Independent qpdf semantic command failed"); }
            try (InputStream values = Files.newInputStream(output.resolve("qpdf/result.properties"))) { result.load(values); }
            if (!T13Corpus.PROFILE.equals(result.getProperty("profile"))
                    || !exactHash.equals(result.getProperty("input-sha256"))
                    || !SCOPE.equals(result.getProperty("semantic-scope"))
                    || !OBSERVER_SHA256.equals(result.getProperty("observer-sha256"))
                    || !EvidenceFiles.sha256(python.toRealPath()).equals(result.getProperty("python-executable-sha256"))) {
                throw new IOException("Independent T13 semantic record identity mismatch");
            }
            if ("pass".equals(result.getProperty("semantic"))) {
                WorkflowOutcome<TextStructureExtraction> outcome = new DocumentWorkflow().execute(WorkflowRequest.builder()
                        .source("input", DocumentSource.path(input)).primarySource("input").saveMode(SaveMode.REWRITE)
                        .outputPolicy(PdfOutputPolicy.version(PdfVersion.PDF_2_0)).executionProfile(execution).build(),
                        session -> session.query(ExtractTextAndStructure.version1(T13Corpus.limits())));
                result.setProperty("execution-profile", outcome.getExecutionProfile().name());
                if (outcome.getExecutionProfile() != execution || !outcome.getPublicationReceipts().isEmpty()) {
                    throw new IOException("T13 public Query execution or publication mismatch");
                }
                Properties observed = T13ExtractionObservation.observe(outcome.getResult());
                T13EvidenceCommand.save(output.resolve("observation.properties"), observed);
                boolean matched = expected.equals(observed);
                result.setProperty("public-observation", matched ? "pass" : "fail");
                if (!matched) {
                    result.setProperty("semantic", "fail");
                    result.setProperty("finding", "The complete public extraction differs from the authored expectations");
                }
            }
            corpus.verifySources();
            if (!OBSERVER_SHA256.equals(EvidenceFiles.sha256(observer))) {
                throw new IOException("Qualified T13 semantic observer changed during execution");
            }
        } catch (IOException unavailable) {
            result.setProperty("semantic", "indeterminate");
            result.setProperty("finding", unavailable.getMessage());
        } catch (DocumentFailure unavailable) {
            result.setProperty("semantic", "indeterminate");
            result.setProperty("finding", "The bounded public Query was unavailable: " + unavailable.getCode());
        }
        if (!exactHash.equals(EvidenceFiles.sha256(input))) {
            result.setProperty("semantic", "indeterminate");
            result.setProperty("finding", "Input changed during semantic observation");
        }
        EvidenceFiles.write(output.resolve("semantic.txt"), "Input exact SHA-256: " + exactHash + "\n"
                + result.getProperty("finding", "No qualified semantic finding was available") + "\n");
        return result;
    }
}
