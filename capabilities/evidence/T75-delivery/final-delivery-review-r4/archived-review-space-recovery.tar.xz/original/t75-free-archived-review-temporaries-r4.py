from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,os,shutil,tarfile,tempfile
root=Path('/home/ubuntu/IdeaProjects/open-pdf')
base=root/'capabilities/evidence/T75-delivery/certification-review-r4'
allow=[
('text-jdk11-and-jdk17-three-tuples-spec','/tmp/t75-final-spec-r4-text-three-rwzmbdzo','461c7a5848420fd6f21eb93603103871523f329947c541b72136fcd327274efb'),
('text-jdk17-and-jdk21-last-three-spec','/tmp/t75-final-spec-r4-text-last-three-9alkqepg','488763b6ddf90093ff255e8e2c27036e31527274d8decc6e84ee57a8eec11d11'),
('pages-eight-tuples-spec','/tmp/t75-final-spec-r4-pages-eight-85hw4hxz','fe70a77740b6d7885f9a84eb532472286f938f42de5ab98c2c4274ab4f4ffe2f'),
('metadata-eight-tuples-spec','/tmp/t75-r4-metadata-spec-qm8qa5w2','3d51ca531c82b78fe9f3db9da844bdfa42e8c4f6cd7d0b51a3a64f62f5a95e2b'),
('annotations-eight-tuples-spec','/tmp/t75-final-spec-r4-annotations-eight-2e38t91l','8dc9405652fe8af3f2c53d6279271e64186f177a2bd6a5e3fff70f8fb6636574')]
packet=Path(tempfile.mkdtemp(prefix='t75-archived-review-space-recovery-r4-',dir='/dev/shm'))
(packet/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
entries=[]
for name,temporary,expected_sha in allow:
 live=Path(temporary); assert live.parent==Path('/tmp') and live.is_dir() and not live.is_symlink()
 ip=base/(name+'-archive-identity.json'); identity=json.loads(ip.read_bytes()); archive=base/identity['archive']
 assert identity['original']==temporary and not identity['symbolic_links']
 assert sha(archive)==identity['sha256']==expected_sha
 expected={m['path']:m for m in identity['members']}; assert len(expected)==len(identity['members'])
 actual={}
 for p in live.rglob('*'):
  assert not p.is_symlink()
  if p.is_file():actual[p.relative_to(live).as_posix()]=p
 assert set(actual)==set(expected)
 seen=set(); total=0
 with tarfile.open(archive,'r:xz') as tar:
  for m in tar:
   assert m.isfile() or m.islnk()
   assert m.name in actual and m.name not in seen; seen.add(m.name)
   h=hashlib.sha256(); size=0
   with tar.extractfile(m) as retained,actual[m.name].open('rb') as source:
    while True:
     a=retained.read(1024*1024); b=source.read(len(a) if a else 1)
     assert a==b,(name,m.name)
     if not a:break
     h.update(a);size+=len(a)
   assert size==expected[m.name]['size'] and h.hexdigest()==expected[m.name]['sha256']
   total+=size
 assert seen==set(expected)
 entry={'original':temporary,'archive':str(archive.relative_to(root)),'sha256':expected_sha,'identity-sha256':sha(ip),'files':len(seen),'bytes':total,'complete-membership-and-byte-equality':True,'verified-utc':datetime.now(timezone.utc).isoformat(),'disk-free-before':shutil.disk_usage(root).free}
 (packet/(name+'-pre-removal.json')).write_text(json.dumps(entry,indent=2)+'\n')
 shutil.rmtree(live); assert not live.exists();assert sha(archive)==expected_sha
 entry['removed-utc']=datetime.now(timezone.utc).isoformat();entry['disk-free-after']=shutil.disk_usage(root).free
 (packet/(name+'-removed.json')).write_text(json.dumps(entry,indent=2)+'\n');entries.append(entry)
 print(name,len(seen),total,'bytes verified and temporary copy removed',flush=True)
receipt={'scope':'Remove only five completed raw-review task-created temporary directories after complete archive membership and byte equality verification. All repository archives, live certification evidence, phase1/phase2/final closure originals and source review originals remain. No recovery of historical lost derived summaries is claimed.','entries':entries,'free-bytes':shutil.disk_usage(root).free}
(packet/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
destination=Path('/tmp')/packet.name
shutil.copytree(packet,destination)
for p in packet.iterdir():assert p.read_bytes()==(destination/p.name).read_bytes()
Path('/tmp/t75-archived-review-space-recovery-r4-original-path.txt').write_text(str(destination)+'\n')
print('packet',destination,'free',receipt['free-bytes'],flush=True)
