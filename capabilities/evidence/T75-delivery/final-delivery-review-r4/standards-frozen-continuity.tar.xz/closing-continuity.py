import hashlib,json,pathlib
from auditlib import Audit,OUT,REPO,DELIVERY
A=Audit('closing');original=A.json(pathlib.Path('/tmp/t75-final-standards-xpr84_u3/new-source-identities.json'),'original-new-source-identities.json');freeze=A.json(DELIVERY/'final-validation-r4/source-and-contract-inputs.json')
paths={x['path'] for key in ['inputs','contract-inputs'] for x in freeze[key]};extra=[]
for row in original:
    if row['path'] not in paths:
        current=A.digest(REPO/row['path']);extra.append({'path':row['path'],'original-reviewed-sha256':row['sha256'],'current-sha256':current,'unchanged':current==row['sha256']})
assert all(x['unchanged'] for x in extra)
assert A.digest(REPO/'.gitattributes')=='7a6a25de64a0dbc04b9b3fefe0b233775855567ff2934003c33c03b144915981'
for key in ['inputs','contract-inputs']:
    for row in freeze[key]:assert A.digest(REPO/row['path'])==row['sha256']
for name in ['source-inspected-input-identities.json','evidence-inspected-input-identities.json','historical-inspected-input-identities.json']:
    data=json.loads((OUT/name).read_text())
    for row in data['selected-original-copies']:assert hashlib.sha256((OUT/row['copy']).read_bytes()).hexdigest()==row['sha256']
review=pathlib.Path('/tmp/t75-standards-historical-facade-counts-lgf_y3x4/report.md');A.read(review,'prior-historical-facade-report.md')
addendum=DELIVERY/'final-delivery-review-r3/historical-facade-counts.md';assert A.digest(addendum)=='b1819867dc2e0b25b8d62759fcf75b205dbd19715fe0723455dd7ed9684a2a37';A.read(addendum,'historical-facade-counts.md')
A.emit('source-and-scope-check',{'original-new-files':len(original),'original-new-files-outside-freeze':extra,'all-current1933-source30-contract-bytes-still-match':True,'all-selected-original-copy-bytes-verified':True,'gitattributes-previously-reviewed-sha256':'7a6a25de64a0dbc04b9b3fefe0b233775855567ff2934003c33c03b144915981','historical-facade-addendum-unchanged':True,'fresh-agent-created':False,'staged-index-reviewed':False,'active-annotations-read':False,'final-approval':False})
A.seal_inputs();print(json.dumps({'original-new-files':len(original),'original-new-files-outside-freeze':extra,'closing-source-contract-check':'PASS','gitattributes-unchanged':True,'historical-facade-addendum-unchanged':True,'scope':'Initial immutable continuity only'},indent=2))
