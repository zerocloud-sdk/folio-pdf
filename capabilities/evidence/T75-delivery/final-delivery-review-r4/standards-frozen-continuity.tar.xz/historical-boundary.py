import hashlib,json,pathlib,tarfile
from auditlib import Audit,OUT,REPO,DELIVERY
A=Audit('historical');base=DELIVERY/'final-certification-r3'
retained=A.json(base/'historical-raw-retention-receipt.json','historical-raw-retention-receipt.json');assert len(retained['archives'])==6
checks=[]
for row in retained['archives']:
    assert A.digest(base/row['archive'])==row['archive-sha256']
    assert A.digest(base/row['member-identities'])==row['member-identities-sha256']
    checks.append({'obligation':row['obligation'],'members-bound-by-retained-catalog':row['members'],'archive-sha256':row['archive-sha256'],'member-identities-sha256':row['member-identities-sha256'],'compressed-archive-and-catalog-unchanged':True,'full-historical-raw-members-replayed-in-this-review':False})
assert sum(x['members-bound-by-retained-catalog'] for x in checks)==254118
path=base/'historical-live-removal-command-archive-identity.json';identity=A.json(path,'historical-live-removal-command-archive-identity.json')
removal,raw=A.archive(identity,path,('receipt.json','result.json','command.json','command.log','archive-checks-before-removal.json','t75-remove-archived-r3-live.py','authority-before-removal.yaml'))
assert removal['member-count']==8
receipt=json.loads(raw['receipt.json']);result=json.loads(raw['result.json']);command=json.loads(raw['command.json'])
assert result['returncode']==0 and all(result[k]==v for k,v in command.items())
assert receipt['removed-files']==254118
assert raw['receipt.json']==A.read(base/'historical-live-removal-command-receipt.json','historical-live-removal-command-receipt.json')
for row in receipt['archive-checks']:
    counterpart=next(x for x in checks if x['obligation']==row['obligation'])
    assert row['archive-sha256']==counterpart['archive-sha256'] and row['member-identities-sha256']==counterpart['member-identities-sha256'] and row['members']==counterpart['members-bound-by-retained-catalog'] and row['every-archive-member-matches-live-original']
assert b'T75-foundation-20260913-r3' not in raw['authority-before-removal.yaml']
for suffix,member in [('command.json','command.json'),('result.json','result.json')]:assert A.read(base/('historical-live-removal-command-'+suffix),'removal-'+suffix)==raw[member]
A.read(pathlib.Path(identity['original'])/'t75-remove-archived-r3-live.py','original-removal-script.py')
assert not pathlib.Path(receipt['removed-live-root']).exists()
incident_path=DELIVERY/'certification-review-r3/annotations-reader-output-incident-and-closure.json';incident=A.json(incident_path,'annotations-reader-output-incident-and-closure.json')
assert A.digest(incident_path)=='3927ee99491a3f71fe24f4dc536cf086608b45e441289e6ab14a2033b3007149'
assert [x['known-pre-overwrite-bytes'] for x in incident['lost-derived-summary-paths']]==[55109,79646]
assert all(x['pre-overwrite-sha256'] is None for x in incident['lost-derived-summary-paths'])
ann_path=DELIVERY/'certification-review-r3/annotations-eight-spec-archive-identity.json';ann=A.json(ann_path)
assert A.digest(ann_path.parent/ann['archive'])==ann['sha256']
members={x['path']:x for x in ann['members']};original=pathlib.Path(ann['original'])
selected={}
for row in [incident['fresh-first-four-reinspection'],incident['JDK17-correct-scope-closure']]+incident['mislabeled-retained-bytes']:
    local=pathlib.Path(row['path']);name=local.relative_to(original).as_posix()
    assert members[name]['sha256']==row['sha256']==A.digest(local);selected[name]=row['sha256']
for name,row in members.items():
    if '/' not in name and (name.startswith('annotations-first-four-') or name.startswith('annotations-first-four.')) and any(term in name for term in ['command','stdout','stderr','result','graph-reader']):selected[name]=row['sha256']
selected_bytes={}
with tarfile.open(ann_path.parent/ann['archive'],'r|*') as tar:
    for member in tar:
        if member.name in selected:
            assert member.isfile();raw_member=tar.extractfile(member).read();assert hashlib.sha256(raw_member).hexdigest()==selected[member.name]
            assert A.digest(original/member.name)==selected[member.name];selected_bytes[member.name]={'bytes':len(raw_member),'sha256':selected[member.name]}
assert selected.keys()==selected_bytes.keys()
for name in ['README.md','annotations-eight-spec-report.md','annotations-eight-spec-receipt.json']:
    A.read(DELIVERY/'certification-review-r3'/name,'r3-review-'+name)
for name in ['README.md','final-execution-receipt.md']:
    A.read(DELIVERY/name,'dated-navigation-'+name)
for name in ['final-candidate-r4/README.md','final-validation-r4/README.md','final-certification-r4/README.md','certification-review-r4/README.md']:
    A.read(DELIVERY/name,'dated-navigation-'+name.replace('/','-'))
A.emit('retention-and-incident-boundary',{'six-r3-raw-archive-identities':checks,'retained-raw-members':254118,'live-removal-archive':removal,'actual-removal-result':result,'retained-no-r3-authority-reference-check':True,'deleted-historical-live-tree-required':False,'incident':incident,'incident-sha256':A.digest(incident_path),'selected-r3-review-members-byte-checked':selected_bytes,'historic-review-archive-sha256':ann['sha256'],'standards-assessment':{'norm':'Original Goal constraint: Preserve historical evidence.','historic-limitation':'Two derived r3 reviewer graph summaries were overwritten. Earlier bytes and SHA identities remain unavailable. This historical preservation exception is not erased by reinspection.','current-review-coverage':'Retained certification originals, surviving command/output records and a separately labeled fresh independent first-four read support review coverage. This audit checks continuity; it does not claim recovered summary bytes.','scope':'No new source/runtime change or certification rerun follows from the disclosed auxiliary-review limitation. Continue to disclose it explicitly in final delivery; no blanket assertion that all historical review outputs survived.','current-actionable-violation':None}})
A.seal_inputs();print(json.dumps({'historical-raw-archive-and-catalog-identities':6,'historical-raw-member-count-bound':254118,'historical-full-raw-replay':False,'historical-removal-archive-members-byte-checked':8,'actual-removal-exit':result['returncode'],'incident-sha256':A.digest(incident_path),'lost-derived-summary-bytes':[55109,79646],'pre-overwrite-SHA-available':False,'selected-historical-review-members-byte-checked':len(selected_bytes),'new-recovery-claim':False,'active-r4-annotations-read':False},indent=2))
