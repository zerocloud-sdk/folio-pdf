import datetime,hashlib,json,pathlib
from auditlib import OUT,REPO,DELIVERY

def sha(path):
    with pathlib.Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(name):return json.loads((OUT/name).read_text())
def emit(name,value):
    with (OUT/name).open('x') as f:json.dump(value,f,indent=2);f.write('\n')
source=read('source-continuity.json');archives=read('evidence-archive-member-audits.json');commands=read('evidence-completed-command-publication-continuity.json');reviews=read('evidence-closed-independent-review-continuity.json');historical=read('historical-retention-and-incident-boundary.json');survivors=read('survivors-historical-graph-survivor-check.json');closing=read('closing-source-and-scope-check.json')
freeze=json.loads((DELIVERY/'final-validation-r4/source-and-contract-inputs.json').read_text());build=json.loads((DELIVERY/'final-candidate-r4/build-inputs.json').read_text())
for rows in [freeze['inputs'],freeze['contract-inputs'],build['candidate']['artifacts'],build['harness']]:
    for row in rows:assert sha(REPO/row['path'])==row['sha256']
for archive in archives:
    assert sha(archive['archive'])==archive['sha256'] and sha(archive['identity'])==archive['identity-sha256']
ledger={};selected=[]
for path in sorted(OUT.glob('*-inspected-input-identities.json')):
    data=json.loads(path.read_text())
    for row in data['files']:
        if row['path'] in ledger:assert ledger[row['path']]==row
        ledger[row['path']]=row
    for row in data['selected-original-copies']:
        assert sha(OUT/row['copy'])==row['sha256'];selected.append(row)
emit('all-inspected-input-identities.json',{'file-count':len(ledger),'files':sorted(ledger.values(),key=lambda x:x['path']),'boundary':'Complete SHA catalog of substantive inspector inputs. Git command stdout additionally retains the original BASE tree object identities. Dated navigation captures are observations, not frozen source or completion authority.'})
emit('all-selected-original-identities.json',{'count':len(selected),'copies':selected})
report="""Independent Standards continuity review on the existing reviewer thread; no newly allocated fresh agent is claimed. Baseline and HEAD remain `5b1603c435f11c40368f75b7b9a2777c9c5e9761`.

**Hard violations in this current bounded scope: 0.** The full 1,933-source/30-contract freeze matches current bytes and staged inputs. BASE comparison includes 571 new source paths and 57 modified source paths; the original review’s additional Arlington patch remains unchanged outside candidate inputs. Applying the original complete review and appearance, observer-budget, Worker-batch and five-file inventory closures reconstructs all current inputs exactly: cumulative 26-source/one-contract changes, with no uncovered delta. All 23 artifact and 24 harness hashes also match.

Completed host/four-JDK validation retains its independently closed 1507/0/0/4 results. Stage actually exited 0 and remains distinct from certification. All 8,374 members of 21 completed archives match manifests and originals, including 8,099 files in twelve independent raw/publication review packets. Five actual certification exits, forty formal transcripts, configurations, 160 chain-record identities and successive dated publication subsets remain consistent. This links the closed raw reviews without repeating their rule/RGB analysis.

**Historical preservation limitation:** the Goal requires “Preserve historical evidence.” Two r3 derived review summaries, originally 55,109 and 79,646 bytes, were overwritten; their old bytes and hashes remain unavailable. The original incident is explicit. Surviving graph commands/results, complete-reference catalogs and separately labeled fresh inspection remain verifiable. Reinspection supports coverage and does not recover the lost summaries. Six historical raw archives retain their recorded identities; their previously verified 254,118 originals need not remain duplicated at deleted live paths. Final delivery must retain this exception and avoid blanket historical-output preservation claims.

**Heuristic findings: 0 open.** No additional code smell arises from this unchanged source scope. Reviewed raw-log attributes and the historical Facade coverage clarification remain unchanged.

This closes initial frozen-source/completed-evidence continuity only. Active r4 annotations was not read. Annotations, all-48 certification, final inventory, frozen Git index, completion marks and delivery approval remain deferred. No project execution or repository mutation occurred.
"""
assert len(report.split())<400
with (OUT/'report.md').open('x') as f:f.write(report)
references=['source-continuity.json','source-baseline-input-comparison.json','evidence-stage-and-validation-continuity.json','evidence-archive-member-audits.json','evidence-completed-command-publication-continuity.json','evidence-closed-independent-review-continuity.json','historical-retention-and-incident-boundary.json','survivors-historical-graph-survivor-check.json','closing-source-and-scope-check.json','all-inspected-input-identities.json','all-selected-original-identities.json']
exclusions=['artifact-manifest.json','commands/seal-review.stdout','commands/seal-review.stderr','commands/seal-review-result.json']
receipt={
    'sealed-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'reviewer':'/root/final_standards','axis':'Standards','existing-independent-thread-reused':True,'fresh-agent-created':False,
    'allocation-boundary':{'path':'selected-originals/source/setup/reviewer-allocation-boundary.json','sha256':sha(OUT/'selected-originals/source/setup/reviewer-allocation-boundary.json')},
    'baseline':source['fixed-baseline'],'observed-HEAD':source['HEAD'],'canonical-committed-diff-empty':True,'commit-list-empty':True,
    'explicit-WIP-adaptation':'Tracked BASE diff plus complete frozen source/contract path comparison to BASE, including new paths. No index completion interpretation.',
    'candidate':'ab18cc9c0473730a6aabec5d12e3172f22bea23a0a0f9529052a2bc186cbfc1b','contract':'3de508f79fcbef7258feee8abc013d6f02b000840cac1cb263cb0d6f927b8f2b',
    'current-inputs':{'sources':1933,'contracts':30,'artifacts':23,'harness':24,'source-contract-freeze-sha256':sha(DELIVERY/'final-validation-r4/source-and-contract-inputs.json'),'build-inputs-sha256':sha(DELIVERY/'final-candidate-r4/build-inputs.json'),'closing-current-hashes-match':True},
    'complete-baseline-comparison':source['baseline-status-counts'],'original-new-files-outside-freeze':closing['original-new-files-outside-freeze'],
    'source-review-lineage':{'original-full-review':'/tmp/t75-final-standards-xpr84_u3/review-record.json','original-full-review-sha256':'09e13975c564fe979e8605e142f4b43d073289bd43dc99aeba4f3a6bc20d2c3e','cumulative-source-delta':26,'cumulative-contract-delta':1,'closures':['appearance crosspage','observer budgets','Worker batch timeout','five-file inventory reader bound'],'sequential-closure-application-exact':True,'uncovered-delta':[],'already-closed-source-code-rereviewed':False},
    'current-hard-violations':[],'open-heururistic-findings':[],
    'fowler-judgement-baseline':['Mysterious Name','Duplicated Code','Feature Envy','Data Clumps','Primitive Obsession','Repeated Switches','Shotgun Surgery','Divergent Change','Speculative Generality','Message Chains','Middle Man','Refused Bequest'],
    'normative-boundaries':['Repository documented standards prevail over Fowler heuristics.','CONTRIBUTING.md requires complete verify and four-JDK matrix for shipped/build changes; the previously independent r4 closures remain unchanged.','Original Goal requires actual current-candidate certification, independent public behavior evidence, historical retention and independent review before completion marks.','Original Goal DocumentWorkflow.execute/public behavior, Java 8, clean-room/provenance, actual IN_PROCESS Facade and real-name DCO rules remain those of the closed source reviews.','Subsequent user authorization permits root commit/push/issue closure after completion; this reviewer performs none.'],
    'completed-archive-audit':{'archive-count':21,'all-members':8374,'every-member-byte-matches-original-and-manifest':True,'raw-publication-review-archives':12,'raw-publication-review-original-files':8099,'prior-host-review-original-files':105,'prior-matrix-review-original-files':96,'stage-original-files':10,'completed-validation-stage-queue-original-files':14,'five-command-packets-original-files':50},
    'completed-certification-continuity':{'obligations':[x['obligation'] for x in commands],'actual-exits':[x['actual-result']['returncode'] for x in commands],'certifications':40,'configuration-identities':40,'chain-record-identities':160,'formal-transcripts':40,'all-dated-publication-subsets-match-own-indexes':True,'raw-rule-or-RGB-analysis-replayed':False,'closed-independent-review-reports':[{'name':x['name'],'report-sha256':x['report-sha256'],'receipt-sha256':x['receipt-sha256']} for x in reviews]},
    'historical-preservation-exception':historical['standards-assessment'],
    'historic-incident':{'path':'capabilities/evidence/T75-delivery/certification-review-r3/annotations-reader-output-incident-and-closure.json','sha256':historical['incident-sha256'],'old-derived-byte-sizes':[55109,79646],'old-derived-SHA-unavailable':True,'lost-original-bytes-recovered':False,'selected-surviving-graph-members-byte-checked':len(survivors['selected-members-byte-checked']),'historical-raw-archive-identities-rechecked':6,'historical-raw-member-count-bound':254118,'historical-full-raw-replay':False,'historical-removal-command-original-files-byte-checked':8,'historical-removal-actual-exit':0,'deleted-old-live-tree-required':False},
    'reviewer-diagnostics':[{'script':'identity-schema.py','result':'commands/identity-schema-result.json','actual-exit':1,'reason':'Reviewer used an unimported Path alias after completing the first schema reads. No project input failed.','separate-correction':'schema-followup.py','corrected-result':'commands/schema-followup-result.json','corrected-actual-exit':0,'original-command-stdout-stderr-result-retained':True}],
    'scope-approvals':{'initial-frozen-source-completed-evidence-continuity':True,'annotations':False,'all48-certifications':False,'final-inventory':False,'frozen-staged-index':False,'completion-marks':False,'commit-push-ticket-close':False,'final-Standards-delivery-approval':False},
    'activity-boundaries':{'active-r4-annotations-read':False,'project-tests-or-Maven-executed':False,'certifiers-or-environment-observers-executed':False,'live-target-reports-read':False,'repository-Git-index-authority-tracker-writes':False,'full-raw-trees-copied':False,'old-packets-overwritten':False},
    'detailed-evidence':[{ 'path':name,'bytes':(OUT/name).stat().st_size,'sha256':sha(OUT/name)} for name in references],
    'report':{'path':'report.md','sha256':sha(OUT/'report.md'),'word-count':len(report.split())},
    'retention':{'exclusive-file-creation':True,'manifest':'artifact-manifest.json','manifest-excludes':exclusions,'excluded-file-boundary':'Manifest excludes itself; the executing runner writes this finalizer command stdout/stderr/result after manifest creation. All are retained in the full packet and should be included by parent archival.','navigation-boundary':'README and execution receipt are dated draft snapshots and may advance; they are not frozen source or final authority.'}
}
emit('receipt.json',receipt)
files=[]
for path in sorted(OUT.rglob('*')):
    if path.is_file() and path.relative_to(OUT).as_posix() not in exclusions:
        assert not path.is_symlink();files.append({'path':path.relative_to(OUT).as_posix(),'bytes':path.stat().st_size,'sha256':sha(path)})
emit('artifact-manifest.json',{'recorded-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':files,'file-count':len(files),'excluded':exclusions})
for row in files:assert sha(OUT/row['path'])==row['sha256']
print(json.dumps({'packet':str(OUT),'report':{'path':str(OUT/'report.md'),'sha256':sha(OUT/'report.md')},'receipt':{'path':str(OUT/'receipt.json'),'sha256':sha(OUT/'receipt.json')},'manifest':{'path':str(OUT/'artifact-manifest.json'),'sha256':sha(OUT/'artifact-manifest.json')},'manifested-files':len(files),'completed-packet-files':len(files)+4,'packet-manifested-bytes':sum(x['bytes'] for x in files),'inspected-input-identities':len(ledger),'selected-original-copies':len(selected),'report-word-count':len(report.split()),'current-hard-violations':0,'open-heuristic-findings':0,'historical-derived-loss-explicitly-retained':True,'final-delivery-approved':False},indent=2))
