import hashlib,json,pathlib
D=pathlib.Path('/home/ubuntu/IdeaProjects/open-pdf/capabilities/evidence/T75-delivery')
for path in [D/'final-certification-r3/historical-raw-retention-receipt.json',D/'final-certification-r3/historical-live-removal-command-receipt.json']:
    print('\n'+str(path)+'\n'+path.read_text())
print('\nANNOTATIONS R3 REVIEW FILES')
for path in sorted((D/'certification-review-r3').glob('*annotations*')):print(path.name,path.stat().st_size)
print('\nSCOPE WORDING')
for path in [D/'README.md',D/'final-execution-receipt.md',D/'certification-review-r3/README.md']:
    print(str(path),hashlib.sha256(path.read_bytes()).hexdigest())
    lines=path.read_text().splitlines()
    for n,line in enumerate(lines):
        if any(word in line.lower() for word in ['derived','overwrit','recovery','24 project','cache','hard-link','preserv']):print(n+1,'\n'.join(lines[max(0,n-1):min(len(lines),n+4)]))
