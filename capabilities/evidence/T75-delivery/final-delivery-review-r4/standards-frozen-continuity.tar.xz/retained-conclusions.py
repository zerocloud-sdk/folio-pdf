import json,pathlib
OUT=pathlib.Path(__file__).parent
reviews=json.loads((OUT/'evidence-closed-independent-review-continuity.json').read_text())
for review in reviews:
    print('\n'+review['name']+'\n'+review['report'])
source=json.loads((OUT/'source-continuity.json').read_text())
prior=pathlib.Path('/tmp/t75-final-standards-xpr84_u3/new-source-identities.json');raw=json.loads(prior.read_text())
print('\nORIGINAL NEW SOURCE SCHEMA',type(raw).__name__)
if isinstance(raw,dict):print(list(raw)[:20])
else:print(raw[:2])
print('\nRAW RETENTION ATTRIBUTES\n'+(OUT/'selected-originals/source/standards/.gitattributes').read_text())
