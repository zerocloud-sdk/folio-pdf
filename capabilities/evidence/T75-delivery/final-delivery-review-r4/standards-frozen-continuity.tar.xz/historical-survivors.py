import hashlib,json,pathlib,tarfile
from auditlib import Audit,OUT,DELIVERY
A=Audit('survivors');path=DELIVERY/'certification-review-r3/annotations-eight-spec-archive-identity.json';identity=A.json(path)
selected={row['path']:row for row in identity['members'] if '/' not in row['path'] and (row['path'].startswith('graph') or row['path'].startswith('first-four-original-tuple-file-identities') or row['path'].startswith('first-four-record-report-reference-identities') or row['path'] in ['annotations-first-four-direct-graph-inspection.json','annotations-first-four-direct-graph-inspection-read-identities.json'])}
assert A.digest(path.parent/identity['archive'])==identity['sha256']
results=[];bytes_checked=0
with tarfile.open(path.parent/identity['archive'],'r|*') as tar:
    for member in tar:
        if member.name not in selected:continue
        raw=tar.extractfile(member).read();row=selected.pop(member.name);assert len(raw)==row['size'] and hashlib.sha256(raw).hexdigest()==row['sha256']
        original=pathlib.Path(identity['original'])/member.name;assert A.digest(original)==row['sha256'];bytes_checked+=len(raw)
        record={'path':member.name,'bytes':len(raw),'sha256':row['sha256']}
        if member.name.endswith('-result.json'):record['retained-actual-result']=json.loads(raw)
        if member.name.startswith('graph') and len(raw)<20000:A.read(original,member.name)
        results.append(record)
assert not selected
A.emit('historical-graph-survivor-check',{'archive-sha256':identity['sha256'],'selected-members-byte-checked':results,'bytes-checked':bytes_checked,'scope':'Surviving original graph scripts/command/output/results, main first-four complete-reference catalogs, and the explicitly mislabeled JDK17 bytes. Earlier derived first-four summaries are unavailable; no recovery is claimed.'})
A.seal_inputs();print(json.dumps({'selected-historical-graph-members':len(results),'bytes-streamed-not-unpacked':bytes_checked,'retained-result-identities':[x for x in results if 'retained-actual-result' in x],'lost-original-summary-bytes-recovered':False},indent=2))
