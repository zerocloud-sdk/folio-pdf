import json,pathlib
D=pathlib.Path('/home/ubuntu/IdeaProjects/open-pdf/capabilities/evidence/T75-delivery/certification-review-r3')
x=json.loads((D/'annotations-eight-spec-archive-identity.json').read_text())
for row in x['members']:
    if 'first-four' in row['path'] and not row['path'].startswith('copies/') and '/' not in row['path']:
        print(row['path'],row['size'],row['sha256'])
