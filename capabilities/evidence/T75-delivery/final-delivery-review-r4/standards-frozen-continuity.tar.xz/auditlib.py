import datetime,hashlib,json,pathlib,subprocess,tarfile
OUT=pathlib.Path(__file__).parent
REPO=pathlib.Path('/home/ubuntu/IdeaProjects/open-pdf')
DELIVERY=REPO/'capabilities/evidence/T75-delivery'
class Audit:
    def __init__(self,label):self.label=label;self.inputs={};self.copies=[]
    def digest(self,path):
        path=pathlib.Path(path)
        assert '/T75-foundation-20260914-r4/annotations' not in str(path)
        with path.open('rb') as f:value=hashlib.file_digest(f,'sha256').hexdigest()
        row={'path':str(path),'bytes':path.stat().st_size,'sha256':value}
        if str(path) in self.inputs:assert self.inputs[str(path)]==row
        self.inputs[str(path)]=row;return value
    def read(self,path,copy=None):
        path=pathlib.Path(path);raw=path.read_bytes();value=self.digest(path);assert hashlib.sha256(raw).hexdigest()==value
        if copy:
            target=OUT/'selected-originals'/self.label/copy;target.parent.mkdir(parents=True,exist_ok=True)
            with target.open('xb') as f:f.write(raw)
            self.copies.append({'original':str(path),'copy':str(target.relative_to(OUT)),'bytes':len(raw),'sha256':value})
        return raw
    def json(self,path,copy=None):return json.loads(self.read(path,copy))
    def emit(self,name,value):
        with (OUT/(self.label+'-'+name+'.json')).open('x') as f:json.dump(value,f,indent=2);f.write('\n')
    def command(self,name,argv):
        prefix=OUT/'commands'/(self.label+'-'+name);start=datetime.datetime.now(datetime.timezone.utc).isoformat()
        result=subprocess.run(argv,cwd=REPO,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        for suffix,raw in [('stdout',result.stdout),('stderr',result.stderr)]:
            with pathlib.Path(str(prefix)+'.'+suffix).open('xb') as f:f.write(raw)
        with pathlib.Path(str(prefix)+'-result.json').open('x') as f:json.dump({'command':argv,'cwd':str(REPO),'started-utc':start,'completed-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'returncode':result.returncode},f,indent=2);f.write('\n')
        assert result.returncode==0;return result.stdout
    def seal_inputs(self):
        self.emit('inspected-input-identities',{'files':list(self.inputs.values()),'file-count':len(self.inputs),'selected-original-copies':self.copies})
    def archive(self,identity,identity_path,selected=()):
        archive=pathlib.Path(identity_path).parent/identity['archive'];assert self.digest(archive)==identity['sha256']
        expected={x['path']:x for x in identity['members']};assert len(expected)==len(identity['members'])
        seen={};kept={}
        with tarfile.open(archive,'r|*') as tar:
            for member in tar:
                assert member.isfile() and not member.name.startswith('/') and '..' not in pathlib.PurePosixPath(member.name).parts and member.name not in seen
                raw_file=tar.extractfile(member);h=hashlib.sha256();size=0;chunks=[] if member.name in selected else None
                while True:
                    chunk=raw_file.read(1024*1024)
                    if not chunk:break
                    h.update(chunk);size+=len(chunk)
                    if chunks is not None:chunks.append(chunk)
                row={'path':member.name,'bytes':size,'sha256':h.hexdigest()};e=expected[member.name]
                assert size==e['size'] and row['sha256']==e['sha256']
                original=pathlib.Path(identity['original'])/member.name
                assert self.digest(original)==row['sha256']
                seen[member.name]=row
                if chunks is not None:kept[member.name]=b''.join(chunks)
        assert seen.keys()==expected.keys()
        return {'archive':str(archive),'sha256':identity['sha256'],'identity':str(identity_path),'identity-sha256':self.digest(identity_path),'original':identity['original'],'member-count':len(seen),'bytes':sum(x['bytes'] for x in seen.values()),'all-members-byte-match-original-and-manifest':True,'members':list(seen.values())},kept
