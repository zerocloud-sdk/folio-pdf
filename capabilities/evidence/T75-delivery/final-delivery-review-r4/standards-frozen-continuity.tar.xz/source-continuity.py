import collections,hashlib,json,pathlib,yaml
from auditlib import Audit,OUT,REPO,DELIVERY
A=Audit('source');BASE='5b1603c435f11c40368f75b7b9a2777c9c5e9761'
head=A.command('head',['git','rev-parse','HEAD']).decode().strip();assert head==BASE
assert not A.command('commit-list',['git','log','--oneline',BASE+'..HEAD'])
assert not A.command('canonical-diff',['git','diff',BASE+'...HEAD'])
listing=A.command('baseline-tree',['git','ls-tree','-r','-z',BASE]);tree={}
for entry in listing.split(b'\0'):
    if not entry:continue
    identity,name=entry.split(b'\t',1);mode,kind,sha=identity.decode().split();tree[name.decode()]={'mode':mode,'type':kind,'git-sha1':sha}
freeze=A.json(DELIVERY/'final-validation-r4/source-and-contract-inputs.json','source-and-contract-inputs.json')
build=A.json(DELIVERY/'final-candidate-r4/build-inputs.json','build-inputs.json')
original=A.json(DELIVERY/'final-candidate/build-inputs.json','original-build-inputs.json')
def mapping(rows):
    value={x['path']:x['sha256'] for x in rows};assert len(value)==len(rows);return value
sources=mapping(freeze['inputs']);contracts=mapping(freeze['contract-inputs']);assert [len(sources),len(contracts)]==[1933,30]
assert mapping(build['candidate']['inputs'])==sources and mapping(build['contract-inputs'])==contracts
roots=yaml.safe_load(A.read(REPO/'capabilities/foundation-release.yaml','foundation-release.yaml'));enumerated=set()
for name in roots['source-roots']:
    root=REPO/name
    for path in root.rglob('*') if root.is_dir() else [root]:
        if path.is_file() and '__pycache__' not in path.parts:
            assert not path.is_symlink();enumerated.add(path.relative_to(REPO).as_posix())
enumerated.difference_update(roots['source-exclusions']);assert enumerated==sources.keys()
contract_paths={'capabilities/foundation-release.yaml','capabilities/capability-matrix.yaml','capabilities/facade-surface.yaml',roots['requirements'],roots['environments'],roots['platform-decision']}
contract_paths.update(x['profile-contract'] for x in roots['obligations']);assert contract_paths==contracts.keys()
rows=[]
for kind,values in [('source',sources),('contract',contracts)]:
    for name,value in values.items():
        assert A.digest(REPO/name)==value
        raw=(REPO/name).read_bytes();git_sha=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
        baseline=tree.get(name);status='new' if baseline is None else 'unchanged' if baseline['git-sha1']==git_sha else 'modified'
        rows.append({'kind':kind,'path':name,'sha256':value,'current-git-sha1':git_sha,'baseline':baseline,'baseline-status':status})
A.command('tracked-input-diff',['git','diff',BASE,'--']+sorted(set(sources)|set(contracts)))
old_sources=mapping(original['candidate']['inputs']);old_contracts=mapping(original['contract-inputs'])
assert old_sources.keys()==sources.keys() and old_contracts.keys()==contracts.keys()
recomputed={kind:[{'path':name,'before':before[name],'after':after[name]} for name in sorted(before) if before[name]!=after[name]] for kind,before,after in [('inputs',old_sources,sources),('contract-inputs',old_contracts,contracts)]}
claimed=A.json(DELIVERY/'inventory-read-bound/input-delta-from-original-full-review.json','reviewed-delta.json')
assert {k:[{x:r[x] for x in ['path','before','after']} for r in claimed[k]] for k in recomputed}==recomputed
assert [len(recomputed['inputs']),len(recomputed['contract-inputs'])]==[26,1]
host=A.json(pathlib.Path('/tmp/t75-standards-host-r4-ad7uhgyj/attempt-v2/source-contract-continuity-audit.json'),'prior-host-continuity.json');assert host['recomputed-original-review-delta']==recomputed
original_review=A.json(pathlib.Path('/tmp/t75-final-standards-xpr84_u3/review-record.json'),'original-full-review-record.json')
assert original_review['artifact-sha256']['build-inputs.json']==A.digest(DELIVERY/'final-candidate/build-inputs.json')
assert original_review['tracked-files']==48 and original_review['new-files']==572
applied=dict(old_sources);applied.update(old_contracts);closures=[]
for index,row in enumerate(host['prior-independent-closure-records']):
    path=pathlib.Path(row['path']);assert A.digest(path)==row['sha256'];data=A.json(path,f'prior-closure-{index+1}.json')
    for entry in data['source-files']:
        name=entry['path'];value=entry.get('current-sha256',entry.get('sha256'))
        if name in applied:applied[name]=value
    closures.append({'path':str(path),'sha256':row['sha256'],'source-files':data['source-files']})
new=A.json(DELIVERY/'inventory-read-bound/independent-review-closure.json','inventory-independent-closure.json');assert A.digest(DELIVERY/'inventory-read-bound/independent-review-closure.json')==host['new-independent-closure-sha256']
for row in new['source-delta']:applied[row['path']]=row['current-sha256']
assert applied=={**sources,**contracts}
for axis in ['standards','spec']:
    path=DELIVERY/'inventory-read-bound'/(axis+'-review-report.md');assert A.digest(path)==new[axis+'-report-sha256'];A.read(path,axis+'-inventory-report.md')
for kind,items in [('artifact',build['candidate']['artifacts']),('harness',build['harness'])]:
    for row in items:assert A.digest(REPO/row['path'])==row['sha256']
assert len(build['candidate']['artifacts'])==23 and len(build['harness'])==24
setup=pathlib.Path('/tmp/t75-final-review-fixed-baseline-r4-zpbk95st')
for path in sorted(setup.iterdir()):
    if path.is_file():A.read(path,'setup/'+path.name)
for name in ['AGENTS.md','CONTRIBUTING.md','CONTEXT.md','docs/agents/domain.md','docs/agents/issue-tracker.md','.gitattributes','PROVENANCE.md']:
    A.read(REPO/name,'standards/'+name)
A.read(pathlib.Path('/home/ubuntu/.codex/attachments/77353239-0dda-4ee1-b4bb-ce7fb3fa0f9b/pasted-text-1.txt'),'original-goal.txt')
A.emit('baseline-input-comparison',rows)
result={'fixed-baseline':BASE,'HEAD':head,'canonical-diff-empty':True,'commit-list-empty':True,'source-count':1933,'contract-count':30,'artifact-count':23,'harness-count':24,'baseline-status-counts':{kind:dict(collections.Counter(r['baseline-status'] for r in rows if r['kind']==kind)) for kind in ['source','contract']},'all-current-input-bytes-match-stage-and-r4-validation-freeze':True,'source-delta-from-original-full-review':26,'contract-delta-from-original-full-review':1,'recomputed-delta':recomputed,'all-original-inputs-covered-by-original-full-review-plus-sequential-closures':True,'uncovered-delta':[],'closures':closures,'inventory-closure':new,'initial-index-review-performed':False}
A.emit('continuity',result);A.seal_inputs();print(json.dumps({k:v for k,v in result.items() if k not in ['recomputed-delta','closures','inventory-closure']},indent=2))
