import json,pathlib
D=pathlib.Path('/home/ubuntu/IdeaProjects/open-pdf/capabilities/evidence/T75-delivery')
identity=json.loads((D/'final-certification-r4/text-command-archive-identity.json').read_text());root=pathlib.Path(identity['original'])
for name in ['observed-index.json','identities.json']:
    data=json.loads((root/name).read_text());print(name)
    for k,v in data.items():print(k,type(v).__name__,str(v)[:7000])
print('REVIEW FILE NAMES')
for path in sorted((D/'certification-review-r4').glob('*-archive-identity.json')):
    data=json.loads(path.read_text());print(path.name,len(data['members']),[r['path'] for r in data['members'] if r['path'].count('/')==0 and ('report' in r['path'] or 'receipt' in r['path'] or 'manifest' in r['path'])])
