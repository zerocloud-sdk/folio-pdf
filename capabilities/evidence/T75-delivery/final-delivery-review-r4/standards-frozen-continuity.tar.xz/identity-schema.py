import hashlib,json,pathlib
OUT=pathlib.Path(__file__).parent;REPO=pathlib.Path('/home/ubuntu/IdeaProjects/open-pdf');D=REPO/'capabilities/evidence/T75-delivery'
def schema(path):
    raw=path.read_bytes();value=json.loads(raw);print('\nJSON '+str(path)+' '+hashlib.sha256(raw).hexdigest())
    if isinstance(value,dict):
        for key,v in value.items():print(key,type(v).__name__,len(v) if hasattr(v,'__len__') else '',str(v)[:1400])
    else:print(str(value)[:2200])
for rel in ['final-candidate-r4/original-archive-identities.json','final-candidate-r4/freeze.json','final-candidate-r4/build-command.json','final-candidate-r4/t75-final-stage-r4-result.json','final-validation-r4/completed-validation-stage-queue-archive-identity.json','final-validation-r4/completed-validation-stage-queue-receipt.json','final-certification-r4/text-command-archive-identity.json','final-certification-r4/text-receipt.json','final-certification-r4/metadata-receipt.json','certification-review-r4/metadata-publication-spec-archive-identity.json','certification-review-r4/metadata-publication-spec-receipt.json','final-certification-r3/historical-live-removal-command-archive-identity.json','inventory-read-bound/input-delta-from-original-full-review.json']:
    path=D/rel
    if path.exists():schema(path)
for path in [Path('/tmp/t75-final-standards-xpr84_u3/review-record.json'),Path('/tmp/t75-standards-host-r4-ad7uhgyj/attempt-v2/source-contract-continuity-audit.json')]:schema(path)
setup=Path('/tmp/t75-final-review-fixed-baseline-r4-zpbk95st')
print('\nSETUP')
for path in sorted(setup.rglob('*')):
    if path.is_file():print(path.relative_to(setup),path.stat().st_size)
print('\nHISTORICAL R3 PACKAGE')
for path in sorted((D/'final-certification-r3').iterdir()):print(path.name,path.stat().st_size)
