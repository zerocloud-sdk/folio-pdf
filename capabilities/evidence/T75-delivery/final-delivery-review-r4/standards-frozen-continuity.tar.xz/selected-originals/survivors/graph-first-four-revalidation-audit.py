from auditlib import *
import base64,copy
from decimal import Decimal
BATCH='first-four-revalidation'
C=REPO/'capabilities/profiles/T12-annotations';corpus=obj(C/'corpus.json');observations=[]
# This reader traverses already retained qpdf JSON bytes only. It neither imports
# the project observer nor runs any project command, PDF parser or renderer.
def inspect_graph(path,product):
 g=obj(path);diff=[]
 def check(a,b,label):
  if a!=b:diff.append(label)
 check(g['version'],2,'JSON schema');check(g['qpdf'][0]['jsonversion'],2,'qpdf schema');table=g['qpdf'][1];refs=[p['object'] for p in g['pages']];check(len(refs),len(set(refs)),'page identity uniqueness');positions={r:i+1 for i,r in enumerate(refs)}
 def resolve(x):
  seen=set()
  while isinstance(x,str) and re.fullmatch(r'[1-9][0-9]* [0-9]+ R',x):
   if x in seen or len(seen)>=64:raise ValueError('cyclic retained graph')
   seen.add(x);v=table['obj:'+x];x=v if 'stream' in v else v['value']
  return x
 def stream(x):
  s=resolve(x)['stream'];b=base64.b64decode(s['data'],validate=True)
  if len(b)>1048576:raise ValueError('oversized retained stream')
  return s['dict'],b
 def text(x):
  x=resolve(x)
  if not isinstance(x,str) or not x.startswith('u:'):raise ValueError('non-string value')
  return x[2:]
 def target(x):
  x=resolve(x)
  if isinstance(x,str):
   if x.startswith('u:'):return {'kind':'NAMED','named':x[2:]}
   if x.startswith('/'):return {'kind':'NAMED','named':x[1:]}
   raise ValueError('invalid named target')
  return {'kind':'PAGE','page':positions[x[0]],'style':{'/Fit':'FIT','/FitH':'FIT_H','/FitR':'FIT_R','/XYZ':'XYZ'}[x[1]],'parameters':x[2:]}
 def action(x):
  if x is None:return None
  d=resolve(x);check(set(d),{'/S','/D'},'single Action keys');check(d['/S'],'/GoTo','local Action subtype');return target(d['/D'])
 def ap(x):
  d,b=stream(x);check(d.get('/Type'),'/XObject','AP XObject identity');check(d.get('/Subtype'),'/Form','AP Form identity');check(d.get('/FormType',1),1,'AP FormType');check(resolve(d['/Resources']),{},'AP empty Resources');matrix=resolve(d.get('/Matrix',[1,0,0,1,0,0]));check(matrix,[1,0,0,1,0,0],'AP identity Matrix');program=b.decode('ascii');m=re.fullmatch(r'q ([01]) ([01]) ([01]) rg 2 3 10 10 re f Q\n',program)
  if not m:raise ValueError('unrecognized frozen appearance program')
  return {'box':resolve(d['/BBox']),'matrix':matrix,'resources':'empty','program':program,'color':[int(v) for v in m.groups()]}
 def annotation(ref,number,page_ref):
  d=resolve(ref);types={'/Text':'TEXT','/Stamp':'STAMP','/Highlight':'HIGHLIGHT','/FileAttachment':'FILE_ATTACHMENT','/Widget':'WIDGET','/Link':'LINK'};kind=types[d['/Subtype']];check(d.get('/Type','/Annot'),'/Annot','Annot type');check(d.get('/P',page_ref),page_ref,'Annot owner');check(d.get('/F'),4,'PRINT flag');bindings=resolve(d['/AP']);check(set(bindings),{'/N'},'AP normal binding');a={'id':text(d['/NM']),'type':kind,'page':number,'rectangle':resolve(d['/Rect']),'contents':text(d['/Contents']),'flags':['PRINT'],'appearance':ap(bindings['/N'])}
  if kind=='TEXT':a.update(icon=d.get('/Name','/Note')[1:].upper(),open=d.get('/Open',False))
  elif kind=='STAMP':a['stamp']=d['/Name'][1:]
  elif kind=='HIGHLIGHT':
   q=resolve(d['/QuadPoints']);check(len(q)%8,0,'quad operand groups');a.update(quads=[q[i:i+8] for i in range(0,len(q),8)],color=resolve(d['/C']))
  elif kind=='FILE_ATTACHMENT':
   f=resolve(d['/FS']);ef=resolve(f['/EF']);sd,b=stream(ef['/F']);name=text(f['/F'])
   if '/UF' in f:check(text(f['/UF']),name,'Unicode file alias')
   if '/UF' in ef:check(stream(ef['/UF'])[1],b,'Unicode stream alias')
   a.update(icon=d['/Name'][1:].upper(),attachment={'name':name,'hex':b.hex(),'size':len(b),'sha256':hashlib.sha256(b).hexdigest(),'md5':hashlib.md5(b).hexdigest(),'mime':sd['/Subtype'][1:],'description':text(f['/Desc']),'relationship':f['/AFRelationship'][1:]})
  elif kind=='WIDGET':check(set(d).intersection({'/FT','/Parent','/Kids','/V','/DV','/T'}),set(),'standalone Widget')
  elif kind=='LINK':
   check(int('/A' in d)+int('/Dest' in d),1,'exclusive Link activation');check(d.get('/Border',[0,0,0]),[0,0,0],'zero Link border');a.update(activation='ACTION' if '/A' in d else 'DESTINATION',target=action(d['/A']) if '/A' in d else target(d['/Dest']))
  return a
 catalog=resolve(table['trailer']['value']['/Root']);check('/AcroForm' in catalog,False,'no form');check(resolve(catalog['/T74Keep']),{'/Flag':True,'/Numbers':[1,2]},'private catalog preservation');actual={'pages':[],'annotations':[],'destinations':{},'actions':{'document-open':action(catalog.get('/OpenAction')),'pages':[]},'page-observations':[]};expected=corpus['products'][product]
 for i,r in enumerate(refs,1):
  d=resolve(r);marker=d['/T74Marker'][1:];actual['pages'].append(marker);original=corpus['pages'][marker];check(resolve(d['/MediaBox']),original['media-box'],'MediaBox');check(resolve(d['/CropBox']),original['crop-box'],'CropBox');check(d.get('/Rotate',0),original['rotation'],'rotation');contents=resolve(d['/Contents']);streams=contents if isinstance(contents,list) else [d['/Contents']];programs=[stream(s)[1].decode('ascii') for s in streams];paint={'marker':marker,'contents':programs,'flattened':[]};actual['page-observations'].append(paint);flat=[a for a in expected['flattened'] if a['page']==i];resources=resolve(d['/Resources'])
  if not flat:check([s.rstrip('\x00\t\n\x0c\r ') for s in programs],[s.rstrip('\x00\t\n\x0c\r ') for s in original['contents']],'unchanged original page program');check(resources,{},'unchanged page Resources')
  else:
   n=len(original['contents']);check(programs[:n+2],['q\n']+original['contents']+['Q\n'],'isolated retained page programs');check(set(resources),{'/XObject'},'flattened page resource keys');xo=resolve(resources['/XObject']);check(len(xo),len(flat),'flattened Form count');tokens=' '.join(programs[n+2:]).split();check(len(tokens),11*len(flat),'flattened invocation count')
   for k,a in enumerate(flat):
    tokenset=tokens[k*11:(k+1)*11];check([tokenset[0],tokenset[7],tokenset[9],tokenset[10]],['q','cm','Do','Q'],'flattened invocation operators');appearance=ap(xo[tokenset[8]]);check(appearance,a['appearance'],'flattened exact appearance');box=list(map(lambda v:Decimal(str(v)),a['appearance']['box']));rect=list(map(lambda v:Decimal(str(v)),a['rectangle']));sx=(rect[2]-rect[0])/(box[2]-box[0]);sy=(rect[3]-rect[1])/(box[3]-box[1]);matrix=[sx,Decimal(0),Decimal(0),sy,rect[0]-box[0]*sx,rect[1]-box[1]*sy];check(list(map(Decimal,tokenset[1:7])),matrix,'flattened placement matrix');paint['flattened'].append({'appearance':appearance,'matrix':[str(v) for v in matrix],'actual-matrix':[str(Decimal(v)) for v in tokenset[1:7]]})
  actual['annotations'] +=[annotation(a,i,r) for a in resolve(d.get('/Annots',[]))];aa=resolve(d.get('/AA',{}));check(set(aa)-{'/O','/C'},set(),'page Action bindings')
  if aa:actual['actions']['pages'].append({'page':i,'open':action(aa.get('/O')),'close':action(aa.get('/C'))})
 names=resolve(catalog.get('/Names',{}));dt=resolve(names.get('/Dests',{}));pairs=resolve(dt.get('/Names',[]));check(len(pairs)%2,0,'destination pairs');check('/Kids' in dt,False,'frozen flat name tree')
 for i in range(0,len(pairs),2):
  name=text(pairs[i]);check(name in actual['destinations'],False,'unique destination name');actual['destinations'][name]=target(pairs[i+1])
 for k in ['pages','annotations','destinations','actions']:check(actual[k],expected[k],'complete '+k)
 return actual,diff

def control_product(n):
 if n in ['payload','icon']:return 'changed'
 if n.startswith('copy-'):return 'copied'
 if n=='merge-name':return 'merged'
 if n=='split-survival':return 'left'
 if n=='open-adoption':return 'adopted'
 if n.startswith('flatten-') or n=='retained-paint':return 'flattened'
 return 'created'
for j,m in TUPLES:
 root=ROOT/('jdk'+str(j)+'-'+m.lower())/'observations'
 for api in ['native','facade']:
  for product in ['created','changed','flattened','copied','merged','adopted','left','right']:
   d=root/(api+'-'+product)/'qpdf';actual,diff=inspect_graph(d/'qpdf.json',product);eq(diff,[],str(d)+' all independent direct graph fields');original=obj(d/'observed.json');normalized=copy.deepcopy(actual)
   for p in normalized['page-observations']:
    for f in p['flattened']:del f['actual-matrix']
   eq(normalized,original,str(d)+' complete retained observations derived from original graph');observations.append({'tuple':root.parent.name,'product':api+'-'+product,'control':None,'qpdf-json-sha256':sha(d/'qpdf.json'),'observed-json-sha256':sha(d/'observed.json'),'independent-mismatches':diff,'annotation-count':len(actual['annotations']),'flattened-count':sum(len(p['flattened']) for p in actual['page-observations'])})
 for d in sorted((root/'negative/semantic').iterdir()):
  if not d.is_dir():continue
  change=d.name;product=control_product(change);actual,diff=inspect_graph(d/'qpdf/qpdf.json',product);eq(bool(diff),True,str(d)+' actual graph defect independent of original verdict');lookup={a['id']:a for a in actual['annotations']}
  if change=='order':eq([a['id'] for a in actual['annotations']][:2],['stamp','note'],str(d)+' actual order mutation')
  elif change=='identifier':eq([a['id'] for a in actual['annotations']][:2],['note','note'],str(d)+' actual duplicate identifier')
  elif change=='rectangle':eq(lookup['note']['rectangle'][0],6,str(d)+' actual rectangle mutation')
  elif change=='appearance':eq(lookup['widget']['appearance']['color'],[1,0,0],str(d)+' actual Widget appearance mutation')
  elif change=='appearance-box':eq(lookup['note']['appearance']['box'][0],1,str(d)+' actual appearance BBox mutation')
  elif change=='payload':eq(lookup['file']['attachment']['hex'],'61626301',str(d)+' actual payload mutation')
  elif change=='icon':eq(lookup['note']['icon'],'NOTE',str(d)+' actual icon mutation')
  elif change=='direct-target':eq(lookup['direct']['target']['page'],2,str(d)+' actual direct target mutation')
  elif change=='action-operand':eq(lookup['action']['target']['parameters'],[10,90,1.25],str(d)+' actual Action operand mutation')
  elif change=='named-target':eq(actual['destinations']['shared']['page'],2,str(d)+' actual named target mutation')
  elif change=='copy-target':eq(lookup['direct-1']['target']['page'],1,str(d)+' actual copied target mutation')
  elif change=='copy-external':eq(actual['destinations']['shared']['page'],4,str(d)+' actual copied external target mutation')
  elif change=='merge-name':eq(lookup['appendix-link']['target']['named'],'shared',str(d)+' actual merge name mutation')
  elif change=='split-survival':eq(actual['destinations']['shared']['page'],1,str(d)+' actual pruned binding mutation')
  elif change=='open-adoption':eq(actual['actions']['document-open']['named'],'shared',str(d)+' actual adopted open Action mutation')
  elif change=='flatten-removal':eq(set(lookup),{'widget','note'},str(d)+' actual failed removal mutation')
  elif change=='flatten-placement':eq(Decimal(actual['page-observations'][0]['flattened'][0]['actual-matrix'][4]),Decimal(3),str(d)+' actual flattened placement mutation')
  elif change=='retained-paint':eq('11 20 40 30 re' in ''.join(actual['page-observations'][0]['contents']),True,str(d)+' actual retained paint mutation')
  else:error(d,'unexpected unassigned semantic control')
  observations.append({'tuple':root.parent.name,'product':product,'control':change,'qpdf-json-sha256':sha(d/'qpdf/qpdf.json'),'original-finding':props(d/'result.properties')['finding'],'independent-mismatches':diff,'actual-intended-mutation-observed':True})
finish('annotations-'+BATCH+'-direct-graph-inspection.json',{'scope':'Completed immutable tuples only; independent read of retained original qpdf graphs without running the project observer','batch':BATCH,'graph-observations':observations,'positive-graphs':len([x for x in observations if x['control'] is None]),'actual-mutation-graphs':len([x for x in observations if x['control'] is not None]),'negative-finding-boundary':'The original observer may first report an earlier ordering/property mismatch after public replacement reorders an annotation. Each intended target/operand mutation is independently inspected by identifier here; an earlier original mismatch is not relabeled as a target-specific diagnostic.'})
if errors:raise ValueError('Independent original graph inspection diagnostics retained')
