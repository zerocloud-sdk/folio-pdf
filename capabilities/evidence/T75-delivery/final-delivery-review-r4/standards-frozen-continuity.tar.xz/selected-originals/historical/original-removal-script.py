#!/usr/bin/env python3
"""Remove only superseded task-owned live copies after complete archive checks."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tarfile
import tempfile

ROOT = Path('/home/ubuntu/IdeaProjects/open-pdf')
LIVE = ROOT / 'capabilities/evidence/T75-foundation-20260913-r3'
DEST = ROOT / 'capabilities/evidence/T75-delivery/final-certification-r3'


def sha(data):
    return hashlib.sha256(data).hexdigest()


for name in ('t75-final-validation-stage-queue-r4', 't75-final-text-certify-r4'):
    result = json.loads(Path('/tmp/' + name + '-result.json').read_bytes())
    assert result['returncode'] == 0, result
authority_bytes = (ROOT / 'capabilities/foundation-evidence.yaml').read_bytes()
assert b'T75-foundation-20260913-r3' not in authority_bytes
authority = json.loads(authority_bytes)
observed = json.loads((ROOT / 'capabilities/evidence/T75-foundation-20260914-r4/text/observed-index.json').read_bytes())
assert len(observed['certifications']) == 8
assert [c for c in authority['certifications'] if c['obligation'] == 'text'] == observed['certifications']
assert LIVE.is_dir() and not LIVE.is_symlink()
tracked = subprocess.run(['git', 'ls-files', '-z', '--', str(LIVE.relative_to(ROOT))], cwd=ROOT, capture_output=True, check=True)
assert not tracked.stdout, 'Refusing to remove any tracked or indexed path.'
retained = json.loads((DEST / 'historical-raw-retention-receipt.json').read_bytes())
assert str(LIVE) == retained['original-root']
names = {item['obligation'] for item in retained['archives']}
assert names == {'text', 'transactions', 'values', 'pages', 'metadata', 'annotations'}
assert {p.name for p in LIVE.iterdir()} == names
audit = []
for item in retained['archives']:
    archive = DEST / item['archive']
    catalog = DEST / item['member-identities']
    assert sha(archive.read_bytes()) == item['archive-sha256']
    assert sha(catalog.read_bytes()) == item['member-identities-sha256']
    identity = json.loads(catalog.read_bytes())
    source = LIVE / item['obligation']
    assert str(source) == identity['original']
    assert not identity['symbolic_links']
    members = {entry['path']: entry for entry in identity['members']}
    assert len(members) == len(identity['members']) == item['members']
    paths = list(source.rglob('*'))
    assert not any(p.is_symlink() for p in paths)
    assert {p.relative_to(source).as_posix() for p in paths if p.is_file()} == set(members)
    checked = set()
    with tarfile.open(archive, 'r|xz') as stream:
        for member in stream:
            assert member.isfile() and member.name in members and member.name not in checked
            assert '..' not in Path(member.name).parts and not Path(member.name).is_absolute()
            entry = members[member.name]
            data = stream.extractfile(member).read()
            assert len(data) == entry['size'] and sha(data) == entry['sha256']
            assert data == (source / member.name).read_bytes(), member.name
            checked.add(member.name)
    assert checked == set(members)
    audit.append({'obligation': item['obligation'], 'members': len(checked), 'archive-sha256': item['archive-sha256'], 'member-identities-sha256': item['member-identities-sha256'], 'every-archive-member-matches-live-original': True})
    print(item['obligation'], len(checked), 'original files byte-verified', flush=True)
assert sum(row['members'] for row in audit) == 254118
original = Path(tempfile.mkdtemp(prefix='t75-archived-r3-live-removal-'))
shutil.copyfile(__file__, original / Path(__file__).name)
(original / 'authority-before-removal.yaml').write_bytes(authority_bytes)
(original / 'archive-checks-before-removal.json').write_text(json.dumps(audit, indent=2) + '\n')
# Certification can publish another new r4 subset while the archive scan runs.
# Recheck the only authority condition on which this deletion depends.
assert b'T75-foundation-20260913-r3' not in (ROOT / 'capabilities/foundation-evidence.yaml').read_bytes()
shutil.rmtree(LIVE)
assert not LIVE.exists()
receipt = {'completed-utc': datetime.now(timezone.utc).isoformat(), 'removed-live-root': str(LIVE), 'original-retention-receipt': str(DEST / 'historical-raw-retention-receipt.json'), 'archive-checks': audit, 'removed-files': 254118, 'scope': 'Only task-created, untracked superseded live duplicates were removed after every archive member matched its original. All historical original bytes remain in the six retained archives. No current r4 evidence was removed.', 'original-operation-record': str(original)}
(original / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
with Path('/tmp/t75-archived-r3-live-removal-original-path.txt').open('x') as out:
    out.write(str(original) + '\n')
print(json.dumps(receipt), flush=True)
