import hashlib,json,pathlib
OUT=pathlib.Path(__file__).parent;D=pathlib.Path('/home/ubuntu/IdeaProjects/open-pdf/capabilities/evidence/T75-delivery')
for path in [pathlib.Path('/tmp/t75-final-standards-xpr84_u3/review-record.json'),pathlib.Path('/tmp/t75-standards-host-r4-ad7uhgyj/attempt-v2/source-contract-continuity-audit.json')]:
    raw=path.read_bytes();data=json.loads(raw);print('\nSCHEMA',path,hashlib.sha256(raw).hexdigest())
    for k,v in data.items():print(k,type(v).__name__,len(v) if hasattr(v,'__len__') else '',str(v)[:1200])
setup=pathlib.Path('/tmp/t75-final-review-fixed-baseline-r4-zpbk95st')
print('\nSETUP')
for path in sorted(setup.rglob('*')):
    if path.is_file():print(path.relative_to(setup),path.stat().st_size)
print('\nHISTORICAL R3 PACKAGE')
for path in sorted((D/'final-certification-r3').iterdir()):print(path.name,path.stat().st_size)
print('\nREVIEWER ALLOCATION BOUNDARY\n'+(setup/'reviewer-allocation-boundary.json').read_text())
for name in ['text-jdk8-two-tuples-spec-receipt.json','values-eight-tuples-spec-receipt.json']:
    path=D/'certification-review-r4'/name;data=json.loads(path.read_text());print('\nREVIEW RECEIPT SCHEMA',name)
    for k,v in data.items():print(k,type(v).__name__,len(v) if hasattr(v,'__len__') else '',str(v)[:600])
