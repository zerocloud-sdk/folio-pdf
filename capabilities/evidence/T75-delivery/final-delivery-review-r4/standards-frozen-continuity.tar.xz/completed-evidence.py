import collections,datetime,hashlib,json,pathlib,re,yaml
from auditlib import Audit,OUT,REPO,DELIVERY
A=Audit('evidence');CANDIDATE='ab18cc9c0473730a6aabec5d12e3172f22bea23a0a0f9529052a2bc186cbfc1b';CONTRACT='3de508f79fcbef7258feee8abc013d6f02b000840cac1cb263cb0d6f927b8f2b'
archives=[];review_summaries=[]
def read_archive(path,key=None,selected=()):
    data=A.json(path,'archive-identities/'+path.parent.name+'-'+path.name)
    identity=data[key] if key else data
    audit,kept=A.archive(identity,path,selected);archives.append(audit);return audit,kept
build=A.json(DELIVERY/'final-candidate-r4/build-inputs.json')
stage_a,stage=read_archive(DELIVERY/'final-candidate-r4/original-archive-identities.json','staged-build',('build.txt','freeze.json','source-and-contract-inputs.json','build-command.json','t75-final-stage-r4-command.json','t75-final-stage-r4-result.json','t75-final-stage-r4.log','t75-run-retained.py'))
assert stage_a['member-count']==10
freeze=json.loads(stage['freeze.json']);stage_result=json.loads(stage['t75-final-stage-r4-result.json']);stage_command=json.loads(stage['t75-final-stage-r4-command.json'])
assert stage_result==freeze['actual-stage-result'] and stage_result['returncode']==0
assert all(stage_result[k]==v for k,v in stage_command.items())
assert b'process.wait()' in stage['t75-run-retained.py']
for name in ['freeze.json','build-command.json','t75-final-stage-r4-command.json','t75-final-stage-r4-result.json','t75-final-stage-r4.log']:
    assert A.read(DELIVERY/'final-candidate-r4'/name,'stage/'+name)==stage[name]
assert hashlib.sha256(stage['source-and-contract-inputs.json']).hexdigest()==A.digest(DELIVERY/'final-validation-r4/source-and-contract-inputs.json')
assert '-DskipTests' in json.loads(stage['build-command.json'])
assert b'[INFO] BUILD SUCCESS' in stage['build.txt'] and b'[INFO] BUILD FAILURE' not in stage['build.txt']
queue_a,queue=read_archive(DELIVERY/'final-validation-r4/completed-validation-stage-queue-archive-identity.json',selected=('receipt.json','t75-final-validation-stage-queue-r4-result.json','t75-final-full-verify-r4-result.json','t75-final-jdk-matrix-r4-result.json','t75-final-stage-r4-result.json'))
assert queue_a['member-count']==14
queue_receipt=json.loads(queue['receipt.json']);queue_result=json.loads(queue['t75-final-validation-stage-queue-r4-result.json'])
assert queue_result==queue_receipt['actual-result'] and queue_result['returncode']==0
assert json.loads(queue['t75-final-stage-r4-result.json'])==stage_result
for kind,expected_archive,expected_report,expected_receipt in [
    ('host','71bc6e9f0634dbcd55e7cf694708abca172952602704da92e118e75400ebb4e9','60e938ec4c240863ad7464abe820ac74f26f40ddbd6a0ed2110fd79d2a6c148f','aad8ba5015f3cdabc49933dee9aecddb8945779b21fab144af50984cd1531322'),
    ('matrix','b59d003ef9a5e5eea98683a402fcbdefe6c6aaa43617ab1d5671655755169bc7','223bedddc49ce8509b41e588ff6ab2593fd8e4072d6da1232235f2354d627c8b','8867b3e1aefc3a3178a35b5477797b99ac8f8669987b80959044c8f592ff1e73')]:
    prefix='standards-'+kind+'-review';path=DELIVERY/'final-validation-r4'/(prefix+'-archive-identity.json')
    audit,kept=read_archive(path,selected=('report.md','review-record.json'))
    assert audit['sha256']==expected_archive and hashlib.sha256(kept['report.md']).hexdigest()==expected_report and hashlib.sha256(kept['review-record.json']).hexdigest()==expected_receipt
    for suffix,member in [('report.md','report.md'),('receipt.json','review-record.json')]:assert A.read(DELIVERY/'final-validation-r4'/(prefix+'-'+suffix),'validation/'+prefix+'-'+suffix)==kept[member]
for prefix,sha in [('host-full-verify','9b25f6e28ee328ec00acb1c762dcec3c226d520619b071a3decb1052e497c604'),('jdk-matrix','920b79db90efbc0d19766ec9c03f91ac107c63ef10f4248e569e5004eaa0d87c')]:
    identity=A.json(DELIVERY/'final-validation-r4'/(prefix+'-archive-identity.json'))
    assert identity['sha256']==sha and A.digest(DELIVERY/'final-validation-r4'/identity['archive'])==sha
    receipt=A.json(DELIVERY/'final-validation-r4'/(prefix+'-receipt.json'))
    assert receipt['actual-result']['returncode']==0
host_result=json.loads(queue['t75-final-full-verify-r4-result.json']);matrix_result=json.loads(queue['t75-final-jdk-matrix-r4-result.json'])
assert host_result==A.json(DELIVERY/'final-validation-r4/t75-final-full-verify-r4-result.json')
assert matrix_result==A.json(DELIVERY/'final-validation-r4/t75-final-jdk-matrix-r4-result.json')
assert host_result['completed-utc']<matrix_result['started-utc']<matrix_result['completed-utc']<stage_result['started-utc']

completed=['text','transactions','values','pages','metadata'];formal={'text':126,'transactions':34,'values':83,'pages':65,'metadata':73};indexes={};commands=[]
for number,obligation in enumerate(completed):
    path=DELIVERY/'final-certification-r4'/(obligation+'-command-archive-identity.json')
    audit,raw=read_archive(path,selected=('command.json','command.log','result.json','identities.json','observed-index.json','authority-at-retention.yaml','receipt.json'))
    assert audit['member-count']==10
    result=json.loads(raw['result.json']);command=json.loads(raw['command.json']);receipt=json.loads(raw['receipt.json'])
    assert result==receipt['actual-result'] and result['returncode']==receipt['actual-exit']==0
    assert all(result[k]==v for k,v in command.items())
    assert result['command']==['/usr/bin/python3','scripts/t03-foundation.py','certify','capabilities/evidence/T75-foundation-20260914-r4/'+obligation,'--obligation',obligation]
    assert len(raw['command.log'].splitlines())==13
    for suffix,member in [('command.json','command.json'),('command.log','command.log'),('result.json','result.json'),('receipt.json','receipt.json')]:
        assert A.read(DELIVERY/'final-certification-r4'/(obligation+'-'+suffix),'completed-commands/'+obligation+'-'+suffix)==raw[member]
    for row in receipt['original-copies']:
        if row['copy'] in ['command.json','command.log','result.json','identities.json','observed-index.json']:
            assert A.digest(row['original'])==row['sha256']==hashlib.sha256(raw[row['copy']]).hexdigest()
    assert receipt['candidate']==CANDIDATE and receipt['contract']==CONTRACT
    assert json.loads(raw['identities.json'])=={'Candidate':CANDIDATE,'Contract':CONTRACT}
    index=json.loads(raw['observed-index.json']);authority=yaml.safe_load(raw['authority-at-retention.yaml']);assert index['candidate']==build['candidate']==authority['candidate']
    assert len(index['certifications'])==8 and {x['obligation'] for x in index['certifications']}=={obligation}
    pairs={(x['environment'],x['execution-profile']) for x in index['certifications']}
    assert pairs=={('ubuntu-24.04-linux-x86-64-jdk'+str(j),mode) for j in [8,11,17,21] for mode in ['IN_PROCESS','HARDENED_WORKER']}
    for cert in index['certifications']:
        refs=[cert['configuration']]+cert['records'];assert len(cert['records'])==4
        assert {pathlib.Path(x['path']).stem for x in cert['records']}=={'syntax','standards','semantic','visual'}
        for ref in refs:assert A.digest(REPO/ref['path'])==ref['sha256']
        scope=pathlib.Path(cert['configuration']['path']).parent
        transcript=A.read(REPO/scope/'contract-tests.txt');assert re.search(rb'OK \('+str(formal[obligation]).encode()+rb' tests\)',transcript)
    indexes[obligation]=index['certifications']
    counts=collections.Counter(x['obligation'] for x in authority['certifications']);assert dict(counts)=={name:8 for name in completed[:number+1]}==receipt['authority-counts']
    for name in completed[:number+1]:assert [x for x in authority['certifications'] if x['obligation']==name]==indexes[name]
    assert receipt['observed-tuples']==8 and receipt['matching-pass-records']==32
    commands.append({'obligation':obligation,'actual-result':result,'command-archive-sha256':audit['sha256'],'own-index-sha256':hashlib.sha256(raw['observed-index.json']).hexdigest(),'dated-authority-sha256':hashlib.sha256(raw['authority-at-retention.yaml']).hexdigest(),'dated-authority-counts':dict(counts),'formal-cases-per-tuple':formal[obligation],'eight-formal-transcripts-and-40-config-record-identities-unchanged':True})
for path in sorted((DELIVERY/'certification-review-r4').glob('*-archive-identity.json')):
    if path.name.startswith('annotations'):continue
    prefix=path.name.removesuffix('-archive-identity.json')
    audit,raw=read_archive(path,selected=('report.md','receipt.json'))
    assert A.read(path.with_name(prefix+'-report.md'),'independent-reviews/'+prefix+'-report.md')==raw['report.md']
    assert A.read(path.with_name(prefix+'-receipt.json'),'independent-reviews/'+prefix+'-receipt.json')==raw['receipt.json']
    receipt=json.loads(raw['receipt.json'])
    assert receipt.get('candidate-sha256',receipt.get('candidate'))==CANDIDATE
    assert receipt.get('contract-sha256',receipt.get('contract'))==CONTRACT
    review_summaries.append({'name':prefix,'archive-sha256':audit['sha256'],'original-members':audit['member-count'],'report-sha256':hashlib.sha256(raw['report.md']).hexdigest(),'receipt-sha256':hashlib.sha256(raw['receipt.json']).hexdigest(),'report':raw['report.md'].decode()})
assert len(review_summaries)==12 and sum(x['original-members'] for x in review_summaries)==8099
A.emit('archive-member-audits',archives)
A.emit('completed-command-publication-continuity',commands)
A.emit('closed-independent-review-continuity',review_summaries)
A.emit('stage-and-validation-continuity',{'stage-actual-result':stage_result,'stage-original-files':10,'queue-actual-result':queue_result,'queue-original-files':14,'source-contract-equal-to-r4-host-matrix':True,'staged-build-tests-skipped':True,'stage-not-a-certification':True,'host-review-original-files':105,'matrix-review-original-files':96,'prior-host-and-matrix-raw-archives-unchanged':True})
A.seal_inputs();print(json.dumps({'archive-count':len(archives),'all-streamed-original-members':sum(x['member-count'] for x in archives),'stage-actual-exit':stage_result['returncode'],'completed-obligations':completed,'closed-certifications':40,'bound-records':160,'raw-and-publication-review-packages':len(review_summaries),'review-original-files':8099,'source-and-contract':CANDIDATE+' / '+CONTRACT,'active-annotations-read':False,'final-48-inventory-index-delivery-approved':False},indent=2))
