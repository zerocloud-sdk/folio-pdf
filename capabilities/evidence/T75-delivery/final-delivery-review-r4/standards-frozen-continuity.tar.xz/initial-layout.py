import hashlib,json,pathlib,subprocess
OUT=pathlib.Path(__file__).parent;REPO=pathlib.Path('/home/ubuntu/IdeaProjects/open-pdf');D=REPO/'capabilities/evidence/T75-delivery'
def show(path):
    raw=path.read_bytes();print('\nFILE '+str(path.relative_to(REPO) if path.is_relative_to(REPO) else path)+' SHA256 '+hashlib.sha256(raw).hexdigest()+'\n'+raw.decode())
for rel in ['final-candidate-r4','final-certification-r4','certification-review-r4','inventory-read-bound','final-validation-r4']:
    path=D/rel;print('\nLAYOUT '+rel)
    for item in sorted(path.iterdir()):print(item.name, 'directory' if item.is_dir() else item.stat().st_size)
for rel in ['final-candidate-r4/README.md','final-certification-r4/README.md','certification-review-r4/README.md','inventory-read-bound/independent-review-closure.json','certification-review-r3/annotations-reader-output-incident-and-closure.json']:
    show(D/rel)
show(pathlib.Path('/home/ubuntu/.codex/attachments/77353239-0dda-4ee1-b4bb-ce7fb3fa0f9b/pasted-text-1.txt'))
for rel in ['final-candidate-r4/build-inputs.json','final-candidate-r4/source-and-contract-inputs.json']:
    path=D/rel
    if path.exists():
        data=json.loads(path.read_text());print('\nSCHEMA '+rel)
        for key,value in data.items():print(key,type(value).__name__,len(value) if hasattr(value,'__len__') else '',str(value)[:450])
