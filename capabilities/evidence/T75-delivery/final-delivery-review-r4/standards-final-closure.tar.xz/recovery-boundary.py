from auditlib import Audit,OUT,REPO
from pathlib import Path
import json
A=Audit('recovery-boundary')
root=Path('/tmp/t75-archived-review-space-recovery-r4-18eew2ck')
receipt=A.json(root/'receipt.json');rows=[]
for x in receipt['entries']:
 archive=REPO/x['archive'];identity=archive.with_name(archive.name[:-7]+'-archive-identity.json')
 assert A.digest(archive)==x['sha256'] and A.digest(identity)==x['identity-sha256']
 j=A.json(identity);assert len(j['members'])==x['files'] and sum(m['size'] for m in j['members'])==x['bytes']
 assert j['original']==x['original'] and not Path(x['original']).exists()
 assert x['complete-membership-and-byte-equality'] and x['verified-utc']<x['removed-utc']
 rows.append(x)
assert len(rows)==5 and sum(x['files'] for x in rows)==6651 and sum(x['bytes'] for x in rows)==968467306
print('RECOVERY SCRIPT',A.read(root/'t75-free-archived-review-temporaries-r4.py','original-recovery-script.py').decode())
for name in ['t75-free-archived-review-temporaries-r4-r2-command.json','t75-free-archived-review-temporaries-r4-r2-result.json','t75-free-archived-review-temporaries-r4-r2.log']:
 p=Path('/dev/shm')/name
 if p.exists():print(name,A.read(p,name).decode())
A.emit('verified-boundary',{'exact-directories':5,'retained-original-members':6651,'retained-original-bytes':968467306,'current-retained-archive-and-identity-hashes-match-before-removal-receipts':True,'removed-live-temp-paths-are-not-missing-evidence':True,'certification-source-and-closure-originals-not-in-removal-allowlist':True,'rows':rows,'review-boundary':'No replay of previously closed raw-rule, RGB or archived-original member analysis. Verify actual cleanup result, exact scope and previously bound archive identities.'})
A.seal_inputs()
