from auditlib import Audit,OUT
from pathlib import Path
import json
A=Audit('recovery-layout')
root=Path('/tmp/t75-archived-review-space-recovery-r4-18eew2ck')
print('RECOVERY FILES',[(str(x.relative_to(root)),x.stat().st_size) for x in sorted(root.rglob('*')) if x.is_file()])
for path in sorted(root.glob('*.json')):
 raw=A.read(path,path.name)
 print('RECOVERY JSON',path.name,raw.decode())
result=Path('/dev/shm/t75-free-archived-review-temporaries-r4-r2-result.json')
if result.exists():print('ACTUAL RESULT',A.read(result,'durable-actual-result.json').decode())
A.seal_inputs()
