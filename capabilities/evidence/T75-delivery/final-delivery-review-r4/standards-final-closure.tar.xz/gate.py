from auditlib import Audit,OUT
from pathlib import Path
import json
A=Audit('gate')
result=Path('/tmp/t75-finalize-delivery-index-r4-result.json');pointer=Path('/tmp/t75-final-delivery-index-r4-original-path.txt')
seen={'actual-result-present':result.exists(),'pointer-present':pointer.exists()}
if result.exists():
 j=A.json(result,'actual-result.json');seen['actual-result']=j;seen['returncode']=j.get('returncode')
if pointer.exists():seen['pointer']=A.read(pointer,'original-path.txt').decode().strip()
seen['authorized-to-read-frozen-index']=seen.get('returncode')==0 and seen['pointer-present']
A.emit('observation',seen);A.seal_inputs();print(json.dumps(seen,indent=2))
