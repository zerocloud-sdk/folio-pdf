from auditlib import Audit,OUT
from pathlib import Path
import json
A=Audit('gate-v2')
r=A.json(Path('/tmp/t75-finalize-delivery-index-r4-r2-result.json'),'actual-result.json')
assert r['returncode']==0
pointer=A.read(Path('/tmp/t75-final-delivery-index-r4-r2-original-path.txt'),'original-path.txt').decode().strip()
root=Path(pointer);assert root.is_dir()
print('ACTUAL RESULT',json.dumps(r));print('FILES',[(x.name,x.stat().st_size) for x in sorted(root.iterdir()) if x.is_file()])
for name in ['receipt.json','delta-identities.json','source-and-contract-inputs.json']:
 path=root/name
 if path.exists():
  raw=A.read(path,name if name!='source-and-contract-inputs.json' else None)
  if name!='source-and-contract-inputs.json':print(name,raw.decode())
A.emit('authorized-snapshot',{'actual-exit':0,'snapshot':pointer,'result':r});A.seal_inputs()
