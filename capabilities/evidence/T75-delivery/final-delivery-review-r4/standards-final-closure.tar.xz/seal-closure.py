from auditlib import Audit,OUT,REPO,DELIVERY
from pathlib import Path
import datetime,hashlib,json
A=Audit('closing-point')
TREE='6b6dd30d0254ee8614df514bc75e54bcabcecf62'
assert not A.command('index-remains-reviewed-B',['git','diff','--cached','--quiet',TREE,'--'])
A.seal_inputs()
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def load(n):return json.loads((OUT/n).read_bytes())
def row(p):
 p=Path(p);return {'path':str(p.relative_to(OUT)),'bytes':p.stat().st_size,'sha256':sha(p)}
def write(n,j):
 with (OUT/n).open('x') as f:json.dump(j,f,indent=2);f.write('\n')
ledgers=sorted(OUT.glob('*-inspected-input-identities.json'));observations={};copies=[]
for p in ledgers:
 j=json.loads(p.read_bytes())
 for e in j['files']:observations[(e['path'],e['bytes'],e['sha256'])]=e
 copies.extend(j.get('selected-original-copies',[]))
for c in copies:
 p=OUT/c['copy'];assert p.stat().st_size==c['bytes'] and sha(p)==c['sha256']
versions={}
for e in observations.values():versions.setdefault(e['path'],[]).append(e)
write('inspected-input-catalog.json',{'scope':'Complete observed input SHA256 catalog for this bounded closure. Preliminary documentation snapshots remain dated observations; subsequent approved versions are separate entries. The former whole Standards archive path is now represented byte-exactly by the ordered parts, not falsely claimed still present as one repository file. No full source/raw/prior-blob replay occurred.','observation-count':len(observations),'unique-paths':len(versions),'files':sorted(observations.values(),key=lambda x:(x['path'],x['sha256'])),'versioned-paths':[{'path':p,'observations':v} for p,v in sorted(versions.items()) if len(v)>1],'component-ledgers':[row(x) for x in ledgers]})
write('selected-original-identities.json',{'copies':copies,'copy-bindings':len(copies),'all-selected-copies-rechecked':True})
report='''Standards bounded closure: **APPROVED** for tree `6b6dd30d0254ee8614df514bc75e54bcabcecf62`, continuing the independently reviewed baseline and phase2 tree `b12a83ab82a0e59425c87fecd16bf317e581adaf`.

Hard violations: **0 open**. The 163,117,736-byte review archive exceeded GitHub’s rule, “GitHub blocks files larger than 100 MiB.” Four ordered parts, each at most 48 MiB, now reconstruct its exact original SHA256. The oversized whole is absent from the final index. [GitHub’s documented limit](https://docs.github.com/en/repositories/working-with-files/managing-large-files/about-large-files-on-github).

Judgment findings: **0 open; 0 new Fowler smells**. The exact 124→126 correction in `capabilities/evidence/T75-text-semantic.md:24` is verified in the frozen index; every other byte of that document remains unchanged.

The successful retry actually exited 0. Its 37-path delta contains three existing documentation changes and 34 audit additions. All actual Git blobs match their retained originals; unrelated staged entries and all 1,933 source/30 contract inputs remain unchanged. Both whitespace checks and clean-workspace gates passed. The largest new blob is 96,132,476 bytes.

Five known archives retain 582 originals. New failure, recovery and packaging records add 109 verified originals. Both multipart concatenations reproduce their original archive identities. The first checker’s exit 1 and partial gzip remain preserved; they are not successful output. Verified archive-backed cleanup preserves the five removed temporary packets’ 6,651 originals. The two historically lost derived summaries remain explicitly unrecovered.

The finite terminal step may copy these sealed closing originals exactly and apply the inspected factual review-status transitions, with strict copy/delta identities, unchanged inputs and successful whitespace checks. This requires no recursive source review or approval of the confirmation’s own seal. A minimal external confirmation may bind that receipt. Actual commit, push and issue closure remain external and pending. No project execution, raw-rule/RGB replay or repository mutation occurred in this review.
'''
assert len(report.split())<400
with (OUT/'report.md').open('x') as f:f.write(report)
commands=[]
for p in sorted((OUT/'commands').glob('*-result.json')):
 j=json.loads(p.read_bytes());commands.append({'result':row(p),'command':j['command'],'actual-exit':j['returncode']})
assert all(x['actual-exit']==0 for x in commands)
index=load('frozen-delta-verification-summary.json');transport=load('transport-parts-and-new-originals.json')
receipt={
 'recorded-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'scope':'Independent bounded final Standards closure, with continued prior full-source/incremental/phase1/phase2 lineage; existing independent reviewer, not a newly created fresh agent.',
 'fixed-baseline-and-head':'5b1603c435f11c40368f75b7b9a2777c9c5e9761','prior-reviewed-tree':'b12a83ab82a0e59425c87fecd16bf317e581adaf','approved-tree':TREE,
 'candidate':'ab18cc9c0473730a6aabec5d12e3172f22bea23a0a0f9529052a2bc186cbfc1b','contract':'3de508f79fcbef7258feee8abc013d6f02b000840cac1cb263cb0d6f927b8f2b',
 'prior-standards-phase2':{'original':'/tmp/t75-standards-final-phase2-r4-ui6kls_1','report-sha256':'3a03ac416c3fcdd77857ed27444d24b83819871492e28ba62bf036853b0d1bef','receipt-sha256':'c29c579747c5265d638144b2d51dd4bd892489f61cbc5e861b761d714bba846b','archive-sha256':'a837ebf37379df6875b439a01aa0bb149c1f5eaab7d4589ead2576faca1e496b','original-files':253,'all-original-files-and-exact-membership-byte-verified':True},
 'standards':{'open-hard-violations':0,'open-judgment-findings':0,'new-Fowler-findings':0,'repository-rules-prevail':True,'Fowler-baseline':['Mysterious Name','Duplicated Code','Feature Envy','Data Clumps','Primitive Obsession','Repeated Switches','Shotgun Surgery','Divergent Change','Speculative Generality','Message Chains','Middle Man','Refused Bequest'],'bounded-application':'No new product code or source identity changed; complete prior source judgments remain in force. Audit retention and factual documentation introduce no new structural smell.'},
 'resolved-findings':[{'type':'documentation accuracy judgment','path':'capabilities/evidence/T75-text-semantic.md','line':24,'before-sha256':'e4284bac2c389943ea8b02d086802ed959c85734830ed01e7047fb06f453398f','after-sha256':'46312a3d59ffe30cecc6c15ec2ff96e21f7aa757b163341e83b74e8ccc6892fa','exact-change':'124 -> 126 once; both1422 bytes; every other byte unchanged','basis':'docs/t13-certification.md:513-514, existing Worker split and actual eight text tuple contracts','closed-in-approved-tree':True},{'type':'GitHub delivery size blocker','path':'capabilities/evidence/T75-delivery/final-delivery-review-r4/standards-final-index.tar.xz','original-bytes':163117736,'applicable-rule':'GitHub blocks files larger than 100 MiB.','source':'https://docs.github.com/en/repositories/working-with-files/managing-large-files/about-large-files-on-github','source-copy':row(OUT/'github-size-limit-web-result.json'),'closed-by':'Four ordered byte-exact parts, maximum50331648 bytes; original concatenation SHA256 retained; oversized whole absent from final index.'}],
 'index':index,
 'actual-successful-checker':load('gate-v2-authorized-snapshot.json'),
 'original-failed-checker':load('gate-observation.json'),
 'source-contract-continuity':{'source-inputs':1933,'contract-inputs':30,'freeze-sha256':'50988226c0db8a0eddd622ec3d9656d5ad6eb1e25328f22a067ee0e54add392d','no-delta-path-intersects-frozen-inputs':True,'all-unrelated-index-entries-unchanged':True,'previous-artifact-harness-and48-certification-identities-unchanged':True,'prior-validation-and-inventory-closures-not-rerun':True},
 'transport':{'standards-parts':4,'standards-archive-bytes':163117736,'standards-archive-sha256':transport['standards-review']['sha256'],'failed-checker-parts':5,'failed-checker-archive-bytes':transport['failed-first-delta']['bytes'],'failed-checker-archive-sha256':transport['failed-first-delta']['sha256'],'per-part-maximum-bytes-inclusive':50331648,'interpretation':'The transport reader key all-individual-parts-under48MiB means at most48 MiB: its actual assertion is <=48*1024*1024 and the full exact sizes are retained.','known-members-byte-verified':582,'new-failure-recovery-packaging-members-byte-verified':109,'total-members-covered':691,'whole-archive-bytes-preserved':True,'partial-gzip-exact-bytes':76283904,'partial-gzip-sha256':'b1b066981a68ca2ed5e6a5828bfa5e3785e44b018c34244a707f4cc7260af5ad','partial-output-not-claimed-complete':True},
 'capacity-recovery':{'parent-actual-exit':0,'exact-old-temp-packets':5,'fully-byte-verified-originals':6651,'logical-bytes':968467306,'archive-and-identity-shas-rechecked-by-reviewer':True,'current-certification-tree-and-active-closure-originals-remain':True,'detail':row(OUT/'recovery-boundary-verified-boundary.json')},
 'reader-capacity-diagnostic':{'source':row(OUT/'capacity-original-commands-errors.json'),'actual-creation-tool-exit':1,'actual-wrapper-tool-exit':1,'cause':'ENOSPC prevented creation of the small membership reader and its wrapper output files. Exact original commands/errors were retained in the tool conversation and orchestration memory, then saved exclusively after capacity recovery.','no-success-claimed-for-failed-attempt':True,'separate-successful-reader':'pre-index-membership-v2.py','separate-result':row(OUT/'commands/pre-index-membership-v2-result.json'),'no-original-overwrite':True},
 'historical-exception':{'two-derived-r3-summary-sizes':[55109,79646],'old-bytes-and-hashes-unavailable':True,'fresh-independent-read-is-not-recovery':True,'certification-originals-intact':True,'no-preservation-waiver-or-blanket-all-history-survived-claim':True,'frozen-final-documents-retain-exact-boundary':True},
 'finite-terminal-approval':{'approved':True,'scope':'Exact copying/sealing of both independently closed packets and the completed checker originals; factual technical-review status transitions in the three inspected navigation documents; bounded retention metadata.','inspected-status-script':{'path':'/tmp/t75-terminal-status-text-r4.py','sha256':sha('/tmp/t75-terminal-status-text-r4.py')},'inspected-terminal-checker':{'path':'/tmp/t75-terminal-index-check-r4.py','sha256':sha('/tmp/t75-terminal-index-check-r4.py')},'required-mechanical-guards':['Exact copied original/part identities and safe file sizes','Only the approved status-document changes and explicit new audit files','All unrelated B entries and1933/30 frozen inputs unchanged','Actual strict-delta and both whitespace checks exit0','Historical loss and external-delivery boundaries unchanged'],'additional-source-raw-review-required':False,'recursive-review-of-confirmation-seal-required':False,'minimal-external-confirmation':'May check the completed terminal receipt, exact copy catalog and approved status outputs without creating another repository-retention cycle.','actual-terminal-check-not-yet-claimed':True,'actual-commit-push-issue-close-not-yet-claimed':True},
 'approval':{'Standards-technical-and-bounded-artifact-status-review':'APPROVED','open-findings':0,'external-delivery-performed-by-reviewer':False,'completion-criteria-marked-by-reviewer':False},
 'activity':{'repo-Git-index-authority-tracker-writes':False,'project-CLI-Maven-tests-certifiers-environment-observers':False,'full-source-raw-rule-RGB-or-prior-blob-replay':False,'archive-payload-output-duplication':False,'new-subagents':False},
 'output-boundary':'All completed formal readers retain original script, command, complete stdout/stderr and actual result. Original capacity errors also retain exact commands and tool exits. Auxiliary display truncation did not truncate saved output. The requested Git streaming comparison records its complete payload hash and per-file identities; actual payload bytes remain the byte-exact staged originals/Git objects rather than a redundant copy.',
 'commands':commands,
 'details':[row(OUT/x) for x in ['frozen-delta-verification-summary.json','frozen-delta-actual-delta-blob-identities.json','transport-parts-and-new-originals.json','completed-archives-member-byte-verification.json','pre-index-membership-v2-exact-original-memberships.json','recovery-boundary-verified-boundary.json','inspected-input-catalog.json','selected-original-identities.json']],
 'report':{**row(OUT/'report.md'),'words':len(report.split())},
 'retention':{'exclusive-file-creation':True,'manifest':'artifact-manifest.json','manifest-excludes':['artifact-manifest.json','commands/seal-closure.stdout','commands/seal-closure.stderr','commands/seal-closure-result.json'],'reason':'The manifest cannot include itself or the executing runner outputs before they exist. All four are retained after completion and must be included by the full parent archive identity.'}}
write('receipt.json',receipt)
excluded=set(receipt['retention']['manifest-excludes'])
files=[row(p) for p in sorted(OUT.rglob('*')) if p.is_file() and str(p.relative_to(OUT)) not in excluded]
write('artifact-manifest.json',{'files':files,'file-count':len(files),'excluded':sorted(excluded),'scope':'Complete finished packet except the explicit self/finalizer boundary; parent archival must include all four after actual finalizer exit.'})
print(json.dumps({'packet':str(OUT),'report':row(OUT/'report.md'),'receipt':row(OUT/'receipt.json'),'catalog':row(OUT/'inspected-input-catalog.json'),'manifest':row(OUT/'artifact-manifest.json'),'manifest-files':len(files),'completed-packet-files':len(files)+4,'input-observations':len(observations),'unique-input-paths':len(versions),'selected-original-copies':len(copies),'report-words':len(report.split()),'approved-tree':TREE,'open-findings':0},indent=2))
