from auditlib import Audit,OUT,DELIVERY
from pathlib import Path,PurePosixPath
import hashlib,json,tarfile
A=Audit('transport')
base=DELIVERY/'final-delivery-review-r4'
class Parts:
 def __init__(self,j):self.parts=j['parts'];self.i=0;self.f=None;self.h=hashlib.sha256();self.n=0;self.ph=None;self.pn=0;self.checked=[]
 def read(self,n):
  assert n>=0
  pieces=[];left=n
  while left:
   if self.f is None:
    if self.i==len(self.parts):break
    e=self.parts[self.i];assert e['offset']==self.n and e['bytes']<=48*1024*1024
    self.f=(base/e['path']).open('rb');self.ph=hashlib.sha256();self.pn=0
   b=self.f.read(left)
   if b:
    self.h.update(b);self.n+=len(b);self.ph.update(b);self.pn+=len(b);pieces.append(b);left-=len(b)
   else:
    e=self.parts[self.i];assert self.pn==e['bytes'] and self.ph.hexdigest()==e['sha256']
    path=base/e['path'];A.inputs[str(path)]={'path':str(path),'bytes':self.pn,'sha256':self.ph.hexdigest()}
    self.checked.append(e);self.f.close();self.f=None;self.i+=1
  return b''.join(pieces)
 def finish(self):
  while self.read(1048576):pass

def verify_parts(name,read_members=False):
 parts=A.json(base/(name+'-parts.json'),name+'-parts.json');identity=A.json(base/(name+'-archive-identity.json'))
 assert parts['archive']==identity['archive'] and parts['sha256']==identity['sha256']
 reader=Parts(parts);members=[]
 if read_members:
  expected={e['path']:e for e in identity['members']};seen=set()
  with tarfile.open(fileobj=reader,mode='r|xz') as tf:
   for m in tf:
    assert m.isfile() and not m.name.startswith('/') and '..' not in PurePosixPath(m.name).parts and m.name not in seen
    e=expected[m.name];source=Path(e['source']);h=hashlib.sha256();size=0
    with tf.extractfile(m) as archived,source.open('rb') as original:
     while True:
      b=archived.read(1048576);s=original.read(len(b) if b else 1);assert s==b,m.name
      if not b:break
      h.update(b);size+=len(b)
    assert size==e['size'] and h.hexdigest()==e['sha256'];seen.add(m.name)
    A.inputs[str(source)]={'path':str(source),'bytes':size,'sha256':h.hexdigest()};members.append({'path':m.name,'source':str(source),'bytes':size,'sha256':h.hexdigest()})
  assert seen==expected.keys()
 reader.finish();assert reader.n==parts['bytes'] and reader.h.hexdigest()==parts['sha256'] and len(reader.checked)==len(parts['parts'])
 return {'logical-archive':parts['archive'],'bytes':reader.n,'sha256':reader.h.hexdigest(),'parts':reader.checked,'all-part-digests-offsets-sizes-and-ordered-concatenation-verified':True,'members-newly-compared':len(members),'members':members,'prior-member-proof':'253 originals already independently verified in completed-archives-member-byte-verification.json' if not read_members else None}
std=verify_parts('standards-final-index');assert len(std['parts'])==4 and std['bytes']==163117736 and std['sha256']=='a837ebf37379df6875b439a01aa0bb149c1f5eaab7d4589ead2576faca1e496b'
failed=verify_parts('final-index-disk-failure',True);assert len(failed['parts'])==5 and failed['members-newly-compared']==89
partial=[e for e in failed['members'] if e['path']=='failed-original/delta-blob-18.stdout.gz'];assert len(partial)==1 and partial[0]['bytes']==76283904 and partial[0]['sha256']=='b1b066981a68ca2ed5e6a5828bfa5e3785e44b018c34244a707f4cc7260af5ad'
# This is original partial compressed Git-output capture, not a complete successful observation.
identity=A.json(base/'archived-review-space-recovery-archive-identity.json');assert len(identity['members'])==15
archive=base/identity['archive'];assert A.digest(archive)==identity['sha256'];expected={x['path']:x for x in identity['members']};seen=set()
with tarfile.open(archive,'r|xz') as tf:
 for m in tf:
  assert m.isfile() and m.name in expected and m.name not in seen;seen.add(m.name);e=expected[m.name];b=tf.extractfile(m).read()
  assert b==A.read(Path(e['source'])) and len(b)==e['size'] and hashlib.sha256(b).hexdigest()==e['sha256']
assert seen==expected.keys()
path=base/'final-audit-packaging-archive-identity.json';identity=A.json(path);pack,_=A.archive(identity,path);assert pack['member-count']==5
A.emit('parts-and-new-originals',{'standards-review':std,'failed-first-delta':failed,'recovery-members-byte-verified':15,'packaging-members-byte-verified':5,'packaging':pack,'newly-verified-originals':109,'previous-known-archive-originals':582,'total-original-members-covered':691,'initial-oversize-archive-finding-closed':True,'all-individual-parts-under48MiB':True,'no-original-whole-archive-rewrite':True,'failed-partial-gzip-kept-byte-exact-not-promoted-to-complete-output':partial})
A.seal_inputs();print(json.dumps({'standards-four-part-sha256':std['sha256'],'failed-five-part-sha256':failed['sha256'],'original-members-covered':691,'new-member-checks':109,'no-payload-copy-or-old-member-replay':True},indent=2))
