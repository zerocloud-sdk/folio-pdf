from auditlib import Audit,OUT,DELIVERY
from pathlib import Path
import json
A=Audit('completed-archives');audits=[]
for name in ['standards-final-index','spec-final-index','git-index-whitespace-failure','git-index-frozen','fixed-baseline-review-setup']:
 path=DELIVERY/'final-delivery-review-r4'/(name+'-archive-identity.json');j=A.json(path)
 audit,_=A.archive(j,path);audits.append(audit)
 print(name,audit['member-count'],'original member bytes verified',flush=True)
assert sum(x['member-count'] for x in audits)==582
A.emit('member-byte-verification',audits)
for name in ['standards-final-index','spec-final-index']:
 for suffix in ['report.md','receipt.json']:
  target=DELIVERY/'final-delivery-review-r4'/(name+'-'+suffix)
  print(name,suffix,A.read(target,name+'-'+suffix).decode() if suffix=='report.md' else A.digest(target))
A.seal_inputs();print('All five completed new archives / 582 original members match. Oversized whole Standards archive remains a separate packaging blocker until a verified bounded representation replaces it in the final index.')
