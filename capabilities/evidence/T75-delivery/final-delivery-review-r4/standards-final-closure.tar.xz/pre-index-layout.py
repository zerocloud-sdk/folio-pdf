from auditlib import Audit,OUT,DELIVERY
from pathlib import Path
import json
A=Audit('pre-index-layout')
for path in sorted((DELIVERY/'final-delivery-review-r4').iterdir()):
 if path.is_file():print(path.name,path.stat().st_size)
for name in ['t75-finalize-delivery-index-r4.log','t75-finalize-delivery-index-r4-command.json','t75-finalize-delivery-index-r4-result.json']:
 path=Path('/tmp')/name
 if path.exists():print(name,A.read(path,name).decode())
for relative in ['final-execution-receipt.md','final-delivery-review-r4/README.md']:
 raw=A.read(DELIVERY/relative,relative);print('CURRENT DOCUMENT',relative,raw.decode())
A.seal_inputs()
