from auditlib import Audit,OUT,DELIVERY
from pathlib import Path
import json
A=Audit('packaging-layout')
for suffix in ['command.json','result.json']:
 path=Path('/tmp/t75-package-final-audit-r4-r2-'+suffix)
 if path.exists():print(path.name,A.read(path,path.name).decode())
log=Path('/tmp/t75-package-final-audit-r4-r2.log')
if log.exists():print(log.name,A.read(log,log.name).decode())
for path in sorted((DELIVERY/'final-delivery-review-r4').iterdir()):
 if path.is_file() and any(x in path.name for x in ['part','multipart','capacity','recovery','packag','failure']):
  print('FILE',path.name,path.stat().st_size)
  if path.suffix=='.json' and path.stat().st_size<1000000:print('JSON',A.read(path,path.name).decode())
A.seal_inputs()
