from auditlib import Audit,OUT,REPO,DELIVERY
from pathlib import Path
import json,hashlib
A=Audit('completed-correction')
old=Path('/tmp/t75-standards-final-phase2-r4-ui6kls_1/selected-originals/closing-interpretation/semantic-evidence-index.md')
old_raw=A.read(old,'original-124-index.md')
new_raw=A.read(REPO/'capabilities/evidence/T75-text-semantic.md','corrected-126-index.md')
assert hashlib.sha256(old_raw).hexdigest()=='e4284bac2c389943ea8b02d086802ed959c85734830ed01e7047fb06f453398f'
assert hashlib.sha256(new_raw).hexdigest()=='46312a3d59ffe30cecc6c15ec2ff96e21f7aa757b163341e83b74e8ccc6892fa'
assert old_raw.count(b'124')==1 and new_raw==old_raw.replace(b'124',b'126') and len(new_raw)==1422
A.emit('finding-closure',{'path':'capabilities/evidence/T75-text-semantic.md','old-sha256':hashlib.sha256(old_raw).hexdigest(),'new-sha256':hashlib.sha256(new_raw).hexdigest(),'old-and-new-bytes':1422,'exact-replacement':'124 -> 126, once; all other bytes identical','worktree-document-correction-closed':True,'final-index-binding-pending-successful-checker':True})
# Only completed new archive identities are read before the final-index gate.
for name in ['standards-final-index','spec-final-index','git-index-whitespace-failure','git-index-frozen','fixed-baseline-review-setup']:
 path=DELIVERY/'final-delivery-review-r4'/(name+'-archive-identity.json')
 j=A.json(path,name+'-archive-identity.json')
 print(name,'keys',list(j),'count',len(j.get('members',[])),'archive',j.get('archive'),'original',j.get('original'),'sha',j.get('sha256'))
 A.digest(path.parent/j['archive'])
A.seal_inputs();print('Exact documentation correction independently verified; final index remains pending.')
