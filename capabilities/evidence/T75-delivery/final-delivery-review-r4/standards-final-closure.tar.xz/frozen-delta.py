from auditlib import Audit,OUT,REPO,DELIVERY
from pathlib import Path
import gzip,hashlib,json,subprocess,datetime,stat
A=Audit('frozen-delta')
prior='b12a83ab82a0e59425c87fecd16bf317e581adaf';tree='6b6dd30d0254ee8614df514bc75e54bcabcecf62'
gate=A.json(OUT/'gate-v2-authorized-snapshot.json');assert gate['actual-exit']==0
original=Path(gate['snapshot']);receipt=A.json(original/'receipt.json')
assert receipt['reviewed-tree']==prior and receipt['final-tree']==tree and len(receipt['delta'])==37
for path in sorted(original.iterdir()):
 if path.is_file():
  raw=A.read(path,'original-checker/'+path.name)
  if path.name.endswith('-result.json'):
   j=json.loads(raw);assert j['returncode']==0
   stem=path.name[:-12]
   if (original/(stem+'.stdout.gz')).exists():
    for kind in ['stdout','stderr']:
     data=gzip.decompress((original/(stem+'.'+kind+'.gz')).read_bytes())
     assert len(data)==j[kind+'-bytes'] and hashlib.sha256(data).hexdigest()==j[kind+'-sha256']
for suffix in ['command.json','result.json']:
 p=Path('/tmp/t75-finalize-delivery-index-r4-r2-'+suffix);A.read(p,'wrapper/'+p.name)
A.read(Path('/tmp/t75-finalize-delivery-index-r4-r2.log'),'wrapper/actual.log')
assert A.command('head',['git','rev-parse','HEAD']).decode().strip()=='5b1603c435f11c40368f75b7b9a2777c9c5e9761'
assert not A.command('index-equals-final-tree',['git','diff','--cached','--quiet',tree,'--'])
live=A.command('live-delta',['git','diff','--cached','--name-status','-z','--no-renames',prior,'--'])
fixed=A.command('frozen-delta',['git','diff','--name-status','-z','--no-renames',prior,tree,'--'])
assert live==fixed
fields=fixed.split(b'\0');assert fields.pop()==b''
changes={fields[i+1].decode():fields[i].decode() for i in range(0,len(fields),2)}
expected={x['path']:x for x in receipt['delta']};assert changes.keys()==expected.keys()
modified={p for p,s in changes.items() if s=='M'}
assert modified=={'capabilities/evidence/T75-text-semantic.md','capabilities/evidence/T75-delivery/final-execution-receipt.md','capabilities/evidence/T75-delivery/final-delivery-review-r4/README.md'}
assert all(s in ['M','A'] for s in changes.values()) and len(changes)-len(modified)==34
prefix='capabilities/evidence/T75-delivery/final-delivery-review-r4/'
assert all(p.startswith(prefix) for p,s in changes.items() if s=='A')
freeze=A.json(DELIVERY/'final-validation-r4/source-and-contract-inputs.json')
assert len(freeze['inputs'])==1933 and len(freeze['contract-inputs'])==30
assert A.digest(DELIVERY/'final-validation-r4/source-and-contract-inputs.json')==receipt['frozen-input-sha256']=='50988226c0db8a0eddd622ec3d9656d5ad6eb1e25328f22a067ee0e54add392d'
assert not set(expected)&{r['path'] for k in ['inputs','contract-inputs'] for r in freeze[k]}
index_raw=A.command('delta-index-entries',['git','ls-files','--stage','-z','--']+sorted(expected))
index={}
for r in index_raw.split(b'\0'):
 if r:
  d,n=r.split(b'\t',1);mode,oid,stage=d.decode().split();assert stage=='0';index[n.decode()]=(mode,oid)
assert index.keys()==expected.keys()
objects=[]
for name in sorted(expected):
 r=expected[name];assert index[name]==(r['mode'],r['oid']) and r['mode']=='100644' and r['bytes']<100*1024*1024
 assert Path(name).suffix not in ['.class','.pyc','.jar','.zip']
 objects.append((name,r))
stdin=OUT/'frozen-delta-object-requests.txt'
with stdin.open('x') as f:
 for name,r in objects:f.write(r['oid']+'\n')
start=datetime.datetime.now(datetime.timezone.utc).isoformat();wire=hashlib.sha256();wire_size=0;verified=[]
err=OUT/'commands/frozen-delta-actual-blobs.stderr'
with stdin.open('rb') as inp,err.open('xb') as errors:
 proc=subprocess.Popen(['git','cat-file','--batch'],cwd=REPO,stdin=inp,stdout=subprocess.PIPE,stderr=errors)
 for name,r in objects:
  header=proc.stdout.readline();wire.update(header);wire_size+=len(header)
  oid,kind,size=header.decode().strip().split();assert oid==r['oid'] and kind=='blob' and int(size)==r['bytes']
  path=REPO/name;assert stat.S_ISREG(path.lstat().st_mode)
  h=hashlib.sha256();h1=hashlib.sha1(('blob '+size+'\0').encode());left=int(size)
  with path.open('rb') as source:
   while left:
    b=proc.stdout.read(min(left,1048576));assert b and source.read(len(b))==b,name
    h.update(b);h1.update(b);wire.update(b);wire_size+=len(b);left-=len(b)
   assert not source.read(1)
  tail=proc.stdout.read(1);assert tail==b'\n';wire.update(tail);wire_size+=1
  assert h.hexdigest()==r['sha256'] and h1.hexdigest()==oid
  A.inputs[str(path)]={'path':str(path),'bytes':int(size),'sha256':h.hexdigest()}
  verified.append({'path':name,'mode':r['mode'],'git-oid':oid,'bytes':int(size),'sha256':h.hexdigest(),'actual-git-blob-byte-equality':True})
 assert not proc.stdout.read(1);rc=proc.wait()
command_result={'command':['git','cat-file','--batch'],'cwd':str(REPO),'stdin':str(stdin),'started-utc':start,'completed-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'returncode':rc,'stdout-stream-bytes':wire_size,'stdout-stream-sha256':wire.hexdigest(),'stderr-bytes':err.stat().st_size,'payload-retention':'No archive payload stdout duplication. Complete blob bytes are the exact retained staged original files cataloged below and actual Git objects; original headers and per-blob SHA256/OID/size are retained as structured results.'}
with (OUT/'commands/frozen-delta-actual-blobs-result.json').open('x') as f:json.dump(command_result,f,indent=2);f.write('\n')
assert rc==0 and err.stat().st_size==0
A.emit('actual-delta-blob-identities',verified)
new=(REPO/'capabilities/evidence/T75-text-semantic.md').read_bytes()
old=A.command('old-semantic-index',['git','show',prior+':capabilities/evidence/T75-text-semantic.md'])
assert len(old)==len(new)==1422 and old.count(b'124')==1 and new==old.replace(b'124',b'126')
assert hashlib.sha256(new).hexdigest()=='46312a3d59ffe30cecc6c15ec2ff96e21f7aa757b163341e83b74e8ccc6892fa'
diff=A.command('three-document-diff',['git','diff','--no-ext-diff','--no-textconv',prior,tree,'--']+sorted(modified));print(diff.decode())
for name in sorted(modified):A.read(REPO/name,'final-documents/'+name)
assert not A.command('index-still-equals-final-tree',['git','diff','--cached','--quiet',tree,'--'])
summary={'prior-tree':prior,'final-tree':tree,'actual-parent-exit':0,'exact-delta-paths':37,'modified-existing-documents':3,'new-audit-files':34,'all37-actual-git-blobs-byte-match-current-originals':True,'source-contract-intersection':[],'source-inputs':1933,'contract-inputs':30,'all-other-prior-staged-entries-unchanged':True,'both-original-whitespace-checks':0,'parent-clean-worktree-and-no-untracked-or-ignored-evidence':True,'maximum-new-blob-bytes':max(x['bytes'] for x in verified),'oversized-whole-standards-archive-not-in-final-index':prefix+'standards-final-index.tar.xz' not in expected,'documentation-finding-closed-in-frozen-index':True,'index-unchanged-through-read':True,'no-complete-raw-source-or-prior-blob-replay':True}
A.emit('verification-summary',summary);A.seal_inputs();print(json.dumps(summary,indent=2))
