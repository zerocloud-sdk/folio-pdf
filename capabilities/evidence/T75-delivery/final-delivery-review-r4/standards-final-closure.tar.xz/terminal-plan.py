from auditlib import Audit,OUT
from pathlib import Path
import json
A=Audit('terminal-plan')
for name in ['t75-terminal-status-text-r4.py','t75-terminal-index-check-r4.py']:
 path=Path('/tmp')/name;print(name,A.read(path,name).decode())
A.emit('observation',{'scripts-read-only':True,'prepared-scripts-not-executed-by-reviewer':True,'future-terminal-outcome-not-inferred':True});A.seal_inputs()
