from auditlib import Audit,OUT,DELIVERY
from pathlib import Path
import json
A=Audit('pre-index-membership-v2');rows=[]
for name in ['standards-final-index','spec-final-index','git-index-whitespace-failure','git-index-frozen','fixed-baseline-review-setup']:
 path=DELIVERY/'final-delivery-review-r4'/(name+'-archive-identity.json');j=A.json(path)
 original=Path(j['original']);expected={x['path'] for x in j['members']}
 actual={str(x.relative_to(original)) for x in original.rglob('*') if x.is_file()}
 assert actual==expected and not j['symbolic_links'],name
 rows.append({'name':name,'original':str(original),'archive-sha256':j['sha256'],'exact-regular-member-count':len(expected),'no-extra-or-missing-original-files':True})
A.emit('exact-original-memberships',rows);A.seal_inputs();print(json.dumps(rows,indent=2))
