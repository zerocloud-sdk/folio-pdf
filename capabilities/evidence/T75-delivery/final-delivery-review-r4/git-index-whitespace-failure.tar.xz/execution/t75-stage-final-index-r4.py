from pathlib import Path
from collections import Counter, defaultdict
from datetime import datetime, timezone
import gzip, hashlib, importlib.util, json, os, stat, subprocess, tempfile
import yaml

root = Path('/home/ubuntu/IdeaProjects/open-pdf')
os.chdir(root)
baseline = '5b1603c435f11c40368f75b7b9a2777c9c5e9761'
original = Path(tempfile.mkdtemp(prefix='t75-final-index-r4-'))
commands = []
def call(name, args):
    start = datetime.now(timezone.utc).isoformat()
    result = subprocess.run(args, cwd=root, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    for label, data in [('stdout', result.stdout), ('stderr', result.stderr)]:
        (original / (name + '.' + label + '.gz')).write_bytes(gzip.compress(data, mtime=0))
    receipt = {'command': args, 'started-utc': start, 'completed-utc': datetime.now(timezone.utc).isoformat(), 'returncode': result.returncode, 'stdout-bytes': len(result.stdout), 'stdout-sha256': hashlib.sha256(result.stdout).hexdigest(), 'stderr-bytes': len(result.stderr), 'stderr-sha256': hashlib.sha256(result.stderr).hexdigest()}
    (original / (name + '-result.json')).write_text(json.dumps(receipt, indent=2) + '\n')
    commands.append(receipt)
    assert result.returncode == 0, name
    return result.stdout

assert call('head-before', ['git', 'rev-parse', 'HEAD']).decode().strip() == baseline
assert not call('initial-index', ['git', 'diff', '--cached', '--name-only'])
frozen_path = root / 'capabilities/evidence/T75-delivery/final-validation-r4/source-and-contract-inputs.json'
frozen = json.loads(frozen_path.read_bytes())
spec = importlib.util.spec_from_file_location('foundation_capture', root / 'scripts/t03-foundation.py')
foundation = importlib.util.module_from_spec(spec)
spec.loader.exec_module(foundation)
contract = yaml.safe_load((root / 'capabilities/foundation-release.yaml').read_bytes())
assert foundation.capture_build_inputs(root, contract) == frozen
assert json.loads(Path('/tmp/t75-final-inventory-queue-r4-result.json').read_bytes())['returncode'] == 0
pre = Path(Path('/tmp/t75-pre-index-classification-r4-v2-original-path.txt').read_text().strip())
pre_receipt = json.loads((pre / 'receipt.json').read_bytes())
(original / 'pre-index-classification-receipt.json').write_bytes((pre / 'receipt.json').read_bytes())
(original / 'pre-index-modified-paths.gz').write_bytes((pre / 'modified.paths.gz').read_bytes())
modified = call('tracked-changes', ['git', 'diff', '-z', '--name-only', 'HEAD', '--'])
assert set(modified.split(b'\0')) == set(gzip.decompress((pre / 'modified.paths.gz').read_bytes()).split(b'\0'))
new = call('untracked', ['git', 'ls-files', '-z', '--others', '--exclude-standard', '--'])
new_paths = [p.decode() for p in new.split(b'\0') if p]
assert {p for p in new_paths if not p.startswith('capabilities/evidence/T75-')} == set(pre_receipt['new-outside-ticket-evidence'])
ignored = call('ignored-evidence', ['git', 'ls-files', '-z', '--others', '--ignored', '--exclude-standard', '--', 'capabilities/evidence/T75-*'])
ignored_paths = [p.decode() for p in ignored.split(b'\0') if p]
assert all(p.endswith('.log') for p in ignored_paths)
print('Staging intentional changes and', len(ignored_paths), 'ignored original logs', flush=True)
call('stage-intentional', ['git', '-c', 'gc.auto=0', 'add', '--all', '--', '.'])
if ignored_paths:
    pathspec = original / 'ignored-evidence.pathspec'
    pathspec.write_bytes(ignored)
    call('stage-original-logs', ['git', '-c', 'gc.auto=0', 'add', '-f', '--pathspec-from-file=' + str(pathspec), '--pathspec-file-nul'])
call('diff-check', ['git', 'diff', '--check'])
call('cached-diff-check', ['git', 'diff', '--cached', '--check'])
call('unstaged-diff', ['git', 'diff', '--exit-code', '--quiet'])
assert not call('remaining-untracked', ['git', 'ls-files', '-z', '--others', '--exclude-standard', '--'])
assert not call('remaining-ignored-evidence', ['git', 'ls-files', '-z', '--others', '--ignored', '--exclude-standard', '--', 'capabilities/evidence/T75-*'])
base_entries = {}
for record in call('baseline-tree', ['git', 'ls-tree', '-r', '-z', baseline]).split(b'\0'):
    if record:
        descriptor, path = record.split(b'\t', 1)
        mode, kind, oid = descriptor.decode().split(' ')
        base_entries[path.decode()] = (mode, oid)
groups = defaultdict(list)
index_paths = set()
unchanged_count = 0
for record in call('index-entries', ['git', 'ls-files', '--stage', '-z']).split(b'\0'):
    if record:
        descriptor, path = record.split(b'\t', 1)
        mode, oid, stage = descriptor.decode().split(' ')
        assert stage == '0' and mode in ('100644', '100755')
        name = path.decode()
        assert name not in index_paths
        index_paths.add(name)
        if base_entries.get(name) == (mode, oid):
            unchanged_count += 1
        else:
            groups[oid].append((name, mode))
assert set(base_entries) <= index_paths
counts, total_bytes = Counter({'unchanged': unchanged_count}), 0
cat = subprocess.Popen(['git', 'cat-file', '--batch'], cwd=root, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
with gzip.open(original / 'complete-staged-change-identities.jsonl.gz', 'xb') as manifest:
    for oid, paths in sorted(groups.items()):
        cat.stdin.write((oid + '\n').encode())
        cat.stdin.flush()
        header = cat.stdout.readline().decode().strip().split(' ')
        assert header[0] == oid and header[1] == 'blob'
        size = int(header[2])
        blob = cat.stdout.read(size)
        assert len(blob) == size and cat.stdout.read(1) == b'\n'
        digest = hashlib.sha256(blob).hexdigest()
        for name, mode in paths:
            path = root / name
            assert not path.is_symlink() and path.is_file()
            assert path.read_bytes() == blob, name
            assert bool(path.stat().st_mode & stat.S_IXUSR) == (mode == '100755'), name
            change = 'modified' if name in base_entries else 'added'
            if change != 'unchanged':
                assert path.suffix not in ('.class', '.jar', '.pyc', '.zip'), name
                assert not blob.startswith(b'\x7fELF'), name
                assert len(blob) < 100 * 1024 * 1024, name
            counts[change] += 1
            total_bytes += size
            manifest.write((json.dumps({'path': name, 'mode': mode, 'git-oid': oid, 'bytes': size, 'sha256': digest, 'change': change}, separators=(',', ':')) + '\n').encode())
cat.stdin.close()
assert cat.wait() == 0 and not cat.stderr.read()
assert foundation.capture_build_inputs(root, contract) == frozen
tree = call('write-tree', ['git', 'write-tree']).decode().strip()
assert call('head-after', ['git', 'rev-parse', 'HEAD']).decode().strip() == baseline
call('final-unstaged-diff', ['git', 'diff', '--exit-code', '--quiet'])
(original / 'source-and-contract-inputs.json').write_bytes(frozen_path.read_bytes())
(original / Path(__file__).name).write_bytes(Path(__file__).read_bytes())
receipt = {'recorded-utc': datetime.now(timezone.utc).isoformat(), 'baseline': baseline, 'tree': tree, 'scope': 'Intentional frozen staged index before final independent review. Every added or modified staged regular file was compared byte-for-byte with its actual Git blob; complete change identities and entire baseline/index listings are retained. Unchanged baseline entries retain their Git OIDs and modes. Later approved review/receipt artifacts require bounded delta verification.', 'counts': dict(counts), 'index-files': len(index_paths), 'unique-changed-blobs': len(groups), 'changed-index-bytes': total_bytes, 'all-baseline-paths-preserved': True, 'explicitly-staged-ignored-original-logs': len(ignored_paths), 'source-and-contract-unchanged': True, 'git-diff-check-exit': 0, 'git-diff-cached-check-exit': 0, 'commands': commands}
(original / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
with Path('/tmp/t75-final-index-r4-original-path.txt').open('x') as out:
    out.write(str(original) + '\n')
print(json.dumps({k: v for k, v in receipt.items() if k != 'commands'}), flush=True)
