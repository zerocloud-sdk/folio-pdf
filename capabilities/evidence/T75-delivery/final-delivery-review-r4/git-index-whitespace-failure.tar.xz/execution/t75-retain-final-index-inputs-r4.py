from pathlib import Path
from datetime import datetime, timezone
import hashlib, importlib.util, json, tempfile

root = Path('/home/ubuntu/IdeaProjects/open-pdf')
dest = root / 'capabilities/evidence/T75-delivery/final-delivery-review-r4'
spec = importlib.util.spec_from_file_location('retain', root / 'capabilities/evidence/T75-delivery/recorder-r4/retain-programs.py')
retain = importlib.util.module_from_spec(spec)
spec.loader.exec_module(retain)
retain.destination = dest
items = [
    ('git-index-whitespace-failure', Path('/tmp/t75-final-index-r4-wiv_ku_6'), '/tmp/t75-stage-final-index-r4', Path('/tmp/t75-stage-final-index-r4.py'), 1),
    ('git-index-frozen', Path('/tmp/t75-final-index-r4-r2-anwem1dh'), '/tmp/t75-stage-final-index-r4-r2', Path('/tmp/t75-stage-final-index-r4-r2.py'), 0),
]
for name, source_root, prefix, program, code in items:
    for suffix in ('.tar.xz', '-archive-identity.json', '-retention-receipt.json'):
        assert not (dest / (name + suffix)).exists(), name + suffix
    actual = json.loads(Path(prefix + '-result.json').read_bytes())
    assert actual['returncode'] == code
    if code == 0:
        receipt = json.loads((source_root / 'receipt.json').read_bytes())
        assert receipt['tree'] == 'b12a83ab82a0e59425c87fecd16bf317e581adaf'
        assert receipt['source-and-contract-unchanged'] and receipt['git-diff-cached-check-exit'] == 0
    else:
        assert json.loads((source_root / 'cached-diff-check-result.json').read_bytes())['returncode'] == 2
    original = Path(tempfile.mkdtemp(prefix='t75-retained-' + name + '-r4-'))
    copies = []
    def copy(source, relative):
        data = source.read_bytes()
        target = original / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as out:
            out.write(data)
        assert target.read_bytes() == data
        copies.append({'original': str(source), 'copy': relative, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
    for path in sorted(source_root.rglob('*')):
        assert not path.is_symlink(), str(path)
        if path.is_file():
            copy(path, 'original/' + path.relative_to(source_root).as_posix())
    for suffix in ('-command.json', '-result.json', '.log'):
        path = Path(prefix + suffix)
        copy(path, 'execution/' + path.name)
    for path in (program, Path('/tmp/t75-run-retained.py'), Path(__file__)):
        copy(path, 'execution/' + path.name)
    receipt = {'recorded-utc': datetime.now(timezone.utc).isoformat(), 'scope': 'Immutable original staging observations. First outer exit1 retains the real cached whitespace exit2; second actual exit0 preserves exact data with scoped Git attributes and freezes the complete reviewed index. This archive is a later review artifact, not part of its own recorded tree.', 'actual-outer-returncode': code, 'original-observation': str(source_root), 'copies': copies}
    with (original / 'retention-receipt.json').open('x') as out:
        out.write(json.dumps(receipt, indent=2) + '\n')
    identity = retain.archive(name, original)
    with (dest / (name + '-archive-identity.json')).open('x') as out:
        out.write(json.dumps(identity, indent=2) + '\n')
    with (dest / (name + '-retention-receipt.json')).open('xb') as out:
        out.write((original / 'retention-receipt.json').read_bytes())
    print(json.dumps({'name': name, 'original': str(original), 'members': len(identity['members']), 'sha256': identity['sha256']}), flush=True)
