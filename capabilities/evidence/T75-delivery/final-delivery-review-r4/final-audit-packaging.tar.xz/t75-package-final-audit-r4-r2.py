from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,tarfile,shutil,subprocess,tempfile,os
root=Path('/home/ubuntu/IdeaProjects/open-pdf'); out=root/'capabilities/evidence/T75-delivery/final-delivery-review-r4'
packet=Path(tempfile.mkdtemp(prefix='t75-final-audit-packaging-r4-'))
(packet/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def split_exact(path,name,expected=None):
 original_sha=sha(path); size=path.stat().st_size
 if expected:assert original_sha==expected
 parts=[]; offset=0
 with path.open('rb') as source:
  while True:
   data=source.read(48*1024*1024)
   if not data:break
   part=out/(name+'.part'+str(len(parts)+1).zfill(3)); assert not part.exists()
   with part.open('xb') as f:f.write(data)
   parts.append({'path':part.name,'offset':offset,'bytes':len(data),'sha256':sha(part)}); offset+=len(data)
 h=hashlib.sha256()
 with path.open('rb') as original:
  for part in parts:
   with (out/part['path']).open('rb') as f:
    while True:
     chunk=f.read(1024*1024)
     if not chunk:break
     assert chunk==original.read(len(chunk));h.update(chunk)
  assert not original.read(1)
 assert offset==size and h.hexdigest()==original_sha
 identity={'archive':name,'bytes':size,'sha256':original_sha,'encoding':'Concatenate parts in listed order, without separators, to recover the byte-identical original .tar.xz archive.','parts':parts,'byte-for-byte-comparison':True,'recorded-utc':datetime.now(timezone.utc).isoformat()}
 (out/(name.removesuffix('.tar.xz')+'-parts.json')).write_text(json.dumps(identity,indent=2)+'\n')
 return identity
standards=out/'standards-final-index.tar.xz'
identity=split_exact(standards,standards.name,'a837ebf37379df6875b439a01aa0bb149c1f5eaab7d4589ead2576faca1e496b')
# The complete original bytes now reside in exact ordered parts, independently reconstructible.
standards.unlink()
print('Standards archive split and byte-verified',identity['bytes'],flush=True)

def retain_files(name,sources):
 archive=packet/(name+'.tar.xz'); members=[]
 with tarfile.open(archive,'w:xz') as tar:
  for relative,source in sorted(sources.items()):
   assert source.is_file() and not source.is_symlink(); assert relative not in [x['path'] for x in members]
   tar.add(source,arcname=relative,recursive=False)
   members.append({'path':relative,'source':str(source),'size':source.stat().st_size,'sha256':sha(source)})
 with tarfile.open(archive,'r:xz') as tar:
  observed=tar.getmembers(); assert [m.name for m in observed]==[m['path'] for m in members]
  for m,expected in zip(observed,members):
   h=hashlib.sha256();size=0
   with tar.extractfile(m) as a,Path(expected['source']).open('rb') as b:
    while True:
     chunk=a.read(1024*1024)
     assert chunk==b.read(len(chunk) if chunk else 1)
     if not chunk:break
     h.update(chunk);size+=len(chunk)
   assert size==expected['size'] and h.hexdigest()==expected['sha256']
 archive_sha=sha(archive)
 if archive.stat().st_size>48*1024*1024:
  split_exact(archive,archive.name,archive_sha);archive.unlink()
 else:
  target=out/archive.name;assert not target.exists();shutil.move(archive,target);assert sha(target)==archive_sha
 record={'archive':name+'.tar.xz','sha256':archive_sha,'members':members,'symbolic_links':[],'complete-membership-and-byte-equality':True}
 (out/(name+'-archive-identity.json')).write_text(json.dumps(record,indent=2)+'\n')
 print(name,len(members),'members byte verified',flush=True)
 return record
failed=Path('/tmp/t75-final-delivery-index-r4-eupeb70e')
sources={'failed-original/'+p.relative_to(failed).as_posix():p for p in failed.rglob('*') if p.is_file()}
for p in [Path('/tmp/t75-finalize-delivery-index-r4.py'),Path('/tmp/t75-finalize-delivery-index-r4-command.json'),Path('/tmp/t75-finalize-delivery-index-r4-result.json'),Path('/tmp/t75-finalize-delivery-index-r4.log')]:sources['wrapper/'+p.name]=p
failure=retain_files('final-index-disk-failure',sources)
cleanup=Path('/tmp/t75-archived-review-space-recovery-r4-original-path.txt').read_text().strip(); directory=Path(cleanup)
sources={'original/'+p.name:p for p in directory.iterdir() if p.is_file()}
for p in Path('/dev/shm').glob('t75-free-archived-review-temporaries-r4-r2*'):
 if p.is_file():sources['wrapper/'+p.name]=p
recovery=retain_files('archived-review-space-recovery',sources)
receipt={'recorded-utc':datetime.now(timezone.utc).isoformat(),'standards-parts':identity,'failed-index-original-members':len(failure['members']),'failure':'Actual wrapper exit 1 from ENOSPC while writing duplicate delta-blob-18 stdout gzip. The partial gzip and every previously completed command/stdout/stderr are retained exactly. No final receipt or pointer existed. All preceding checks returned 0.','cleanup':'Five completed raw-review temporary directories removed only after complete byte/membership verification against retained archives. Initial script/wrapper preparation attempts on full root disk failed before execution; successful recorder ran in /dev/shm and copied its exact observations to /tmp after recovery.','recovery-original-members':len(recovery['members']),'product-source-or-contract-edited':False}
(out/'final-index-packaging-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
(packet/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
Path('/tmp/t75-final-audit-packaging-r4-original-path.txt').write_text(str(packet)+'\n')
print('packet',packet,'free',shutil.disk_usage(root).free,flush=True)
