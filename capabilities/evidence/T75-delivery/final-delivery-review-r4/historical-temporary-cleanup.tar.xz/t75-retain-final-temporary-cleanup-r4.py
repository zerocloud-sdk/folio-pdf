from pathlib import Path
import hashlib, importlib.util, json

root = Path('/home/ubuntu/IdeaProjects/open-pdf')
dest = root / 'capabilities/evidence/T75-delivery/final-delivery-review-r4'
review = Path('/tmp/t75-standards-r3-temp-hygiene-i21yv5la')
expected = {'report.md': '69ce50e43fc98266aafbcf1e446ac25561a8fe6a0d5c196ab98e9ff14de25572', 'receipt.json': '3e49121bb6f14f02453c867f4d05040a20ec28856055090b71171d8002a338d0', 'artifact-manifest.json': '1e470f091e804b45777e9f1356e61b2e0eedb7fed2ffadc13855802d8ec463f4'}
for name, digest in expected.items():
    assert hashlib.sha256((review / name).read_bytes()).hexdigest() == digest, name
manifest = json.loads((review / 'artifact-manifest.json').read_bytes())
files = {p.relative_to(review).as_posix() for p in review.rglob('*') if p.is_file()}
assert len(files) == 34 and files == {f['path'] for f in manifest['files']} | set(manifest['excluded'])
for member in manifest['files']:
    data = (review / member['path']).read_bytes()
    assert len(data) == member['bytes'] and hashlib.sha256(data).hexdigest() == member['sha256']
assert json.loads((review / 'commands/seal-packet-result.json').read_bytes())['returncode'] == 0
actual_prefix = '/tmp/t75-remove-verified-historical-review-temporaries-r4'
assert json.loads(Path(actual_prefix + '-result.json').read_bytes())['returncode'] == 0
removal = Path(Path('/tmp/t75-historical-review-temporary-removal-r4-original-path.txt').read_text().strip())
for suffix, name in [('-command.json', 'actual-removal-command.json'), ('-result.json', 'actual-removal-result.json'), ('.log', 'actual-removal.log')]:
    with (removal / name).open('xb') as out:
        out.write(Path(actual_prefix + suffix).read_bytes())
for source in (Path('/tmp/t75-run-retained.py'), Path(__file__)):
    with (removal / source.name).open('xb') as out:
        out.write(source.read_bytes())
spec = importlib.util.spec_from_file_location('retain', root / 'capabilities/evidence/T75-delivery/recorder-r4/retain-programs.py')
retain = importlib.util.module_from_spec(spec)
spec.loader.exec_module(retain)
retain.destination = dest
for name, original, adjacent in [
    ('historical-temporary-cleanup-standards', review, [('report.md', '-report.md'), ('receipt.json', '-receipt.json')]),
    ('historical-temporary-cleanup', removal, [('pre-removal-verification.json', '-verification.json'), ('removal-result.json', '-receipt.json'), ('actual-removal-command.json', '-command.json'), ('actual-removal-result.json', '-result.json'), ('actual-removal.log', '-command.log')]),
]:
    for suffix in ['.tar.xz', '-archive-identity.json'] + [suffix for _, suffix in adjacent]:
        assert not (dest / (name + suffix)).exists(), name + suffix
    for path in original.rglob('*'):
        assert not path.is_symlink(), str(path)
        if path.is_file():
            assert path.suffix not in ('.class', '.jar', '.pyc', '.zip') and not path.read_bytes().startswith(b'\x7fELF')
    identity = retain.archive(name, original)
    with (dest / (name + '-archive-identity.json')).open('x') as out:
        out.write(json.dumps(identity, indent=2) + '\n')
    for source, suffix in adjacent:
        data = (original / source).read_bytes()
        with (dest / (name + suffix)).open('xb') as out:
            out.write(data)
        assert (dest / (name + suffix)).read_bytes() == data
    print(json.dumps({'name': name, 'members': len(identity['members']), 'sha256': identity['sha256']}), flush=True)
