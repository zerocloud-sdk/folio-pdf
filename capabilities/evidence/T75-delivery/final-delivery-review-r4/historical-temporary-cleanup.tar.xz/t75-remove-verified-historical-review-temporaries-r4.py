from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
import hashlib, json, os, shutil, stat, tarfile, tempfile

root = Path('/home/ubuntu/IdeaProjects/open-pdf')
archives = root / 'capabilities/evidence/T75-delivery/certification-review-r3'
allow = [
    ('jdk8-two-tuples-spec', '/tmp/t75-final-spec-r3-two-tuples-_xr8bj_5', '9d8fd3aec8b2e5631a3cb0f40657a8b8ca4aa61f198c16fe4d8c5e64e976c063'),
    ('jdk11-and-jdk17-three-tuples-spec', '/tmp/t75-final-spec-r3-three-tuples-smdhs3w8', '7e7f82096fb997dc89581bd1faf9c3d505e300121d195b7bb3d4e1a47632438e'),
    ('last-three-tuples-spec', '/tmp/t75-final-spec-r3-last-three-d_5tt9z2', '2369153f182265ed782a1acbea593a38a216e910a64dddbee67afaf2ed905534'),
    ('metadata-eight-spec', '/tmp/t75-final-spec-metadata-eight-uncpifp_', 'a781b83d6cf23a2967922f064fa6f3b42fb407fdd51d0c9cc2571e2862e8bb06'),
    ('pages-eight-spec', '/tmp/t75-final-spec-pages-eight-btlle2s_', 'f8edf37a32648c4989de8526166bbecdd136d739c0dc749bbb4fc56d2f3dfb51'),
]
original = Path(tempfile.mkdtemp(prefix='t75-historical-review-temporary-removal-r4-'))
(original / Path(__file__).name).write_bytes(Path(__file__).read_bytes())
verified = []
for name, temporary, expected_sha in allow:
    directory = Path(temporary)
    assert directory.parent == Path('/tmp') and directory.is_dir() and not directory.is_symlink()
    identity_path = archives / (name + '-archive-identity.json')
    identity_bytes = identity_path.read_bytes()
    identity = json.loads(identity_bytes)
    assert identity['original'] == temporary and not identity['symbolic_links']
    archive = archives / identity['archive']
    assert archive.name == name + '.tar.xz'
    assert hashlib.sha256(archive.read_bytes()).hexdigest() == identity['sha256'] == expected_sha
    expected = {m['path']: m for m in identity['members']}
    assert len(expected) == len(identity['members'])
    actual = {}
    for path in directory.rglob('*'):
        assert not path.is_symlink(), str(path)
        if path.is_file():
            assert stat.S_ISREG(path.stat().st_mode)
            actual[path.relative_to(directory).as_posix()] = path
    assert set(actual) == set(expected), (name, 'live membership mismatch')
    names, total = set(), 0
    with tarfile.open(archive, 'r:xz') as tar:
        for member in tar:
            assert member.isfile() or member.islnk(), member.name
            path = PurePosixPath(member.name)
            assert not path.is_absolute() and '..' not in path.parts
            assert member.name not in names and member.name in expected
            names.add(member.name)
            if member.islnk():
                assert member.linkname in expected and not PurePosixPath(member.linkname).is_absolute()
            retained = tar.extractfile(member).read()
            source = actual[member.name].read_bytes()
            observation = expected[member.name]
            assert retained == source, (name, member.name, 'byte mismatch')
            assert len(source) == observation['size']
            assert hashlib.sha256(source).hexdigest() == observation['sha256']
            total += len(source)
    assert names == set(expected)
    (original / identity_path.name).write_bytes(identity_bytes)
    verified.append({'original': temporary, 'archive': str(archive.relative_to(root)), 'archive-sha256': expected_sha, 'original-files': len(names), 'original-bytes': total, 'complete-membership-and-byte-equality': True})
    print(name, len(names), 'original files byte-verified; no deletion yet', flush=True)
before = {'recorded-utc': datetime.now(timezone.utc).isoformat(), 'scope': 'Only five completed task-created historical r3 review temporary directories, with all original bytes preserved in existing repository archives. Current r4 originals, source-review closures and all certification raw evidence are outside this allowlist. Both independent final reviewers confirmed archive access suffices.', 'verified': verified, 'earlier-lost-derived-summaries-recovered': False, 'disk-free-before': shutil.disk_usage(root).free}
with (original / 'pre-removal-verification.json').open('x') as out:
    out.write(json.dumps(before, indent=2) + '\n')
for entry in verified:
    directory = Path(entry['original'])
    shutil.rmtree(directory)
    assert not directory.exists()
after = {'recorded-utc': datetime.now(timezone.utc).isoformat(), 'removed-only-verified-temporary-directories': [entry['original'] for entry in verified], 'repository-archives-retained': True, 'disk-free-after': shutil.disk_usage(root).free}
for entry in verified:
    assert hashlib.sha256((root / entry['archive']).read_bytes()).hexdigest() == entry['archive-sha256']
with (original / 'removal-result.json').open('x') as out:
    out.write(json.dumps(after, indent=2) + '\n')
with Path('/tmp/t75-historical-review-temporary-removal-r4-original-path.txt').open('x') as out:
    out.write(str(original) + '\n')
print(json.dumps({'original': str(original), 'directories': len(verified), 'files': sum(e['original-files'] for e in verified), 'bytes': sum(e['original-bytes'] for e in verified), 'disk-free-after': after['disk-free-after']}), flush=True)
