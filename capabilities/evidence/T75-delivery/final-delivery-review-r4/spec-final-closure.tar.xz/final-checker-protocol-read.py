from pathlib import Path
import json
from auditlib import OUT,read,obj,put
original=Path(read(OUT/'completed-final-index-pointer.txt').decode().strip())
print(read(OUT/'selected-t75-finalize-delivery-index-r4-r2.py').decode())
receipt=obj(original/'receipt.json')
print('RECEIPT SCALARS')
for key,value in receipt.items():
 if key!='delta':print(key,json.dumps(value,ensure_ascii=False))
print('DELTA COUNT',len(receipt['delta']))
print('DELTA PATHS','\n'.join(row['path'] for row in receipt['delta']))
for name in ['stream-blob-0-result.json','actual-audit-delta-result.json','diff-check-result.json','no-unstaged-diff-result.json']:
 print('RESULT SCHEMA',name,json.dumps(obj(original/name),indent=2))
