from pathlib import Path
import hashlib,json,datetime
P=Path(__file__).resolve().parent
manifest_path=P/'artifact-manifest.json'
assert not manifest_path.exists()
for path in P.glob('*.result.json'):
 assert json.loads(path.read_text())['actual_exit']==0,path
assert json.loads((P/'finalize-closure-records-check.result.json').read_text())['actual_exit']==0
receipt=json.loads((P/'receipt.json').read_text())
assert receipt['technical-Spec-approval'] is True and receipt['open-findings']==[]
assert receipt['Goal-achieved'] is False and receipt['completion-marks'] is False
def identity(path):
 digest=hashlib.sha256()
 with path.open('rb') as stream:
  for block in iter(lambda:stream.read(1024*1024),b''):digest.update(block)
 return {'path':str(path.relative_to(P)),'bytes':path.stat().st_size,'sha256':digest.hexdigest()}
assert not any(path.is_symlink() for path in P.rglob('*'))
files=sorted(path for path in P.rglob('*') if path.is_file())
rows=[identity(path) for path in files]
manifest={
 'sealed-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'scope':'Independent bounded final Spec closure on B6b6dd30d0254ee8614df514bc75e54bcabcecf62; zero open findings; finite terminal guard and actual external delivery remain distinguished.',
 'excluded-only':['artifact-manifest.json'],
 'manifest-members':len(rows),
 'packet-files-including-manifest':len(rows)+1,
 'files':rows,
}
with manifest_path.open('x') as out:json.dump(manifest,out,indent=2);out.write('\n')
assert len([p for p in P.rglob('*') if p.is_file()])==len(rows)+1
print(json.dumps({
 'original-packet':str(P),'packet-files':len(rows)+1,'manifest-members-excluding-only-itself':len(rows),
 'total-packet-bytes':sum(r['bytes'] for r in rows)+manifest_path.stat().st_size,
 'identities':[identity(P/name) for name in ['report.md','receipt.json','artifact-manifest.json','input-sha256-catalog.json','archive-member-sha256-catalog.json','goal-28-criteria-map-final.json']],
 'open-findings':0,'technical-Spec-approval':True,'actual-external-delivery':'pending',
},indent=2))
