from pathlib import Path
import hashlib,json,os
root=Path('/home/ubuntu/IdeaProjects/open-pdf')
# Run only after both independent bounded reviews close. Changes are limited
# to the factual status wording explicitly allowed by the final reviewers.
def edit(relative,pairs,append=''):
 path=root/relative;before=path.read_bytes();text=before.decode()
 for old,new in pairs:
  assert text.count(old)==1,(relative,old);text=text.replace(old,new)
 if append:text+=append
 path.write_text(text)
 return {'path':relative,'before-sha256':hashlib.sha256(before).hexdigest(),'after-sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'before-bytes':len(before),'after-bytes':path.stat().st_size}
changes=[]
changes.append(edit('capabilities/evidence/T75-delivery/final-execution-receipt.md',[
('This delivery corrects that sentence to the actual 126 cases. Bounded review\nof the final documentation/artifact delta and Git delivery remain required.',
'This delivery corrects that sentence to the actual 126 cases. Both independent\naxes have closed the bounded documentation/artifact review. Authorized Git\ndelivery follows the final checks of the sealed review receipts.'),
('the final reviews\' one stale 124-case evidence sentence is corrected to 126 in the bounded final documentation delta',
'the stale 124-case evidence sentence is corrected to 126 and independently closed in the bounded final documentation delta'),
('Both axes verified frozen tree b12a83ab82a0e59425c87fecd16bf317e581adaf and the complete review lineage; the final documentation/artifact delta requires bounded closure',
'Both axes verified frozen tree b12a83ab82a0e59425c87fecd16bf317e581adaf, the complete review lineage and final audit tree 6b6dd30d0254ee8614df514bc75e54bcabcecf62; applicable findings are closed'),
('User authorization recorded; commit and push pending technical gates, followed by issue closure',
'User authorization recorded and independent technical reviews closed; a real-name DCO commit follows terminal receipt checks, then remote verification and issue closure'),
('both whitespace checks passed, with a separate check required for the final audit/documentation delta',
'both whitespace checks and the 37-file final audit/documentation delta passed; the terminal receipt-only addition is checked again before commit'),
('final bounded approval and actual external delivery result remain separate',
'final bounded approval is retained; the actual external delivery result remains separate'),
('documentation correction described above. All fourteen current certification review archives',
'documentation correction described above. Their [bounded closing reports](final-delivery-review-r4/README.md) resolve that correction and the byte-exact archive packaging, with no remaining applicable technical findings. All fourteen current certification review archives')
]))
changes.append(edit('capabilities/evidence/T75-delivery/final-delivery-review-r4/README.md',[
('contract, test, artifact or certification input. Final independent closure\nmust bind the corrected document and added audit/status records.',
'contract, test, artifact or certification input. Final independent closure\nbinds the corrected document and added audit/status records.'),
('Completion marks and authorized DCO delivery remain pending that bounded closure.',
'The [Standards bounded closure](standards-final-closure-report.md) and\n[Spec bounded closure](spec-final-closure-report.md) bind the completed\n37-path delta and tree `6b6dd30d0254ee8614df514bc75e54bcabcecf62`.\nThe original checker exited 0; every delta Git blob matches its retained\nworktree bytes, both whitespace checks passed, and the 1,933-source/30-contract\nfreeze is unchanged. Applicable technical findings are closed. The two closing\narchives preserve their complete sealed originals and adjacent receipts.\n`final-delta-index.tar.xz` preserves 81 original checker and wrapper files.\n\nThe finite terminal step copies those sealed records exactly and updates only\nfactual technical-review status. It must preserve every unrelated staged entry,\nverify copied bytes and frozen inputs, and pass strict delta and whitespace\nchecks before the authorized DCO commit. Commit, push and issue closure remain\nexternal actions; their actual results are reported after they occur.')
]))
changes.append(edit('capabilities/evidence/T75-delivery/final-certification-r4/README.md',[
('have also passed with the frozen source and contract unchanged. Final independent\ndelivery review remains required. No overall Foundation',
'have also passed with the frozen source and contract unchanged. Final independent\n[delivery review](../final-delivery-review-r4/README.md) has closed. No overall Foundation')
]))
Path('/tmp/t75-terminal-status-text-r4-result.json').write_text(json.dumps(changes,indent=2)+'\n')
print(json.dumps(changes,indent=2))
