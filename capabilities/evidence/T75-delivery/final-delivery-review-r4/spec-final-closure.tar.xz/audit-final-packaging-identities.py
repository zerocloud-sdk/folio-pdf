from pathlib import Path
import hashlib,json,tarfile
from auditlib import REPO,OUT,FILES,read,obj,put

base=REPO/'capabilities/evidence/T75-delivery/final-delivery-review-r4'
indexed={r['path']:r for r in obj(OUT/'final-bounded-index-file-catalog.json')}
part_results=[]
for stem,count in [('standards-final-index',4),('final-index-disk-failure',5)]:
 identity=obj(base/(stem+'-parts.json'))
 archive_identity=obj(base/(stem+'-archive-identity.json'))
 assert identity['sha256']==archive_identity['sha256']
 assert len(identity['parts'])==count and identity['byte-for-byte-comparison']
 offset=0;whole=hashlib.sha256()
 for part in identity['parts']:
  assert part['offset']==offset and 0<part['bytes']<=48*1024*1024
  path=base/part['path'];relative=str(path.relative_to(REPO));record=indexed[relative]
  assert (record['bytes'],record['sha256'])==(part['bytes'],part['sha256'])
  digest=hashlib.sha256();size=0
  with path.open('rb') as stream:
   for block in iter(lambda:stream.read(1024*1024),b''):
    whole.update(block);digest.update(block);size+=len(block)
  assert (size,digest.hexdigest())==(part['bytes'],part['sha256'])
  offset+=size
 assert (offset,whole.hexdigest())==(identity['bytes'],identity['sha256'])
 if stem=='standards-final-index':
  assert offset==163117736 and whole.hexdigest()=='a837ebf37379df6875b439a01aa0bb149c1f5eaab7d4589ead2576faca1e496b'
 part_results.append({'archive':identity['archive'],'parts':count,'bytes':offset,'sha256':whole.hexdigest(),'each-part-size-and-SHA-exact-and-at-most48MiB':True,'reconstruction-stream-SHA-exact':True,'reconstructed-file-written':False})

class Parts:
 def __init__(self,paths):self.paths=iter(paths);self.current=None
 def read(self,n):
  assert n>=0
  blocks=[];needed=n
  while needed:
   if self.current is None:
    try:self.current=next(self.paths).open('rb')
    except StopIteration:break
   data=self.current.read(needed)
   if not data:self.current.close();self.current=None;continue
   blocks.append(data);needed-=len(data)
  return b''.join(blocks)
 def close(self):
  if self.current is not None:self.current.close();self.current=None

members=[];new_archives=[]
for stem in ['final-index-disk-failure','archived-review-space-recovery','final-audit-packaging']:
 identity=obj(base/(stem+'-archive-identity.json'))
 expected={r['path']:r for r in identity['members']};seen=set()
 if stem=='final-index-disk-failure':
  part_identity=obj(base/(stem+'-parts.json'));stream=Parts([base/r['path'] for r in part_identity['parts']])
  archive=tarfile.open(fileobj=stream,mode='r|xz')
 else:
  path=base/identity['archive'];record=indexed[str(path.relative_to(REPO))]
  assert record['sha256']==identity['sha256']
  stream=None;archive=tarfile.open(path,'r:xz')
 with archive:
  for member in archive:
   if member.isdir():continue
   assert member.isfile() and member.name in expected and member.name not in seen
   row=expected[member.name];digest=hashlib.sha256();size=0
   source=Path(row['source']) if 'source' in row else Path(identity['original'])/row['path']
   selected=bytearray() if member.name.endswith(('receipt.json','result.json')) and member.size<65536 else None
   with archive.extractfile(member) as extracted,source.open('rb') as original:
    while True:
     block=extracted.read(1024*1024)
     assert block==original.read(len(block) if block else 1)
     if not block:break
     digest.update(block);size+=len(block)
     if selected is not None:selected.extend(block)
   assert (size,digest.hexdigest())==(row['size'],row['sha256'])
   FILES[str(source)]={'path':str(source),'bytes':size,'sha256':digest.hexdigest()}
   members.append({'archive':identity['archive'],'member':member.name,'source':str(source),'bytes':size,'sha256':digest.hexdigest()})
   if selected is not None:put('selected-'+stem+'-'+member.name.replace('/','__'),selected.decode())
   seen.add(member.name)
 assert seen==set(expected)
 if stream is not None:stream.close()
 new_archives.append({'archive':identity['archive'],'sha256':identity['sha256'],'members':len(seen),'every-original-member-byte-exact':True})
 if stem=='final-index-disk-failure':
  assert len(seen)==89 and 'failed-original/receipt.json' not in seen
  assert any('delta-blob-18.stdout.gz' in name for name in seen)
 if stem=='archived-review-space-recovery':assert len(seen)==15

put('new-packaging-retention-member-catalog.json',members)
put('final-packaging-identities-inspection.json',{
 'part-reconstructions':part_results,
 'prior-five-archive582-member-inspection-reused-for-byte-identical-originals':True,
 'new-retention-archives':new_archives,
 'first-final-delta-failure':'Actual exit1 with absent final receipt; complete89 originals include the partial gzip and exact wrapper trace. Partial gzip is retained as failed original bytes, not treated as a successful compressed stream.',
 'new-payload-or-reconstructed-archive-duplicates-written':False,
 'raw-rules-source-or-product-execution':False,'errors':[],
})
print(json.dumps({'part-reconstructions':part_results,'new-retention-archives':new_archives,'new-original-members':len(members),'errors':[]},indent=2))
