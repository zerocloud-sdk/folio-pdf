from pathlib import Path
import json,hashlib,datetime

P=Path(__file__).resolve().parent
def obj(name):return json.loads((P/name).read_text())
def put(name,value):
 with (P/name).open('x') as out:out.write(value if isinstance(value,str) else json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def identity(name):
 data=(P/name).read_bytes();return {'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}

index=obj('final-bounded-index-inspection.json')
packaging=obj('final-packaging-identities-inspection.json')
assert index['errors']==[] and packaging['errors']==[]
assert obj('retained-final-reviews-inspection.json')['errors']==[]
assert index['approved-B-tree']=='6b6dd30d0254ee8614df514bc75e54bcabcecf62'
results=[]
for path in sorted(P.glob('*.result.json')):
 result=obj(path.name);assert result['actual_exit']==0,(path.name,result)
 results.append(dict(identity(path.name),actual_exit=0))
peer=obj('standards-bounded-result-message.json')
assert peer['open-hard-findings']==peer['open-heuristic-findings']==0

observations={};sources=[]
for path in sorted(P.glob('*-input-catalog.json')):
 stem=path.name[:-len('-input-catalog.json')]
 if not (P/(stem+'.py')).is_file():continue
 rows=obj(path.name);assert isinstance(rows,list)
 sources.append(identity(path.name))
 for row in rows:
  if Path(row['path']).is_relative_to(P):continue
  key=(row['path'],row['sha256'],row['bytes'])
  observations.setdefault(key,dict(row,observed_by=[]))['observed_by'].append(path.name)
for row in obj('bootstrap-inputs.json'):
 key=(row['path'],row['sha256'],row['bytes'])
 observations.setdefault(key,dict(row,observed_by=[]))['observed_by'].append('bootstrap-inputs.json')
by_path={}
for path,sha,size in observations:by_path.setdefault(path,set()).add(sha)
member_rows=obj('retained-final-review-member-catalog.json')+obj('new-packaging-retention-member-catalog.json')
assert len(member_rows)==691
put('archive-member-sha256-catalog.json',member_rows)
put('input-sha256-catalog.json',{
 'scope':'Bounded final Spec closure original input observations; changed versions are retained as separate historical observations',
 'external-observations':len(observations),'external-unique-paths':len(by_path),
 'paths-observed-at-multiple-SHAs':{path:sorted(values) for path,values in by_path.items() if len(values)>1},
 'source-catalogs':sources,
 'files':sorted(observations.values(),key=lambda row:(row['path'],row['sha256'])),
 'complete-37-file-Git-bindings':identity('final-bounded-index-file-catalog.json'),
 'complete-archive-member-catalog':identity('archive-member-sha256-catalog.json'),
 'counting-boundary':'External observations, staged-file bindings and archive-original rows overlap and are not summed as distinct inputs. Internal packet inputs are covered by the artifact manifest. The observed original Standards whole archive is now represented by ordered parts with the exact same163117736-byte SHA256 identity. Removed raw-review /tmp copies are represented by the already byte-verified retained repository archives and exact removal receipt. No original payload is duplicated here.',
})

mapping=obj('prior-phase2-goal-28-criteria-map-final.json')
mapping['bounded-closure-tree']=index['approved-B-tree']
mapping['bounded-closure-source']=identity('final-bounded-index-inspection.json')
for row in mapping['criteria']:
 row['completion-marked']=False
 row['bounded-closure-status']='Technical evidence closed for reviewed B; established phase1/phase2 source and certification evidence remains unchanged.'
 row['bounded-closure-evidence']=['final-bounded-index-inspection.json','final-packaging-identities-inspection.json']
 if row['number']==19:
  row['bounded-closure-status']='Closed: SPEC-DOC-01 corrected by the exact124-to126 byte substitution and independently bound into B; authority/contract/provenance continuity remains exact.'
  row['closed-finding']='SPEC-DOC-01';row.pop('open-finding',None)
 if row['number']==25:
  row['bounded-closure-status']='Closed technical review gate: this independent Spec review and the independent Standards peer report zero applicable findings on B. Original fixed-BASE full reviews and all increments remain traceable. Parent retains both closing originals and executes the finite terminal exact-copy/status guard before delivery.'
  row['bounded-closure-evidence'].append('standards-bounded-result-message.json')
 if row['number']==26:
  row['bounded-closure-status']='Authorized DCO commit is eligible after the finite terminal guards. HEAD remains BASE; actual sign-off, commit, push, remote verification and issue closure remain pending external actions.'
  row['DCO-identity']=index['DCO-identity']
 if row['number']==27:
  row['bounded-closure-status']='Closed for B: exact37-path intentional delta, every actual Git stream byte matches, no unrelated index change, both whitespace checks and clean/untracked checks passed. The terminal sealed-copy/status addition must pass the same finite guards before commit.'
 if row['number']==28:
  row['bounded-closure-status']='Closed precommit technical receipt: validation, evidence, review outcome, pending commit status and exact limitations are recorded. Prepared factual technical-status substitutions are acceptable only after both closing originals are sealed. Actual external delivery results remain separate.'
mapping['summary']={
 'technical-evidence-criteria-closed-on-B':27,
 'authorized-commit-eligibility-criterion':26,
 'technical-criteria19-25-27-28':'closed',
 'current-open-findings':0,
 'finite-terminal-copy-status-guards-required-before-commit':True,
 'actual-commit-push-remote-verification-issue-closure':'pending external actions',
 'no-completion-marks':True,
}
mapping['open-current-findings']=[]
mapping['closed-current-findings']=['SPEC-DOC-01']
mapping['final-approval']='Independent Spec technical scope approved for B and the bounded finite terminal guard; actual delivery not yet performed.'
mapping['goal-achieved']=False
mapping['required-bounded-final-delta']='Finite terminal sealing only: exact byte-preserving copies of the sealed independent closing packets and completed final-index81 originals, the three prepared factual technical-status transitions, unchanged1933/30 and unrelated entries, strict actual delta/Git-byte/whitespace/clean checks. Then minimal external confirmation and authorized delivery; no recursive review expansion.'
put('goal-28-criteria-map-final.json',mapping)

report='''Independent Spec closure: **0 open findings** for tree `6b6dd30d0254ee8614df514bc75e54bcabcecf62`, continuing fixed BASE `5b1603c435f11c40368f75b7b9a2777c9c5e9761` and the sealed full-review lineage.

SPEC-DOC-01 is closed. Goal criterion 19 requires that “Capability Matrix, Facade Surface, Foundation authorities, generated/public English contracts, Chinese usage material and clean-room provenance agree.” The semantic evidence sentence changes exactly 124→126 and now agrees with the current contract and all eight formal transcripts.

The actual retry exited zero. I independently checked all 37 changed paths: 34 audit additions and three documents. Every actual Git stream matches its retained file, all unrelated index entries remain unchanged, and the 1,933-source/30-contract freeze, whitespace and clean-worktree gates pass. No implementation defect or unauthorized scope expansion was found.

The four Standards parts reconstruct the already reviewed 163,117,736-byte archive exactly. The failed attempt’s five parts also reproduce its original archive; all 109 added failure/cleanup/packaging originals match. Earlier 582 reviewed originals remain bound. The failed exit and partial gzip remain failed observations. Historical loss of two derived r3 summaries remains disclosed; no recovery is claimed.

Technical criteria 19/25/27/28 close; criterion 26 permits the authorized MaBaiqiu DCO commit after the finite terminal guard. Both independent axes report no open applicable findings. Exact sealing/copying of closing records and the prepared factual status substitutions require unchanged inputs/unrelated entries, exact byte/delta checks and passing whitespace checks, followed by minimal external confirmation.

Actual commit, push, remote verification and issue closure remain pending external actions. This review does not mark the Goal achieved or claim global Foundation/platform readiness.
'''
assert len(report.split())<400
put('report.md',report)
put('receipt.json',{
 'recorded-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'scope':'Bounded final independent Spec closure, continuing the same originally independent thread; no new fresh reviewer is claimed and no implementation was written by this reviewer.',
 'BASE-and-HEAD':index['BASE-and-HEAD'],'reviewed-A':index['reviewed-A-tree'],'approved-B':index['approved-B-tree'],
 'candidate':'ab18cc9c0473730a6aabec5d12e3172f22bea23a0a0f9529052a2bc186cbfc1b',
 'contract':'3de508f79fcbef7258feee8abc013d6f02b000840cac1cb263cb0d6f927b8f2b',
 'closed-findings':['SPEC-DOC-01'],'open-findings':[],
 'implementation-defects':[],'unauthorized-scope-expansion':[],
 'technical-Spec-approval':True,'Goal-achieved':False,'completion-marks':False,
 'criterion-map':identity('goal-28-criteria-map-final.json'),
 'criteria-summary':mapping['summary'],
 'independent-Standards-result':identity('standards-bounded-result-message.json'),
 'bounded-index-check':identity('final-bounded-index-inspection.json'),
 'retention-checks':[identity('retained-final-reviews-inspection.json'),identity('final-packaging-identities-inspection.json')],
 'source1933-contract30-continuity':'Exact frozen input SHA50988226c0db8a0eddd622ec3d9656d5ad6eb1e25328f22a067ee0e54add392d; independent A-to-B changed-path set excludes sources/contracts; parent actual before/after capture equals the frozen manifest, and current working tree/index are clean. Existing23artifact/24harness and six certifications remain unchanged.',
 'delta':{'paths':37,'audit-additions':34,'documents':3,'independent-streamed-Git-bytes':510335856,'all-mode-size-SHA256-and-byte-equality':True,'all-other-index-entries-unchanged':True,'maximum-file-bytes':index['maximum-added-or-modified-file-bytes'],'payload-copies-written':False},
 'packaging':packaging,
 'historical-exception':'Two derived r3 annotations summaries (55109/79646 bytes) remain unavailable; original certification evidence is intact and no recovery is claimed. Five r4 temporary review copies were removed only after archive byte/membership verification (6651 files/968467306 bytes); retained repository archives and current certification/source/final-review originals remain.',
 'retained-diagnostics':{'first-parent-final-delta':'Actual exit1 ENOSPC and partial gzip retained in complete89-member archive; retry actual0 remains distinct.','own-small-reader-creation':'ENOSPC prevented the original small apply_patch reader creation before execution; exact returned error is retained in capacity-write-attempt-diagnostic.json and the execution transcript; separately named v2 reader executed0. No result was overwritten.'},
 'actual-own-reader-results-before-finalizer':results,
 'input-catalog':identity('input-sha256-catalog.json'),
 'archive-member-catalog':identity('archive-member-sha256-catalog.json'),
 'terminal-approval':{
  'permitted':'Exact copies/archives of the sealed Standards and Spec closing originals plus the completed B-index81 originals; only the prepared factual substitutions in final-execution-receipt.md, final-delivery-review-r4/README.md and final-certification-r4/README.md.',
  'prepared-status-script':identity('selected-t75-terminal-status-text-r4.py'),
  'prepared-checker-script':identity('selected-t75-terminal-index-check-r4.py'),
  'required':'Both independent closing originals sealed; copy identities and member bytes exact; actual changed paths exactly copies plus those three status documents; all unrelated entries and1933/30 inputs unchanged; every actual Git blob equals approved bytes; size, whitespace and clean/untracked checks actually0. The prepared wording must remain factual and preserve historical/external-delivery boundaries.',
  'confirmation':'One minimal read-only external confirmation of actual terminal results; it need not create further repository audit artifacts or repeat source/raw checks.',
  'current-status':'Prepared and reviewed, not represented as executed by this packet.',
 },
 'delivery':{'authorization':'User explicitly authorizes real-name DCO commit, push and subsequent closing75 after gates.','identity':index['DCO-identity'],'actual-commit':'pending','actual-push':'pending','actual-remote-verification':'pending','actual-issue-closure':'pending','permission-again-needed':False},
 'execution-boundary':'No project/source/rules/RGB/product replay and no repository/Git/index/tracker mutation. Only read-only metadata/Git streams and bounded retained-original inspection; binary payload streams are identified in complete SHA catalogs without duplicated bodies.',
 'report':identity('report.md'),'report-word-count':len(report.split()),
 'finalizer-result':'finalize-closure-records-check.result.json must actually0 before sealing',
 'manifest':'artifact-manifest.json written last, excludes only itself, includes completed finalizer command/stdout/stderr/actual result.',
})
print(json.dumps({'report':identity('report.md'),'receipt':identity('receipt.json'),'map':identity('goal-28-criteria-map-final.json'),'catalog':identity('input-sha256-catalog.json'),'external-observations':len(observations),'external-unique-paths':len(by_path),'archive-members':691,'report-words':len(report.split()),'open-findings':0,'technical-Spec-approval':True},indent=2))
