from pathlib import Path
import difflib,json
from auditlib import OUT,read,obj,put
prior=Path('/tmp/t75-final-spec-r4-phase2-tev_ggjy')
pairs=[
 ('execution-receipt',prior/'snapshot-final-execution-receipt.md',OUT/'current-final-execution-receipt.md'),
 ('delivery-review-readme',prior/'snapshot-final-delivery-review-r4--README.md',OUT/'current-final-delivery-review-readme.md'),
 ('semantic-count',OUT/'semantic-before.md',OUT/'semantic-after.md'),
]
for label,old,new in pairs:
 diff=''.join(difflib.unified_diff(read(old).decode().splitlines(True),read(new).decode().splitlines(True),fromfile=str(old),tofile=str(new)))
 put(label+'-review.diff',diff)
 print('DOCUMENT DELTA',label);print(diff)
print('DELIVERY RETENTION FILES')
for line in read(OUT/'delivery-files.stdout.txt').decode().splitlines():
 if any(key in line for key in ['phase2','git-index','fixed-baseline']):print(line)
print('PRIOR MAP SUMMARY',json.dumps(obj(OUT/'prior-phase2-goal-28-criteria-map-final.json')['summary'],ensure_ascii=False))
