from auditlib import REPO,OUT,read,obj,put,sha
from pathlib import Path
import json
base=REPO/'capabilities/evidence/T75-delivery/final-delivery-review-r4'
for name in ['standards-final-index','spec-final-index','git-index-frozen','git-index-whitespace-failure','fixed-baseline-review-setup']:
 path=base/(name+'-archive-identity.json')
 data=obj(path)
 print('ARCHIVE IDENTITY',name)
 print('KEYS',list(data))
 for key,value in data.items():
  if isinstance(value,list):print(key,'rows',len(value),'first',json.dumps(value[:1],ensure_ascii=False))
  elif isinstance(value,dict):print(key,'keys',list(value))
  else:print(key,repr(value))
for name in ['standards-final-index-report.md','standards-final-index-receipt.json','spec-final-index-report.md','spec-final-index-receipt.json']:
 path=base/name;data=read(path);put('selected-'+name,data.decode())
 if name.endswith('.md'):print('REPORT',name);print(data.decode())
 else:
  d=json.loads(data);print('RECEIPT',name,'keys',list(d))
  for k,v in d.items():
   if not isinstance(v,(dict,list)):print(k,repr(v))
print('RETENTION SCHEMA OBSERVED')
