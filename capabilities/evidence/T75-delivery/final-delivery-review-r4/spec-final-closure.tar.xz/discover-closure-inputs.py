from pathlib import Path
import json, subprocess
from auditlib import REPO, OUT, read, obj, put, sha

prior = Path('/tmp/t75-final-spec-r4-phase2-tev_ggjy')
phase1 = Path('/tmp/t75-final-spec-r4-phase1-3jll045g')
delivery = REPO / 'capabilities/evidence/T75-delivery/final-delivery-review-r4'
goal = Path('/home/ubuntu/.codex/attachments/77353239-0dda-4ee1-b4bb-ce7fb3fa0f9b/pasted-text-1.txt')
assert sha(goal) == '794423d41161169ea6a4fee993553f777d6249cb05c5fe4d34f59657ab18f83f'
for path in [Path('/home/ubuntu/.codex/skills/code-review/SKILL.md'), REPO/'AGENTS.md']:
    print('INSTRUCTIONS', str(path)); print(read(path).decode())
for name in ['report.md', 'receipt.json', 'artifact-manifest.json', 'goal-28-criteria-map-final.json']:
    data = read(prior/name)
    put('prior-phase2-' + name, data.decode())
print('PRIOR REPORT'); print(read(prior/'report.md').decode())
mapping = obj(prior/'goal-28-criteria-map-final.json')
print('REMAINING CRITERIA')
for row in mapping['criteria']:
    if row['number'] in [19,25,26,28]:print(json.dumps(row,ensure_ascii=False,indent=2))
old = read(prior/'snapshot-T75-text-semantic-before.md')
new = read(REPO/'capabilities/evidence/T75-text-semantic.md')
assert old.count(b'124') == 1
assert new == old.replace(b'124',b'126')
assert sha(REPO/'capabilities/evidence/T75-text-semantic.md') == '46312a3d59ffe30cecc6c15ec2ff96e21f7aa757b163341e83b74e8ccc6892fa'
put('semantic-before.md', old.decode()); put('semantic-after.md', new.decode())
for label,path in [
    ('final-execution-receipt',REPO/'capabilities/evidence/T75-delivery/final-execution-receipt.md'),
    ('final-delivery-review-readme',delivery/'README.md'),
]:
    data=read(path); put('current-'+label+'.md',data.decode())
    print('CURRENT DOCUMENT',str(path)); print(data.decode())
result_path=Path('/tmp/t75-finalize-delivery-index-r4-result.json')
if result_path.is_file():
    data=read(result_path);put('initial-parent-delta-result.json',data.decode());print('INITIAL DELTA RESULT',data.decode())
command=['rg','--files',str(delivery)]
listing=subprocess.run(command,capture_output=True)
put('delivery-files.command.json',{'argv':command,'cwd':str(REPO)})
put('delivery-files.stdout.txt',listing.stdout.decode());put('delivery-files.stderr.txt',listing.stderr.decode())
put('delivery-files.actual-result.json',{'actual_exit':listing.returncode})
assert listing.returncode == 0
print('DELIVERY AUDIT FILES')
print('\n'.join(line for line in listing.stdout.decode().splitlines() if any(t in line for t in ['phase2','final-spec','final-standards','frozen','whitespace','baseline'])))
print('Semantic exact count-only correction passes; final index approval still requires the completed actual0 marker.')
