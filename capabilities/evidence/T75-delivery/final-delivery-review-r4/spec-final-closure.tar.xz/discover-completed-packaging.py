from pathlib import Path
import json,subprocess
from auditlib import REPO,OUT,read,obj,put
result_path=Path('/tmp/t75-package-final-audit-r4-r2-result.json')
result=obj(result_path)
assert result['returncode']==0
print('PACKAGING RESULT',json.dumps(result,indent=2))
put('completed-packaging-wrapper-result.json',read(result_path).decode())
log=Path(result['original-log'])
assert log.stat().st_size < 1024*1024
put('completed-packaging-wrapper.log',read(log).decode());print('PACKAGING LOG',read(log).decode())
command=result['command']
for value in command:
 if isinstance(value,str) and value.endswith('.py'):
  script=Path(value)
  if script.is_file():
   data=read(script);put('selected-'+script.name,data.decode());print('PACKAGING SCRIPT',data.decode())
base=REPO/'capabilities/evidence/T75-delivery/final-delivery-review-r4'
argv=['rg','--files',str(base)]
r=subprocess.run(argv,capture_output=True)
put('post-packaging-files.command.json',{'argv':argv,'cwd':str(REPO)})
put('post-packaging-files.stdout.txt',r.stdout.decode());put('post-packaging-files.stderr.txt',r.stderr.decode())
put('post-packaging-files.actual-result.json',{'actual_exit':r.returncode})
assert r.returncode==0
print('NEW PACKAGING PATHS')
old=set(read(OUT/'delivery-files.stdout.txt').decode().splitlines())
print('\n'.join(sorted(set(r.stdout.decode().splitlines())-old)))
print('ACTIVE FINAL CHECKER STATUS ONLY')
path=Path('/tmp/t75-finalize-delivery-index-r4-r2-result.json')
if path.is_file():print(read(path).decode())
print('r2-pointer-present',Path('/tmp/t75-final-delivery-index-r4-r2-original-path.txt').is_file())
