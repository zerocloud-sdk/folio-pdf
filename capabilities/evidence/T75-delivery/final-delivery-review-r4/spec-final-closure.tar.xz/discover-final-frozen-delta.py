from pathlib import Path
import json,subprocess
from auditlib import REPO,OUT,read,obj,put
result_path=Path('/tmp/t75-finalize-delivery-index-r4-r2-result.json')
result=obj(result_path);assert result['returncode']==0
pointer=Path('/tmp/t75-final-delivery-index-r4-r2-original-path.txt')
original=Path(read(pointer).decode().strip())
put('completed-final-index-wrapper-result.json',read(result_path).decode())
put('completed-final-index-pointer.txt',str(original)+'\n')
print('FROZEN ORIGINAL',str(original))
argv=['rg','--files',str(original)]
r=subprocess.run(argv,capture_output=True)
put('frozen-original-files.command.json',{'argv':argv,'cwd':str(REPO)})
put('frozen-original-files.stdout.txt',r.stdout.decode());put('frozen-original-files.stderr.txt',r.stderr.decode())
put('frozen-original-files.actual-result.json',{'actual_exit':r.returncode});assert r.returncode==0
print('ORIGINAL FILES',r.stdout.decode())
receipt=obj(original/'receipt.json')
put('completed-final-index-receipt.json',read(original/'receipt.json').decode())
print('RECEIPT',json.dumps(receipt,ensure_ascii=False,indent=2))
for value in result['command']:
 if isinstance(value,str) and value.endswith('.py'):
  script=Path(value);put('selected-'+script.name,read(script).decode());print('FINAL INDEX CHECKER',read(script).decode())
