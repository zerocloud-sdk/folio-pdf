from pathlib import Path
import hashlib,json,tarfile
from auditlib import REPO,OUT,FILES,read,obj,put

base=REPO/'capabilities/evidence/T75-delivery/final-delivery-review-r4'
expected={
 'standards-final-index':('a837ebf37379df6875b439a01aa0bb149c1f5eaab7d4589ead2576faca1e496b',253),
 'spec-final-index':('00306169237cdb39cff2bab3d8dc15152f905455ee5449e4081f0d86825c41d8',208),
 'git-index-frozen':('977f05129de1e8b64e6a79a77db9a75cc78e8e766170366d7657c9b9ca555427',59),
 'git-index-whitespace-failure':('bab5206091e8363d35c6ad657a71a3fb6e3a1bd323a4a5db42c513438dc53dea',39),
 'fixed-baseline-review-setup':('37864b75affb2ab063036696051c0e6ab617142d8f5691aad50f520bcb42729e',23),
}
def digest_stream(stream):
 h=hashlib.sha256();size=0
 for block in iter(lambda:stream.read(1024*1024),b''):
  h.update(block);size+=len(block)
 return size,h.hexdigest()
def file_identity(path):
 with path.open('rb') as stream:size,digest=digest_stream(stream)
 row={'path':str(path),'bytes':size,'sha256':digest}
 if str(path) in FILES:assert FILES[str(path)]==row
 FILES[str(path)]=row
 return row
members=[];summaries=[]
for stem,(archive_sha,count) in expected.items():
 identity=obj(base/(stem+'-archive-identity.json'))
 archive=base/identity['archive'];original=Path(identity['original'])
 assert identity['sha256']==archive_sha
 assert file_identity(archive)['sha256']==archive_sha
 assert not identity['symbolic_links']
 expected_members={row['path']:row for row in identity['members']}
 assert len(expected_members)==count
 seen=set()
 with tarfile.open(archive,'r:xz') as tar:
  for member in tar:
   if member.isdir():continue
   assert member.isfile() and member.name not in seen
   assert member.name in expected_members and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
   row=expected_members[member.name]
   with tar.extractfile(member) as stream:size,digest=digest_stream(stream)
   assert (size,digest)==(row['size'],row['sha256'])
   actual=file_identity(original/member.name)
   assert (actual['bytes'],actual['sha256'])==(size,digest)
   members.append({'archive':str(archive),'member':member.name,'original':str(original/member.name),'bytes':size,'sha256':digest})
   seen.add(member.name)
 assert seen==set(expected_members)
 actual_names={str(path.relative_to(original)) for path in original.rglob('*') if path.is_file()}
 assert actual_names==seen,stem
 summaries.append({'archive':str(archive),'sha256':archive_sha,'original':str(original),'members':count,'every-member-matches-original-and-identity':True})
assert len(members)==582
spec={row['member']:row for row in members if '/spec-final-index.tar.xz' in row['archive']}
assert spec['report.md']['sha256']=='43e2ca2f95a2e11a8b92985a286ed4bdc35dfa6d6019d680d9a48e9f76e71829'
assert spec['receipt.json']['sha256']=='8229438f9c815a38bc620f0c4a744a44cca4c5c7a8194c4b9eb000296450ef40'
assert spec['artifact-manifest.json']['sha256']=='ad316e8bdfaa8af3d0c35078356bdf8a645ecfdf02970ba73bc459e5a15ef0e1'
assert spec['goal-28-criteria-map-final.json']['sha256']=='3e5d5ae132eb113a277eaffb0df661c85121a28c93b885bf95592ec7acbc7134'
for axis in ['standards','spec']:
 identity=obj(base/(axis+'-final-index-archive-identity.json'))
 original=Path(identity['original'])
 for name in ['report.md','receipt.json']:
  assert read(original/name)==read(base/(axis+'-final-index-'+name))
assert read(base/'spec-final-index-criteria-map.json')==read(Path('/tmp/t75-final-spec-r4-phase2-tev_ggjy')/'goal-28-criteria-map-final.json')
put('retained-final-review-member-catalog.json',members)
put('retained-final-reviews-inspection.json',{'archives':summaries,'members':582,'all-members-byte-exact-and-original-directory-membership-exact':True,'phase2-own-seal-preserved':True,'adjacent-reports-receipts-and-map-byte-exact':True,'raw-rules-source-or-product-tests-replayed':False,'errors':[]})
print(json.dumps({'archives':5,'members':582,'all-member-original-and-identity-bytes-exact':True,'phase2-own-seal-preserved':True,'errors':[]},indent=2))
