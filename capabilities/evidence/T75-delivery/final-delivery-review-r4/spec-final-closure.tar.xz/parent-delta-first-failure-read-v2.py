from pathlib import Path
from auditlib import read,obj,put,sha
result_path=Path('/tmp/t75-finalize-delivery-index-r4-result.json')
result=obj(result_path)
assert result['returncode']==1
log=Path(result['original-log'])
assert log.stat().st_size < 1024*1024, 'unexpectedly large wrapper trace'
data=read(log)
put('first-parent-delta-complete-wrapper.log',data.decode())
put('first-parent-delta-failure-inspection.json',{
 'actual-returncode':1,
 'started-utc':result['started-utc'],
 'completed-utc':result['completed-utc'],
 'original-log':str(log),
 'original-log-sha256':sha(log),
 'retention-boundary':'Complete small wrapper trace copied; partial gzip payload and original failed packet remain with the parent. No archive/Git payload duplicate is written here.',
 'final-index-approval':False,
})
print(data.decode())
