from pathlib import Path
import json
from auditlib import OUT,read,obj,put
for path in [Path('/tmp/t75-terminal-status-text-r4.py'),Path('/tmp/t75-terminal-index-check-r4.py')]:
 data=read(path);put('selected-'+path.name,data.decode());print('PREPARED TERMINAL HELPER',str(path));print(data.decode())
print('RETAINED RECOVERY RECEIPTS')
for path in sorted(OUT.glob('selected-archived-review-space-recovery-*receipt.json')):
 print(path.name);print(read(path).decode())
print('RETAINED RECOVERY ACTUAL RESULTS')
for path in sorted(OUT.glob('selected-archived-review-space-recovery-*result.json')):
 d=obj(path);print(path.name,json.dumps(d,ensure_ascii=False))
