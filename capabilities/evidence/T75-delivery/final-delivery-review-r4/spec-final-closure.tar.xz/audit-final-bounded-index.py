from pathlib import Path
import json,subprocess,hashlib,gzip,datetime,difflib
from auditlib import REPO,OUT,FILES,read,obj,put,sha

A='b12a83ab82a0e59425c87fecd16bf317e581adaf'
B='6b6dd30d0254ee8614df514bc75e54bcabcecf62'
BASE='5b1603c435f11c40368f75b7b9a2777c9c5e9761'
original=Path(read(OUT/'completed-final-index-pointer.txt').decode().strip())
receipt=obj(original/'receipt.json')
assert receipt['reviewed-tree']==A and receipt['final-tree']==B
assert receipt['source-and-contract-unchanged']
assert receipt['frozen-input-sha256']=='50988226c0db8a0eddd622ec3d9656d5ad6eb1e25328f22a067ee0e54add392d'
freeze=REPO/'capabilities/evidence/T75-delivery/final-validation-r4/source-and-contract-inputs.json'
assert sha(freeze)==receipt['frozen-input-sha256']

parent_results=[]
for path in sorted(original.glob('*-result.json')):
 r=obj(path);assert r['returncode']==0,path
 if 'stdout-bytes' in r:
  stem=path.name[:-len('-result.json')]
  for label in ['stdout','stderr']:
   raw=gzip.decompress(read(original/(stem+'.'+label+'.gz')))
   assert len(raw)==r[label+'-bytes'] and hashlib.sha256(raw).hexdigest()==r[label+'-sha256']
 parent_results.append({'path':str(path),'returncode':0})
assert len([p for p in parent_results if '/stream-blob-' in p['path']])==37

def call(label,argv):
 put(label+'.command.json',{'argv':argv,'cwd':str(REPO)})
 r=subprocess.run(argv,cwd=REPO,capture_output=True)
 with (OUT/(label+'.stdout.bin')).open('xb') as f:f.write(r.stdout)
 with (OUT/(label+'.stderr.bin')).open('xb') as f:f.write(r.stderr)
 put(label+'.actual-result.json',{'actual_exit':r.returncode,'stdout-bytes':len(r.stdout),'stdout-sha256':hashlib.sha256(r.stdout).hexdigest(),'stderr-bytes':len(r.stderr),'stderr-sha256':hashlib.sha256(r.stderr).hexdigest()})
 assert r.returncode==0,(label,r.returncode,r.stderr)
 return r.stdout

assert call('closure-HEAD',['git','rev-parse','HEAD']).decode().strip()==BASE
raw=call('closure-A-to-B-raw-diff',['git','diff-tree','-r','--no-commit-id','--raw','-z','--no-abbrev','--no-renames',A,B,'--'])
chunks=raw.split(b'\0');assert chunks[-1]==b'';chunks=chunks[:-1];assert len(chunks)%2==0
changes={}
for j in range(0,len(chunks),2):
 meta=chunks[j].decode().split();path=chunks[j+1].decode()
 assert len(meta)==5 and meta[4] in ['A','M']
 changes[path]={'old-mode':meta[0][1:],'mode':meta[1],'old-oid':meta[2],'oid':meta[3],'change':meta[4]}
expected={r['path']:r for r in receipt['delta']}
assert len(changes)==37 and set(changes)==set(expected)
docs={
 'capabilities/evidence/T75-text-semantic.md',
 'capabilities/evidence/T75-delivery/final-execution-receipt.md',
 'capabilities/evidence/T75-delivery/final-delivery-review-r4/README.md',
}
assert {p for p,r in changes.items() if r['change']=='M'}==docs
assert all(p.startswith('capabilities/evidence/T75-delivery/final-delivery-review-r4/') for p,r in changes.items() if r['change']=='A')
assert len([r for r in changes.values() if r['change']=='A'])==34
call('closure-index-equals-B-before',['git','diff','--cached','--exit-code','--quiet',B,'--'])
observed=[]
for n,path in enumerate(sorted(changes)):
 row=expected[path];change=changes[path]
 assert (row['oid'],row['mode'])==(change['oid'],change['mode'])
 assert row['mode']=='100644' and row['bytes']<100*1024*1024
 actual=REPO/path;assert actual.is_file() and not actual.is_symlink()
 assert bool(actual.stat().st_mode&0o111)==False
 argv=['git','cat-file','blob',row['oid']]
 label='closure-delta-blob-'+str(n)
 put(label+'.command.json',{'argv':argv,'cwd':str(REPO),'repository-path':path})
 process=subprocess.Popen(argv,cwd=REPO,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 digest=hashlib.sha256();size=0
 with actual.open('rb') as source:
  while True:
   block=process.stdout.read(1024*1024)
   assert block==source.read(len(block) if block else 1),path
   if not block:break
   digest.update(block);size+=len(block)
 stderr=process.stderr.read();rc=process.wait()
 with (OUT/(label+'.stderr.bin')).open('xb') as f:f.write(stderr)
 put(label+'.actual-result.json',{'actual_exit':rc,'stdout-bytes':size,'stdout-sha256':digest.hexdigest(),'stdout-retention':'Complete stream compared against the retained original file and durable Git blob; no payload duplicate is written.','stderr-bytes':len(stderr),'stderr-sha256':hashlib.sha256(stderr).hexdigest()})
 assert rc==0 and (size,digest.hexdigest())==(row['bytes'],row['sha256'])
 FILES[str(actual)]={'path':str(actual),'bytes':size,'sha256':digest.hexdigest()}
 observed.append(dict(row,change=change['change'],independent_actual_exit=rc))

assert read(REPO/'capabilities/evidence/T75-text-semantic.md')==read(OUT/'semantic-after.md')
for label,path,previous in [
 ('execution-receipt',REPO/'capabilities/evidence/T75-delivery/final-execution-receipt.md',OUT/'current-final-execution-receipt.md'),
 ('delivery-review-readme',REPO/'capabilities/evidence/T75-delivery/final-delivery-review-r4/README.md',OUT/'current-final-delivery-review-readme.md'),
]:
 data=read(path);put('frozen-B-'+label+'.md',data.decode())
 diff=''.join(difflib.unified_diff(read(previous).decode().splitlines(True),data.decode().splitlines(True),fromfile=str(previous),tofile=str(path)))
 put('packaging-'+label+'-delta.diff',diff)
 print('FINAL PACKAGING DOC DELTA',label);print(diff)

call('closure-working-tree-clean',['git','diff','--exit-code','--quiet','--'])
call('closure-B-delta-whitespace',['git','diff','--check',A,B,'--'])
call('closure-index-equals-B-after',['git','diff','--cached','--exit-code','--quiet',B,'--'])
assert not call('closure-no-untracked',['git','ls-files','-z','--others','--exclude-standard'])
assert not call('closure-no-ignored-ticket-originals',['git','ls-files','-z','--others','--ignored','--exclude-standard','--','capabilities/evidence/T75-*'])
name=call('closure-DCO-name',['git','config','user.name']).decode().strip()
email=call('closure-DCO-email',['git','config','user.email']).decode().strip()
assert name and email=='mabaiqiu@gmail.com'
put('final-bounded-index-file-catalog.json',observed)
put('final-bounded-index-inspection.json',{
 'BASE-and-HEAD':BASE,'reviewed-A-tree':A,'approved-B-tree':B,
 'delta-paths':37,'added-audit-paths':34,'modified-document-paths':sorted(docs),
 'every-delta-file-mode-size-SHA-and-actual-Git-stream-byte-exact':True,
 'all-other-index-entries-unchanged-from-reviewed-A':True,
 'source1933-contract30-freeze-sha256':receipt['frozen-input-sha256'],
 'source-contract-continuity':'Frozen input file identity matches phase2; actual A-to-B delta excludes source/contracts and parent checker captured exact build inputs before/after. Current working tree and final index are clean. No source/raw/product replay.',
 'parent-results-all-actual0':parent_results,
 'full-parent-whitespace-checks':[receipt['diff-check-exit'],receipt['cached-diff-check-exit']],
 'independent-B-delta-whitespace-actual-exit':0,
 'independent-clean-and-index-equality-actual-exits':0,
 'maximum-added-or-modified-file-bytes':max(r['bytes'] for r in observed),
 'DCO-identity':{'name':name,'email':email,'actual-commit-signoff':'pending authorized commit'},
 'git-or-repository-mutated-by-reviewer':False,'errors':[],
})
print(json.dumps({'tree':B,'delta':37,'added':34,'modified':3,'independent-streamed-Git-bytes':sum(r['bytes'] for r in observed),'DCO':name+' <'+email+'>','errors':[]},indent=2))
