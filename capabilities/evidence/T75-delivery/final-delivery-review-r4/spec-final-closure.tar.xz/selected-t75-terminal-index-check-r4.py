from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,importlib.util,json,os,subprocess,tempfile
import yaml
root=Path('/home/ubuntu/IdeaProjects/open-pdf');os.chdir(root)
reviewed='6b6dd30d0254ee8614df514bc75e54bcabcecf62'
packet=Path(tempfile.mkdtemp(prefix='t75-terminal-index-r4-'));(packet/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
def call(label,args):
 start=datetime.now(timezone.utc).isoformat();r=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,cwd=root)
 record={'command':args,'started-utc':start,'completed-utc':datetime.now(timezone.utc).isoformat(),'returncode':r.returncode}
 for stream,data in [('stdout',r.stdout),('stderr',r.stderr)]:
  (packet/(label+'.'+stream+'.gz')).write_bytes(gzip.compress(data,mtime=0));record[stream+'-bytes']=len(data);record[stream+'-sha256']=hashlib.sha256(data).hexdigest()
 (packet/(label+'-result.json')).write_text(json.dumps(record,indent=2)+'\n');assert r.returncode==0,label
 return r.stdout
def names(b):return {x.decode() for x in b.split(b'\0') if x}
assert call('reviewed-index',['git','write-tree']).decode().strip()==reviewed
catalog=json.loads(Path('/tmp/t75-terminal-copy-catalog-r4.json').read_bytes());expected_new=set(catalog)
assert names(call('untracked',['git','ls-files','-z','--others','--exclude-standard']))==expected_new
for path,expected in catalog.items():
 p=root/path;assert p.is_file() and not p.is_symlink();assert p.stat().st_size==expected['bytes']<100*1024*1024
 with p.open('rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()==expected['sha256']
changes=json.loads(Path('/tmp/t75-terminal-status-text-r4-result.json').read_bytes());expected_docs={e['path'] for e in changes}
assert names(call('modified-documents',['git','diff','-z','--name-only']))==expected_docs
for e in changes:
 before=call('before-status-'+str(changes.index(e)),['git','show',reviewed+':'+e['path']]);after=(root/e['path']).read_bytes()
 assert hashlib.sha256(before).hexdigest()==e['before-sha256'];assert hashlib.sha256(after).hexdigest()==e['after-sha256']
frozen_path=root/'capabilities/evidence/T75-delivery/final-validation-r4/source-and-contract-inputs.json';frozen=json.loads(frozen_path.read_bytes())
spec=importlib.util.spec_from_file_location('capture',root/'scripts/t03-foundation.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);contract=yaml.safe_load((root/'capabilities/foundation-release.yaml').read_bytes())
assert m.capture_build_inputs(root,contract)==frozen
paths=sorted(expected_new|expected_docs);call('stage-terminal-records',['git','-c','gc.auto=0','add','--',*paths])
assert names(call('exact-terminal-delta',['git','diff','--cached','-z','--name-only',reviewed,'--']))==set(paths)
call('diff-check',['git','diff','--check']);call('cached-diff-check',['git','diff','--cached','--check']);call('no-unstaged',['git','diff','--exit-code','--quiet'])
assert not call('no-untracked',['git','ls-files','-z','--others','--exclude-standard'])
assert not call('no-ignored-evidence',['git','ls-files','-z','--others','--ignored','--exclude-standard','--','capabilities/evidence/T75-*'])
entries=call('terminal-index-entries',['git','ls-files','-s','-z','--',*paths]);identities=[]
for entry in entries.split(b'\0'):
 if not entry:continue
 metadata,name=entry.split(b'\t',1);name=name.decode();mode,oid,stage=metadata.decode().split();assert stage=='0'
 start=datetime.now(timezone.utc).isoformat();args=['git','cat-file','blob',oid];p=subprocess.Popen(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,cwd=root);size=0;h=hashlib.sha256()
 with (root/name).open('rb') as f:
  while True:
   b=p.stdout.read(1024*1024);assert b==f.read(len(b) if b else 1)
   if not b:break
   h.update(b);size+=len(b)
 stderr=p.stderr.read();rc=p.wait();assert rc==0
 identities.append({'path':name,'mode':mode,'oid':oid,'bytes':size,'sha256':h.hexdigest(),'worktree-byte-equality':True,'stream-command':args,'started-utc':start,'completed-utc':datetime.now(timezone.utc).isoformat(),'returncode':rc,'stderr':stderr.decode()})
assert {e['path'] for e in identities}==set(paths);assert m.capture_build_inputs(root,contract)==frozen
final=call('final-tree',['git','write-tree']).decode().strip()
assert call('unchanged-head',['git','rev-parse','HEAD']).decode().strip()=='5b1603c435f11c40368f75b7b9a2777c9c5e9761'
receipt={'recorded-utc':datetime.now(timezone.utc).isoformat(),'reviewed-tree':reviewed,'final-tree':final,'scope':'Finite terminal sealing only: exact independent closing originals and completed index observations, factual review-status updates, and their retention identities. Every unrelated staged entry remains unchanged. External commit/push/close results follow.','source-and-contract-unchanged':True,'frozen-input-sha256':hashlib.sha256(frozen_path.read_bytes()).hexdigest(),'strict-delta-verified':True,'diff-check-exit':0,'cached-diff-check-exit':0,'no-unstaged-or-untracked-ticket-files':True,'delta':identities,'copy-catalog':catalog,'status-changes':changes}
(packet/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
with Path('/tmp/t75-terminal-index-r4-original-path.txt').open('x') as f:f.write(str(packet)+'\n')
print('actual0 final tree',final,'terminal paths',len(paths),'packet',packet,flush=True)
