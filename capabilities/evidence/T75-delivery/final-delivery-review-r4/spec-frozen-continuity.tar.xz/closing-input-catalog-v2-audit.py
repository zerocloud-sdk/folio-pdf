from auditlib import *
from collections import defaultdict
import datetime
stage=obj(REPO/'capabilities/evidence/T75-delivery/final-candidate-r4/build-inputs.json')
counts={}
for kind,values,count in [('sources',stage['candidate']['inputs'],1933),('contracts',stage['contract-inputs'],30),('artifacts',stage['candidate']['artifacts'],23),('harness',stage['harness'],24)]:
 assert len(values)==count
 for v in values:assert sha(REPO/v['path'])==v['sha256'],'changed frozen '+v['path']
 counts[kind]=count
rows={};observations=defaultdict(list)
for p in sorted(OUT.glob('*-input-catalog.json')):
 # auditlib catalogs belong to a retained script; archive-member catalogs use a deliberately different schema.
 if not (OUT/(p.name[:-len('-input-catalog.json')]+'.py')).is_file():continue
 data=json.loads(p.read_bytes())
 for r in data:
  assert set(r)=={'path','sha256','bytes'}
  if str(OUT)+'/' in r['path']:continue
  key=(r['path'],r['sha256'],r['bytes']);rows[key]=dict(r);observations[key].append(p.name)
for r in FILES.values():
 if str(OUT)+'/' in r['path']:continue
 key=(r['path'],r['sha256'],r['bytes']);rows[key]=dict(r);observations[key].append('closing-input-catalog-v2-audit.py')
assert all('/T75-foundation-20260914-r4/annotations' not in r['path'] for r in rows.values())
versions=defaultdict(set)
for r in rows.values():versions[r['path']].add(r['sha256'])
external=[]
for k in sorted(rows):external.append(dict(rows[k],observed_by=sorted(set(observations[k]))))
memberrows=obj(OUT/'review-archive-member-input-catalog.json')+obj(OUT/'validation-stage-review-member-catalog.json')
for a in obj(OUT/'five-certification-command-member-catalog.json'):
 for m in a['members']:memberrows.append({'archive':a['archive'],'member':m['path'],'bytes':m['size'],'sha256':m['sha256']})
assert len(memberrows)==2566+579+50==3195
assert len({(r['archive'],r['member']) for r in memberrows})==3195
put('input-sha256-catalog.json',{'scope':'Every external filesystem input actually read by the retained phase1 readers, including exact compressed archives. Review-generated internal files are covered by the artifact manifest. Member bytes actually read are separately cataloged. Multiple versions, if any, are distinct timed observations, never overwritten.','inputs':external,'input-observations':len(external),'distinct-paths':len(versions),'archive-member-catalog':'archive-member-sha256-catalog.json','archive-members-actually-read':3195})
put('archive-member-sha256-catalog.json',memberrows)
versions=[{'path':p,'sha256':sorted(v)} for p,v in versions.items() if len(v)>1]
put('phase1-observed-input-version-boundary.json',{'mutable-observation-files-with-multiple-sha256':versions,'scope':'Each input SHA records actual bytes read. Canonical status/navigation prose may advance. Source, contract, artifacts and harness match the r4 freeze at closing; no old pending prose is required to equal later state.'})
put('closing-frozen-input-inspection.json',{'checked-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'counts':counts,'all-current-frozen-bytes-match':True,'baseline':'5b1603c435f11c40368f75b7b9a2777c9c5e9761','candidate':'ab18cc9c0473730a6aabec5d12e3172f22bea23a0a0f9529052a2bc186cbfc1b','contract':'3de508f79fcbef7258feee8abc013d6f02b000840cac1cb263cb0d6f927b8f2b','input-observations':len(external),'archive-members-read':3195,'catalog-v1-diagnostic':'closing-input-catalog-check actual1 tried to treat an archive-member row as a filesystem row; v2 selects the documented schemas explicitly. No source, evidence or original output changed.','errors':[]})
print(json.dumps({'current-frozen-inputs':counts,'external-input-observations':len(external),'archive-members':3195,'multi-version-paths':len(versions),'errors':0}))
