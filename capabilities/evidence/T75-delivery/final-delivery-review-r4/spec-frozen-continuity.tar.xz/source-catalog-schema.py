from auditlib import *
root=OUT/'selected-review-originals'
for name in ['final-review/original-spec-review/source-sha256.json','final-review/original-spec-review/new-source-identities.json','final-review/original-spec-review/review-receipt.json','final-review/original-review-point/review-point.json','final-review/original-standards-review/source-identities.json','final-review/appearance-spec-final-closure/inspected-source-sha256.json','observer-budget/spec-final-closure/inspected-source-sha256.json','worker-batch-timeout/spec-closure/inspected-source-sha256.json','inventory-read-bound/spec-review-archive-identity/final-source-identity-audit.json','inventory-read-bound/spec-review-archive-identity/five-file-source-identity-audit.json']:
 q=root/name;o=obj(q);print('SCHEMA',name,type(o).__name__)
 if isinstance(o,dict):print('KEYS',list(o));print('SCALARS',{k:v for k,v in o.items() if isinstance(v,(str,int,bool))});print('LISTS',{k:len(v) for k,v in o.items() if isinstance(v,list)})
 else:print('COUNT',len(o),'FIRST',o[:1])
for q in sorted(Path('/tmp/t75-final-review-fixed-baseline-r4-zpbk95st').glob('*result.json')):
 o=obj(q);print('SETUP_RESULT',q.name,{k:v for k,v in o.items() if isinstance(v,(str,int,bool,list))})
