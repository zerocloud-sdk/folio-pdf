from auditlib import *
from collections import defaultdict
import datetime
rows={};observations=defaultdict(list)
for p in sorted(OUT.glob('*-input-catalog.json')):
 data=json.loads(p.read_bytes())
 for r in data:
  key=(r['path'],r['sha256'],r['bytes']);rows[key]=dict(r);observations[key].append(p.name)
assert all('/T75-foundation-20260914-r4/annotations' not in r['path'] for r in rows.values())
# Only immutable frozen product/contract/artifact/harness inputs are checked against live bytes again.
frozen=obj(REPO/'capabilities/evidence/T75-delivery/final-candidate-r4/build-inputs.json')
print('FREEZE_KEYS',list(frozen))
for key,value in frozen.items():
 if isinstance(value,list):print('FREEZE_LIST',key,len(value),value[:1])
versions=defaultdict(set)
for r in rows.values():versions[r['path']].add(r['sha256'])
put('phase1-observed-input-version-boundary.json',{'mutable-observation-files-with-multiple-sha256':[{ 'path':p,'sha256':sorted(v)} for p,v in versions.items() if len(v)>1], 'scope':'Each input SHA records the actual read time. Canonical status/navigation prose may advance. Source, contract and sealed evidence identities are asserted separately; no old pending prose is required to equal later state.'})
print(json.dumps({'unique-input-observations':len(rows),'distinct-paths':len(versions),'multi-version-paths':sum(len(v)>1 for v in versions.values())}))
