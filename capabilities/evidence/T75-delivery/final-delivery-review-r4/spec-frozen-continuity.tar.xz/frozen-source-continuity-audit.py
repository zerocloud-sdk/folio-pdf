from auditlib import *
import subprocess,datetime
BASE='5b1603c435f11c40368f75b7b9a2777c9c5e9761';D=REPO/'capabilities/evidence/T75-delivery';stage=obj(D/'final-candidate-r4/build-inputs.json');freeze=obj(D/'final-validation-r4/source-and-contract-inputs.json');old=obj(D/'final-candidate/build-inputs.json');delta=obj(D/'inventory-read-bound/input-delta-from-original-full-review.json')
assert sha(D/'final-candidate/build-inputs.json')==delta['original-full-review-receipt']['sha256'];assert freeze=={'inputs':stage['candidate']['inputs'],'contract-inputs':stage['contract-inputs']};assert len(freeze['inputs'])==1933 and len(freeze['contract-inputs'])==30
command=['git','ls-tree','-rz',BASE];start=datetime.datetime.now(datetime.timezone.utc).isoformat();put('baseline-ls-tree.command.json',{'argv':command,'cwd':str(REPO),'started-utc':start});r=subprocess.run(command,cwd=REPO,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
for name,data in [('baseline-ls-tree.stdout',r.stdout),('baseline-ls-tree.stderr',r.stderr)]:
 with (OUT/name).open('xb') as f:f.write(data)
put('baseline-ls-tree.result.json',{'actual_exit':r.returncode,'started-utc':start,'completed-utc':datetime.datetime.now(datetime.timezone.utc).isoformat()});assert r.returncode==0;tree={}
for entry in r.stdout.split(b'\0'):
 if not entry:continue
 header,path=entry.split(b'\t',1);mode,kind,oid=header.decode().split();tree[path.decode()]={'mode':mode,'kind':kind,'oid':oid}
rows=[];changes={};current={};original={}
for label,values,oldvalues in [('sources',freeze['inputs'],old['candidate']['inputs']),('contracts',freeze['contract-inputs'],old['contract-inputs'])]:
 current[label]={v['path']:v['sha256'] for v in values};original[label]={v['path']:v['sha256'] for v in oldvalues};assert current[label].keys()==original[label].keys(),'no dropped or added paths since complete full review';changes[label]=[]
 for item in values:
  path=REPO/item['path'];b=read(path);assert hashlib.sha256(b).hexdigest()==item['sha256'],'frozen current bytes '+item['path'];gitblob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();oldblob=tree.get(item['path']);status='new' if oldblob is None else 'unchanged' if oldblob['oid']==gitblob else 'modified';rows.append({'kind':label,'path':item['path'],'sha256':item['sha256'],'bytes':len(b),'baseline-git-object':oldblob,'current-git-blob':gitblob,'baseline-status':status,'original-full-review-sha256':original[label][item['path']]})
  if item['sha256']!=original[label][item['path']]:changes[label].append({'path':item['path'],'before':original[label][item['path']],'after':item['sha256']})
for label,field,count in [('sources','inputs',26),('contracts','contract-inputs',1)]:assert changes[label]==[{k:r[k] for k in ['path','before','after']} for r in delta[field]] and len(changes[label])==count,'exact cumulative independently closed delta '+label
for label,values,count in [('artifacts',stage['candidate']['artifacts'],23),('harness',stage['harness'],24)]:
 assert len(values)==count
 for row in values:assert sha(REPO/row['path'])==row['sha256'],'same current staged '+label
put('all-frozen-source-contract-baseline-inputs.json',rows);put('frozen-source-continuity-inspection.json',{'baseline':BASE,'candidate':'ab18cc9c0473730a6aabec5d12e3172f22bea23a0a0f9529052a2bc186cbfc1b','contract':'3de508f79fcbef7258feee8abc013d6f02b000840cac1cb263cb0d6f927b8f2b','inputs':{'sources':1933,'contracts':30,'artifacts':23,'harness':24},'baseline-comparison-counts':{k:{s:sum(r['kind']==k and r['baseline-status']==s for r in rows) for s in ['new','modified','unchanged']} for k in ['sources','contracts']},'current-delta-from-original-full-review':changes,'original-full-review-inputs-sha256':sha(D/'final-candidate/build-inputs.json'),'current-build-inputs-sha256':sha(D/'final-candidate-r4/build-inputs.json'),'all-new-or-modified-frozen-inputs-included':True,'git-object-comparison':'Read-only pinned git ls-tree plus independently computed exact Git blob SHA-1 and file SHA-256; no checkout or Git mutation.','errors':[]});print(json.dumps({'current-frozen-files':len(rows),'source-delta':len(changes['sources']),'contract-delta':len(changes['contracts']),'baseline-counts':{k:{s:sum(r['kind']==k and r['baseline-status']==s for r in rows) for s in ['new','modified','unchanged']} for k in ['sources','contracts']},'errors':0}))
