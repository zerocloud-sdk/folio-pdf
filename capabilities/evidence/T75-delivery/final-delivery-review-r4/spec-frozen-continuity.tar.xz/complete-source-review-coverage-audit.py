from auditlib import *
import subprocess,datetime
D=REPO/'capabilities/evidence/T75-delivery';R=OUT/'selected-review-originals';BASE='5b1603c435f11c40368f75b7b9a2777c9c5e9761';old=obj(D/'final-candidate/build-inputs.json');current=obj(D/'final-candidate-r4/build-inputs.json');rows=obj(OUT/'all-frozen-source-contract-baseline-inputs.json');oldspec=obj(R/'final-review/original-spec-review/source-sha256.json');specmap={r['path']:r['sha256'] for r in oldspec};oldstand=obj(R/'final-review/original-standards-review/source-identities.json')+obj(R/'final-review/original-standards-review/supplementary-source-identities.json');standmap={r['path']:r['sha256'] for r in oldstand};new=obj(R/'final-review/original-spec-review/new-source-identities.json');newmap={r['path']:r['sha256'] for r in new};assert len(new)==572
for q in ['final-review/original-review-point/build-inputs.json','final-review/original-spec-review/build-inputs.json','final-review/original-standards-review/build-inputs.json']:assert obj(R/q)==old,'same full review frozen original candidate '+q
covered=[];fallbacks=[]
for row in rows:
 if row['baseline-status']=='unchanged':continue
 path=row['path'];oldsha=row['original-full-review-sha256'];specok=specmap.get(path)==oldsha;standok=standmap.get(path)==oldsha
 if row['baseline-status']=='new':assert newmap[path]==oldsha and specok and standok,'all new frozen source/fixture inputs independently reviewed '+path
 if not (specok and standok):
  # A file unchanged at the original full review can first change in a closed later increment.
  cmd=['git','show',BASE+':'+path];result=subprocess.run(cmd,cwd=REPO,stdout=subprocess.PIPE,stderr=subprocess.PIPE);assert result.returncode==0,'baseline-only source comparison '+path;h=hashlib.sha256(result.stdout).hexdigest();assert h==oldsha,'uncovered original full-review changed source '+path
  prefix='baseline-original-unchanged-'+str(len(fallbacks)+1);put(prefix+'.command.json',{'argv':cmd,'cwd':str(REPO)})
  for suffix,data in [('stdout',result.stdout),('stderr',result.stderr)]:
   with (OUT/(prefix+'.'+suffix)).open('xb') as f:f.write(data)
  put(prefix+'.result.json',{'actual_exit':result.returncode,'stdout-sha256':h});fallbacks.append({'path':path,'baseline-sha256':h,'command':prefix+'.command.json'})
 covered.append({'path':path,'kind':row['kind'],'baseline-status':row['baseline-status'],'original-full-review-sha256':oldsha,'original-spec-covered':specok,'original-standards-covered':standok,'baseline-unchanged-at-original-review':not (specok and standok)})
extra_new=sorted(set(newmap)-{r['path'] for r in rows});assert len(extra_new)==1;print('EXTRA_REVIEWED_NEW_PATH',extra_new)
closures={}
for name in ['final-review/appearance-spec-final-closure/inspected-source-sha256.json','observer-budget/spec-final-closure/inspected-source-sha256.json','worker-batch-timeout/spec-closure/inspected-source-sha256.json']:
 for row in obj(R/name):
  for field in ['path','copy']:
   if field in row:closures.setdefault(row['sha256'],[]).append({'catalog':name,'reference':row[field]})
inventory=obj(R/'inventory-read-bound/spec-review-archive-identity/five-file-source-identity-audit.json')
for row in inventory:closures.setdefault(row['frozen_and_live_sha256'],[]).append({'catalog':'inventory-read-bound/spec-review-archive-identity/five-file-source-identity-audit.json','reference':row['path']})
delta=obj(D/'inventory-read-bound/input-delta-from-original-full-review.json');links=[]
for row in delta['inputs']+delta['contract-inputs']:
 matches=[v for v in closures.get(row['after'],[]) if v['reference']==row['path'] or v['reference'].endswith('/'+row['path'])];assert matches,'unclosed latest source/contract hash '+row['path'];links.append(dict(row,**{'independent-closure-matches':matches}))
setup=Path('/tmp/t75-final-review-fixed-baseline-r4-zpbk95st');setupresults=[]
for path in sorted(setup.glob('*-result.json')):
 result=obj(path);label=path.name[:-len('-result.json')];stdout=read(setup/(label+'.stdout'));stderr=read(setup/(label+'.stderr'));assert result['returncode']==0 and len(stdout)==result['stdout-bytes'] and hashlib.sha256(stdout).hexdigest()==result['stdout-sha256'] and len(stderr)==result['stderr-bytes'];setupresults.append({'result':str(path),'sha256':sha(path),'command':result['command'],'stdout-sha256':hashlib.sha256(stdout).hexdigest(),'bytes':len(stdout)})
assert read(setup/'canonical-committed-diff.stdout')==read(setup/'commit-list.stdout')==read(setup/'current-index-diff.stdout')==b'';assert read(setup/'baseline.stdout').decode().strip()==read(setup/'head.stdout').decode().strip()==BASE;assert read(setup/'tracked-work-in-progress-diff.stdout');assert obj(setup/'build-inputs.json')==current;assert obj(setup/'source-and-contract-inputs.json')==obj(D/'final-validation-r4/source-and-contract-inputs.json');read(setup/'receipt.json');allocation=obj(setup/'reviewer-allocation-boundary.json')
put('complete-source-review-coverage-inspection.json',{'baseline':BASE,'original-full-source-review-new-files':572,'current-frozen-new-source-files':571,'additional-original-reviewed-new-path-outside-current-source-contract-inputs':extra_new,'all-current-new-and-modified-frozen-inputs':covered,'originally-unchanged-baseline-cases':fallbacks,'latest-closed-source-and-contract-delta':links,'source-delta-count':26,'contract-delta-count':1,'setup-results':setupresults,'allocation-boundary':allocation,'independence':'Continuation of existing independent reviewer; no newly spawned fresh-agent claim. Standards runs in its separate existing thread.','not-approved':['future staged index','active annotations raw','final inventory/48/delivery/completion marks'],'errors':[]});print(json.dumps({'all-current-new-or-modified-frozen-inputs':len(covered),'originally-unchanged-fallbacks':len(fallbacks),'latest-closure-links':len(links),'errors':0}))
