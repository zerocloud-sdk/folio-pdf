from auditlib import *
import tarfile,io,re,datetime
from collections import Counter
D=REPO/'capabilities/evidence/T75-delivery';C=D/'certification-review-r4';F=D/'final-certification-r4';root=REPO/'capabilities/evidence/T75-foundation-20260914-r4';CID='ab18cc9c0473730a6aabec5d12e3172f22bea23a0a0f9529052a2bc186cbfc1b';TID='3de508f79fcbef7258feee8abc013d6f02b000840cac1cb263cb0d6f927b8f2b';build=obj(D/'final-candidate-r4/build-inputs.json')
pins={'text':'bdcca3024295ef7f006ccec8b87d357a6b2c49317f0cc395faec8ae592744855','transactions':'5e232cfe64c16e2cabf5eed05765aa5f3ed30af9559dea7cec8c043f6632fdfa','values':'e0','pages':'b24c7fa62c298b6644e64bd910b74776adbed75deb835ce53f88fbf3a99a2260','metadata':'3b6893481086767e6f0ce30577b43c3651f85ab5d9d7d9146aa5cafe00adb4a2'}
# Values publication was previously sealed by this independent reviewer; bind its complete archived original identity.
values_identity=obj(C/'values-publication-spec-archive-identity.json');pins['values']=values_identity['sha256'];assert sha(Path('/tmp/t75-r4-values-publication-spec-fbsksqo5/receipt.json'))=='34b25acd8a8ac5883cfdfbcb48aa83f4a23d67c1bc1f176565037af51a0169cf'
formal={'text':126,'transactions':34,'values':83,'pages':65,'metadata':73};obligations=[];command_members=[];review_links=[]
for label in formal:
 identity=obj(C/(label+'-publication-spec-archive-identity.json'));assert identity['sha256']==pins[label];assert sha(C/identity['archive'])==pins[label];original=Path(identity['original']);members={r['path']:r for r in identity['members']}
 for name in ['report.md','receipt.json']:
  payload=read(C/(label+'-publication-spec-'+name));assert hashlib.sha256(payload).hexdigest()==members[name]['sha256'];assert read(original/name)==payload
 receipt=obj(C/(label+'-publication-spec-receipt.json'));assert receipt['findings']==[];assert receipt['candidate']==CID and receipt['contract']==TID
 approvals=receipt['approvals'];assert any(v is True and ('outer-exit' in k or 'actual-outer-exit' in k) for k,v in approvals.items());assert any(v is True and 'publication' in k for k,v in approvals.items());review_links.append({'obligation':label,'report':str(C/(label+'-publication-spec-report.md')),'report-sha256':sha(C/(label+'-publication-spec-report.md')),'receipt-sha256':sha(C/(label+'-publication-spec-receipt.json')),'archive-sha256':pins[label],'archive-member-count':len(members),'approvals':approvals})
 cid=obj(F/(label+'-command-archive-identity.json'));assert len(cid['members'])==10 and cid['symbolic_links']==[];arc=F/cid['archive'];blob=read(arc);assert hashlib.sha256(blob).hexdigest()==cid['sha256'];expected={r['path']:r for r in cid['members']};saved={}
 with tarfile.open(fileobj=io.BytesIO(blob),mode='r:xz') as tar:
  actual=[]
  for m in tar.getmembers():
   assert m.isfile();b=tar.extractfile(m).read();row={'path':m.name,'size':len(b),'sha256':hashlib.sha256(b).hexdigest()};assert row==expected[m.name];actual.append(row)
   if m.name in ['command.json','result.json','command.log','receipt.json','observed-index.json']:saved[m.name]=b
  assert actual==cid['members']
 command=json.loads(saved['command.json']);result=json.loads(saved['result.json']);assert result['returncode']==0 and result['command']==command['command'];assert command['command']==['/usr/bin/python3','scripts/t03-foundation.py','certify',str((root/label).relative_to(REPO)),'--obligation',label]
 for member,adjacent in [('command.json',label+'-command.json'),('result.json',label+'-result.json'),('command.log',label+'-command.log'),('receipt.json',label+'-receipt.json')]:
  if not (F/adjacent).exists() and member=='command.log':adjacent=label+'-command.log'
  assert read(F/adjacent)==saved[member]
 index=obj(root/label/'observed-index.json');assert read(root/label/'observed-index.json')==saved['observed-index.json'];assert index['candidate']==build['candidate'];assert len(index['certifications'])==8 and len(index['environments'])==4;assert {(c['environment'],c['execution-profile']) for c in index['certifications']}=={('ubuntu-24.04-linux-x86-64-jdk'+str(j),m) for j in [8,11,17,21] for m in ['IN_PROCESS','HARDENED_WORKER']}
 records=[];suites=[]
 for c in index['certifications']:
  assert c['obligation']==label;cfg=REPO/c['configuration']['path'];assert sha(cfg)==c['configuration']['sha256'];conf=obj(cfg);assert conf['candidate-sha256']==CID and conf['execution-profile']==c['execution-profile'];assert conf['settings']['providers']=='none; Stable Facade execution is IN_PROCESS'
  log=read(cfg.parent/'contract-tests.txt').decode();assert log.startswith('JUnit version 4.13.2\n') and re.search(r'\nOK \('+str(formal[label])+r' tests\)\n\n\Z',log) and 'FAILURES!!!' not in log;suites.append({'tuple':cfg.parent.name,'tests':formal[label],'raw-sha256':sha(cfg.parent/'contract-tests.txt')})
  for r in c['records']:
   path=REPO/r['path'];assert sha(path)==r['sha256'];record=obj(path);assert record['result']=='pass' and record['obligation']==label and record['candidate-sha256']==CID and record['contract-sha256']==TID and record['execution-profile']==c['execution-profile'];assert record['execution-configuration-sha256']==c['configuration']['sha256'];report=REPO/record['report']['path'];assert sha(report)==record['report']['sha256'];records.append({'record':r,'report':record['report']})
 assert len(records)==32;obligations.append({'obligation':label,'actual-command':command,'actual-result':result,'command-archive-sha256':cid['sha256'],'observed-index-sha256':sha(root/label/'observed-index.json'),'certifications':index['certifications'],'records':records,'formal-suites':suites});command_members.append({'obligation':label,'archive':str(arc),'sha256':cid['sha256'],'members':actual})
rawreports=['text-jdk8-two-tuples-spec','text-jdk11-and-jdk17-three-tuples-spec','text-jdk17-and-jdk21-last-three-spec','transactions-eight-tuples-spec','values-eight-tuples-spec','pages-eight-tuples-spec','metadata-eight-tuples-spec'];rawlinks=[]
for name in rawreports:
 ident=obj(C/(name+'-archive-identity.json'));assert sha(C/ident['archive'])==ident['sha256'];byname={r['path']:r for r in ident['members']}
 for filename in ['report.md','receipt.json']:assert sha(C/(name+'-'+filename))==byname[filename]['sha256']
 rawlinks.append({'scope':name,'archive-sha256':ident['sha256'],'member-count':len(ident['members']),'report-sha256':sha(C/(name+'-report.md')),'receipt-sha256':sha(C/(name+'-receipt.json'))})
# Publication continuity to the latest independently sealed five-obligation dated authority; active annotations remain excluded.
latest=obj(C/'metadata-publication-spec-receipt.json');path=Path(latest['dated-authority']['path']);authority=obj(path);assert sha(path)==latest['dated-authority']['sha256'];assert Counter(c['obligation'] for c in authority['certifications'])==Counter({k:8 for k in formal})
for o in obligations:assert [c for c in authority['certifications'] if c['obligation']==o['obligation']]==o['certifications']
extra=obj(OUT/'complete-source-review-coverage-inspection.json')['additional-original-reviewed-new-path-outside-current-source-contract-inputs'];originalnew={r['path']:r['sha256'] for r in obj(OUT/'selected-review-originals/final-review/original-spec-review/new-source-identities.json')}
for path in extra:assert sha(REPO/path)==originalnew[path]
put('five-certification-command-member-catalog.json',command_members);put('five-certification-continuity-inspection.json',{'candidate':CID,'contract':TID,'obligation-count':5,'certification-count':40,'PASS-chain-count':160,'obligations':obligations,'raw-review-links':rawlinks,'publication-review-links':review_links,'dated-authority':latest['dated-authority'],'additional-qualification-inputs':extra,'raw-rule-or-RGB-replayed':False,'active-annotations-raw-read':False,'errors':[],'deferred':['annotations8','final48/192PASS','finalall6satisfied','finalinventory/index/delivery']});print(json.dumps({'obligations':5,'certifications':40,'PASS-chains':160,'raw-review-packets':len(rawlinks),'publication-review-packets':5,'command-archive-members':50,'errors':0}))
