from auditlib import *
base=REPO/'capabilities/evidence/T75-delivery'
for name in ['inventory-read-bound/README.md','final-execution-receipt.md','delivery-readiness-review/development-coverage-map.md']:
 data=read(base/name).decode();print('FILE',name,'CHARS',len(data));print(data if name!='final-execution-receipt.md' else '\n'.join(line for line in data.splitlines() if line.startswith('|') or line.startswith('#') or ('pending' in line.lower()) or ('derived' in line.lower())))
