from auditlib import *
reports=obj(OUT/'selected-original-review-reports.json')
for row in reports:
 if row['scope'] in ['final-review/original-spec-review','final-review/appearance-spec-final-closure','observer-budget/spec-final-closure','worker-batch-timeout/spec-closure']:print('ORIGINAL_REPORT',row['scope'],'\n'+row['text'])
