from auditlib import *
import tarfile,io
base=REPO/'capabilities/evidence/T75-delivery';selected=[]
for f,keys in [('final-review/original-archive-identities.json',['original-review-point','original-spec-review','original-standards-review']),('final-review/final-closure-archive-identities.json',None),('observer-budget/final-closure-identities.json',['spec-final-closure','standards-final-closure']),('worker-batch-timeout/closure-archive-identities.json',None),('step4-review/review-archive-identities.json',['full-spec','full-standards','optional-spec-closure']),('step4-review/source-closure-archive-identities.json',['source-standards-closure'])]:
 data=obj(base/f)
 for key in keys or list(data):selected.append((str(Path(f).parent)+'/'+key,base/Path(f).parent,data[key]))
for f in ['inventory-read-bound/spec-review-archive-identity.json','inventory-read-bound/standards-review-archive-identity.json','step4-review/candidate-metadata-spec-identity.json','step4-review/candidate-metadata-standards-identity.json']:
 selected.append((str(Path(f).parent)+'/'+Path(f).stem,base/Path(f).parent,obj(base/f)))
member_catalog=[];packets=[];reports=[]
keep_exact={'report.md','standards-report.md','review-receipt.json','review-record.json','review-point.json','receipt.json','receipt.md','source-sha256.json','source-identities.json','supplementary-source-identities.json','new-source-identities.json','build-inputs.json','inspected-source-sha256.json','final-source-identity-audit.json','five-file-source-identity-audit.json','detailed-receipt.json','inspection.json'}
for label,parent,identity in selected:
 archive=parent/identity['archive'];data=read(archive);assert hashlib.sha256(data).hexdigest()==identity['sha256'],'archive SHA '+label;expected={r['path']:r for r in identity['members']};actual=[];kept=[]
 with tarfile.open(fileobj=io.BytesIO(data),mode='r:xz') as tar:
  for member in tar.getmembers():
   if not member.isfile():continue
   payload=tar.extractfile(member).read();row={'path':member.name,'size':len(payload),'sha256':hashlib.sha256(payload).hexdigest()};assert row==expected[member.name],'exact archive member '+label+'/'+member.name;actual.append(row);member_catalog.append({'archive':str(archive),'member':member.name,'bytes':len(payload),'sha256':row['sha256']})
   if member.name in keep_exact:
    relative=Path('selected-review-originals')/label/member.name;dest=OUT/relative;dest.parent.mkdir(parents=True,exist_ok=True)
    with dest.open('xb') as f:f.write(payload)
    kept.append({'member':member.name,'copy':str(relative),'sha256':row['sha256']})
    if member.name in ['report.md','standards-report.md']:reports.append({'scope':label,'copy':str(relative),'text':payload.decode()})
 assert actual==identity['members'],'complete archive member ordering '+label;assert identity['symbolic_links']==[],'declared original archive links '+label
 packets.append({'scope':label,'archive':str(archive),'archive-sha256':identity['sha256'],'original':identity['original'],'member-count':len(actual),'selected-originals':kept})
put('review-archive-member-input-catalog.json',member_catalog);put('review-archive-inspection.json',{'packets':packets,'archive-count':len(packets),'verified-original-members':len(member_catalog),'project-or-certifier-execution':False,'raw-certification-replayed':False,'errors':[]});put('selected-original-review-reports.json',reports)
print(json.dumps({'archives':len(packets),'verified-members':len(member_catalog),'selected-reports':len(reports),'errors':0}));print('REPORT SCOPES',[r['scope'] for r in reports])
