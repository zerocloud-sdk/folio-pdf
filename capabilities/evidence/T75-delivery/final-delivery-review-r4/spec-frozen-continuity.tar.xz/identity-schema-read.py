from auditlib import *
base=REPO/'capabilities/evidence/T75-delivery'
for name in ['inventory-read-bound/input-delta-from-original-full-review.json','final-validation-r4/source-and-contract-inputs.json','final-review/original-archive-identities.json','step4-review/review-archive-identities.json','final-review/final-source-identity-delta-receipt.json','observer-budget/final-closure-identities.json','worker-batch-timeout/closure-archive-identities.json','inventory-read-bound/spec-review-archive-identity.json']:
 o=obj(base/name);print('JSON',name,'TYPE',type(o).__name__)
 if isinstance(o,dict):print('KEYS',list(o),'SCALARS',{k:v for k,v in o.items() if isinstance(v,(str,int,bool))});print('LIST_LENGTHS',{k:len(v) for k,v in o.items() if isinstance(v,list)});print('FIRST_ROWS',{k:v[:1] for k,v in o.items() if isinstance(v,list)})
 else:print('COUNT',len(o),'FIRST_TWO',o[:2])
