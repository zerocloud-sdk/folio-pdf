from auditlib import *
import re
m=obj(OUT/'goal-28-criteria-map.json')
corrections={
 'capabilities/evidence/T75-delivery/certification-review-r4/text-first-two-spec-report.md':'capabilities/evidence/T75-delivery/certification-review-r4/text-jdk8-two-tuples-spec-report.md',
 'capabilities/evidence/T75-delivery/certification-review-r4/text-next-three-spec-report.md':'capabilities/evidence/T75-delivery/certification-review-r4/text-jdk11-and-jdk17-three-tuples-spec-report.md',
 'capabilities/evidence/T75-delivery/certification-review-r4/text-final-three-spec-report.md':'capabilities/evidence/T75-delivery/certification-review-r4/text-jdk17-and-jdk21-last-three-spec-report.md',
 'capabilities/evidence/T75-delivery/final-certification-r4/text-command-result.json':'capabilities/evidence/T75-delivery/final-certification-r4/text-result.json'
}
assert set(m['unresolved-navigation-references'])==set(corrections)
for c in m['criteria']:c['evidence']=[corrections.get(e,e) for e in c['evidence']]
resolved=[]
for e in sorted(set(e for c in m['criteria'] for e in c['evidence'])):
 plain=re.sub(r':\d+$','',e);p=Path(plain) if plain.startswith('/') else (OUT/plain if (OUT/plain).is_file() else REPO/plain)
 assert p.is_file(),e;resolved.append({'reference':e,'path':str(p),'sha256':sha(p)})
frozen={r['path']:r['sha256'] for r in obj(OUT/'all-frozen-source-contract-baseline-inputs.json')}
for c in m['criteria']:
 for t in c['current-public-observers']:assert frozen[t['path']]==t['source-sha256']
assert len(m['criteria'])==28 and all(not c['completion-marked'] for c in m['criteria'])
m['resolved-evidence-references']=resolved;m['unresolved-navigation-references']=[]
m['navigation-correction']={'original':'goal-28-criteria-map.json','retained-diagnostic':'goal-criteria-mapping-check.stdout.txt','scope':'Four unresolvable hand-written navigation aliases only; existing underlying source and actual certification continuity checks used their true paths and were already complete. No product defect or certification output change.','exact-path-corrections':corrections}
put('goal-28-criteria-map-final.json',m)
body=['This is an independent phase-1 requirement map, not a completion checklist. All original criteria remain unmarked. The known historical preservation exception is separate from current product/raw correctness.\n','| # / Goal lines | Exact criterion | Established evidence and explicit remaining boundary |','| --- | --- | --- |']
for c in m['criteria']:
 criterion=c['criterion'].replace('|','\\|');evidence='; '.join(c['evidence']);body.append('| '+str(c['number'])+' / '+str(c['goal-first-line'])+'–'+str(c['goal-last-line'])+' | '+criterion+' | '+c['independent-assessment']+' Evidence: '+evidence+' |')
body.append('\nKnown historical partial constraint: original Goal “Preserve historical evidence.” Two derived r3 summaries (55,109 and 79,646 bytes, old SHA unavailable) were overwritten. Certification originals, commands/stdout and fresh independent inspection remain retained. The new inspection does not recover the lost old summaries. No current r4 raw loss is asserted.\n')
put('goal-28-criteria-map.md','\n'.join(body))
print(json.dumps({'criteria':28,'resolved-evidence-references':len(resolved),'current-public-method-references':sum(len(c['current-public-observers']) for c in m['criteria']),'unresolved':0,'completion-marks':0,'navigation-aliases-corrected':4}))
