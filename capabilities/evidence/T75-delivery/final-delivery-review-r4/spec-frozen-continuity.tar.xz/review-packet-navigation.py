from auditlib import *
import tarfile
base=REPO/'capabilities/evidence/T75-delivery'
groups=[('final-review/original-archive-identities.json',['original-review-point','original-spec-review','original-standards-review','first-final-candidate']),('final-review/final-closure-archive-identities.json',None),('observer-budget/final-closure-identities.json',['spec-final-closure','standards-final-closure']),('worker-batch-timeout/closure-archive-identities.json',None),('step4-review/review-archive-identities.json',['full-spec','optional-spec-closure'])]
for f,keys in groups:
 data=obj(base/f)
 for key in keys or list(data):
  row=data[key];archive=base/Path(f).parent/row['archive'];print('ARCHIVE',str(archive.relative_to(base)))
  with tarfile.open(archive,'r:xz') as tar:
   names=[m.name for m in tar.getmembers() if m.isfile()];candidates=[n for n in names if any(w in n.lower() for w in ['report','receipt','identit','sha256','catalog','review.json','input']) and n.count('/')<=1];print('MEMBERS',len(names),'KEY_MEMBERS',candidates[:35]);print('ROOT_NAMES',sorted({n.split('/')[0] for n in names})[:35])
for name in ['inventory-read-bound/spec-review-archive-identity.json','inventory-read-bound/standards-review-archive-identity.json']:
 row=obj(base/name);archive=base/Path(name).parent/row['archive']
 with tarfile.open(archive,'r:xz') as tar:print('ARCHIVE',name,'KEY_MEMBERS',[m.name for m in tar.getmembers() if m.isfile() and m.name.count('/')<=1 and any(w in m.name.lower() for w in ['report','receipt','manifest','catalog','identit'])][:35])
print('ORIGINAL_BASE_SOURCE_EXISTS',(base/'final-candidate/build-inputs.json').exists())
for name in ['step4-review/candidate-metadata-spec-identity.json','inventory-read-bound/independent-review-closure.json']:
 print('JSON',name,obj(base/name))
