from auditlib import *
D=REPO/'capabilities/evidence/T75-delivery/certification-review-r4'
for name in ['text-jdk8-two-tuples-spec-report.md','text-jdk11-and-jdk17-three-tuples-spec-report.md','text-jdk17-and-jdk21-last-three-spec-report.md','text-publication-spec-report.md','transactions-eight-tuples-spec-report.md','pages-eight-tuples-spec-report.md']:
 print('ORIGINAL_REPORT',name,'\n'+read(D/name).decode())
for label in ['text','transactions','values','pages','metadata']:
 o=obj(D/(label+'-publication-spec-receipt.json'));print('PUB_SCHEMA',label,list(o));print('APPROVALS',o.get('approvals'))
