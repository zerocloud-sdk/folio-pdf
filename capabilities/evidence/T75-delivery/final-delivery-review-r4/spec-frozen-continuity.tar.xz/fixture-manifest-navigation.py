from auditlib import *
d=obj(OUT/'all-frozen-source-contract-baseline-inputs.json')
print(type(d).__name__)
print(list(d)[:8] if isinstance(d,dict) else d[:1])
