from auditlib import *
base=REPO/'capabilities/evidence/T75-delivery'
for name in ['final-review/README.md','step4-review/README.md','observer-budget/README.md','worker-batch-timeout/README.md','inventory-read-bound/README.md']:
 q=base/name;print('FILE',name,'\n'+read(q).decode())
for name in ['inventory-read-bound/input-delta-from-original-full-review.json','final-validation-r4/source-and-contract-inputs.json','final-review/original-archive-identities.json','step4-review/review-archive-identities.json','final-review/final-source-identity-delta-receipt.json','observer-budget/final-closure-identities.json','worker-batch-timeout/closure-archive-identities.json']:
 q=base/name;o=obj(q);print('JSON',name,'TYPE',type(o).__name__)
 if isinstance(o,dict):print('KEYS',list(o),'SCALARS',{k:v for k,v in o.items() if isinstance(v,(str,int,bool))});print('FIRST_ROWS',{k:v[:1] for k,v in o.items() if isinstance(v,list)})
 else:print('ROWS',o[:2])
