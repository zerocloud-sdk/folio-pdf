from pathlib import Path
import json,hashlib,atexit,sys
REPO=Path('/home/ubuntu/IdeaProjects/open-pdf');OUT=Path(__file__).parent;FILES={}
def read(path):
 path=Path(path)
 if '/T75-foundation-20260914-r4/annotations' in str(path):raise PermissionError('Active annotations raw excluded from phase1')
 data=path.read_bytes();row={'path':str(path),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
 if str(path) in FILES:assert FILES[str(path)]['sha256']==row['sha256'],'changed between reads '+str(path)
 FILES[str(path)]=row;return data
def obj(path):return json.loads(read(path))
def sha(path):return hashlib.sha256(read(path)).hexdigest()
def put(name,value):
 with (OUT/name).open('x') as f:f.write(value if isinstance(value,str) else json.dumps(value,ensure_ascii=False,indent=2)+'\n')
@atexit.register
def retain_inputs():put(Path(sys.argv[0]).stem+'-input-catalog.json',list(FILES.values()))
