from auditlib import *
import tarfile,io
base=REPO/'capabilities/evidence/T75-delivery';v=base/'final-validation-r4';stage=base/'final-candidate-r4'
freeze_sha='50988226c0db8a0eddd622ec3d9656d5ad6eb1e25328f22a067ee0e54add392d'
assert sha(v/'source-and-contract-inputs.json')==freeze_sha
members=[];archives=[]
def archive(root,identity):
 p=root/identity['archive']; assert sha(p)==identity['sha256']; expected=identity['members']; assert not identity['symbolic_links']
 with tarfile.open(p,'r:xz') as tf:
  actual=tf.getmembers(); assert [m.name for m in actual]==[m['path'] for m in expected]
  for m,e in zip(actual,expected):
   assert m.isfile() and not m.issym() and not m.islnk();data=tf.extractfile(m).read();digest=hashlib.sha256(data).hexdigest()
   assert digest==e['sha256'] and len(data)==e['size'];members.append({'archive':str(p),'member':m.name,'bytes':len(data),'sha256':digest})
 archives.append({'path':str(p),'sha256':identity['sha256'],'members':len(expected)})
 return {e['path']:e for e in expected}
validation=[]
for kind,stem,major in [('host-full-verify','t75-final-full-verify-r4',[17]),('jdk-matrix','t75-final-jdk-matrix-r4',[8,11,17,21])]:
 r=obj(v/(kind+'-receipt.json'));actual=obj(v/(stem+'-result.json'));cmd=obj(v/(stem+'-command.json'))
 assert actual==r['actual-result'] and actual['returncode']==0 and all(actual[k]==value for k,value in cmd.items())
 assert r['source-and-contract-inputs-unchanged'] and (r['source-count'],r['contract-count'])==(1933,30)
 assert r['result']=='pass' and sha(r['original-log'])==r['log-sha256']
 assert [x['jdk-major'] for x in r['runs']]==major
 for run in r['runs']:
  assert run['totals']=={'tests':1507,'failures':0,'errors':0,'skipped':4} and run['class-results']==87 and run['result']=='PASS'
  assert len(run['reactor-results'])==10 and all(' SUCCESS ' in x for x in run['reactor-results'])
 assert len(r['reports'])==177 and len(r['skipped-cases'])==4
 assert sum(x['class'].endswith('HardenedWorkerScaleProfileTest') for x in r['skipped-cases'])==3
 assert sum(x['class'].endswith('T30BarcodeEvidenceCommandTest') for x in r['skipped-cases'])==1
 ident=obj(v/(kind+'-archive-identity.json'));cat=archive(v,ident)
 assert len(cat)==184
 for row in r['reports']:
  candidates=[x for n,x in cat.items() if n.endswith(row['path'])]
  assert len(candidates)==1 and candidates[0]['sha256']==row['sha256']
 for name in [stem+'-command.json',stem+'-result.json',stem+'.log']:
  assert name in cat and sha(v/name)==cat[name]['sha256']
 validation.append({'kind':kind,'actual-result':actual,'runs':r['runs'],'archive':archives[-1],'report-files':177,'skips':r['skipped-cases'],'report-boundary':r['report-boundary']})
host=obj(v/'standards-host-review-receipt.json');matrix=obj(v/'standards-matrix-review-receipt.json')
assert not host['hard-breaches'] and not host['open-judgement-findings'] and host['host-actual-returncode']==0
assert host['frozen-input-receipt-sha256']==freeze_sha and not host['source-current-mismatches']
assert not matrix['hard-violations'] and not matrix['open-heuristic-findings']
assert matrix['original-process']['actual-returncode']==0 and matrix['review-continuity']['freeze-sha256']==freeze_sha
assert matrix['review-continuity']['all-current-input-paths-and-bytes-match-frozen-host-and-matrix']
assert matrix['final-JDK21-reports']['earlier-three-JDK-XML-retained-or-inspected'] is False
review_records=[]
for kind,count in [('host',105),('matrix',96)]:
 ident=obj(v/('standards-'+kind+'-review-archive-identity.json'));assert len(ident['members'])==count; cat=archive(v,ident)
 receipt=host if kind=='host' else matrix
 reportsha=receipt['report-sha256'] if kind=='host' else receipt['report']['sha256']
 assert sha(v/('standards-'+kind+'-review-report.md'))==reportsha
 assert any(e['sha256']==reportsha for e in cat.values())
 assert any(e['sha256']==sha(v/('standards-'+kind+'-review-receipt.json')) for e in cat.values())
 review_records.append({'kind':kind,'archive':archives[-1],'receipt-sha256':sha(v/('standards-'+kind+'-review-receipt.json')),'report-sha256':reportsha,'open-findings':[]})
stageid=obj(stage/'original-archive-identities.json')['staged-build'];cat=archive(stage,stageid);assert len(cat)==10
actual=obj(stage/'t75-final-stage-r4-result.json');cmd=obj(stage/'t75-final-stage-r4-command.json')
assert actual['returncode']==0 and all(actual[k]==value for k,value in cmd.items())
assert actual['command']==['/usr/bin/python3','scripts/t03-foundation.py','stage','--obligation','text']
for name in ['build-inputs.json','build-command.json','freeze.json','t75-final-stage-r4-command.json','t75-final-stage-r4-result.json','t75-final-stage-r4.log']:
 assert sha(stage/name)==cat[name]['sha256']
assert cat['source-and-contract-inputs.json']['sha256']==freeze_sha
incident=base/'certification-review-r3/annotations-reader-output-incident-and-closure.json'
assert sha(incident)=='3927ee99491a3f71fe24f4dc536cf086608b45e441289e6ab14a2033b3007149'
loss=obj(incident);assert len(loss['lost-derived-summary-paths'])==2
assert sorted(x['known-pre-overwrite-bytes'] for x in loss['lost-derived-summary-paths'])==[55109,79646]
assert all(x['pre-overwrite-sha256'] is None for x in loss['lost-derived-summary-paths'])
retention=base/'final-certification-r3/historical-raw-retention-receipt.json';removal=base/'final-certification-r3/historical-live-removal-command-receipt.json'
assert sha(retention)=='444e0f2b7aba30c7d59b5812d5f231c80007828107052ca14520b1fafd0cf4b1'
assert sha(removal)=='fbd61ae9d93ba45b17b47c3a921c50dd5fa20769b43aef7b858c57aac3b1c6d2'
r=obj(retention);d=obj(removal);assert len(r['archives'])==len(d['archive-checks'])==6
assert sum(x['members'] for x in r['archives'])==d['removed-files']==254118
history=[]
for a,c in zip(r['archives'],d['archive-checks']):
 assert all(a[k]==c[k] for k in ['obligation','members','archive-sha256','member-identities-sha256'])
 assert c['every-archive-member-matches-live-original']
 arc=retention.parent/a['archive'];catalog=retention.parent/a['member-identities']
 assert sha(arc)==a['archive-sha256'] and arc.stat().st_size==a['archive-bytes']
 assert sha(catalog)==a['member-identities-sha256'] and catalog.stat().st_size==a['member-identities-bytes']
 history.append(a)
assert d['original-retention-receipt']==str(retention)
put('validation-stage-review-member-catalog.json',members)
put('validation-history-binding-inspection.json',{'validation':validation,'independent-validation-reviews':review_records,'stage':{'actual-result':actual,'archive':archives[-1],'source-contract-freeze-sha256':freeze_sha},'archive-byte-checks':archives,'history':{'retention-receipt-sha256':sha(retention),'removal-receipt-sha256':sha(removal),'archives':history,'members':254118,'scope':'Compressed archive/catalog continuity; prior complete per-member removal audit is bound, not replayed. Deleted historical live paths are not required.','derived-review-output-exception':{'incident-sha256':sha(incident),'lost-original-derived-summaries':loss['lost-derived-summary-paths'],'assessment':'Original two historical derived summaries are unavailable. Certification raw and original reader commands/stdout remain preserved; independent fresh inspection closes behavior, without recovering old bytes. No claim that all historical derived evidence was preserved.'}},'errors':[]})
print(json.dumps({'host-and-matrix-runs':5,'each-run-tests':1507,'each-run-failures':0,'each-run-errors':0,'each-run-default-skips':4,'validation-stage-review-archives':len(archives),'verified-archive-members':len(members),'historical-raw-retained-members':254118,'known-historical-derived-summary-losses':2,'errors':0}))
