from auditlib import *
reports=obj(OUT/'selected-original-review-reports.json')
for row in reports:
 if row['scope'] in ['step4-review/full-spec','step4-review/optional-spec-closure','inventory-read-bound/spec-review-archive-identity','step4-review/candidate-metadata-spec-identity']:print('ORIGINAL_REPORT',row['scope'],'\n'+row['text'])
