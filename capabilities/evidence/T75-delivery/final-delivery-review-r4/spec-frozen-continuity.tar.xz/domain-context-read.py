from auditlib import *
print('FILE /home/ubuntu/IdeaProjects/open-pdf/CONTEXT.md','\n'+read(Path('/home/ubuntu/IdeaProjects/open-pdf/CONTEXT.md')).decode())
