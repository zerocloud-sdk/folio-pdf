from auditlib import *
D=REPO/'capabilities/evidence/T75-delivery'
for name in ['final-validation-r4/README.md','final-validation-r4/standards-host-review-report.md','final-validation-r4/standards-matrix-review-report.md','final-candidate-r4/README.md','final-delivery-review-r3/historical-facade-counts.md','final-delivery-review-r3/historical-facade-counts-standards-report.md','git-retention/spec-report.md']:
 path=D/name;print('FILE',name,'\n'+read(path).decode())
for name in ['final-validation-r4/host-full-verify-receipt.json','final-validation-r4/jdk-matrix-receipt.json','final-validation-r4/standards-host-review-receipt.json','final-validation-r4/standards-matrix-review-receipt.json']:
 o=obj(D/name);print('SCHEMA',name,list(o));print('SCALARS',{k:v for k,v in o.items() if isinstance(v,(str,int,bool))});print('LIST_LENGTHS',{k:len(v) for k,v in o.items() if isinstance(v,list)})
