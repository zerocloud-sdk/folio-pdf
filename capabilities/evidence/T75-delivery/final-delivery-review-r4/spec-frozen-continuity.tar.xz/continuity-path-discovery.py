from auditlib import *
base=REPO/'capabilities/evidence/T75-delivery'
for name in ['final-review','step4-review','appearance','observer-budget','worker-batch-timeout','inventory-read-bound','delivery-readiness-review']:
 p=base/name
 print('DIRECTORY',name,'exists',p.exists())
 if p.exists():print('\n'.join(str(q.relative_to(base)) for q in sorted(p.rglob('*')) if q.is_file() and not q.name.endswith(('.tar.xz','.log'))))
print('ADR0035',[str(q.relative_to(REPO)) for q in sorted((REPO/'docs/adr').glob('*0035*'))])
print('SETUP_FILES',[q.name for q in sorted(Path('/tmp/t75-final-review-fixed-baseline-r4-zpbk95st').iterdir()) if q.is_file()])
