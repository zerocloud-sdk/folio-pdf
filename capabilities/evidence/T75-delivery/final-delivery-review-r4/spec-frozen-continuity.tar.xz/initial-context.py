from auditlib import *
paths=[Path('/home/ubuntu/.codex/attachments/77353239-0dda-4ee1-b4bb-ce7fb3fa0f9b/pasted-text-1.txt'),Path('/home/ubuntu/.codex/skills/code-review/SKILL.md')]+[REPO/n for n in ['AGENTS.md','CONTRIBUTING.md','CONTEXT.md','docs/agents/domain.md','docs/agents/issue-tracker.md']]
for path in paths:print('FILE',path,'\n'+read(path).decode())
