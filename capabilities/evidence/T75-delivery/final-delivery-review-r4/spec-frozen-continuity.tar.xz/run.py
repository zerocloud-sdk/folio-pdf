from pathlib import Path
import subprocess,sys,json,datetime
base=Path(__file__).resolve().parent
label=sys.argv[1]
argv=sys.argv[2:]
assert label and not any(base.glob(label+'.*')), 'refusing output overwrite'
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
command={'argv':argv,'cwd':'/home/ubuntu/IdeaProjects/open-pdf','started_utc':start}
(base/(label+'.command.json')).write_text(json.dumps(command,indent=2)+'\n')
with (base/(label+'.stdout.txt')).open('xb') as stdout,(base/(label+'.stderr.txt')).open('xb') as stderr:
 result=subprocess.run(argv,cwd=command['cwd'],stdout=stdout,stderr=stderr)
end=datetime.datetime.now(datetime.timezone.utc).isoformat()
(base/(label+'.result.json')).write_text(json.dumps({'actual_exit':result.returncode,'started_utc':start,'finished_utc':end},indent=2)+'\n')
print('actual_exit',result.returncode)
shown=(base/(label+'.stdout.txt')).read_text();print(shown if len(shown)<=16000 else shown[:16000]+'\n[Display bounded; complete stdout retained on disk.]')
print((base/(label+'.stderr.txt')).read_text(),file=sys.stderr)
sys.exit(result.returncode)
