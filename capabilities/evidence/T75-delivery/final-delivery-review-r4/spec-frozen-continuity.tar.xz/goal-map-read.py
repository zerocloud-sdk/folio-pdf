from auditlib import *
paths=[REPO/'docs/adr/0035-represent-uncertain-unicode-mappings.md',REPO/'capabilities/evidence/T75-delivery/final-execution-receipt.md',REPO/'capabilities/evidence/T75-delivery/delivery-readiness-review/development-coverage-map.md']
for path in paths:
 data=read(path);print('FILE',path,'\n'+data.decode());dest=OUT/('snapshot-'+path.name)
 with dest.open('xb') as f:f.write(data)
