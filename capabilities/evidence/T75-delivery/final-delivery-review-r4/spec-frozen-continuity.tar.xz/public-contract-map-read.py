from auditlib import *
import re
paths=['pdf-document/src/test/java/net/zerocloud/pdf/consumer/TextStructureExtractionWorkflowTest.java','pdf-migration-itext7/src/test/java/net/zerocloud/pdf/itext7/consumer/TextStructureFacadeTest.java','docs/t13-certification.md','capabilities/evidence/T75-text-semantic.md','capabilities/evidence/T75-text-visual.md','capabilities/evidence/T75-text-standards.md','capabilities/evidence/T75-text-syntax.md','capabilities/evidence/T13-text-logical-structure.md']
rows=[]
for p in paths:
 data=read(REPO/p).decode();methods=[];heads=[]
 for n,line in enumerate(data.splitlines(),1):
  m=re.search(r'public void (\w+)\(',line)
  if m:methods.append({'line':n,'method':m.group(1)})
  if line.startswith('#'):heads.append({'line':n,'heading':line})
 rows.append({'path':p,'sha256':sha(REPO/p),'methods':methods,'headings':heads})
 print('SOURCE',p,'METHODS',json.dumps(methods),'HEADINGS',json.dumps(heads))
put('public-test-and-contract-navigation.json',rows)
