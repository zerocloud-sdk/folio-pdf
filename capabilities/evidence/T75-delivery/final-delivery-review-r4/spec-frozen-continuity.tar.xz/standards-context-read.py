from auditlib import *
print('FILE /home/ubuntu/.codex/skills/code-review/SKILL.md','\n'+read(Path('/home/ubuntu/.codex/skills/code-review/SKILL.md')).decode())
print('FILE /home/ubuntu/IdeaProjects/open-pdf/AGENTS.md','\n'+read(Path('/home/ubuntu/IdeaProjects/open-pdf/AGENTS.md')).decode())
print('FILE /home/ubuntu/IdeaProjects/open-pdf/CONTRIBUTING.md','\n'+read(Path('/home/ubuntu/IdeaProjects/open-pdf/CONTRIBUTING.md')).decode())
print('FILE /home/ubuntu/IdeaProjects/open-pdf/docs/agents/domain.md','\n'+read(Path('/home/ubuntu/IdeaProjects/open-pdf/docs/agents/domain.md')).decode())
print('FILE /home/ubuntu/IdeaProjects/open-pdf/docs/agents/issue-tracker.md','\n'+read(Path('/home/ubuntu/IdeaProjects/open-pdf/docs/agents/issue-tracker.md')).decode())
