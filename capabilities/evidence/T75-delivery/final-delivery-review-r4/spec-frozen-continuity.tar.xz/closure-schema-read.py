from auditlib import *
base=REPO/'capabilities/evidence/T75-delivery'
def summary(v):
 if isinstance(v,dict):return {'keys':list(v),'scalars':{k:x for k,x in v.items() if isinstance(x,(str,int,bool))},'lists':{k:len(x) for k,x in v.items() if isinstance(x,list)}}
 return v
for name in ['final-review/original-archive-identities.json','final-review/final-closure-archive-identities.json','step4-review/review-archive-identities.json','step4-review/source-closure-archive-identities.json','step4-review/candidate-metadata-archive-identities.json','observer-budget/final-closure-identities.json','worker-batch-timeout/closure-archive-identities.json']:
 o=obj(base/name);print('FILE',name)
 for k,v in o.items():print(k,summary(v))
o=obj(base/'inventory-read-bound/input-delta-from-original-full-review.json');print('DELTA_ORIGINAL',o['original-full-review-receipt']);print('DELTA_PRIOR',o['prior-reviewed-delta']);print('DELTA_ROWS',o['inputs']);print('CONTRACT_DELTA',o['contract-inputs'])
q=Path('/tmp/t75-final-review-fixed-baseline-r4-zpbk95st/receipt.json');o=obj(q);print('SETUP_RECEIPT',summary(o));print('SETUP_ALLOCATION',obj(q.parent/'reviewer-allocation-boundary.json'))
