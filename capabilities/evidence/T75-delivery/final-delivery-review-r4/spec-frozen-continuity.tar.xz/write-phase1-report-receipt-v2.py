from pathlib import Path
import json,hashlib,datetime
OUT=Path(__file__).parent
def obj(n):return json.loads((OUT/n).read_bytes())
def sha(n):return hashlib.sha256((OUT/n).read_bytes()).hexdigest()
def put(n,v):
 with (OUT/n).open('x') as f:f.write(v if isinstance(v,str) else json.dumps(v,ensure_ascii=False,indent=2)+'\n')
report='''No newly discovered implementation defect or unauthorized scope expansion was found in this phase.

The fixed baseline and HEAD remain `5b1603c435f11c40368f75b7b9a2777c9c5e9761`. This is explicitly WIP: empty committed/index diffs do not erase tracked changes or new files. Original complete independent reviews cover the frozen inputs, and every later 26-source/one-contract delta matches a closed independent review. All current 1,933 source, 30 contract, 23 artifact and 24 harness identities match candidate `ab18cc9c…` and contract `3de508f7…`. The 16 MiB reader correction bounds accepted record input; it is not a total-I/O or heap bound.

The independent 28-criterion map distinguishes established evidence from pending gates. Text, transactions, values, pages and metadata retain exact own-index publication: 40 certifications, 160 PASS chains, five actual outer exits 0. Sealed raw reviews and all 50 command-archive members bind these observations without replaying raw qualification. Native covers both profiles; Facade remains actual IN_PROCESS. Text runs 126 formal tests per tuple. Whole Stable/Preview surfaces are 21 types/157 members; 20 coexistence probes are distinguished from the new extractor’s source-reviewed initialization delegation.

Host and four-JDK validation each retain 1,507 tests, zero failures/errors and four documented default skips. The complete matrix log covers all four JDKs; retained matrix XML belongs to the final JDK21 run only.

Known historical partial constraint: the Goal says “Preserve historical evidence.” Two derived r3 summaries, 55,109 and 79,646 bytes, were overwritten; their old bytes/SHA remain unavailable (incident `3927ee99…`). The 254,118 certification originals remain archived. Fresh independent inspection closes the affected behavioral scope without recovering those summaries. This is not current r4 raw loss.

Annotations, final 48/192 publication, all-six-satisfied inventory results, frozen-index review, final diff checks and delivery remain deferred. No completion criterion is marked. This originally independent thread was reused after allocation failed; no newly created reviewer is claimed. Windows/macOS remain uncertified; global Foundation readiness is not approved.
'''
assert len(report.split())<400;put('report.md',report)
coverage=obj('complete-source-review-coverage-inspection.json');frozen=obj('frozen-source-continuity-inspection.json');cert=obj('five-certification-continuity-inspection.json');validation=obj('validation-history-binding-inspection.json');catalog=obj('input-sha256-catalog.json');closing=obj('closing-frozen-input-inspection.json')
results=[]
known={'closing-input-catalog-check.result.json':1,'write-phase1-report-receipt-check.result.json':2}
for p in sorted(OUT.glob('*.result.json')):
 r=json.loads(p.read_bytes());assert r['actual_exit']==known.get(p.name,0),p.name
 stem=p.name[:-len('.result.json')];assert (OUT/(stem+'.command.json')).is_file()
 stdout=OUT/(stem+'.stdout.txt');stderr=OUT/(stem+'.stderr.txt')
 if not stdout.is_file():stdout=OUT/(stem+'.stdout');stderr=OUT/(stem+'.stderr')
 assert stdout.is_file() and stderr.is_file()
 results.append({'name':stem,'command-sha256':sha(stem+'.command.json'),'stdout':stdout.name,'stdout-sha256':sha(stdout.name),'stderr':stderr.name,'stderr-sha256':sha(stderr.name),'result-sha256':sha(p.name),'actual-exit':r['actual_exit']})
put('completed-reader-command-results.json',results)
receipt={
 'reviewer':'/root/values_raw_spec_r4; independent Spec axis; no repository implementation work',
 'sealed-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'phase':'First stage only: frozen source/contract complete-review continuity, original Goal28 mapping, five completed certifications and validation/history boundaries',
 'baseline':frozen['baseline'],'HEAD-at-fixed-review-setup':frozen['baseline'],'candidate':cert['candidate'],'contract':cert['contract'],
 'review-method':'Bound current frozen tracked WIP plus all1933source/30contract paths against BASE, including new/untracked files, to original complete independent reviews and every later closed identity delta. Read-only inspectors; no product or certification tests rerun.',
 'independence-boundary':'Continued the originally fork-none independent reviewer after system thread allocation failed. No new fresh agent was created in this phase. Parent retains allocation-boundary.json.',
 'scope-inputs':frozen['inputs'],'baseline-comparison-counts':frozen['baseline-comparison-counts'],
 'original-source-review-new-paths':coverage['original-full-source-review-new-files'],'current-frozen-new-source-paths':coverage['current-frozen-new-source-files'],'additional-original-reviewed-qualification-paths':coverage['additional-original-reviewed-new-path-outside-current-source-contract-inputs'],
 'all-current-new-modified-frozen-paths':len(coverage['all-current-new-and-modified-frozen-inputs']),
 'cumulative-independent-closed-deltas':{'sources':26,'contracts':1},
 'source-review-archives':{'count':17,'every-member-checked':2566,'inspection':'review-archive-inspection.json'},
 'completed-certification-continuity':{'obligations':['text','transactions','values','pages','metadata'],'certifications':40,'PASS-chains':160,'raw-review-links':cert['raw-review-links'],'publication-review-links':cert['publication-review-links'],'dated-authority':cert['dated-authority'],'actual-outer-exits':[x['actual-result'] for x in cert['obligations']],'retained-command-members':50,'raw-rules-or-RGB-replayed':False,'active-annotations-read':False},
 'validation':{'host-plus-matrix-runs':5,'each-run-tests':1507,'each-run-failures':0,'each-run-errors':0,'each-run-default-skips':4,'matrix-earlier-JDK-XML-separately-retained':False,'validation-stage-review-archives':5,'verified-members':579,'inspection':'validation-history-binding-inspection.json'},
 'goal-map':{'path':'goal-28-criteria-map-final.json','sha256':sha('goal-28-criteria-map-final.json'),'criteria':28,'established-for-frozen-phase-scope':20,'explicit-final-gates-deferred':8,'all-completion-marks':False},
 'new-implementation-or-scope-findings':[],
 'known-historical-partial-constraint':[{'spec':'Original Goal constraint: Preserve historical evidence.','scope':'Two derived r3 annotations summaries only; oldbytes55109/79646, oldSHA unavailable','incident-sha256':'3927ee99491a3f71fe24f4dc536cf086608b45e441289e6ab14a2033b3007149','assessment':'Historical derived preservation is partial. All254118 certification raw originals remain archived; fresh independent read closes behavior without recovering old summaries. No current r4 raw loss or complete historical-derived preservation is claimed.','newly-discovered':False}],
 'approvals':{'frozen-source-review-continuity':True,'five-completed-certification-publication-continuity':True,'final-annotations':False,'final48-and192PASS':False,'final-all-six-satisfied-inventory':False,'future-frozen-staged-index':False,'final-delivery':False,'completion-marking':False},
 'deferred':['annotations sealed raw/publication review','exact final48certifications/192PASS and prior40 preservation','actual final inventory generate/validate/check and all-six-satisfied assertion','full frozen staged index and byte-preservation/intentional workspace/diff checks','final two-axis review and delivery receipt','authorized real-name DCO commit/push/remote verification/issue closure by parent after gates'],
 'historical-retention':validation['history'],'closing-freeze':closing,
 'original-input-catalog':{'path':'input-sha256-catalog.json','sha256':sha('input-sha256-catalog.json'),'input-observations':catalog['input-observations'],'distinct-paths':catalog['distinct-paths']},
 'archive-member-catalog':{'path':'archive-member-sha256-catalog.json','sha256':sha('archive-member-sha256-catalog.json'),'members':3195},
 'report':{'path':'report.md','sha256':sha('report.md'),'words':len(report.split())},
 'diagnostics-preserved':['fixture-path-navigation-diagnostic.json: guessed directory absent; no evidence relied on it','goal-criteria-mapping-check: four unresolved aliases; v2 resolves exact existing paths','closing-input-catalog-check: actual1 member/filesystem schema confusion; v2 uses separate schemas, actual0','report-writer-construction-diagnostic.json and write-phase1-report-receipt-check actual2: original generator parse failed before creating script; distinct v2 construction retained'],
 'tools-display-boundary':'Complete underlying stdout and input hashes remain retained despite bounded tool displays.',
 'write-boundary':'Exclusive /tmp packet writes only; no repository, index, authority, tracker or sealed original mutation; no Maven/inventory/certifier/product execution.',
 'manifest-boundary':'artifact-manifest.json covers every final packet file except itself, including actual report-writer command/stdout/stderr/result. External inputs and actual archive-member bytes are separately cataloged.'
}
put('receipt.json',receipt)
print(json.dumps({'report-words':len(report.split()),'report-sha256':sha('report.md'),'receipt-sha256':sha('receipt.json'),'original-input-observations':catalog['input-observations'],'archive-members-read':3195,'completed-retained-reader-results':len(results),'new-implementation-or-scope-findings':0,'known-historical-partial-constraint':1,'final-approval':False}))
