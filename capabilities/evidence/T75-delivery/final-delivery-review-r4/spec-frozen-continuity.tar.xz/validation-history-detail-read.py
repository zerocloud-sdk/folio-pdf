from auditlib import *
base=REPO/'capabilities/evidence/T75-delivery'
for rel in ['final-validation-r4/host-full-verify-receipt.json','final-validation-r4/jdk-matrix-receipt.json']:
 d=obj(base/rel); print(rel, 'RUNS',json.dumps(d['runs']), 'REPORT0',json.dumps(d['reports'][0]),'SKIPS',json.dumps(d['skipped-cases']))
for rel in ['final-candidate-r4/original-archive-identities.json','final-candidate-r4/t75-final-stage-r4-command.json','final-candidate-r4/t75-final-stage-r4-result.json']:
 d=obj(base/rel); print(rel,json.dumps(d))
for rel in ['final-validation-r4/standards-host-review-archive-identity.json','final-validation-r4/standards-matrix-review-archive-identity.json']:
 p=base/rel
 print('EXISTS',rel,p.exists())
 if p.exists():
  d=obj(p);print('SHAPE',json.dumps({k:(len(v) if isinstance(v,list) else v) for k,v in d.items()}))
for rel,key in [('certification-review-r3/annotations-reader-output-incident-and-closure.json','lost-derived-summary-paths'),('final-certification-r3/historical-raw-retention-receipt.json','archives'),('final-certification-r3/historical-live-removal-command-receipt.json','archive-checks')]:
 d=obj(base/rel);print(rel,json.dumps(d[key]))
