from pathlib import Path
import json,hashlib
p=Path(__file__).parent
assert not (p/'artifact-manifest.json').exists()
receipt=json.loads((p/'receipt.json').read_bytes())
assert hashlib.sha256((p/'report.md').read_bytes()).hexdigest()==receipt['report']['sha256']
assert json.loads((p/'write-phase1-report-receipt-v2-check.result.json').read_bytes())['actual_exit']==0
assert json.loads((p/'closing-input-catalog-v2-check.result.json').read_bytes())['actual_exit']==0
assert json.loads((p/'goal-criteria-mapping-v2-check.result.json').read_bytes())['actual_exit']==0
rows=[]
for f in sorted(p.rglob('*')):
 if f.is_dir():continue
 assert f.is_file() and not f.is_symlink()
 assert f.suffix!='.pyc' and '__pycache__' not in f.parts
 data=f.read_bytes();rows.append({'path':str(f.relative_to(p)),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
manifest={'scope':'Every final phase1 packet artifact, including scripts, original command/stdout/stderr/actual results, preserved diagnostics, original selected bytes and input catalogs. No self hash.','excluded':['artifact-manifest.json'],'files':rows,'member-count-excluding-self':len(rows),'member-count-including-manifest':len(rows)+1}
with (p/'artifact-manifest.json').open('x') as f:json.dump(manifest,f,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps({'packet':str(p),'members':len(rows)+1,'manifest-excludes-only-itself':True,'identities':{n:hashlib.sha256((p/n).read_bytes()).hexdigest() for n in ['report.md','receipt.json','artifact-manifest.json','input-sha256-catalog.json','archive-member-sha256-catalog.json','goal-28-criteria-map-final.json']}}))
