import json,pathlib
BASE=pathlib.Path('/home/ubuntu/IdeaProjects/open-pdf/capabilities/evidence/T75-delivery/certification-review-r3')
for path in sorted(BASE.glob('*-archive-identity.json')):
    data=json.loads(path.read_text());print(path.name,len(data['members']),data['original'])
