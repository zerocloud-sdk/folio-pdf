import datetime,hashlib,json,os,pathlib,stat
OUT=pathlib.Path(__file__).parent

def sha(path):
    with pathlib.Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def emit(name,data):
    with (OUT/name).open('x') as f:json.dump(data,f,indent=2);f.write('\n')
rows=[]
for name in ['candidate-directory-layout.json','last-three-directory-layout.json','pages-directory-layout.json']:rows.extend(json.loads((OUT/name).read_text()))
assert len(rows)==5
allowlist=[]
for row in rows:
    root=pathlib.Path(row['original']);assert root.parent==pathlib.Path('/tmp') and root.resolve()==root and stat.S_ISDIR(root.lstat().st_mode)
    assert sha(row['identity'])==row['identity-sha256'] and sha(row['archive'])==row['archive-sha256']
    identity=json.loads(pathlib.Path(row['identity']).read_text());assert identity['original']==str(root)
    expected={x['path']:x for x in identity['members']};assert len(expected)==row['archive-members']
    assert all(not name.startswith('/') and '..' not in pathlib.PurePosixPath(name).parts for name in expected)
    expected_dirs={'.'}
    for name in expected:
        p=pathlib.PurePosixPath(name).parent
        while str(p)!='.':expected_dirs.add(str(p));p=p.parent
    actual=set();actual_dirs=set();inodes={};dir_allocated=0
    for current,dirs,names in os.walk(root,followlinks=False):
        current=pathlib.Path(current);actual_dirs.add(current.relative_to(root).as_posix());dir_allocated+=current.lstat().st_blocks*512
        for name in dirs:assert not (current/name).is_symlink()
        for name in names:
            path=current/name;st=path.lstat();assert stat.S_ISREG(st.st_mode)
            relative=path.relative_to(root).as_posix();actual.add(relative);assert st.st_size==expected[relative]['size']
            inodes.setdefault((st.st_dev,st.st_ino),{'allocated':st.st_blocks*512,'nlink':st.st_nlink,'observed-links':0})['observed-links']+=1
    assert actual==set(expected) and actual_dirs==expected_dirs
    assert all(x['observed-links']==x['nlink'] for x in inodes.values())
    allocated=sum(x['allocated'] for x in inodes.values())
    assert allocated==row['allocated-bytes-unique-inodes']
    allowlist.append({'original':str(root),'archive':row['archive'],'archive-sha256':row['archive-sha256'],'identity':row['identity'],'identity-sha256':row['identity-sha256'],'file-count':len(actual),'directory-count':len(actual_dirs),'logical-bytes':row['logical-bytes'],'allocated-regular-file-bytes':allocated,'allocated-directory-bytes':dir_allocated,'estimated-reclaim-bytes':allocated+dir_allocated,'exact-file-and-directory-membership':True,'every-original-file-size-matches-manifest':True,'symlinks-or-special-files':0,'hardlinks-outside-selected-directory':0,'membership-paths-sha256':hashlib.sha256(('\n'.join(sorted(actual))+'\n').encode()).hexdigest(),'full-original-member-SHA-rechecked-by-this-hygiene-review':False,'required-parent-gate':'Independently stream every archived regular member, compare member SHA/size to identity and original file bytes, recheck exact files/directories and no outside hard links, retain successful originals/results and removal receipt before/after deleting only this exact path.'})
confirmations=[{'agent':'/root/final_spec','scope':'All five exact allowlisted paths','message':'Confirmed: the four named old r3 packets and /tmp/t75-final-spec-pages-eight-btlle2s_ are not required as live paths for this review. Verified original archives and complete identities suffice for historical linkage. My current r4 annotations publication reads its r4 raw packet and r4 metadata publication packet; all r4 originals stay intact.'},{'agent':'/root/values_raw_spec_r4','scope':'First four preferred paths','message':'Confirmed dependency boundary only: my eventual phase 2 does not require those four OLD r3 /tmp raw-review directories to remain live. Retained certification-review-r3 archives plus exact member identities can serve the historical references after root verifies all member bytes and exact directory membership and retains the removal receipt. This does not authorize deletion of current r4 originals, source-review closures, or any other path. No new inspection was needed or performed.'},{'agent':'/root/values_raw_spec_r4','scope':'Additional pages exact path','message':'Confirmed for that additional exact path: phase 2 does not require /tmp/t75-final-spec-pages-eight-btlle2s_ to remain live. Its retained old r3 pages review archive plus exact identities suffice after root’s full byte/membership verification and removal receipt. This is dependency confirmation only, with no new inspection or broader cleanup authorization.'}]
emit('peer-dependency-confirmations.json',{'recorded-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':'Explicit collaboration messages delivered to /root/final_standards in this hygiene task; faithfully transcribed here.','confirmations':confirmations})
totals={'directories':5,'files':sum(x['file-count'] for x in allowlist),'logical-bytes':sum(x['logical-bytes'] for x in allowlist),'allocated-regular-file-bytes':sum(x['allocated-regular-file-bytes'] for x in allowlist),'allocated-directory-bytes':sum(x['allocated-directory-bytes'] for x in allowlist),'estimated-reclaim-bytes':sum(x['estimated-reclaim-bytes'] for x in allowlist)}
emit('cleanup-candidates.json',{'recorded-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Only five exact old r3 archive-backed task review directories; recommendation remains conditional on the independent parent byte/membership gate.','totals':totals,'candidates':allowlist,'current-r4-originals-or-raw-selected':False,'source-review-closure-packets-selected':False,'historical-annotations-review-selected':False,'missing-historic-summaries-recovered':False,'deletion-executed':False})
print(json.dumps({'totals':totals,'estimated-reclaim-GiB':totals['estimated-reclaim-bytes']/1024**3,'archive-digests-match':True,'exact-current-file-directory-membership':True,'live-reviewer-dependencies-cleared':True,'parent-every-member-byte-verification-still-required':True,'deletion-executed':False},indent=2))
