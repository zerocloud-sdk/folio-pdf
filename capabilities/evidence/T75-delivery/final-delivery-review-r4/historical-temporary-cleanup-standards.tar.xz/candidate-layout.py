import hashlib,json,os,pathlib,stat
OUT=pathlib.Path(__file__).parent
BASE=pathlib.Path('/home/ubuntu/IdeaProjects/open-pdf/capabilities/evidence/T75-delivery/certification-review-r3')
rows=[]
for path in sorted(BASE.glob('*-archive-identity.json')):
    name=path.name
    if not any(term in name for term in ['jdk8-two-tuples','jdk11','jdk17','metadata-eight']):continue
    raw=path.read_bytes();identity=json.loads(raw);root=pathlib.Path(identity['original'])
    if not root.is_dir():continue
    files=[];symlinks=[];directories=0;by_inode={}
    for current,dirs,names in os.walk(root,followlinks=False):
        directories+=1
        for item in dirs+names:
            p=pathlib.Path(current)/item;st=p.lstat()
            if stat.S_ISLNK(st.st_mode):symlinks.append(str(p.relative_to(root)))
            elif stat.S_ISREG(st.st_mode):
                files.append(p.relative_to(root).as_posix());by_inode.setdefault((st.st_dev,st.st_ino),{'bytes':st.st_size,'allocated':st.st_blocks*512,'nlink':st.st_nlink,'paths':[]})['paths'].append(str(p.relative_to(root)))
    expected={x['path'] for x in identity['members']};actual=set(files)|set(symlinks)
    record={'identity':str(path),'identity-sha256':hashlib.sha256(raw).hexdigest(),'archive':str(BASE/identity['archive']),'archive-sha256':identity['sha256'],'original':str(root),'archive-members':len(expected),'actual-files':len(files),'actual-directory-count':directories,'actual-symlinks':symlinks,'extra-paths':sorted(actual-expected),'missing-paths':sorted(expected-actual),'logical-bytes':sum(x['bytes'] for x in by_inode.values()),'allocated-bytes-unique-inodes':sum(x['allocated'] for x in by_inode.values()),'files-with-links-outside-this-directory':[x for x in by_inode.values() if len(x['paths'])<x['nlink']]}
    rows.append(record)
with (OUT/'candidate-directory-layout.json').open('x') as f:json.dump(rows,f,indent=2);f.write('\n')
print(json.dumps(rows,indent=2))
