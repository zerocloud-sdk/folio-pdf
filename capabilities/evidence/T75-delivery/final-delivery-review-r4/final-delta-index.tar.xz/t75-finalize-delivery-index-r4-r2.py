from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,importlib.util,json,os,re,subprocess,tempfile,shutil
import yaml
root=Path('/home/ubuntu/IdeaProjects/open-pdf'); os.chdir(root)
reviewed_tree='b12a83ab82a0e59425c87fecd16bf317e581adaf'
original=Path(tempfile.mkdtemp(prefix='t75-final-delivery-index-r4-r2-')); commands=[]
(original/Path(__file__).name).write_bytes(Path(__file__).read_bytes())
def call(name,args):
 start=datetime.now(timezone.utc).isoformat();result=subprocess.run(args,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 record={'command':args,'started-utc':start,'completed-utc':datetime.now(timezone.utc).isoformat(),'returncode':result.returncode}
 for label,data in [('stdout',result.stdout),('stderr',result.stderr)]:
  (original/(name+'.'+label+'.gz')).write_bytes(gzip.compress(data,mtime=0));record[label+'-bytes']=len(data);record[label+'-sha256']=hashlib.sha256(data).hexdigest()
 (original/(name+'-result.json')).write_text(json.dumps(record,indent=2)+'\n');commands.append(record)
 assert result.returncode==0,name
 return result.stdout
def names(data):return {p.decode() for p in data.split(b'\0') if p}
starting_tree=call('starting-tree',['git','write-tree']).decode().strip()
prior=names(call('existing-audit-delta',['git','diff','--cached','-z','--name-only',reviewed_tree,'--']))
assert len(prior)==21,('unexpected prior staged audit delta',len(prior))
frozen_path=root/'capabilities/evidence/T75-delivery/final-validation-r4/source-and-contract-inputs.json'; frozen=json.loads(frozen_path.read_bytes())
spec=importlib.util.spec_from_file_location('foundation_capture',root/'scripts/t03-foundation.py'); foundation=importlib.util.module_from_spec(spec);spec.loader.exec_module(foundation)
contract=yaml.safe_load((root/'capabilities/foundation-release.yaml').read_bytes());assert foundation.capture_build_inputs(root,contract)==frozen
allowed_docs={'capabilities/evidence/T75-text-semantic.md','capabilities/evidence/T75-delivery/final-execution-receipt.md','capabilities/evidence/T75-delivery/final-delivery-review-r4/README.md','capabilities/evidence/T75-delivery/final-certification-r4/README.md'}
modified=names(call('unstaged-paths',['git','diff','-z','--name-only']))
added=names(call('untracked-paths',['git','ls-files','-z','--others','--exclude-standard']))
paths=sorted(prior|modified|added)
for p in paths:
 assert p in allowed_docs or (p.startswith('capabilities/evidence/T75-delivery/final-delivery-review-r4/') and (p.endswith('.tar.xz') or Path(p).suffix in ('.json','.md') or re.search(r'\.tar\.xz\.part[0-9]{3}$',p))),p
 if (root/p).exists():
  assert (root/p).is_file() and not (root/p).is_symlink();assert (root/p).stat().st_size<100*1024*1024,('oversized',p)
 else:assert p=='capabilities/evidence/T75-delivery/final-delivery-review-r4/standards-final-index.tar.xz'
# All other index entries retain the previously independently verified tree identity.
call('stage-audit-delta',['git','-c','gc.auto=0','add','-A','--',*paths])
actual=names(call('actual-audit-delta',['git','diff','--cached','-z','--name-only',reviewed_tree,'--']))
assert actual=={p for p in paths if (root/p).exists()}
call('diff-check',['git','diff','--check']);call('cached-diff-check',['git','diff','--cached','--check'])
call('no-unstaged-diff',['git','diff','--exit-code','--quiet'])
assert not call('no-untracked',['git','ls-files','-z','--others','--exclude-standard'])
assert not call('no-ignored-evidence',['git','ls-files','-z','--others','--ignored','--exclude-standard','--','capabilities/evidence/T75-*'])
entries=call('delta-index-entries',['git','ls-files','-s','-z','--',*sorted(actual)])
indexed={}
for entry in entries.split(b'\0'):
 if not entry:continue
 meta,path=entry.split(b'\t',1);mode,oid,stage=meta.decode().split();assert stage=='0';indexed[path.decode()]=(mode,oid)
assert set(indexed)==actual
identities=[]
for i,name in enumerate(sorted(actual)):
 mode,oid=indexed[name];args=['git','cat-file','blob',oid];start=datetime.now(timezone.utc).isoformat()
 p=subprocess.Popen(args,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE);h=hashlib.sha256();size=0
 with (root/name).open('rb') as source:
  while True:
   chunk=p.stdout.read(1024*1024);assert chunk==source.read(len(chunk) if chunk else 1),(name,'Git bytes differ')
   if not chunk:break
   h.update(chunk);size+=len(chunk)
 stderr=p.stderr.read();rc=p.wait();record={'command':args,'path':name,'started-utc':start,'completed-utc':datetime.now(timezone.utc).isoformat(),'returncode':rc,'bytes':size,'sha256':h.hexdigest(),'stdout-retention':'Stream compared byte-for-byte with the retained staged worktree file; blob payload deliberately not duplicated.','stderr':stderr.decode()}
 (original/('stream-blob-'+str(i)+'-result.json')).write_text(json.dumps(record,indent=2)+'\n');assert rc==0
 identities.append({'path':name,'mode':mode,'oid':oid,'bytes':size,'sha256':h.hexdigest(),'worktree-byte-equality':True})
assert foundation.capture_build_inputs(root,contract)==frozen
final_tree=call('final-tree',['git','write-tree']).decode().strip()
receipt={'recorded-utc':datetime.now(timezone.utc).isoformat(),'scope':'Bounded audit/status delta from independently reviewed tree; source/contract/artifact/certification identities unchanged. All other Git entries retain that tree identity. Independent closure and authorized delivery follow.','reviewed-tree':reviewed_tree,'starting-tree':starting_tree,'final-tree':final_tree,'source-and-contract-unchanged':True,'frozen-input-sha256':hashlib.sha256(frozen_path.read_bytes()).hexdigest(),'delta':identities,'diff-check-exit':0,'cached-diff-check-exit':0,'no-unstaged-or-untracked-ticket-files':True,'no-oversized-changed-blob':True,'commands':commands}
(original/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
with Path('/tmp/t75-final-delivery-index-r4-r2-original-path.txt').open('x') as out:out.write(str(original)+'\n')
print('actual0 frozen tree',final_tree,'delta',len(identities),'original',original,flush=True)
