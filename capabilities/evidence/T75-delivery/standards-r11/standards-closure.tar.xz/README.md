# Incremental Standards closure and namespace declaration review

Frozen observer: 8a523b6c1e7545e09e826b8fae4dedf4624d6477a8d8c3961a5f8f079b900a8b, copied byte-for-byte from standards-r11/observer-hierarchy-parent-tree-namespaces.py. All 53 public CLI processes ran only observer.py in this directory, never the live observer. No repository implementation edit, delegation or Maven/build action occurred. The fixed overall baseline remains 5b1603c435f11c40368f75b7b9a2777c9c5e9761; this is an incremental review only.

## Prior hard findings closed

The original 25 CLI observations from /tmp/t75-structure-standards-review-5oc4nufc were replayed with byte-identical PDFs. All eight stream-at-dictionary false-PASS observations now FAIL through Graph.dictionary. The direct-parent value-copy cases now FAIL, as do the ordinary malformed parent/duplicate/null-array controls. Existing literal/indirect null omission/unused-slot outcomes are unchanged, and qpdf continues to make the unsupported indirect-object alias INDETERMINATE.

A new legacy PDF1.7 variant of the direct parent value-copy case FAILs specifically at the mandatory indirect P check, proving the original equality bug is fixed independently of PDF2's indirect-root requirement. Legacy empty direct root PASS and the same PDF2 direct root FAIL. Empty element K FAIL and empty root K PASS. Without any ParentTree, integer NextKey PASS and Boolean NextKey FAIL.

## Namespace declaration increment

No new hard standard violation or independently actionable smell was established in the limited declaration checker. Original declaration PASS; namespace stream/type/missing-name/null-name/numeric-name and invalid destination kind/direct identity cases FAIL. Unlisted or direct element namespace identities FAIL. Same-standard-namespace remapping FAILs for both literal and UTF16 text-string spellings of the standard URI.

A two-namespace custom-role cycle terminates and PASSes the declaration-only scope. This is not asserted as complete Tagged PDF role resolution, which the contract explicitly excludes. An array containing the same indirect namespace 1001 times remains one observed dictionary identity and PASSes. Direct dictionary counts 1000 PASS/1001 INDETERMINATE. Root RoleMap without Namespaces 10000 entries PASS/10001 INDETERMINATE. Combined root RoleMap (5000) and RoleMapNS (5000 or 5001) correctly produce PASS/INDETERMINATE at the same total bound.

The null Namespaces array-member negative also retains a listed element NS and therefore fails first at the missing listed identity check; its report is not misrepresented as independently testing the later null-dictionary branch. Other namespace dictionary-kind and required-name controls isolate those branches.

## Evidence and provenance

probe.py and adjacent-probe.py repeat the original independent eight-object authoring. namespace-probe.py adds original PDF1.7/empty/NextKey and namespace declarations, mapping graphs and exact-count cases. It imports no product or generator implementation. Each original fixture's stream Length and xref are authored explicitly. The fixtures isolate only currently declared predicates; actual content ownership/backlink equality and complete Tagged PDF role resolution are not inferred.

results.json, adjacent-results.json, namespace-results.json and per-case result JSON retain exact command arrays, inputs, return codes, timing and output identities. Each output directory preserves actual qpdf JSON, stdout/stderr and public properties. Every process has an independent 40-second timeout and completes normally. identity.json, namespace-identity.json and identity-final.json bind the snapshot, copied contract, Python executable, qpdf executable/wrapper/pin and all 11 runtime library paths; all checked identities remain unchanged. validation.txt records literal outcome and identity assertions.

This closes only the previous structural object-kind/backlink findings and reviews the new bounded namespace declaration scope. Final clean-context whole-task review is still required separately.
