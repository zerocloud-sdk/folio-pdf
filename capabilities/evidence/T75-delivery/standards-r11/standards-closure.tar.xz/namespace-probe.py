from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time
ROOT=Path('/home/ubuntu/IdeaProjects/open-pdf');HERE=Path(__file__).resolve().parent
SHA='8a523b6c1e7545e09e826b8fae4dedf4624d6477a8d8c3961a5f8f079b900a8b'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert sha(HERE/'observer.py')==SHA
ENV=dict(os.environ);ENV.pop('QPDF_CACHE_DIRECTORY',None)
files=[HERE/'observer.py',HERE/'contract.md',Path(sys.executable).resolve(),ROOT/'.build-cache/qpdf/12.4.0/bin/qpdf']+[ROOT/'scripts'/x for x in ['qpdf-pin.properties','container-bin/qpdf','t13-qpdf-runtime.sha256']]
for line in (ROOT/'scripts/t13-qpdf-runtime.sha256').read_text().splitlines():files.append(ROOT/'.build-cache/qpdf/12.4.0'/line.split('  ',1)[1])
identities={str(p):sha(p) for p in files};rows=[]
def stream(dictionary=b'<<>>',data=b''):
 assert dictionary.endswith(b'>>')
 return dictionary[:-2]+b'/Length '+str(len(data)).encode()+b'>>\nstream\n'+data+b'\nendstream'
def objects():
 return [b'<</Type/Catalog/Pages 2 0 R/StructTreeRoot 4 0 R/MarkInfo<</Marked true>>>>',b'<</Type/Pages/Kids[3 0 R]/Count 1>>',b'<</Type/Page/Parent 2 0 R/MediaBox[0 0 100 100]/Resources<<>>/Contents 7 0 R/StructParents 0>>',b'<</Type/StructTreeRoot/K 5 0 R/ParentTree 6 0 R/ParentTreeNextKey 1>>',b'<</Type/StructElem/S/P/P 4 0 R/Pg 3 0 R/K 0/Lang(en)>>',b'<</Nums[0[5 0 R]]>>',stream(data=b'/P<</MCID 0>>BDC EMC'),b'null']
def pdf(parts):
 data=bytearray(b'%PDF-2.0\n');offsets=[0]
 for i,body in enumerate(parts,1):offsets.append(len(data));data.extend(str(i).encode()+b' 0 obj\n'+body+b'\nendobj\n')
 xref=len(data);data.extend(b'xref\n0 '+str(len(offsets)).encode()+b'\n0000000000 65535 f \n')
 for off in offsets[1:]:data.extend(('%010d 00000 n \n'%off).encode())
 data.extend(b'trailer\n<</Size '+str(len(offsets)).encode()+b'/Root 1 0 R>>\nstartxref\n'+str(xref).encode()+b'\n%%EOF\n');return data

def run(label,parts,scope):
 path=HERE/(label+'.pdf');data=pdf(parts);path.write_bytes(data);out=HERE/(label+'-'+scope+'-output');args=[sys.executable,str(HERE/'observer.py'),str(ROOT),str(path),scope,str(out)];started=time.monotonic()
 with (HERE/(out.name+'.stdout')).open('wb') as stdout,(HERE/(out.name+'.stderr')).open('wb') as stderr:
  p=subprocess.run(args,cwd=HERE,env=ENV,stdout=stdout,stderr=stderr,timeout=40)
 prop=out/'result.properties';result=dict(line.split('=',1) for line in prop.read_text().splitlines() if line and not line.startswith(('#','!'))) if prop.exists() else None
 row={'label':label,'scope':scope,'command':args,'cwd':str(HERE),'exit':p.returncode,'elapsed':time.monotonic()-started,'input-sha256':sha(path),'result':result,'files':{str(f.relative_to(out)):sha(f) for f in out.iterdir() if f.is_file()}}
 rows.append(row);(HERE/(label+'-'+scope+'-result.json')).write_text(json.dumps(row,indent=2)+'\n');print(label,scope,p.returncode,result.get('standards') if result else None,result.get('finding') if result else None,flush=True)


plain_pdf=pdf
pdf=lambda parts:plain_pdf(parts).replace(b'%PDF-2.0',b'%PDF-1.7',1)
parts=objects();direct=parts[3];parts[0]=parts[0].replace(b'/StructTreeRoot 4 0 R',b'/StructTreeRoot '+direct);parts[4]=parts[4].replace(b'/P 4 0 R',b'/P '+direct)
run('legacy-direct-parent-value-copy',parts,'structure-hierarchy')
parts=objects();parts[0]=parts[0].replace(b'/StructTreeRoot 4 0 R',b'/StructTreeRoot<</Type/StructTreeRoot>>');run('legacy-empty-direct-root',parts,'structure-hierarchy')
pdf=plain_pdf
run('pdf2-empty-direct-root',parts,'structure-hierarchy')
for label,num in [('element-empty-k',5),('root-empty-k',4)]:
 parts=objects();before=b'/K 0' if num==5 else b'/K 5 0 R';parts[num-1]=parts[num-1].replace(before,b'/K[]');run(label,parts,'structure-hierarchy')
for label,key in [('absent-tree-integer-next',b'3'),('absent-tree-boolean-next',b'false')]:
 parts=objects();parts[3]=b'<</Type/StructTreeRoot/ParentTreeNextKey '+key+b'>>';run(label,parts,'structure-parent-tree')

def ns_parts(namespace=b'<</Type/Namespace/NS(urn:independent:test)/RoleMapNS<</Custom/P>>>>'):
 parts=objects();parts[3]=parts[3][:-2]+b'/Namespaces[9 0 R]>>';parts[4]=parts[4][:-2]+b'/NS 9 0 R>>';parts.append(namespace);return parts
scope='structure-namespaces'
run('namespace-original',ns_parts(),scope)
for label,ns in [('namespace-stream',stream(b'<</NS(urn:independent:test)>>')),('namespace-type',b'<</Type/Other/NS(urn:independent:test)>>'),('namespace-missing-name',b'<</Type/Namespace>>'),('namespace-null-name',b'<</NS null>>'),('namespace-numeric-name',b'<</NS 1>>'),('namespace-numeric-destination',b'<</NS(urn:independent:test)/RoleMapNS<</A 1>>>>'),('namespace-direct-destination',b'<</NS(urn:independent:test)/RoleMapNS<</A[/P<</NS(urn:x)>>]>>>>'),('namespace-standard-self',b'<</NS(http://iso.org/pdf2/ssn)/RoleMapNS<</P[/P 9 0 R]>>>>'),('namespace-standard-utf16-self',b'<</NS<FEFF'+ 'http://iso.org/pdf2/ssn'.encode('utf-16-be').hex().encode()+b'>/RoleMapNS<</P[/P 9 0 R]>>>>')]:
 run(label,ns_parts(ns),scope)
parts=ns_parts(b'<</NS(urn:independent:test)/RoleMapNS<</P[/P 10 0 R]>>>>');parts.append(b'<</NS(urn:independent:other)/RoleMapNS<</P[/P 9 0 R]>>>>');run('namespace-cycle-declarations',parts,scope)
parts=ns_parts();parts[3]=parts[3].replace(b'/Namespaces[9 0 R]',b'/Namespaces[]');run('namespace-unlisted-element',parts,scope)
parts=ns_parts();parts[4]=parts[4].replace(b'/NS 9 0 R',b'/NS<</NS(urn:x)>>');run('namespace-direct-element',parts,scope)
parts=ns_parts();parts[3]=parts[3].replace(b'/Namespaces[9 0 R]',b'/Namespaces[null]');run('namespace-null-array-member',parts,scope)
parts=ns_parts();parts[3]=parts[3].replace(b'/Namespaces[9 0 R]',b'/Namespaces['+b'9 0 R '*1001+b']');run('namespace-shared-identity',parts,scope)
for n in [1000,1001]:
 parts=objects();parts[3]=b'<</Type/StructTreeRoot/Namespaces['+b'<</NS(urn:independent:bound)>>'*n+b']>>';run('namespace-count-'+str(n),parts,scope)
for n in [10000,10001]:
 parts=objects();mapping=b''.join(('/Role%d/P'%i).encode() for i in range(n));parts[3]=b'<</Type/StructTreeRoot/RoleMap<<'+mapping+b'>>>>';run('root-mapping-count-'+str(n),parts,scope)
for n in [5000,5001]:
 mapping=b''.join(('/Role%d/P'%i).encode() for i in range(n));parts=ns_parts(b'<</NS(urn:independent:test)/RoleMapNS<<'+mapping+b'>>>>');mapping=b''.join(('/Root%d/P'%i).encode() for i in range(5000));parts[3]=parts[3][:-2]+b'/RoleMap<<'+mapping+b'>>>>';run('combined-mapping-count-'+str(5000+n),parts,scope)
after={str(p):sha(p) for p in files};(HERE/'namespace-identity.json').write_text(json.dumps({'before':identities,'after':after,'unchanged':identities==after,'probe-sha256':sha(Path(__file__))},indent=2)+'\n');(HERE/'namespace-results.json').write_text(json.dumps(rows,indent=2)+'\n');print(HERE,'identities unchanged',identities==after,flush=True)
