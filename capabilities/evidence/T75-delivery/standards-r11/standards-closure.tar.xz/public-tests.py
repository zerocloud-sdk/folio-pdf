"""Qualify original logical-structure relationships through the public tool CLI."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[2]
SCRIPT = ROOT / 'scripts/t13-program-standards.py'
SOURCE = ROOT / 'capabilities/profiles/T13-text/fixtures/marked-structure.pdf'


class T13StructureStandardsTest(unittest.TestCase):
    def test_namespace_qualification_bounds_include_root_role_maps_without_namespaces(self):
        objects = [b'<</Type/Catalog/Pages 2 0 R/StructTreeRoot 4 0 R>>',
                   b'<</Type/Pages/Count 1/Kids[3 0 R]>>',
                   b'<</Type/Page/Parent 2 0 R/MediaBox[0 0 100 100]/Resources<<>>>>', b'']
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            for count, expected in ((10000, 'pass'), (10001, 'indeterminate')):
                with self.subTest(role_map_entries=count):
                    mapping = b''.join(('/Role%d/P' % index).encode('ascii') for index in range(count))
                    objects[3] = b'<</Type/StructTreeRoot/RoleMap<<' + mapping + b'>>>>'
                    self.observe(directory, 'entries-' + str(count), self.pdf(objects), expected, scope='structure-namespaces')
            for count, expected in ((1000, 'pass'), (1001, 'indeterminate')):
                with self.subTest(namespace_count=count):
                    namespaces = b'<</NS(urn:folio:bound)>>' * count
                    objects[3] = b'<</Type/StructTreeRoot/Namespaces[' + namespaces + b']>>'
                    self.observe(directory, 'namespaces-' + str(count), self.pdf(objects), expected, scope='structure-namespaces')

    def test_structure_root_and_parent_edges_preserve_required_indirect_identity(self):
        objects = [b'<</Type/Catalog/Pages 2 0 R/StructTreeRoot 4 0 R>>',
                   b'<</Type/Pages/Count 1/Kids[3 0 R]>>',
                   b'<</Type/Page/Parent 2 0 R/MediaBox[0 0 100 100]/Resources<<>>>>',
                   b'<</Type/StructTreeRoot/K 5 0 R>>', b'<</S/P/P 4 0 R>>']
        empty = b'<</Type/StructTreeRoot>>'
        root = b'<</Type/StructTreeRoot/K 5 0 R>>'
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            for name, header, catalog, parent, expected in (
                    ('indirect-identities', b'%PDF-2.0', objects[0], b'4 0 R', 'pass'),
                    ('pdf2-direct-root', b'%PDF-2.0', b'<</Type/Catalog/Pages 2 0 R/StructTreeRoot' + empty + b'>>', b'4 0 R', 'fail'),
                    ('legacy-direct-empty-root', b'%PDF-1.7', b'<</Type/Catalog/Pages 2 0 R/StructTreeRoot' + empty + b'>>', b'4 0 R', 'pass'),
                    ('catalog-overrides-header', b'%PDF-1.7', b'<</Type/Catalog/Pages 2 0 R/Version/2.0/StructTreeRoot' + empty + b'>>', b'4 0 R', 'fail'),
                    ('legacy-parent-value-copy', b'%PDF-1.7', b'<</Type/Catalog/Pages 2 0 R/StructTreeRoot' + root + b'>>', root, 'fail'),
                    ('parent-direct-value', b'%PDF-2.0', objects[0], root, 'fail'),
                    ('parent-wrong-identity', b'%PDF-2.0', objects[0], b'3 0 R', 'fail')):
                with self.subTest(identity=name):
                    changed = list(objects); changed[0] = catalog; changed[4] = b'<</S/P/P ' + parent + b'>>'
                    data = self.pdf(changed).replace(b'%PDF-2.0', header, 1)
                    self.observe(directory, name, data, expected, 'structure-hierarchy' if expected == 'fail' else None)

    def test_next_parent_tree_key_has_integer_type_even_without_content_or_a_parent_tree(self):
        objects = [b'<</Type/Catalog/Pages 2 0 R/StructTreeRoot 4 0 R>>',
                   b'<</Type/Pages/Count 1/Kids[3 0 R]>>',
                   b'<</Type/Page/Parent 2 0 R/MediaBox[0 0 100 100]/Resources<<>>>>',
                   b'<</Type/StructTreeRoot>>']
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            for name, value, expected in (('name', b'/bad', 'fail'), ('real', b'0.5', 'fail'),
                                            ('boolean', b'false', 'fail'), ('integer', b'3', 'pass'),
                                            ('negative-integer', b'-1', 'pass'), ('null', b'null', 'pass')):
                with self.subTest(next_key=name):
                    objects[3] = b'<</Type/StructTreeRoot/ParentTreeNextKey ' + value + b'>>'
                    self.observe(directory, name, self.pdf(objects), expected,
                                 'structure-parent-tree' if expected == 'fail' else None, scope='structure-parent-tree')

    def test_element_child_arrays_are_nonempty_while_root_arrays_can_be_empty(self):
        objects = [b'<</Type/Catalog/Pages 2 0 R/StructTreeRoot 4 0 R>>',
                   b'<</Type/Pages/Count 1/Kids[3 0 R]>>',
                   b'<</Type/Page/Parent 2 0 R/MediaBox[0 0 100 100]/Resources<<>>>>',
                   b'<</Type/StructTreeRoot/K 5 0 R>>', b'<</S/P/P 4 0 R>>', b'[]']
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            for name, number, body, expected in (
                    ('element-absent-k', 5, b'<</S/P/P 4 0 R>>', 'pass'),
                    ('element-null-k', 5, b'<</S/P/P 4 0 R/K null>>', 'pass'),
                    ('element-empty-k', 5, b'<</S/P/P 4 0 R/K[]>>', 'fail'),
                    ('element-indirect-empty-k', 5, b'<</S/P/P 4 0 R/K 6 0 R>>', 'fail'),
                    ('root-empty-k', 4, b'<</Type/StructTreeRoot/K[]>>', 'pass'),
                    ('root-indirect-empty-k', 4, b'<</Type/StructTreeRoot/K 6 0 R>>', 'pass')):
                with self.subTest(children=name):
                    changed = list(objects); changed[number - 1] = body
                    self.observe(directory, name, self.pdf(changed), expected,
                                 'structure-hierarchy' if expected == 'fail' else None)

    def test_structure_dictionary_positions_reject_stream_objects(self):
        objects = [b'<</Type/Catalog/Pages 2 0 R/StructTreeRoot 4 0 R>>',
                   b'<</Type/Pages/Count 1/Kids[3 0 R]>>',
                   b'<</Type/Page/Parent 2 0 R/MediaBox[0 0 100 100]/Resources<<>>>>',
                   b'<</Type/StructTreeRoot/K 5 0 R/ParentTree 7 0 R/Namespaces[9 0 R]/RoleMap 10 0 R>>',
                   b'<</Type/StructElem/S/P/P 4 0 R/K 6 0 R/NS 9 0 R>>',
                   b'<</Type/MCR/Pg 3 0 R/MCID 0>>',
                   b'<</Kids[8 0 R]>>', b'<</Nums[0[5 0 R]]/Limits[0 0]>>',
                   b'<</Type/Namespace/NS(urn:folio:test)/RoleMapNS 11 0 R>>',
                   b'<</Custom/P>>', b'<</Custom/P>>']
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            for scope in ('structure-hierarchy', 'structure-parent-tree', 'structure-namespaces'):
                with self.subTest(ordinary_dictionary=scope):
                    self.observe(directory, 'ordinary-' + scope, self.pdf(objects), 'pass', scope=scope)
            for name, number, scope, rule in (
                    ('root', 4, 'structure-hierarchy', 'structure-hierarchy'),
                    ('element', 5, 'structure-hierarchy', 'structure-hierarchy'),
                    ('mcr', 6, 'structure-hierarchy', 'structure-hierarchy'),
                    ('objr', 6, 'structure-hierarchy', 'structure-hierarchy'),
                    ('parent-tree-root', 7, 'structure-parent-tree', 'structure-parent-tree'),
                    ('parent-tree-leaf', 8, 'structure-parent-tree', 'structure-parent-tree'),
                    ('namespace', 9, 'structure-namespaces', 'structure-namespace'),
                    ('role-map', 10, 'structure-namespaces', 'structure-namespace'),
                    ('namespace-role-map', 11, 'structure-namespaces', 'structure-namespace')):
                with self.subTest(stream=name):
                    changed = list(objects)
                    if name == 'objr':
                        changed[number - 1] = b'<</Type/OBJR/Pg 3 0 R/Obj 3 0 R>>'
                    changed[number - 1] = changed[number - 1][:-2] + b'/Length 0>>\nstream\n\nendstream'
                    self.observe(directory, name, self.pdf(changed), 'fail', rule, scope=scope)

    def pdf(self, objects):
        data = bytearray(b'%PDF-2.0\n'); offsets = []
        for number, body in enumerate(objects, 1):
            offsets.append(len(data))
            data.extend(('%d 0 obj\n' % number).encode('ascii') + body + b'\nendobj\n')
        xref = len(data)
        data.extend(('xref\n0 %d\n0000000000 65535 f \n' % (len(objects) + 1)).encode('ascii'))
        for offset in offsets:
            data.extend(('%010d 00000 n \n' % offset).encode('ascii'))
        data.extend(('trailer\n<</Root 1 0 R/Size %d>>\nstartxref\n%d\n%%%%EOF\n' %
                     (len(objects) + 1, xref)).encode('ascii'))
        return bytes(data)

    def test_namespaces_bind_element_identifiers_and_typed_role_map_destinations(self):
        original = SOURCE.read_bytes()
        namespaces = b'/Namespaces [14 0 R 15 0 R 16 0 R]'
        mapping = b'/RoleMapNS << /Custom [/Intermediate 16 0 R] >>'
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            for path in sorted(SOURCE.parent.glob('*.pdf')):
                with self.subTest(source=path.name):
                    self.observe(directory, 'source-' + path.stem, path.read_bytes(), 'pass', scope='structure-namespaces')
            for name, number, before, after, expected in (
                    ('missing-namespace-array', 8, namespaces, b'', 'fail'),
                    ('invalid-namespace-array', 8, namespaces, b'/Namespaces /Other', 'fail'),
                    ('unlisted-element-namespace', 8, namespaces, b'/Namespaces [15 0 R 16 0 R]', 'fail'),
                    ('numeric-element-namespace', 9, b'/NS 14 0 R', b'/NS 1234', 'fail'),
                    ('non-namespace-dictionary', 9, b'/NS 14 0 R', b'/NS 12 0 R', 'fail'),
                    ('namespace-type', 14, b'/Type /Namespace', b'/Type /Other', 'fail'),
                    ('namespace-optional-type', 14, b'/Type /Namespace', b'', 'pass'),
                    ('namespace-name-type', 14, b'/NS (urn:folio:t13:roles)', b'/NS 1234', 'fail'),
                    ('namespace-map-type', 14, mapping, b'/RoleMapNS 1234', 'fail'),
                    ('namespace-destination-type', 14, mapping, b'/RoleMapNS<</Custom 1234>>', 'fail'),
                    ('namespace-destination-arity', 14, mapping, b'/RoleMapNS<</Custom[/P]>>', 'fail'),
                    ('namespace-destination-role', 14, mapping, b'/RoleMapNS<</Custom[12 15 0 R]>>', 'fail'),
                    ('namespace-destination-identity', 14, mapping, b'/RoleMapNS<</Custom[/P 12 0 R]>>', 'fail'),
                    ('namespace-default-destination', 14, mapping, b'/RoleMapNS<</Custom/P>>', 'pass'),
                    ('root-role-map-type', 8, b'/ParentTreeNextKey 3', b'/RoleMap 1234', 'fail'),
                    ('root-role-destination', 8, b'/ParentTreeNextKey 3', b'/RoleMap<</X 123>>', 'fail'),
                    ('root-role-map-name', 8, b'/ParentTreeNextKey 3', b'/RoleMap<</X/P>>', 'pass')):
                with self.subTest(namespace=name):
                    self.observe(directory, name, self.change(original, number, before, after), expected,
                                 'structure-namespace' if expected == 'fail' else None, scope='structure-namespaces')
            before = b'/Type /Namespace /NS (urn:folio:t13:roles) ' + mapping
            after = b'/NS(http://iso.org/pdf2/ssn)/RoleMapNS<</P[/P 14 0 R]>>'
            self.observe(directory, 'direct-standard-namespace-remap', self.change(original, 14, before, after),
                         'fail', 'structure-namespace', scope='structure-namespaces')

    def test_parent_tree_child_ranges_match_ordered_disjoint_leaf_keys(self):
        original = SOURCE.read_bytes()
        nums = b'/Nums [0 [10 0 R] 1 [10 0 R] 2 10 0 R]'
        data = self.change(original, 13, nums, b'/Kids [18 0 R 19 0 R]')
        position = int(data.rsplit(b'startxref\n', 1)[1].splitlines()[0])
        leaf_a = b'18 0 obj\n<</Nums[0[10 0 R]1[10 0 R]]/Limits[0 1]>>\nendobj\n'
        leaf_b = b'19 0 obj\n<</Nums[2 10 0 R]/Limits[2 2]>>\nendobj\n'
        tail = data[position:]; self.assertTrue(tail.startswith(b'xref\n0 18\n'))
        tail = tail.replace(b'xref\n0 18\n', b'xref\n0 20\n', 1)
        extra = ('%010d 00000 n \n%010d 00000 n \n' % (position, position + len(leaf_a))).encode('ascii')
        tail = tail.replace(b'trailer\n', extra + b'trailer\n', 1).replace(b'/Size 18', b'/Size 20')
        tail = tail.replace(('startxref\n%d\n' % position).encode('ascii'),
                            ('startxref\n%d\n' % (position + len(leaf_a) + len(leaf_b))).encode('ascii'))
        tree = data[:position] + leaf_a + leaf_b + tail
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            with self.subTest(number_tree='multi-level'):
                self.observe(directory, 'multi-level', tree, 'pass', scope='structure-parent-tree')
            for name, number, before, after in (
                    ('missing-limits', 18, b'/Limits[0 1]', b''),
                    ('incorrect-limits', 18, b'/Limits[0 1]', b'/Limits[0 2]'),
                    ('overlapping-ranges', 19, b'/Nums[2 10 0 R]/Limits[2 2]', b'/Nums[1 10 0 R]/Limits[1 1]'),
                    ('unordered-children', 13, b'/Kids [18 0 R 19 0 R]', b'/Kids [19 0 R 18 0 R]'),
                    ('cyclic-tree', 13, b'/Kids [18 0 R 19 0 R]', b'/Kids [18 0 R 13 0 R]')):
                with self.subTest(number_tree=name):
                    self.observe(directory, name, self.change(tree, number, before, after),
                                 'fail', 'structure-parent-tree', scope='structure-parent-tree')
            for name, replacement in (('root-limits', b'/Kids[18 0 R 19 0 R]/Limits[0 2]'),
                                       ('mixed-kids-and-nums', b'/Kids[18 0 R 19 0 R]/Nums[]'),
                                       ('direct-tree-child', b'/Kids[<</Nums[]/Limits[0 0]>>]')):
                with self.subTest(number_tree=name):
                    self.observe(directory, name, self.change(tree, 13, b'/Kids [18 0 R 19 0 R]'.ljust(len(nums)), replacement),
                                 'fail', 'structure-parent-tree', scope='structure-parent-tree')

    def test_parent_tree_has_ordered_integer_keys_structural_values_and_a_fresh_next_key(self):
        original = SOURCE.read_bytes()
        nums = b'/Nums [0 [10 0 R] 1 [10 0 R] 2 10 0 R]'
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            for path in sorted(SOURCE.parent.glob('*.pdf')):
                with self.subTest(source=path.name):
                    self.observe(directory, 'source-' + path.stem, path.read_bytes(), 'pass', scope='structure-parent-tree')
            for name, number, before, after, expected in (
                    ('missing-parent-tree', 8, b'/ParentTree 13 0 R', b'', 'fail'),
                    ('numeric-parent-tree', 8, b'/ParentTree 13 0 R', b'/ParentTree 1234', 'fail'),
                    ('missing-number-tree-entries', 13, nums, b'', 'fail'),
                    ('odd-key-values', 13, nums, b'/Nums [0]', 'fail'),
                    ('unordered-keys', 13, nums, b'/Nums [1 [10 0 R] 0 [10 0 R] 2 10 0 R]', 'fail'),
                    ('duplicate-keys', 13, nums, b'/Nums [0 [10 0 R] 0 [10 0 R] 2 10 0 R]', 'fail'),
                    ('boolean-key', 13, nums, b'/Nums [false 10 0 R]', 'fail'),
                    ('real-key', 13, nums, b'/Nums [0.0 10 0 R]', 'fail'),
                    ('numeric-parent-value', 13, nums, b'/Nums [0 42]', 'fail'),
                    ('non-element-parent-value', 13, nums, b'/Nums [0 [12 0 R]]', 'fail'),
                    ('used-next-key', 8, b'/ParentTreeNextKey 3', b'/ParentTreeNextKey 2', 'fail'),
                    ('name-next-key', 8, b'/ParentTreeNextKey 3', b'/ParentTreeNextKey/X', 'fail'),
                    ('absent-next-key', 8, b'/ParentTreeNextKey 3', b'', 'pass'),
                    ('unused-null-slot', 13, nums, b'/Nums[0[10 0 R null]1[10 0 R]2 10 0 R]', 'pass')):
                with self.subTest(parent_tree=name):
                    self.observe(directory, name, self.change(original, number, before, after), expected,
                                 'structure-parent-tree' if expected == 'fail' else None, scope='structure-parent-tree')

    def test_hierarchy_qualification_admits_exact_depth_and_item_bounds(self):
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            for name, count, nested, expected in (('depth-128', 128, True, 'pass'),
                                                   ('depth-129', 129, True, 'indeterminate'),
                                                   ('items-10000', 10000, False, 'pass'),
                                                   ('items-10001', 10001, False, 'indeterminate')):
                with self.subTest(boundary=name):
                    children = b'5 0 R' if nested else b'[' + b' '.join(
                        ('%d 0 R' % (5 + index)).encode('ascii') for index in range(count)) + b']'
                    objects = [b'<</Type/Catalog/Pages 2 0 R/StructTreeRoot 4 0 R>>',
                               b'<</Type/Pages/Count 1/Kids[3 0 R]>>',
                               b'<</Type/Page/Parent 2 0 R/MediaBox[0 0 100 100]/Resources<<>>>>',
                               b'<</Type/StructTreeRoot/K ' + children + b'>>']
                    for index in range(count):
                        parent = 4 + index if nested else 4
                        child = ('/K %d 0 R' % (6 + index)).encode('ascii') if nested and index + 1 < count else b''
                        objects.append(('<</Type/StructElem/S/P/P %d 0 R' % parent).encode('ascii') + child + b'>>')
                    data = bytearray(b'%PDF-2.0\n'); offsets = []
                    for number, body in enumerate(objects, 1):
                        offsets.append(len(data)); data.extend(('%d 0 obj\n' % number).encode('ascii') + body + b'\nendobj\n')
                    xref = len(data); data.extend(('xref\n0 %d\n0000000000 65535 f \n' % (len(objects) + 1)).encode('ascii'))
                    for offset in offsets:
                        data.extend(('%010d 00000 n \n' % offset).encode('ascii'))
                    data.extend(('trailer\n<</Root 1 0 R/Size %d>>\nstartxref\n%d\n%%%%EOF\n' % (len(objects) + 1, xref)).encode('ascii'))
                    self.observe(directory, name, data, expected)

    def test_structure_language_and_replacement_metadata_are_text_strings(self):
        original = SOURCE.read_bytes()
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            for name, number, before, after, expected in (
                    ('catalog-numeric-language', 1, b'/Lang (en)', b'/Lang 123', 'fail'),
                    ('element-name-language', 9, b'/Lang (fr)', b'/Lang /FR', 'fail'),
                    ('element-boolean-language', 11, b'/Lang (ja)', b'/Lang true', 'fail'),
                    ('element-name-alternate', 9, b'/Alt (RootAlt)', b'/Alt /RootAlt', 'fail'),
                    ('element-boolean-replacement', 9, b'/ActualText (RootActual)', b'/ActualText false', 'fail'),
                    ('element-empty-language', 9, b'/Lang (fr)', b'/Lang ()', 'pass'),
                    ('element-hex-language', 9, b'/Lang (fr)', b'/Lang <66>', 'pass'),
                    ('element-null-language', 9, b'/Lang (fr)', b'/Lang null', 'pass'),
                    ('element-null-replacement', 9, b'/ActualText (RootActual)', b'/ActualText null', 'pass')):
                with self.subTest(metadata=name):
                    self.observe(directory, name, self.change(original, number, before, after), expected,
                                 'structure-text' if expected == 'fail' else None)

    def observe(self, directory, name, data, expected, rule=None, scope='structure-hierarchy'):
        pdf = directory / (name + '.pdf'); pdf.write_bytes(data)
        output = directory / name
        run = subprocess.run([sys.executable, str(SCRIPT), str(ROOT), str(pdf), scope, str(output)],
                             capture_output=True, text=True, timeout=40)
        self.assertEqual(0, run.returncode, run.stderr)
        result = dict(line.split('=', 1) for line in (output / 'result.properties').read_text().splitlines())
        self.assertEqual(expected, result['standards'], name + ': ' + result['finding'])
        self.assertEqual(hashlib.sha256(data).hexdigest(), result['input-sha256'])
        self.assertEqual(hashlib.sha256(SCRIPT.read_bytes()).hexdigest(), result['observer-sha256'])
        if rule is not None:
            self.assertEqual(rule, result['rule'])
        return result

    def change(self, source, number, before, after):
        marker = ('\n%d 0 obj\n' % number).encode('ascii')
        self.assertEqual(1, source.count(marker))
        self.assertLessEqual(len(after), len(before))
        start = source.index(marker) + len(marker); end = source.index(b'\nendobj\n', start)
        body = source[start:end]; self.assertEqual(1, body.count(before))
        return source[:start] + body.replace(before, after.ljust(len(before))) + source[end:]

    def test_structure_hierarchy_has_typed_children_unique_elements_and_matching_parent_backlinks(self):
        original = SOURCE.read_bytes()
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            for path in sorted(SOURCE.parent.glob('*.pdf')):
                with self.subTest(source=path.name):
                    self.observe(directory, 'source-' + path.stem, path.read_bytes(), 'pass')
            for name, number, before, after, expected in (
                    ('root-type', 8, b'/Type /StructTreeRoot', b'/Type /Other', 'fail'),
                    ('root-content-child', 8, b'/K 9 0 R', b'/K 0', 'fail'),
                    ('root-null-is-absent', 8, b'/K 9 0 R', b'/K null', 'pass'),
                    ('root-null-array-child', 8, b'/K 9 0 R', b'/K[null]', 'fail'),
                    ('root-absent-children', 8, b'/K 9 0 R', b'', 'pass'),
                    ('element-root-backlink', 9, b'/P 8 0 R', b'/P 7 0 R', 'fail'),
                    ('element-child-backlink', 11, b'/P 10 0 R', b'/P 9 0 R', 'fail'),
                    ('element-cycle', 9, b'/K [10 0 R]', b'/K [9 0 R]', 'fail'),
                    ('element-unknown-kind', 11, b'/Type /StructElem', b'/Type /Other', 'fail'),
                    ('element-optional-type', 11, b'/Type /StructElem', b'', 'pass'),
                    ('element-missing-role', 9, b'/S /Custom', b'', 'fail'),
                    ('element-numeric-role', 11, b'/S /Span', b'/S 12345', 'fail'),
                    ('element-null-is-absent', 11, b'/ActualText ()', b'/K null', 'pass'),
                    ('element-null-array-child', 11, b'/ActualText ()', b'/K [null]', 'fail'),
                    ('element-numeric-children', 11, b'/ActualText ()', b'/K 0.5', 'fail')):
                with self.subTest(hierarchy=name):
                    self.observe(directory, name, self.change(original, number, before, after), expected,
                                 'structure-hierarchy' if expected == 'fail' else None)
            children = b'/K [0 << /Type /MCR /Pg 3 0 R /Stm 7 0 R /MCID 0 >> << /Type /OBJR /Pg 3 0 R /Obj 12 0 R >> 11 0 R]'
            self.observe(directory, 'shared-child', self.change(original, 10, children, b'/K [11 0 R 11 0 R]'),
                         'fail', 'structure-hierarchy')


if __name__ == '__main__':
    unittest.main()
