from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time
ROOT=Path('/home/ubuntu/IdeaProjects/open-pdf');HERE=Path(__file__).resolve().parent
SHA='8a523b6c1e7545e09e826b8fae4dedf4624d6477a8d8c3961a5f8f079b900a8b'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert sha(HERE/'observer.py')==SHA
ENV=dict(os.environ);ENV.pop('QPDF_CACHE_DIRECTORY',None)
files=[HERE/'observer.py',HERE/'contract.md',Path(sys.executable).resolve(),ROOT/'.build-cache/qpdf/12.4.0/bin/qpdf']+[ROOT/'scripts'/x for x in ['qpdf-pin.properties','container-bin/qpdf','t13-qpdf-runtime.sha256']]
for line in (ROOT/'scripts/t13-qpdf-runtime.sha256').read_text().splitlines():files.append(ROOT/'.build-cache/qpdf/12.4.0'/line.split('  ',1)[1])
identities={str(p):sha(p) for p in files};rows=[]
def stream(dictionary=b'<<>>',data=b''):
 assert dictionary.endswith(b'>>')
 return dictionary[:-2]+b'/Length '+str(len(data)).encode()+b'>>\nstream\n'+data+b'\nendstream'
def objects():
 return [b'<</Type/Catalog/Pages 2 0 R/StructTreeRoot 4 0 R/MarkInfo<</Marked true>>>>',b'<</Type/Pages/Kids[3 0 R]/Count 1>>',b'<</Type/Page/Parent 2 0 R/MediaBox[0 0 100 100]/Resources<<>>/Contents 7 0 R/StructParents 0>>',b'<</Type/StructTreeRoot/K 5 0 R/ParentTree 6 0 R/ParentTreeNextKey 1>>',b'<</Type/StructElem/S/P/P 4 0 R/Pg 3 0 R/K 0/Lang(en)>>',b'<</Nums[0[5 0 R]]>>',stream(data=b'/P<</MCID 0>>BDC EMC'),b'null']
def pdf(parts):
 data=bytearray(b'%PDF-2.0\n');offsets=[0]
 for i,body in enumerate(parts,1):offsets.append(len(data));data.extend(str(i).encode()+b' 0 obj\n'+body+b'\nendobj\n')
 xref=len(data);data.extend(b'xref\n0 '+str(len(offsets)).encode()+b'\n0000000000 65535 f \n')
 for off in offsets[1:]:data.extend(('%010d 00000 n \n'%off).encode())
 data.extend(b'trailer\n<</Size '+str(len(offsets)).encode()+b'/Root 1 0 R>>\nstartxref\n'+str(xref).encode()+b'\n%%EOF\n');return data

def run(label,parts,scope):
 path=HERE/(label+'.pdf');data=pdf(parts);path.write_bytes(data);out=HERE/(label+'-'+scope+'-output');args=[sys.executable,str(HERE/'observer.py'),str(ROOT),str(path),scope,str(out)];started=time.monotonic()
 with (HERE/(out.name+'.stdout')).open('wb') as stdout,(HERE/(out.name+'.stderr')).open('wb') as stderr:
  p=subprocess.run(args,cwd=HERE,env=ENV,stdout=stdout,stderr=stderr,timeout=40)
 prop=out/'result.properties';result=dict(line.split('=',1) for line in prop.read_text().splitlines() if line and not line.startswith(('#','!'))) if prop.exists() else None
 row={'label':label,'scope':scope,'command':args,'cwd':str(HERE),'exit':p.returncode,'elapsed':time.monotonic()-started,'input-sha256':sha(path),'result':result,'files':{str(f.relative_to(out)):sha(f) for f in out.iterdir() if f.is_file()}}
 rows.append(row);(HERE/(label+'-'+scope+'-result.json')).write_text(json.dumps(row,indent=2)+'\n');print(label,scope,p.returncode,result.get('standards') if result else None,result.get('finding') if result else None,flush=True)

for scope in ['structure-hierarchy','structure-parent-tree']:run('original',objects(),scope)
for label,num in [('stream-root',4),('stream-element',5),('stream-parent-tree',6)]:
 parts=objects();parts[num-1]=stream(parts[num-1])
 for scope in ['structure-hierarchy','structure-parent-tree'] if num!=6 else ['structure-parent-tree']:run(label,parts,scope)
for label,k in [('direct-null',b'null'),('indirect-null',b'8 0 R'),('array-null',b'[null]'),('array-indirect-null',b'[8 0 R]'),('dangling-child',b'99 0 R')]:
 parts=objects();parts[4]=parts[4].replace(b'/K 0',b'/K '+k)
 run(label,parts,'structure-hierarchy')
parts=objects();parts[3]=parts[3].replace(b'/K 5 0 R',b'/K[5 0 R 8 0 R]');parts[7]=b'5 0 R';run('shared-aliased-element',parts,'structure-hierarchy')
parts=objects();parts[3]=parts[3].replace(b'/K 5 0 R',b'/K[5 0 R 5 0 R]');run('shared-same-reference',parts,'structure-hierarchy')
for label,value in [('parent-null-slot',b'null'),('parent-indirect-null-slot',b'8 0 R'),('parent-dangling-slot',b'99 0 R')]:
 parts=objects();parts[5]=b'<</Nums[0[5 0 R '+value+b']]>>';run(label,parts,'structure-parent-tree')
for label,k in [('mcr-stream',b'<</Type/MCR/Pg 3 0 R/MCID 0>>'),('objr-stream',b'<</Type/OBJR/Pg 3 0 R/Obj 7 0 R>>')]:
 parts=objects();parts[4]=parts[4].replace(b'/K 0',b'/K 8 0 R');parts[7]=stream(k);run(label,parts,'structure-hierarchy')
after={str(p):sha(p) for p in files};(HERE/'identity.json').write_text(json.dumps({'before':identities,'after':after,'unchanged':identities==after,'probe-sha256':sha(Path(__file__))},indent=2)+'\n');(HERE/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(HERE,'identities unchanged',identities==after,flush=True)
