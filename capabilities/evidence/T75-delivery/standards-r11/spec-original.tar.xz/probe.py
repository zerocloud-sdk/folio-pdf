from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,tempfile
repo=Path('/home/ubuntu/IdeaProjects/open-pdf');base=Path(tempfile.mkdtemp(prefix='t75-spec-structure.'));print(base,flush=True)
shutil.copy2(__file__,base/'probe.py')
src=repo/'capabilities/evidence/T75-delivery/standards-r11/observer-hierarchy-parent-tree.py'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(src)=='d7225e23efc634fe5b71edb1713ba6e4d24e91d29e33cc5e9ca959af8938bf81'
observer=base/'observer.py';shutil.copy2(src,observer)
paths=[src,observer,repo/'scripts/qpdf-pin.properties',repo/'scripts/container-bin/qpdf',repo/'scripts/t13-qpdf-runtime.sha256',repo/'.build-cache/qpdf/12.4.0/bin/qpdf']
for line in (repo/'scripts/t13-qpdf-runtime.sha256').read_text().splitlines():
 expected,path=line.split('  ',1);item=repo/'.build-cache/qpdf/12.4.0'/path;assert sha(item)==expected;paths.append(item)
identity={str(p):sha(p) for p in paths};(base/'identities-before.json').write_text(json.dumps(identity,indent=2))
(base/'inputs').mkdir();(base/'outputs').mkdir();rows=[]
def stream(data=b'',dictionary=b''):
 return b'<< '+dictionary+b' /Length '+str(len(data)).encode()+b' >>\nstream\n'+data+b'\nendstream'
def write_pdf(objects):
 data=b'%PDF-2.0\n%\xe2\xe3\xcf\xd3\n';offsets=[]
 for n,obj in enumerate(objects,1):offsets.append(len(data));data+=str(n).encode()+b' 0 obj\n'+obj+b'\nendobj\n'
 pos=len(data);data+=b'xref\n0 '+str(len(objects)+1).encode()+b'\n0000000000 65535 f \n'+b''.join(('%010d 00000 n \n'%x).encode() for x in offsets)
 return data+b'trailer\n<< /Root 1 0 R /Size '+str(len(objects)+1).encode()+b' >>\nstartxref\n'+str(pos).encode()+b'\n%%EOF\n'
def objects():
 return [b'<< /Type /Catalog /Pages 2 0 R /StructTreeRoot 4 0 R /Lang (en) >>',b'<< /Type /Pages /Count 1 /Kids [3 0 R] >>',b'<< /Type /Page /Parent 2 0 R /MediaBox [0 0 100 100] /Resources <<>> /Contents 7 0 R /StructParents 0 >>',b'<< /Type /StructTreeRoot /K 5 0 R /ParentTree 6 0 R /ParentTreeNextKey 1 >>',b'<< /Type /StructElem /S /P /P 4 0 R /K 0 /Lang (en) /Alt (A) /ActualText () >>',b'<< /Nums [0 [5 0 R null]] >>',stream(b'/P << /MCID 0 >> BDC EMC'),b'null',b'(en)',b'[]']
def changed(index,old,new):
 v=objects();assert old in v[index-1];v[index-1]=v[index-1].replace(old,new);return v

def run(name,objs,expected,scope='structure-hierarchy',authority='',origin=None):
 pdf=base/'inputs'/(name+'.pdf');pdf.write_bytes(write_pdf(objs) if isinstance(objs,list) else objs);out=base/'outputs'/name
 cmd=[sys.executable,str(observer),str(repo),str(pdf),scope,str(out)];env=os.environ.copy();env.pop('QPDF_CACHE_DIRECTORY',None)
 p=subprocess.run(cmd,env=env,capture_output=True,text=True,timeout=40)
 props=dict(s.split('=',1) for s in (out/'result.properties').read_text().splitlines()) if (out/'result.properties').exists() else {}
 row={'case':name,'scope':scope,'input':str(pdf),'input-sha256':sha(pdf),'argv':cmd,'expected':expected,'actual':props.get('standards'),'matched':props.get('standards')==expected,'return-code':p.returncode,'result':props,'authority':authority,'output':str(out)}
 if origin:row['origin']=str(origin);row['origin-sha256']=sha(origin);assert sha(origin)==sha(pdf)
 rows.append(row);(base/(name+'.command.json')).write_text(json.dumps(row,indent=2));(base/(name+'.stdout.txt')).write_text(p.stdout);(base/(name+'.stderr.txt')).write_text(p.stderr)
 print(json.dumps({k:row[k] for k in ('case','scope','expected','actual','matched')}),flush=True)

run('baseline-hierarchy',objects(),'pass');run('baseline-parent-tree',objects(),'pass','structure-parent-tree')
for number,label in ((4,'root'),(5,'element')):
 objs=objects();objs[number-1]=stream(dictionary=objs[number-1][2:-2]);run(label+'-is-stream',objs,'fail',authority='ISO1 14.7.2 Tables322/323: root and elements are dictionary objects, not stream objects')
objs=objects();objs[5]=stream(dictionary=b'/Nums [0 [5 0 R null]]');run('parent-tree-root-is-stream',objs,'fail','structure-parent-tree','ISO1 7.9.7 Table37 requires number-tree node dictionaries')
objs=objects();objs[5]=b'<< /Kids [10 0 R] >>';objs[9]=stream(dictionary=b'/Nums [0 [5 0 R]] /Limits [0 0]');run('parent-tree-leaf-is-stream',objs,'fail','structure-parent-tree','ISO1 Table37 node dictionary type')
for kind in (b'MCR',b'OBJR'):
 objs=changed(5,b'/K 0',b'/K 10 0 R');objs[9]=stream(dictionary=b'/Type /'+kind+b' /Pg 3 0 R /MCID 0 /Obj 3 0 R');run(kind.decode().lower()+'-child-is-stream',objs,'fail',authority='ISO1 Table323 K content references are dictionary objects; actual ownership outside scope')
for name,number,replacement,expected in [
 ('root-direct-null',4,b'null','pass'),('root-indirect-null',4,b'8 0 R','pass'),('root-array-null',4,b'[null]','fail'),('root-array-indirect-null',4,b'[8 0 R]','fail'),('root-empty-array',4,b'[]','pass'),
 ('element-direct-null',5,b'null','pass'),('element-indirect-null',5,b'8 0 R','pass'),('element-array-null',5,b'[null]','fail'),('element-array-indirect-null',5,b'[8 0 R]','fail'),('element-empty-array',5,b'[]','fail'),('element-indirect-empty-array',5,b'10 0 R','fail')]:
 old=b'/K 5 0 R' if number==4 else b'/K 0';run(name,changed(number,old,b'/K '+replacement),expected,authority='ISO1 7.3.7/7.3.9 optional-null omission; Table323 K array has one or more objects; PDF2 Tables354/355 array null prohibited')
for name,new,expected in [('name',b'/bad','fail'),('real',b'0.5','fail'),('integer',b'0','pass'),('null',b'null','pass'),('indirect-null',b'8 0 R','pass')]:
 objs=changed(4,b'/ParentTree 6 0 R /ParentTreeNextKey 1',b'/ParentTreeNextKey '+new);objs[4]=objs[4].replace(b'/K 0',b'');run('next-key-without-tree-'+name,objs,expected,'structure-parent-tree','ISO1 Table322 optional ParentTreeNextKey still must be integer if present')
run('required-root-type-null',changed(4,b'/Type /StructTreeRoot',b'/Type null'),'fail')
run('required-element-role-indirect-null',changed(5,b'/S /P',b'/S 8 0 R'),'fail')
run('optional-element-type-indirect-null',changed(5,b'/Type /StructElem',b'/Type 8 0 R'),'pass')
run('metadata-indirect-string',changed(5,b'/Lang (en)',b'/Lang 9 0 R'),'pass')
run('metadata-indirect-null',changed(5,b'/Lang (en)',b'/Lang 8 0 R'),'pass')
run('metadata-array',changed(5,b'/Lang (en)',b'/Lang []'),'fail')
run('num-keys-indirect-integer',changed(6,b'/Nums [0 [5 0 R null]]',b'/Nums [11 0 R [5 0 R null]]')+[b'0'],'pass','structure-parent-tree','General indirect numeric objects allowed')
run('num-keys-indirect-null',changed(6,b'/Nums [0 [5 0 R null]]',b'/Nums [8 0 R [5 0 R null]]'),'fail','structure-parent-tree','PDF2 Table37 keys shall not be null')
run('parent-slot-indirect-null',changed(6,b'[5 0 R null]',b'[5 0 R 8 0 R]'),'pass','structure-parent-tree','PDF2 Table354 ParentTree permits unused null slots')
run('parent-slot-direct-element',changed(6,b'[5 0 R null]',b'[<< /Type /StructElem /S /P /P 4 0 R >>]'),'fail','structure-parent-tree','ISO1 Table322 parents must be indirect references')
# Independently authored two-leaf control and its order/limit representations.
objs=objects();objs[5]=b'<< /Kids [10 0 R 11 0 R] >>';objs[3]=objs[3].replace(b'/ParentTreeNextKey 1',b'/ParentTreeNextKey 3');objs[9]=b'<< /Nums [0 [5 0 R]] /Limits [0 0] >>';objs.append(b'<< /Nums [2 5 0 R] /Limits [2 2] >>')
run('tree-two-leaves',objs,'pass','structure-parent-tree')
for label,index,old,new in [('wrong-limits',10,b'/Limits [0 0]',b'/Limits [0 2]'),('wrong-order',6,b'[10 0 R 11 0 R]',b'[11 0 R 10 0 R]'),('shared-node',6,b'[10 0 R 11 0 R]',b'[10 0 R 10 0 R]'),('root-limits',6,b'>>',b'/Limits [0 2] >>')]:
 val=list(objs);val[index-1]=val[index-1].replace(old,new);run(label,val,'fail','structure-parent-tree')
for source in sorted((repo/'capabilities/profiles/T13-text/fixtures').glob('*.pdf')):
 if source.name in ('nested-split-type3.pdf','marked-structure.pdf','embedded-font-kinds.pdf','embedded-font-inheritance.pdf','uncertain-geometry.pdf'):
  for scope in ('structure-hierarchy','structure-parent-tree'):run(source.stem+'-'+scope,source.read_bytes(),'pass',scope,origin=source)
after={str(p):sha(p) for p in paths};(base/'identities-after.json').write_text(json.dumps(after,indent=2));(base/'summary.json').write_text(json.dumps({'observer-sha256':sha(observer),'identities-unchanged':identity==after,'rows':rows},indent=2));print(json.dumps({'directory':str(base),'total':len(rows),'matched':sum(r['matched'] for r in rows),'identities-unchanged':identity==after}),flush=True)
