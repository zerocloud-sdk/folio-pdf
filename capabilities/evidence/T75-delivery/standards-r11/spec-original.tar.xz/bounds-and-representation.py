from pathlib import Path
import ast,hashlib,json,os,subprocess,sys
base=Path(__file__).parent;repo=Path('/home/ubuntu/IdeaProjects/open-pdf');observer=base/'observer.py';rows=[]
node=ast.parse((base/'probe.py').read_text());keep={'sha','stream','write_pdf','objects','changed','run'};defs=[n for n in node.body if isinstance(n,ast.FunctionDef) and n.name in keep]
exec(compile(ast.Module(body=defs,type_ignores=[]),str(base/'probe.py'),'exec'),globals())
assert sha(observer)=='d7225e23efc634fe5b71edb1713ba6e4d24e91d29e33cc5e9ca959af8938bf81'
v=objects();v[0]=b'<< /Type /Catalog /Pages 2 0 R /StructTreeRoot << /Type /StructTreeRoot >> >>'
run('direct-structure-root',v,'fail',authority='PDF2 Table29 Catalog StructTreeRoot shall be an indirect reference; original hierarchy below detached root not claimed')
v=objects();v[3]=v[3].replace(b'/ParentTree 6 0 R',b'/ParentTree << /Nums [0 [5 0 R]] >>');run('direct-parent-tree-root',v,'pass','structure-parent-tree','Table37 permits a direct root dictionary; child nodes must be indirect')
v=changed(4,b'/K 5 0 R',b'/K << /Type /StructElem /S /P /P 4 0 R >>');run('direct-structure-element-unqualified',v,'indeterminate',authority='Contract explicitly excludes direct structure-element identities')
for kind in (b'MCR',b'OBJR'):
 v=changed(5,b'/K 0',b'/K 10 0 R');v[9]=b'<< /Type /'+kind+b' /Pg 3 0 R /MCID 0 /Obj 3 0 R >>';run(kind.decode().lower()+'-dictionary-kind',v,'pass',authority='Dictionary representation control only; ownership pending')
for count in (1000,1001):
 v=objects();children=[]
 for i in range(count-1):
  number=len(v)+1;children.append(str(number).encode()+b' 0 R');v.append(b'<< /Nums ['+str(i).encode()+b' [5 0 R]] /Limits ['+str(i).encode()+b' '+str(i).encode()+b'] >>')
 v[5]=b'<< /Kids ['+b' '.join(children)+b'] >>';v[3]=v[3].replace(b'/ParentTreeNextKey 1',b'/ParentTreeNextKey '+str(count).encode())
 run('parent-tree-nodes-'+str(count),v,'pass' if count==1000 else 'indeterminate','structure-parent-tree','Contract 1000 total number-tree nodes including root')
for count in (10000,10001):
 v=objects();v[5]=b'<< /Nums ['+b' '.join(str(i).encode()+b' [5 0 R]' for i in range(count))+b'] >>';v[3]=v[3].replace(b'/ParentTreeNextKey 1',b'/ParentTreeNextKey '+str(count).encode())
 run('parent-tree-entries-'+str(count),v,'pass' if count==10000 else 'indeterminate','structure-parent-tree','Contract 10000 number-tree key/value entries')
for depth in (128,129):
 v=objects();v[5]=b'<< /Kids [11 0 R] >>'
 for level in range(2,depth+1):
  number=len(v)+1
  content=(b'/Nums [0 [5 0 R]]' if level==depth else b'/Kids ['+str(number+1).encode()+b' 0 R]')
  v.append(b'<< '+content+b' /Limits [0 0] >>')
 run('parent-tree-depth-'+str(depth),v,'pass' if depth==128 else 'indeterminate','structure-parent-tree','Contract 128 number-tree levels including root')
for depth in (128,129):
 v=objects();v[3]=b'<< /Type /StructTreeRoot /K 11 0 R >>'
 for level in range(1,depth+1):
  number=len(v)+1;parent=4 if level==1 else number-1
  child=b'' if level==depth else b'/K '+str(number+1).encode()+b' 0 R'
  v.append(b'<< /Type /StructElem /S /P /P '+str(parent).encode()+b' 0 R '+child+b' >>')
 run('hierarchy-depth-'+str(depth),v,'pass' if depth==128 else 'indeterminate',authority='Contract 128 traversed child levels')
for count in (10000,10001):
 v=objects();refs=[]
 for i in range(count):
  refs.append(str(len(v)+1).encode()+b' 0 R');v.append(b'<< /Type /StructElem /S /P /P 4 0 R >>')
 v[3]=b'<< /Type /StructTreeRoot /K ['+b' '.join(refs)+b'] >>'
 run('hierarchy-items-'+str(count),v,'pass' if count==10000 else 'indeterminate',authority='Contract 10000 traversed children')
(base/'bounds-and-representation-summary.json').write_text(json.dumps({'observer-sha256':sha(observer),'rows':rows},indent=2));print(json.dumps({'count':len(rows),'matched':sum(r['matched'] for r in rows)}))
