# Independent bounded Standards review: hierarchy and ParentTree

Snapshot SHA d7225e23efc634fe5b71edb1713ba6e4d24e91d29e33cc5e9ca959af8938bf81 was copied from the exact retained standards-r11/observer-hierarchy-parent-tree.py to observer.py before probing. The live observer was never executed or edited. No Maven action or implementation delegation occurred. The fixed overall baseline is 5b1603c435f11c40368f75b7b9a2777c9c5e9761. contract.md records the contemporary limited scope; content ownership/backlink equality and namespaces are explicitly excluded from completeness conclusions.

## Hard findings

1. New structural dictionary predicates consume Graph.resolve, which converts a qpdf stream object into its stream dictionary. Thus isinstance(..., dict) at snapshot lines 1197, 1221 and 1262 cannot enforce the claimed PDF object kind. Independently replacing the structure root, structure element, ParentTree root or child, MCR or OBJR with an empty stream preserves PASS. Eight actual scope observations demonstrate this (root and element tested through both scopes; remaining four through their applicable scope). Actual qpdf.json files clearly retain the objects as stream, not value dictionaries. Ordinary dictionary controls PASS. This breaches the root/child-kind and number-tree topology/type predicates declared in contract.md:366-380. A structural dictionary reader should preserve the underlying object kind; do not change the general resolver's existing stream uses blindly.

2. The backlink equality at snapshot line 1231 is raw Python == without requiring P to be an indirect reference. A direct StructTreeRoot embedded in the catalog, and a separate value-equal copy embedded as the child's P, yields PASS in both scopes. The direct parent does not refer to the same parent identity and violates the required indirect P field in ISO32000-1 Table323 (normative-reference.json records the local public source identity). The otherwise identical direct P beneath an indirect root FAILs, demonstrating the equality-path difference. direct-parent-value-copy.pdf and both raw outputs preserve the false PASS. Require an indirect parent identity before comparing the relationship; direct roots may remain explicitly unqualified if needed by this bounded subset.

## Controls and scope limits

- Original legal hierarchy/ParentTree fixture: both PASS.
- Optional K literal null and indirect null: PASS via qpdf's null/omission semantics; array literal/indirect null children: FAIL.
- Dangling optional K becomes null/omitted, and dangling unused parent slots resolve to null under the PDF null semantics; neither is asserted as a new finding.
- Reusing the exact same element reference: FAIL. An additional object whose whole value is another indirect reference is rejected by qpdf with a warning and yields INDETERMINATE; no alias-identity bypass is asserted from that case.
- Repeated ParentTree leaf identity: FAIL. Whole-object null parent: FAIL. Literal and indirect unused null array slots: PASS.

No additional standalone actionable heuristic smell was identified. The object-kind preserving helper suggested above directly supports fixing finding 1 rather than speculative abstraction.

## Evidence and provenance

probe.py and adjacent-probe.py independently author original eight-object PDFs with exact stream Lengths and xrefs, using a real page, an empty marked sequence, its structure element and corresponding ParentTree slot. No product or generator code is imported. Mutations are isolated object-kind, parent-identity or null/reference controls. No content ownership or namespace conclusion is drawn from these limited scopes.

All 25 subprocesses execute the public observer CLI with exact argument arrays and an independent 40-second timeout; all exit normally. results.json, adjacent-results.json and per-case JSON retain commands, input hashes, result properties, timings and output identities. Each output directory retains the actual qpdf JSON/stdout/stderr and public report. identity.json and identity-final.json bind the snapshot, Python executable, qpdf wrapper/pin/binary and all 11 declared runtime library files. Every public record matches its exact PDF and observer SHA, and every checked tool/snapshot identity stayed unchanged.

This is an incremental Standards review, not a final clean review or whole-task qualification.
