"""Qualify original logical-structure relationships through the public tool CLI."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[2]
SCRIPT = ROOT / 'scripts/t13-program-standards.py'
SOURCE = ROOT / 'capabilities/profiles/T13-text/fixtures/marked-structure.pdf'


class T13StructureStandardsTest(unittest.TestCase):
    def test_parent_tree_child_ranges_match_ordered_disjoint_leaf_keys(self):
        original = SOURCE.read_bytes()
        nums = b'/Nums [0 [10 0 R] 1 [10 0 R] 2 10 0 R]'
        data = self.change(original, 13, nums, b'/Kids [18 0 R 19 0 R]')
        position = int(data.rsplit(b'startxref\n', 1)[1].splitlines()[0])
        leaf_a = b'18 0 obj\n<</Nums[0[10 0 R]1[10 0 R]]/Limits[0 1]>>\nendobj\n'
        leaf_b = b'19 0 obj\n<</Nums[2 10 0 R]/Limits[2 2]>>\nendobj\n'
        tail = data[position:]; self.assertTrue(tail.startswith(b'xref\n0 18\n'))
        tail = tail.replace(b'xref\n0 18\n', b'xref\n0 20\n', 1)
        extra = ('%010d 00000 n \n%010d 00000 n \n' % (position, position + len(leaf_a))).encode('ascii')
        tail = tail.replace(b'trailer\n', extra + b'trailer\n', 1).replace(b'/Size 18', b'/Size 20')
        tail = tail.replace(('startxref\n%d\n' % position).encode('ascii'),
                            ('startxref\n%d\n' % (position + len(leaf_a) + len(leaf_b))).encode('ascii'))
        tree = data[:position] + leaf_a + leaf_b + tail
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            with self.subTest(number_tree='multi-level'):
                self.observe(directory, 'multi-level', tree, 'pass', scope='structure-parent-tree')
            for name, number, before, after in (
                    ('missing-limits', 18, b'/Limits[0 1]', b''),
                    ('incorrect-limits', 18, b'/Limits[0 1]', b'/Limits[0 2]'),
                    ('overlapping-ranges', 19, b'/Nums[2 10 0 R]/Limits[2 2]', b'/Nums[1 10 0 R]/Limits[1 1]'),
                    ('unordered-children', 13, b'/Kids [18 0 R 19 0 R]', b'/Kids [19 0 R 18 0 R]'),
                    ('cyclic-tree', 13, b'/Kids [18 0 R 19 0 R]', b'/Kids [18 0 R 13 0 R]')):
                with self.subTest(number_tree=name):
                    self.observe(directory, name, self.change(tree, number, before, after),
                                 'fail', 'structure-parent-tree', scope='structure-parent-tree')
            for name, replacement in (('root-limits', b'/Kids[18 0 R 19 0 R]/Limits[0 2]'),
                                       ('mixed-kids-and-nums', b'/Kids[18 0 R 19 0 R]/Nums[]'),
                                       ('direct-tree-child', b'/Kids[<</Nums[]/Limits[0 0]>>]')):
                with self.subTest(number_tree=name):
                    self.observe(directory, name, self.change(tree, 13, b'/Kids [18 0 R 19 0 R]'.ljust(len(nums)), replacement),
                                 'fail', 'structure-parent-tree', scope='structure-parent-tree')

    def test_parent_tree_has_ordered_integer_keys_structural_values_and_a_fresh_next_key(self):
        original = SOURCE.read_bytes()
        nums = b'/Nums [0 [10 0 R] 1 [10 0 R] 2 10 0 R]'
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            for path in sorted(SOURCE.parent.glob('*.pdf')):
                with self.subTest(source=path.name):
                    self.observe(directory, 'source-' + path.stem, path.read_bytes(), 'pass', scope='structure-parent-tree')
            for name, number, before, after, expected in (
                    ('missing-parent-tree', 8, b'/ParentTree 13 0 R', b'', 'fail'),
                    ('numeric-parent-tree', 8, b'/ParentTree 13 0 R', b'/ParentTree 1234', 'fail'),
                    ('missing-number-tree-entries', 13, nums, b'', 'fail'),
                    ('odd-key-values', 13, nums, b'/Nums [0]', 'fail'),
                    ('unordered-keys', 13, nums, b'/Nums [1 [10 0 R] 0 [10 0 R] 2 10 0 R]', 'fail'),
                    ('duplicate-keys', 13, nums, b'/Nums [0 [10 0 R] 0 [10 0 R] 2 10 0 R]', 'fail'),
                    ('boolean-key', 13, nums, b'/Nums [false 10 0 R]', 'fail'),
                    ('real-key', 13, nums, b'/Nums [0.0 10 0 R]', 'fail'),
                    ('numeric-parent-value', 13, nums, b'/Nums [0 42]', 'fail'),
                    ('non-element-parent-value', 13, nums, b'/Nums [0 [12 0 R]]', 'fail'),
                    ('used-next-key', 8, b'/ParentTreeNextKey 3', b'/ParentTreeNextKey 2', 'fail'),
                    ('name-next-key', 8, b'/ParentTreeNextKey 3', b'/ParentTreeNextKey/X', 'fail'),
                    ('absent-next-key', 8, b'/ParentTreeNextKey 3', b'', 'pass'),
                    ('unused-null-slot', 13, nums, b'/Nums[0[10 0 R null]1[10 0 R]2 10 0 R]', 'pass')):
                with self.subTest(parent_tree=name):
                    self.observe(directory, name, self.change(original, number, before, after), expected,
                                 'structure-parent-tree' if expected == 'fail' else None, scope='structure-parent-tree')

    def test_hierarchy_qualification_admits_exact_depth_and_item_bounds(self):
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            for name, count, nested, expected in (('depth-128', 128, True, 'pass'),
                                                   ('depth-129', 129, True, 'indeterminate'),
                                                   ('items-10000', 10000, False, 'pass'),
                                                   ('items-10001', 10001, False, 'indeterminate')):
                with self.subTest(boundary=name):
                    children = b'5 0 R' if nested else b'[' + b' '.join(
                        ('%d 0 R' % (5 + index)).encode('ascii') for index in range(count)) + b']'
                    objects = [b'<</Type/Catalog/Pages 2 0 R/StructTreeRoot 4 0 R>>',
                               b'<</Type/Pages/Count 1/Kids[3 0 R]>>',
                               b'<</Type/Page/Parent 2 0 R/MediaBox[0 0 100 100]/Resources<<>>>>',
                               b'<</Type/StructTreeRoot/K ' + children + b'>>']
                    for index in range(count):
                        parent = 4 + index if nested else 4
                        child = ('/K %d 0 R' % (6 + index)).encode('ascii') if nested and index + 1 < count else b''
                        objects.append(('<</Type/StructElem/S/P/P %d 0 R' % parent).encode('ascii') + child + b'>>')
                    data = bytearray(b'%PDF-2.0\n'); offsets = []
                    for number, body in enumerate(objects, 1):
                        offsets.append(len(data)); data.extend(('%d 0 obj\n' % number).encode('ascii') + body + b'\nendobj\n')
                    xref = len(data); data.extend(('xref\n0 %d\n0000000000 65535 f \n' % (len(objects) + 1)).encode('ascii'))
                    for offset in offsets:
                        data.extend(('%010d 00000 n \n' % offset).encode('ascii'))
                    data.extend(('trailer\n<</Root 1 0 R/Size %d>>\nstartxref\n%d\n%%%%EOF\n' % (len(objects) + 1, xref)).encode('ascii'))
                    self.observe(directory, name, data, expected)

    def test_structure_language_and_replacement_metadata_are_text_strings(self):
        original = SOURCE.read_bytes()
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            for name, number, before, after, expected in (
                    ('catalog-numeric-language', 1, b'/Lang (en)', b'/Lang 123', 'fail'),
                    ('element-name-language', 9, b'/Lang (fr)', b'/Lang /FR', 'fail'),
                    ('element-boolean-language', 11, b'/Lang (ja)', b'/Lang true', 'fail'),
                    ('element-name-alternate', 9, b'/Alt (RootAlt)', b'/Alt /RootAlt', 'fail'),
                    ('element-boolean-replacement', 9, b'/ActualText (RootActual)', b'/ActualText false', 'fail'),
                    ('element-empty-language', 9, b'/Lang (fr)', b'/Lang ()', 'pass'),
                    ('element-hex-language', 9, b'/Lang (fr)', b'/Lang <66>', 'pass'),
                    ('element-null-language', 9, b'/Lang (fr)', b'/Lang null', 'pass'),
                    ('element-null-replacement', 9, b'/ActualText (RootActual)', b'/ActualText null', 'pass')):
                with self.subTest(metadata=name):
                    self.observe(directory, name, self.change(original, number, before, after), expected,
                                 'structure-text' if expected == 'fail' else None)

    def observe(self, directory, name, data, expected, rule=None, scope='structure-hierarchy'):
        pdf = directory / (name + '.pdf'); pdf.write_bytes(data)
        output = directory / name
        run = subprocess.run([sys.executable, str(SCRIPT), str(ROOT), str(pdf), scope, str(output)],
                             capture_output=True, text=True, timeout=40)
        self.assertEqual(0, run.returncode, run.stderr)
        result = dict(line.split('=', 1) for line in (output / 'result.properties').read_text().splitlines())
        self.assertEqual(expected, result['standards'], name + ': ' + result['finding'])
        self.assertEqual(hashlib.sha256(data).hexdigest(), result['input-sha256'])
        self.assertEqual(hashlib.sha256(SCRIPT.read_bytes()).hexdigest(), result['observer-sha256'])
        if rule is not None:
            self.assertEqual(rule, result['rule'])
        return result

    def change(self, source, number, before, after):
        marker = ('\n%d 0 obj\n' % number).encode('ascii')
        self.assertEqual(1, source.count(marker))
        self.assertLessEqual(len(after), len(before))
        start = source.index(marker) + len(marker); end = source.index(b'\nendobj\n', start)
        body = source[start:end]; self.assertEqual(1, body.count(before))
        return source[:start] + body.replace(before, after.ljust(len(before))) + source[end:]

    def test_structure_hierarchy_has_typed_children_unique_elements_and_matching_parent_backlinks(self):
        original = SOURCE.read_bytes()
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            for path in sorted(SOURCE.parent.glob('*.pdf')):
                with self.subTest(source=path.name):
                    self.observe(directory, 'source-' + path.stem, path.read_bytes(), 'pass')
            for name, number, before, after, expected in (
                    ('root-type', 8, b'/Type /StructTreeRoot', b'/Type /Other', 'fail'),
                    ('root-content-child', 8, b'/K 9 0 R', b'/K 0', 'fail'),
                    ('root-null-is-absent', 8, b'/K 9 0 R', b'/K null', 'pass'),
                    ('root-null-array-child', 8, b'/K 9 0 R', b'/K[null]', 'fail'),
                    ('root-absent-children', 8, b'/K 9 0 R', b'', 'pass'),
                    ('element-root-backlink', 9, b'/P 8 0 R', b'/P 7 0 R', 'fail'),
                    ('element-child-backlink', 11, b'/P 10 0 R', b'/P 9 0 R', 'fail'),
                    ('element-cycle', 9, b'/K [10 0 R]', b'/K [9 0 R]', 'fail'),
                    ('element-unknown-kind', 11, b'/Type /StructElem', b'/Type /Other', 'fail'),
                    ('element-optional-type', 11, b'/Type /StructElem', b'', 'pass'),
                    ('element-missing-role', 9, b'/S /Custom', b'', 'fail'),
                    ('element-numeric-role', 11, b'/S /Span', b'/S 12345', 'fail'),
                    ('element-null-is-absent', 11, b'/ActualText ()', b'/K null', 'pass'),
                    ('element-null-array-child', 11, b'/ActualText ()', b'/K [null]', 'fail'),
                    ('element-numeric-children', 11, b'/ActualText ()', b'/K 0.5', 'fail')):
                with self.subTest(hierarchy=name):
                    self.observe(directory, name, self.change(original, number, before, after), expected,
                                 'structure-hierarchy' if expected == 'fail' else None)
            children = b'/K [0 << /Type /MCR /Pg 3 0 R /Stm 7 0 R /MCID 0 >> << /Type /OBJR /Pg 3 0 R /Obj 12 0 R >> 11 0 R]'
            self.observe(directory, 'shared-child', self.change(original, 10, children, b'/K [11 0 R 11 0 R]'),
                         'fail', 'structure-hierarchy')


if __name__ == '__main__':
    unittest.main()
