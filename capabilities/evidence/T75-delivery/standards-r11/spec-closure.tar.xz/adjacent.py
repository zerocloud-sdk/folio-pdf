from pathlib import Path
import ast,hashlib,json,os,subprocess,sys
base=Path(__file__).parent;repo=Path('/home/ubuntu/IdeaProjects/open-pdf');observer=base/'observer.py';rows=[]
node=ast.parse((base/'probe.py').read_text());defs=[n for n in node.body if isinstance(n,ast.FunctionDef) and n.name in ('sha','run','ns_objects','variant')];exec(compile(ast.Module(body=defs,type_ignores=[]),str(base/'probe.py'),'exec'),globals())
old=ast.parse(Path('/tmp/t75-spec-structure._jaafen4/probe.py').read_text());defs=[n for n in old.body if isinstance(n,ast.FunctionDef) and n.name in ('stream','write_pdf')];exec(compile(ast.Module(body=defs,type_ignores=[]),'prior-original-author', 'exec'),globals())
assert sha(observer)=='8a523b6c1e7545e09e826b8fae4dedf4624d6477a8d8c3961a5f8f079b900a8b'
for label,header,catalog,expected in [('legacy-empty-direct-root','1.7',None,'pass'),('catalog2-direct-root','1.7','2.0','fail'),('header2-lower-catalog','2.0','1.7','fail')]:
 v=ns_objects();v[0]=b'<< /Type /Catalog /Pages 2 0 R /StructTreeRoot << /Type /StructTreeRoot >>'+(b'' if catalog is None else b' /Version /'+catalog.encode())+b' >>'
 data=write_pdf(v).replace(b'%PDF-2.0',b'%PDF-'+header.encode(),1);run(label,data,expected,'structure-hierarchy',authority='PDF2 root indirection is based on effective maximum version; legacy empty direct root is within hierarchy subset')
v=ns_objects();v[4]=b'<< /S /P /P << /Type /StructTreeRoot /K 5 0 R >> >>';run('required-parent-direct-dictionary',v,'fail','structure-hierarchy','Table355 P is a required indirect reference')
for count in (1000,1001):
 v=ns_objects();v[3]=b'<< /Type /StructTreeRoot /Namespaces [11 0 R] >>'
 for i in range(count):
  number=len(v)+1;mapping=b'' if i+1==count else b' /RoleMapNS << /X [/X '+str(number+1).encode()+b' 0 R] >>'
  v.append(b'<< /NS (urn:spec:chain:'+str(i).encode()+b')'+mapping+b' >>')
 run('mapped-namespace-nodes-'+str(count),v,'pass' if count==1000 else 'indeterminate',authority='1000 distinct declarations includes RoleMapNS-discovered targets outside the root array')
for label,uri in [('utf16-pdf2-uri','http://iso.org/pdf2/ssn'),('utf16-pdf17-uri','http://iso.org/pdf/ssn')]:
 v=ns_objects();value=b'<'+(b'\xfe\xff'+uri.encode('utf-16-be')).hex().encode()+b'>';v[5]=b'<< /NS '+value+b' /RoleMapNS << /P [/Span 7 0 R] >> >>';v[6]=b'<< /NS ('+uri.encode()+b') >>';run(label,v,'fail',authority='Equivalent text-string encodings denote the same standard namespace name')
# Count repeated references once per distinct declaration. No role-resolution conformance assertion.
v=ns_objects();v[3]=b'<< /Type /StructTreeRoot /Namespaces ['+b'6 0 R '*1001+b'] >>';v[5]=b'<< /NS (urn:spec:reuse) >>';run('repeated-namespace-reference',v,'pass',authority='Node bound is on distinct dictionaries, not repeated array references')
(base/'adjacent-summary.json').write_text(json.dumps({'observer-sha256':sha(observer),'rows':rows},indent=2));print(json.dumps({'calls':len(rows),'matched':sum(r['matched'] for r in rows)}),flush=True)
