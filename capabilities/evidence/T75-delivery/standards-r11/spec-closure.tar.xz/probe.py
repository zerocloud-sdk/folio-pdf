from pathlib import Path
import ast,hashlib,json,os,shutil,subprocess,sys,tempfile
repo=Path('/home/ubuntu/IdeaProjects/open-pdf');prior=Path('/tmp/t75-spec-structure._jaafen4');base=Path(tempfile.mkdtemp(prefix='t75-spec-structure-closure.'));print(base,flush=True)
shutil.copy2(__file__,base/'probe.py')
source=repo/'capabilities/evidence/T75-delivery/standards-r11/observer-hierarchy-parent-tree-namespaces.py'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(source)=='8a523b6c1e7545e09e826b8fae4dedf4624d6477a8d8c3961a5f8f079b900a8b'
observer=base/'observer.py';shutil.copy2(source,observer);shutil.copy2(repo/'docs/t13-certification.md',base/'t13-certification.md')
paths=[source,observer,repo/'scripts/qpdf-pin.properties',repo/'scripts/container-bin/qpdf',repo/'scripts/t13-qpdf-runtime.sha256',repo/'.build-cache/qpdf/12.4.0/bin/qpdf']
for line in (repo/'scripts/t13-qpdf-runtime.sha256').read_text().splitlines():
 expected,name=line.split('  ',1);p=repo/'.build-cache/qpdf/12.4.0'/name;assert sha(p)==expected;paths.append(p)
identities={str(p):sha(p) for p in paths};(base/'identities-before.json').write_text(json.dumps(identities,indent=2));(base/'inputs').mkdir();(base/'outputs').mkdir();rows=[]
node=ast.parse((prior/'probe.py').read_text());defs=[n for n in node.body if isinstance(n,ast.FunctionDef) and n.name in ('stream','write_pdf','objects','changed')];exec(compile(ast.Module(body=defs,type_ignores=[]),str(prior/'probe.py'),'exec'),globals())
def run(name,body,expected,scope='structure-namespaces',authority='',origin=None):
 pdf=base/'inputs'/(name+'.pdf');pdf.write_bytes(write_pdf(body) if isinstance(body,list) else body);out=base/'outputs'/name
 cmd=[sys.executable,str(observer),str(repo),str(pdf),scope,str(out)];env=os.environ.copy();env.pop('QPDF_CACHE_DIRECTORY',None)
 p=subprocess.run(cmd,env=env,capture_output=True,text=True,timeout=40)
 props=dict(line.split('=',1) for line in (out/'result.properties').read_text().splitlines()) if (out/'result.properties').exists() else {}
 row={'case':name,'scope':scope,'input':str(pdf),'input-sha256':sha(pdf),'argv':cmd,'expected':expected,'actual':props.get('standards'),'matched':props.get('standards')==expected,'return-code':p.returncode,'result':props,'authority':authority,'output':str(out)}
 if origin:row['origin']=str(origin);row['origin-sha256']=sha(origin);assert sha(origin)==sha(pdf)
 rows.append(row);(base/(name+'.command.json')).write_text(json.dumps(row,indent=2));(base/(name+'.stdout.txt')).write_text(p.stdout);(base/(name+'.stderr.txt')).write_text(p.stderr)
 print(json.dumps({k:row[k] for k in ('case','expected','actual','matched')}),flush=True)
for manifest in ('summary.json','bounds-and-representation-summary.json'):
 for row in json.loads((prior/manifest).read_text())['rows']:
  original=Path(row['input']);run(row['case'],original.read_bytes(),row['expected'],row['scope'],row.get('authority',''),original)
summary={'observer-sha256':sha(observer),'identities-unchanged':identities=={str(p):sha(p) for p in paths},'rows':rows}
(base/'closure-summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps({'original-calls':len(rows),'matched':sum(r['matched'] for r in rows)}),flush=True)
# Fresh, independently authored namespace declaration cases. Empty hierarchy keeps full role resolution out of scope.
rows=[]
def ns_objects():
 return [b'<< /Type /Catalog /Pages 2 0 R /StructTreeRoot 4 0 R >>',b'<< /Type /Pages /Count 1 /Kids [3 0 R] >>',b'<< /Type /Page /Parent 2 0 R /MediaBox [0 0 100 100] /Resources <<>> >>',b'<< /Type /StructTreeRoot /K 5 0 R /Namespaces [6 0 R 7 0 R] >>',b'<< /Type /StructElem /S /Custom /P 4 0 R /NS 6 0 R >>',b'<< /Type /Namespace /NS (urn:spec:one) /RoleMapNS << /Custom [/P 7 0 R] >> >>',b'<< /Type /Namespace /NS (http://iso.org/pdf2/ssn) >>',b'null',b'(urn:spec:one)',b'/P']
def variant(number,old,new):
 v=ns_objects();assert old in v[number-1];v[number-1]=v[number-1].replace(old,new);return v
run('namespace-baseline',ns_objects(),'pass')
for label,number,old,new,expected in [
 ('required-ns-null',6,b'/NS (urn:spec:one)',b'/NS null','fail'),
 ('required-ns-indirect-null',6,b'/NS (urn:spec:one)',b'/NS 8 0 R','fail'),
 ('ns-indirect-string',6,b'/NS (urn:spec:one)',b'/NS 9 0 R','pass'),
 ('optional-type-null',6,b'/Type /Namespace',b'/Type null','pass'),
 ('element-ns-null',5,b'/NS 6 0 R',b'/NS null','pass'),
 ('element-ns-indirect-null',5,b'/NS 6 0 R',b'/NS 8 0 R','pass'),
 ('unlisted-element-identity',4,b'[6 0 R 7 0 R]',b'[7 0 R]','fail'),
 ('missing-namespace-list',4,b'/Namespaces [6 0 R 7 0 R]',b'','fail'),
 ('list-null-member',4,b'[6 0 R 7 0 R]',b'[6 0 R 7 0 R null]','fail'),
 ('list-indirect-null-member',4,b'[6 0 R 7 0 R]',b'[6 0 R 7 0 R 8 0 R]','fail'),
 ('role-destination-name',6,b'[/P 7 0 R]',b'/P','pass'),
 ('role-destination-indirect-name',6,b'[/P 7 0 R]',b'10 0 R','pass'),
 ('role-destination-array-first-indirect-name',6,b'[/P 7 0 R]',b'[10 0 R 7 0 R]','pass'),
 ('role-destination-integer',6,b'[/P 7 0 R]',b'0','fail'),
 ('role-destination-three-members',6,b'[/P 7 0 R]',b'[/P 7 0 R /Span]','fail'),
 ('role-destination-null-namespace',6,b'[/P 7 0 R]',b'[/P 8 0 R]','fail'),
 ('role-destination-direct-namespace',6,b'[/P 7 0 R]',b'[/P << /NS (urn:spec:target) >>]','fail'),
 ('custom-same-namespace',6,b'[/P 7 0 R]',b'[/Other 6 0 R]','pass'),
 ('standard-pdf2-same-namespace',6,b'(urn:spec:one)',b'(http://iso.org/pdf2/ssn)','fail'),
 ('root-map-bad-value',4,b'/K 5 0 R',b'/RoleMap << /Custom [ /P ] >> /K 5 0 R','fail'),
 ('root-map-indirect-name',4,b'/K 5 0 R',b'/RoleMap << /Custom 10 0 R >> /K 5 0 R','pass'),
 ('optional-ns-rolemap-null',6,b'/RoleMapNS << /Custom [/P 7 0 R] >>',b'/RoleMapNS null','pass')]:
 run(label,variant(number,old,new),expected,authority='PDF2 Tables354-356 and bounded namespace contract; full role resolution unclaimed')
# Predefined namespace name and array destinations.
v=ns_objects();v[5]=b'<< /NS (http://iso.org/pdf/ssn) /RoleMapNS << /Custom /P >> >>';run('standard-pdf17-name-destination',v,'fail',authority='Explicit standard namespace cannot remap directly to itself; a name target denotes default PDF1.7')
v[5]=b'<< /NS (http://iso.org/pdf2/ssn) /RoleMapNS << /Custom /P >> >>';run('standard-pdf2-to-default-name',v,'pass',authority='Name destination denotes another standard namespace, default PDF1.7')
v=ns_objects();v[6]=b'<< /NS (urn:spec:two) /RoleMapNS << /P [/Custom 6 0 R] >> >>';run('unknown-cross-namespace-cycle',v,'pass',authority='Finite declarations only; no assertion of transitive resolution or TaggedPDF conformance')
v=ns_objects();v[3]=b'<< /Type /StructTreeRoot /Namespaces [<< /NS (urn:spec:direct) >>] >>';run('unused-direct-declaration',v,'pass',authority='Root array declarations may be direct; element identifiers may not')
v=ns_objects();v[4]=b'<< /S /P /P 4 0 R /NS << /NS (urn:spec:one) >> >>';run('element-direct-namespace',v,'fail',authority='Table355 NS must be an indirect identity')
v=ns_objects();v[3]=b'<< /Type /StructTreeRoot /K 5 0 R /Namespaces [6 0 R] >>';run('unlisted-map-target-only',v,'pass',authority='Table354 array covers namespaces referenced by structure elements; no element references target7')
for number,label in ((6,'namespace-stream'),):
 v=ns_objects();v[number-1]=stream(dictionary=v[number-1][2:-2]);run(label,v,'fail')
v=ns_objects();v[3]=b'<< /Type /StructTreeRoot /RoleMap 11 0 R >>';v.append(stream(dictionary=b'/X /P'));run('root-rolemap-stream',v,'fail')
v=ns_objects();v[5]=b'<< /NS (urn:spec:one) /RoleMapNS 11 0 R >>';v.append(stream(dictionary=b'/X /P'));run('namespace-rolemap-stream',v,'fail')
for count in (1000,1001):
 v=ns_objects();v[3]=b'<< /Type /StructTreeRoot /Namespaces ['+b' '.join(b'<< /NS (urn:spec:n'+str(i).encode()+b') >>' for i in range(count))+b'] >>'
 run('namespace-nodes-'+str(count),v,'pass' if count==1000 else 'indeterminate',authority='1000 distinct namespace declaration nodes')
for count in (10000,10001):
 mapping=b' '.join(b'/R'+str(i).encode()+b' /P' for i in range(count));v=ns_objects();v[3]=b'<< /Type /StructTreeRoot /RoleMap << '+mapping+b' >> >>';run('root-only-map-entries-'+str(count),v,'pass' if count==10000 else 'indeterminate',authority='10000 total map entries includes RoleMap without Namespaces')
for extra in (0,1):
 v=ns_objects();a=b' '.join(b'/R'+str(i).encode()+b' /P' for i in range(4999));b=b' '.join(b'/Q'+str(i).encode()+b' /Span' for i in range(5000+extra))
 v[3]=b'<< /Type /StructTreeRoot /Namespaces [6 0 R 7 0 R] /RoleMap << /One /P >> >>';v[5]=b'<< /NS (urn:spec:first) /RoleMapNS << '+a+b' >> >>';v[6]=b'<< /NS (urn:spec:second) /RoleMapNS << '+b+b' >> >>'
 run('combined-map-entries-'+str(10000+extra),v,'pass' if extra==0 else 'indeterminate',authority='Combined root and per-namespace mapping count')
for source_pdf in sorted((repo/'capabilities/profiles/T13-text/fixtures').glob('*.pdf')):
 if source_pdf.name in ('nested-split-type3.pdf','marked-structure.pdf','embedded-font-kinds.pdf','embedded-font-inheritance.pdf','uncertain-geometry.pdf'):run('namespace-source-'+source_pdf.stem,source_pdf.read_bytes(),'pass',origin=source_pdf)
after={str(p):sha(p) for p in paths};(base/'identities-after.json').write_text(json.dumps(after,indent=2));(base/'namespace-summary.json').write_text(json.dumps({'observer-sha256':sha(observer),'identities-unchanged':identities==after,'rows':rows},indent=2));print(json.dumps({'directory':str(base),'namespace-calls':len(rows),'matched':sum(r['matched'] for r in rows),'identities-unchanged':identities==after}),flush=True)
