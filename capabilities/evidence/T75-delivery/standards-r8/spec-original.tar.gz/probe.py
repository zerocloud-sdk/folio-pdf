from pathlib import Path
import tempfile, json, re, struct, subprocess, hashlib, shutil
ROOT=Path('/home/ubuntu/IdeaProjects/open-pdf')
DEST=Path(tempfile.mkdtemp(prefix='t75-spec-font-bounds.'))
OBSERVER=ROOT/'scripts/t13-program-standards.py'
shutil.copyfile(OBSERVER,DEST/'observer.py'); shutil.copyfile(__file__,DEST/'probe.py')
ORIGINAL=(ROOT/'capabilities/profiles/T13-text/fixtures/embedded-font-kinds.pdf').read_bytes()
OBJECTS={int(m[1]):m[2] for m in re.finditer(rb'(?m)^(\d+) 0 obj\n(.*?)\nendobj\n',ORIGINAL,re.S)}
assert len(OBJECTS)==25

def integer(v):
 return b'\x1d'+struct.pack('>i',v)
def real(v):
 if isinstance(v,int): return integer(v)
 n=[10 if c=='.' else 14 if c=='-' else int(c) for c in v]+[15]
 if len(n)%2: n.append(15)
 return b'\x1e'+bytes(n[i]*16+n[i+1] for i in range(0,len(n),2))
def index(entries):
 if not entries: return b'\0\0'
 offsets=[1]
 for e in entries: offsets.append(offsets[-1]+len(e))
 width=1 if offsets[-1]<256 else 2
 return len(entries).to_bytes(2,'big')+bytes([width])+b''.join(n.to_bytes(width,'big') for n in offsets)+b''.join(entries)
def cmap_font(cid=False,topmatrix=None,fdmatrix=None):
 name=b'FolioT13RectangleCID' if cid else b'FolioT13RectangleCFF'
 names=index([name]); strings=index([b'Folio',b'T13']) if cid else index([])
 gsubrs=index([]); charset=b'\x00\x00'+(b'\x01' if cid else b'\x22')
 fdselect=b'\0\0\0'; cs=index([bytes.fromhex('f8880e'),bytes.fromhex('f8888b16f824f8ecfc24060e')]); private=bytes.fromhex('f88814')
 def top(offsets):
  result=integer(391)+integer(392)+integer(0)+bytes([12,30]) if cid else b''
  if topmatrix is not None: result+=b''.join(real(v) for v in topmatrix)+bytes([12,7])
  result+=b''.join(integer(v)for v in (0,0,400,600))+bytes([5])
  if cid: result+=integer(2)+bytes([12,34])+integer(offsets['fdselect'])+bytes([12,37])+integer(offsets['fdarray'])+bytes([12,36])
  else: result+=integer(len(private))+integer(offsets['private'])+bytes([18])
  return result+integer(offsets['charset'])+bytes([15])+integer(offsets['cs'])+bytes([17])
 offsets=dict.fromkeys(('charset','fdselect','fdarray','private','cs'),0)
 topindex=index([top(offsets)]); cursor=4+len(names)+len(topindex)+len(strings)+len(gsubrs)
 offsets['charset']=cursor; cursor+=len(charset)
 if cid: offsets['fdselect']=cursor; cursor+=len(fdselect)
 offsets['cs']=cursor; cursor+=len(cs); offsets['private']=cursor; cursor+=len(private); offsets['fdarray']=cursor
 fd=b'' if fdmatrix is None else b''.join(real(v)for v in fdmatrix)+bytes([12,7])
 fd+=integer(len(private))+integer(offsets['private'])+bytes([18]); fdarray=index([fd])
 return bytes.fromhex('01000404')+names+index([top(offsets)])+strings+gsubrs+charset+(fdselect if cid else b'')+cs+private+(fdarray if cid else b'')
def serial(objects):
 data=bytearray(b'%PDF-1.7\n%\xe2\xe3\xcf\xd3\n'); offsets=[0]
 for i in range(1,len(objects)+1):
  offsets.append(len(data)); data+=str(i).encode()+b' 0 obj\n'+objects[i]+b'\nendobj\n'
 start=len(data); data+=b'xref\n0 '+str(len(objects)+1).encode()+b'\n0000000000 65535 f \n'
 for offset in offsets[1:]: data+=f'{offset:010d} 00000 n \n'.encode()
 data+=b'trailer\n<< /Size '+str(len(objects)+1).encode()+b' /Root 1 0 R >>\nstartxref\n'+str(start).encode()+b'\n%%EOF\n'; return bytes(data)
def font_objects(program,cid,box):
 objects=dict(OBJECTS); stream_number=24 if cid else 22; subtype=b'CIDFontType0C' if cid else b'Type1C'; encoded=program.hex().encode()+b'>'
 objects[stream_number]=b'<< /Length '+str(len(encoded)).encode()+b' /Filter /ASCIIHexDecode /Subtype /'+subtype+b' >>\nstream\n'+encoded+b'\nendstream'
 descriptor=14 if cid else 12; objects[descriptor]=objects[descriptor].replace(b'/FontBBox [0 0 400 600]',b'/FontBBox '+box)
 return objects
cases=[]
variants=[('baseline',dict(OBJECTS),'pass')]
for label,box,expected in [('exact',b'[0 0 2040 3060]','pass'),('wide',b'[0 0 2041 3061]','pass'),('small',b'[0 0 2039 3059]','fail')]:
 variants.append(('cff-decimal-matrix-'+label,font_objects(cmap_font(topmatrix=('0.0051',0,0,'0.0051',0,0)),False,box),expected))
for label,box,expected in [('exact',b'[0 0 400 600]','pass'),('small',b'[0 0 399 599]','fail')]:
 variants.append(('cid-fd-only-'+label,font_objects(cmap_font(cid=True,fdmatrix=('0.001',0,0,'0.001',0,0)),True,box),expected))
variants.append(('cid-top-and-fd-exact',font_objects(cmap_font(cid=True,topmatrix=('0.001',0,0,'0.001',0,0),fdmatrix=(1,0,0,1,0,0)),True,b'[0 0 400 600]'),'pass'))
objects=dict(OBJECTS); objects[26]=b'0'; objects[13]=objects[13].replace(b'/FontBBox [0 0 400 600]',b'/FontBBox [26 0 R 0 400 600]'); variants.append(('ttf-indirect-bbox-coordinate',objects,'pass'))
for label,objects,expected in variants:
 pdf=DEST/(label+'.pdf'); pdf.write_bytes(serial(objects)); output=DEST/label; command=['python3',str(OBSERVER),str(ROOT),str(pdf),'fonts',str(output)]; done=subprocess.run(command,capture_output=True,timeout=25)
 (DEST/(label+'.stderr')).write_bytes(done.stderr); (DEST/(label+'.stdout')).write_bytes(done.stdout)
 record=dict(line.split('=',1)for line in(output/'result.properties').read_text().splitlines()); cases.append({'case':label,'command':command,'expected':expected,'exit':done.returncode,'input-sha256':hashlib.sha256(pdf.read_bytes()).hexdigest(),**record})
summary={'observer-sha256':hashlib.sha256((DEST/'observer.py').read_bytes()).hexdigest(),'observer-unchanged':OBSERVER.read_bytes()==(DEST/'observer.py').read_bytes(),'cases':cases}; (DEST/'summary.json').write_text(json.dumps(summary,indent=2)); print(DEST); print(json.dumps([{k:c[k]for k in('case','expected','standards','finding')}for c in cases],indent=2))
