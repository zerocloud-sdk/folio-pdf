from pathlib import Path
from io import BytesIO
from types import SimpleNamespace
import hashlib,json,re,subprocess,sys,time
ROOT=Path('/home/ubuntu/IdeaProjects/open-pdf')
HERE=Path(__file__).resolve().parent
SCRIPT=ROOT/'scripts/t13-program-standards.py'
WHEEL=ROOT/'.build-cache/t75-fonttools-4.59.2/fonttools-4.59.2-py3-none-any.whl'
assert hashlib.sha256(WHEEL.read_bytes()).hexdigest()=='8bd0f759020e87bb5d323e6283914d9bf4ae35a7307dafb2cbd1e379e720ad37'
sys.path.insert(0,str(WHEEL))
from fontTools.cffLib import CFFFontSet
SOURCE=ROOT/'capabilities/profiles/T13-text/fixtures/embedded-font-kinds.pdf'
ORIGINAL=SOURCE.read_bytes()
CFF=(ROOT/'capabilities/profiles/T13-fonts/FolioT13Rectangle.cff').read_bytes()
CIDCFF=(ROOT/'capabilities/profiles/T13-fonts/FolioT13RectangleCID.cff').read_bytes()
OBSERVER_SHA=hashlib.sha256(SCRIPT.read_bytes()).hexdigest()

def objects():
    result=re.findall(rb'(?m)^([0-9]+) 0 obj\n(.*?)\nendobj\n',ORIGINAL,re.S)
    assert [int(n) for n,b in result]==list(range(1,26))
    return [b for n,b in result]

def serialize(parts):
    result=bytearray(b'%PDF-2.0\n');offsets=[0]
    for n,body in enumerate(parts,1):
        offsets.append(len(result));result.extend(str(n).encode()+b' 0 obj\n'+body+b'\nendobj\n')
    xref=len(result)
    result.extend(b'xref\n0 '+str(len(offsets)).encode()+b'\n0000000000 65535 f \n')
    for offset in offsets[1:]:result.extend(('%010d 00000 n \n'%offset).encode())
    result.extend(b'trailer\n<< /Size '+str(len(offsets)).encode()+b' /Root 1 0 R >>\nstartxref\n'+str(xref).encode()+b'\n%%EOF\n')
    return bytes(result)

def indirect_box(elements):
    parts=objects()
    if elements:
        parts[11]=parts[11].replace(b'/FontBBox [0 0 400 600]',b'/FontBBox [26 0 R 0 400 600]')
        parts.append(b'0')
    else:
        parts[11]=parts[11].replace(b'/FontBBox [0 0 400 600]',b'/FontBBox 26 0 R')
        parts.append(b'[0 0 400 600]')
    return serialize(parts)

def missing_fdselect():
    assert CIDCFF.count(bytes.fromhex('0c25'))==1
    changed=CIDCFF.replace(bytes.fromhex('0c25'),bytes.fromhex('0c1f'))
    font=CFFFontSet();font.decompile(BytesIO(changed),None)
    assert 'FDSelect' not in font.topDictIndex[0].rawDict
    assert 'FDArray' in font.topDictIndex[0].rawDict
    return ORIGINAL.replace(CIDCFF.hex().encode(),changed.hex().encode())

def matrix_box(margin):
    font=CFFFontSet();font.decompile(BytesIO(CFF),None)
    top=font.topDictIndex[0]
    top.FontMatrix=[0.0011,0,0,0.0011,0,0]
    output=BytesIO();font.compile(output,SimpleNamespace(recalcBBoxes=False),isCFF2=False)
    data=output.getvalue()
    (HERE/'matrix-0011.cff').write_bytes(data)
    parts=objects()
    encoded=data.hex().encode()+b'>\n'
    parts[21]=b'<< /Subtype /Type1C /Filter /ASCIIHexDecode /Length '+str(len(encoded)).encode()+b' >>\nstream\n'+encoded+b'endstream'
    parts[11]=parts[11].replace(b'/FontBBox [0 0 400 600]',b'/FontBBox [0 0 '+(b'441' if margin else b'440')+b' 660]')
    parts[11]=parts[11].replace(b'/Ascent 600',b'/Ascent 660').replace(b'/CapHeight 600',b'/CapHeight 660').replace(b'/StemV 400',b'/StemV 440')
    for n in (4,5):parts[n]=parts[n].replace(b'/Widths [500]',b'/Widths [550]')
    return serialize(parts)

variants=[('original',ORIGINAL),('indirect-box-array',indirect_box(False)),('indirect-box-number',indirect_box(True)),
          ('missing-cid-fdselect',missing_fdselect()),('exact-decimal-matrix-box',matrix_box(False)),('margin-decimal-matrix-box',matrix_box(True))]
records=[]
for label,data in variants:
    pdf=HERE/(label+'.pdf');pdf.write_bytes(data);output=HERE/label
    cmd=[sys.executable,str(SCRIPT),str(ROOT),str(pdf),'fonts',str(output)]
    start=time.monotonic();proc=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=40)
    (HERE/(label+'.stdout')).write_bytes(proc.stdout);(HERE/(label+'.stderr')).write_bytes(proc.stderr)
    props=output/'result.properties'
    values=dict(line.split('=',1) for line in props.read_text().splitlines()) if props.exists() else None
    if values:
        assert values['input-sha256']==hashlib.sha256(data).hexdigest()
        assert values['observer-sha256']==OBSERVER_SHA
        assert values['qpdf-json-sha256']==hashlib.sha256((output/'qpdf.json').read_bytes()).hexdigest()
    row=dict(label=label,command=cmd,exit=proc.returncode,elapsed=round(time.monotonic()-start,3),input_sha256=hashlib.sha256(data).hexdigest(),observer_sha256=OBSERVER_SHA,result=values,stderr=proc.stderr.decode())
    records.append(row);print(json.dumps(row),flush=True)
assert OBSERVER_SHA==hashlib.sha256(SCRIPT.read_bytes()).hexdigest()
(HERE/'results.json').write_text(json.dumps(records,indent=2)+'\n')
