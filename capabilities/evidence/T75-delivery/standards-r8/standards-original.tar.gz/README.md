# FontBBox / Matrix incremental Standards probes

Scope: only changes since standards-r7/observer.py. No product files or Maven/shared targets were modified. All six CLI subprocesses completed within one second each. results.json retains the exact command, return code, stdout/stderr, input hash, observer hash and any result.properties fields; identity.json binds the script/probe/results. The observer stayed unchanged throughout.

The inputs are authored independently from the project's original PDF and font bytes. probe.py imports no product, fixture generator, or observer internals. FontTools 4.59.2 is loaded only from the repository's permitted wheel after the published SHA check, to serialize an original CFF Matrix variant; expected exact rectangle values are literal authoring arithmetic, not copied from checker output.

Results:
- Original input: PASS.
- Whole FontBBox array referenced as an indirect object: PASS.
- One FontBBox number referenced indirectly, [26 0 R 0 400 600] with object26=0: incorrectly FAIL. qpdf.json confirms the exact reference and target. ISO 32000-1 7.3.10 permits an indirect object as an array element; 7.9.5 rectangle operands have no direct-only restriction.
- CID CFF with FDSelect removed by replacing only operator 12 37 with 12 31 (CIDFontVersion): exit1, uncaught AttributeError: FDSelect, no result.properties. The new matrix path at observer.py:702 introduced this direct access. CFF 5176 section18 requires FDSelect, so this input needs a failure record instead of aborting result publication.
- Original CFF rectangle400x600 with Top FontMatrix[.0011 0 0 .0011 0 0] and PDF FontBBox[0 0 440 660]: incorrectly FAIL. The corresponding owning Widths, Ascent, CapHeight, StemV are also scaled. The matrix read back from the serialized program is exactly the intended .0011 decimal token. Its correct mathematical xmax is440, but the pinned floating API reports440.00000000000006.
- Same CFF matrix with FontBBox xmax441: PASS. This isolates the exact-boundary floating comparison from unavailable font syntax or parser errors.

Sources:
- https://developer.adobe.com/document-services/docs/assets/35e4369068f86065372c18787171a17e/PDF_ISO_32000-1.pdf (7.3.10; 7.9.5; 9.2.4; 9.8.1/Table122)
- https://adobe-type-tools.github.io/font-tech-notes/pdfs/5176.CFF.pdf (FontMatrix; CID FDSelect section18)
- docs/t13-certification.md (distinct independent results and qualified controls)

Reproduce any retained PDF with a fresh output directory:

```
python3 /home/ubuntu/IdeaProjects/open-pdf/scripts/t13-program-standards.py /home/ubuntu/IdeaProjects/open-pdf /tmp/t75-font-bbox-review-4iems05o/indirect-box-number.pdf fonts /tmp/t75-font-box-fresh-output
```

For all six, copy probe.py into a fresh directory and run it. An initial shell invocation accidentally named an unresolved PLACEHOLDER path and did not execute the observer; it is not counted among the six actual invocations or used as finding evidence.
