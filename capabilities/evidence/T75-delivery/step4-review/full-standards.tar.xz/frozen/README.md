# Folio PDF by ZeroCloud

> **Independent project:** Folio PDF by ZeroCloud is not affiliated with,
> endorsed by, or sponsored by LibrePDF OpenPDF or Apryse/iText.

Folio PDF is an Apache-2.0 Java component suite under the `net.zerocloud`
namespace. Its Native Interface is being built as a clean-room implementation
for Java 8 and is tested on JDK 8, 11, 17, and 21. The project is currently
experimental and has not published a Foundation Release.

T03 provides the complete trusted in-process Document Workflow transaction:
uniquely named Sources, an explicit primary Source, ordered named Path and
stream Targets, explicit Save Mode, cancellation, deadlines, sanitized
progress, stable failures, immutable execution outcomes, and one Publication
Receipt per Target. An immutable Workflow Environment owns deadline time.
PDFBox is an internal implementation dependency and is never part of the
public interface. T20 makes that profile finite by default with one shared
request/environment policy for input, page, object, nesting, decompression,
pixel, accounted owned-memory, temporary-storage, elapsed-time, and concurrency
limits. The policy is cooperative; hostile multi-tenant input still requires
the opt-in T21 Hardened Worker Profile, which is implemented for the documented
Linux/JDK support envelope. T22 adds optional environment-local transaction
identity and status lookup, bounded authenticated multi-frame values, public
modeled resource high-water marks, and generated 5,000-page, exact 1-GiB, and
configured-concurrency scale profiles. Recovery is finite and in-memory, not
durable or automatic.

T70 certifies `document.blank.create-publish-reopen` and promotes the 12 T04
lifecycle mappings into `pdf-migration-itext7`. Preview currently contains the
same mappings. The two artifacts are mutually exclusive. Certification is bound
to the candidate and Ubuntu/JDK identities in the [T03 certification contract](docs/t03-certification.md);
other Foundation obligations remain unfinished.

T72 certifies `document.page.manipulate-merge-split` and adds the bounded Stable
page, merger, and splitter Facade subset. Native certification covers actual
IN_PROCESS and HARDENED_WORKER execution on Ubuntu 24.04/Linux x86-64 with JDK
8, 11, 17, and 21; the Facade is recorded separately in its actual IN_PROCESS
mode. See [page manipulation](docs/page-manipulation.md) and the
[T10 certification contract](docs/t10-certification.md). The current
[Foundation Evidence inventory](capabilities/foundation-evidence.yaml) is the
candidate and environment authority. Other Foundation obligations still keep
global readiness at NOT READY.

T74 adds the matching 12-member Stable Annotation/Action mapping, inherited by
Preview: six Annotation families, bounded reads, resource-free AP/N, local
GoTo/event bindings and non-Widget flattening. The
[T12 contract](docs/t12-certification.md) defines independent original semantic,
standards and visual expectations and the eight actual Native-mode/JDK tuples;
the [usage guide](docs/annotations-actions.md) describes the public boundaries.

T05 establishes the Capability Provider contract for in-process Java, native
linkage, local subprocess, and explicitly authorized remote engines. The
default Workflow Environment registers no Provider, remains offline, and
performs no implicit network access. A generic bounded subprocess adapter is
included, but no external engine is bundled.

T23 adds the offline `Rendering` capability with a bundled PDFBox Renderer
fallback, versioned page Queries, configurable geometry and pixel profiles,
session-scoped PNG consumption, and shared resource limits in both execution
profiles. See [bounded page rendering](docs/rendering.md) for the public
contract, Provider integration, and experimental evidence boundary.

## Build

No system Maven installation is required. The wrapper uses Maven 3.9.16.
T29 tests require the separately installed HarfBuzz 10.2.0 helper. Prepare the
pinned source archive and native build tools using the
[explicit installation instructions](docs/harfbuzz-shaping.md#explicit-installation),
then select that installation for verification:

```sh
export FOLIO_HARFBUZZ_HELPER=/explicit/folio-harfbuzz-10.2.0/bin/folio-harfbuzz
./mvnw -B -ntp verify
```

Ordinary verification tests recorder behavior, including unavailable tools, but
does not run the T03/T09/T10/T11/T12 tests that require independently provisioned
acceptance tools. After installing the pinned tools documented in
[T03 certification](docs/t03-certification.md) and
[T11 certification](docs/t11-certification.md) and
[T12 certification](docs/t12-certification.md), run those tests explicitly:

```sh
./mvnw -B -ntp -Pindependent-certification -pl pdf-acceptance -am \
  -Dtest=T03EvidenceCommandTest,T09EvidenceCommandTest,T10EvidenceCommandTest,T10StandardsQualificationTest,T11EvidenceCommandTest,T11StandardsQualificationTest,T12EvidenceCommandTest,T12StandardsQualificationTest \
  -Dsurefire.failIfNoSpecifiedTests=false test
```

This profile requires the real tools; it has no missing-tool skip or fallback.
An ordinary build result is not independent certification. Candidate and
environment certification still uses the separate Foundation runner.

Run all opt-in generated T22 scale profiles with:

```text
./scripts/t22-scale all
```

Run the repository-owned container matrix with Podman:

```text
./scripts/verify-jdk-matrix.sh
```

Both commands compile shipped code for Java release 8. The local matrix runs
the same Maven verification contract on JDK 8, 11, 17, and 21.

The repository-only Acceptance Evidence path is separate from the normal
build and published artifacts. Supply the pinned release assets locally and
run the offline provisioners before recording evidence. T29 also uses the
explicit HarfBuzz installation above and a Python environment with fontTools
4.59.2 for independent embedded-subset checks:

```text
./scripts/provision-qpdf /path/to/qpdf-12.4.0-bin-linux-x86_64.zip
./scripts/provision-pdfium /path/to/pdfium-webassembly-linux-amd64
./scripts/provision-imagemagick /path/to/ImageMagick-7.1.2-30-gcc-x86_64.AppImage
export FOLIO_SHAPING_PYTHON=/absolute/python-with-fonttools-4.59.2
./scripts/acceptance /new/evidence-directory
```

This records qpdf syntax, project semantic, and PDFium/ImageMagick visual
findings for the same Document Workflow-produced PDF. PDFium is the independent
renderer; ImageMagick receives fixed-size PNG rasters only. The tools remain in
ignored local caches and never enter the normal Maven build, BOM, Native
Interface, or published artifacts. See
[capabilities/README.md](capabilities/README.md) for exact versions, hashes,
licenses and bundled-component notice manifests, the documented ID-neutral
input-hash policy, profile settings, output artifacts, and conservative
determination rules.

T29 records native glyph/cluster metrics, reopened semantic geometry, embedded
subsets, syntax and all eight fixed visual pages. The installed engine and
local chains do not certify Windows x86-64 or macOS x86-64/arm64. Those targets
are not required gates for Foundation 0.1.0 under
[ADR-0040](docs/adr/0040-certify-only-observed-foundation-environments.md).
Only actual Ubuntu 24.04/Linux x86-64 environments with JDK 8, 11, 17 and 21
are required, with exact image/JDK/native/tool identities and complete evidence.
See [Foundation readiness](docs/generated/foundation-readiness.md) and
[HarfBuzz shaping](docs/harfbuzz-shaping.md)
for selection, installation, execution-mode and migration contracts.

T30 records every one-dimensional barcode family in both execution profiles:
232 actual PDF and raster decodes, 230 label observations, independent
reference rasters, and pinned syntax/visual checks. The
[T30-only recording command](capabilities/README.md) protects existing evidence.
The capability remains experimental while standards and dependency gates
are incomplete.

Validate or regenerate the machine-readable compatibility inventories and
their cross-linked human-readable views with:

```text
./scripts/inventory validate
./scripts/inventory generate
```

The YAML authorities, state and evidence rules, exact output paths, and drift
contract are documented in
[capabilities/README.md](capabilities/README.md).

## Maven coordinates

All first-party artifacts use the `0.1.0-SNAPSHOT` Release Train. Consumers
select versions through `net.zerocloud:pdf-bom`. The BOM manages
`pdf-provider-contract`, `pdf-document`, `pdf-conversion`,
`pdf-migration-itext7`, and `pdf-migration-itext7-preview`.

```xml
<dependencyManagement>
  <dependencies>
    <dependency>
      <groupId>net.zerocloud</groupId>
      <artifactId>pdf-bom</artifactId>
      <version>0.1.0-SNAPSHOT</version>
      <type>pom</type>
      <scope>import</scope>
    </dependency>
  </dependencies>
</dependencyManagement>

<dependencies>
  <dependency>
    <groupId>net.zerocloud</groupId>
    <artifactId>pdf-document</artifactId>
  </dependency>
</dependencies>
```

Migration callers must select exactly one facade artifact. Use
`pdf-migration-itext7` for compatible mappings only, or use
`pdf-migration-itext7-preview` for all Stable mappings plus any experimental
mappings. The two surfaces are currently equal:

```xml
<!-- Stable: contains the 12 compatible document lifecycle mappings. -->
<dependency>
  <groupId>net.zerocloud</groupId>
  <artifactId>pdf-migration-itext7</artifactId>
</dependency>
```

```xml
<!-- Preview: currently exposes the same lifecycle surface as Stable. -->
<dependency>
  <groupId>net.zerocloud</groupId>
  <artifactId>pdf-migration-itext7-preview</artifactId>
</dependency>
```

Do not place both facade artifacts on one classpath. Every mapped
public class checks the packaged edition markers when initialized and fails
with an explicit conflict if both are present, independent of jar order.

The snapshot is not published to Maven Central yet. Build it locally before
using these coordinates from another project.

## Capability Providers

Applications register explicitly installed Provider adapters through the
immutable Workflow Environment. Registration order is deterministic; a
`ProviderPreference` either accepts the first eligible registration or names
one Provider ID. `WorkflowEnvironment.getProviderMetadata()` exposes only
immutable identity, capability, version, execution-mode, availability, limit,
license, and distribution facts—never executable Provider instances.

```java
import net.zerocloud.pdf.WorkflowEnvironment;
import net.zerocloud.pdf.provider.CapabilityProvider;

CapabilityProvider installedProvider = obtainInstalledProvider();
WorkflowEnvironment environment = WorkflowEnvironment.builder()
        .provider(installedProvider)
        .build();
```

A workflow request can make a capability-scoped preference. The resulting
`WorkflowOutcome.getProviderSelections()` reports the selected metadata. T05
selection does not itself invoke an engine; capability-specific modules invoke
the selected Provider at the real Provider seam.

Remote disclosure is absent by default and is never implied by registration
or preference. A workflow must call
`authorizeRemoteDisclosure(capabilityId)` for the same capability before a
remote Provider is eligible. Direct `ProviderRequest` execution has the same
explicit authorization gate. The deterministic remote tests use an in-memory
adapter and contact no network service.

`pdf-provider-contract` contains the project-owned metadata, request/result,
selection, execution, limit, and stable failure types. `pdf-conversion`
contains `SubprocessCapabilityProvider`, which launches a fixed argument list
without a shell, enforces input/output/time bounds, terminates stalled or
oversized processing, discards child diagnostics, and removes its private
per-run staging directory. It is not the Hardened Worker Profile and must not
be used as hard isolation for hostile multi-tenant input.

See the [Capability Provider guide](docs/capability-providers.md) for the
selection and subprocess protocol contracts and [SECURITY.md](SECURITY.md) for
the disclosure and isolation boundaries.

## Migration Facade

For a mapped surface, replace the package prefix `com.itextpdf.*` with
`net.zerocloud.pdf.itext7.*`. The lifecycle mapping supports this blank-document flow:

```java
import java.nio.file.Path;
import net.zerocloud.pdf.itext7.kernel.pdf.PdfDocument;
import net.zerocloud.pdf.itext7.kernel.pdf.PdfReader;
import net.zerocloud.pdf.itext7.kernel.pdf.PdfWriter;
import net.zerocloud.pdf.itext7.layout.Document;

Path output = java.nio.file.Paths.get("blank.pdf");

PdfDocument created = new PdfDocument(new PdfWriter(output.toString()));
Document layout = new Document(created);
created.addNewPage();
layout.close();

try (PdfReader reader = new PdfReader(output.toString());
        PdfDocument reopened = new PdfDocument(reader)) {
    if (reopened.getNumberOfPages() != 1) {
        throw new IllegalStateException("Expected one page");
    }
}
```

Closing a writing `PdfDocument` or its associated layout `Document` executes
the Native Interface transaction and returns only after the Path target has a
`COMMITTED` Publication Receipt. A reader failure is an `IOException` whose
safe message begins with the stable Document Failure code. Publication
failures are mapped to
`net.zerocloud.pdf.itext7.kernel.exceptions.PdfException`. The exact mapped
members and their limitations are generated from
[capabilities/facade-surface.yaml](capabilities/facade-surface.yaml).

The [PDF Values and Document Patches guide](docs/document-values.md) covers
Native ordered dictionary, array, value and stream edits, and the mapped kernel
value family. Reader/writer documents edit an existing Source through one Native
Session. Caller input/output streams stay open. T09 independent certification
remains separate from implementation and artifact verification; consult the
[current profile](capabilities/evidence/T09-document-value-inspection-patch.md).

## Document Workflow

```java
import java.nio.file.Path;
import java.nio.file.Paths;
import net.zerocloud.pdf.DocumentSource;
import net.zerocloud.pdf.DocumentWorkflow;
import net.zerocloud.pdf.PublicationTarget;
import net.zerocloud.pdf.SaveMode;
import net.zerocloud.pdf.WorkflowExecutionProfile;
import net.zerocloud.pdf.WorkflowOutcome;
import net.zerocloud.pdf.WorkflowRequest;
import net.zerocloud.pdf.command.AddBlankPage;
import net.zerocloud.pdf.query.PageCount;

Path output = Paths.get("blank.pdf");
DocumentWorkflow workflow = new DocumentWorkflow();

WorkflowRequest create = WorkflowRequest.builder()
        .target("primary-output", PublicationTarget.path(output))
        .saveMode(SaveMode.REWRITE)
        // Opt in for hostile-input process isolation; IN_PROCESS is the default.
        .executionProfile(WorkflowExecutionProfile.HARDENED_WORKER)
        .build();

workflow.execute(create, session -> {
    session.execute(AddBlankPage.INSTANCE);
    return null;
});

WorkflowRequest inspect = WorkflowRequest.builder()
        .source("published", DocumentSource.path(output))
        .primarySource("published")
        .saveMode(SaveMode.REWRITE)
        .build();

WorkflowOutcome<Integer> inspected = workflow.execute(
        inspect,
        session -> session.query(PageCount.INSTANCE));

if (inspected.getResult().intValue() != 1) {
    throw new IllegalStateException("Expected one page");
}
```

Use `DocumentSession.executeBatch(...)` when several ordered Commands should
cross a Hardened Worker boundary together. Fixed-size page-structure batches
whose complete encoder, retained-payload, cross-process payload, and completion-
control peak fits the parent's current message and aggregate owned-memory
bounds are offered by encoded length and may cross in one atomic frame when the
Worker accepts their current modeled-memory cost. Every other, parent-
ineligible, or Worker-deferred batch uses one authenticated count declaration
followed by indexed preflight, detail, and Command requests, each issued only
after its predecessor succeeds. The parent therefore does not encode a later
one-shot input or lazy value after an earlier failure. Both forms have one
logical completion. A following Query remains an ordering barrier and observes
the completed batch prefix; ordinary `execute(...)` delegates its singleton
batch through the same selection.

Every execution uses `WorkflowResourcePolicy.safeDefaults()` unless its
`WorkflowRequest` supplies a complete immutable override or its shared
`WorkflowEnvironment` supplies a different finite default. All named Sources,
Session operations, staged/split products, and publication Targets continue
the same transaction counters. Exact boundaries succeed and the first excess
produces a stable `DocumentFailure`; cancellation, deadlines, and elapsed time
are checked cooperatively inside project-owned bounded work. Configure the
environment-owned temporary root for service deployments. See the
[trusted in-process hostile-input policy](docs/hostile-input-policy.md) for
the exact defaults, accounting model, and failure/receipt behavior.

The T21/T22 [Hardened Worker guide](docs/hardened-worker.md) documents the
authenticated closed protocol, callback/query ordering, parent-owned Source
and Target adapters, exact classpath authority, INET and Unix-domain network
denial, filesystem/process controls, cleanup, stable Worker failures,
count- and per-record-bounded transaction retention and retry rules, target-specific uncertainty, bounded
multi-frame transport, controlled scale profiles, configuration, supported
Linux/JDK envelope, and explicit non-certification boundaries. Selecting the
profile never silently falls back to in-process execution. Remote Capability
Providers remain parent-brokered and separately require Remote Disclosure
Authorization.

The Native Interface uses only `net.zerocloud.pdf` and JDK types. Sources may
be Paths, caller-owned streams, caller-owned channels, or bounded bytes.
Targets may be Paths or caller-owned streams. Caller-owned resources are never
closed.

`REWRITE` publishes a complete replacement. `INCREMENTAL` requires an existing
primary Source, preserves all Source bytes as an unchanged prefix, and appends
a non-empty revision for commands in the version-1 policy. Each
successful or partially attempted publication reports Targets in declaration
order as `COMMITTED`, `FAILED`, or `NOT_ATTEMPTED`; there is no
cross-Target atomicity, and a failed stream may contain partial output.
Operational failures use checked `DocumentFailure` values with stable codes,
safe diagnostics, and available per-Target receipts.

Existing signatures are protected conservatively: signed Sources remain
available to target-free queries, cannot be republished with `REWRITE`, and
reject mutation unless a sole coherent DocMDP P=3 policy permits a supported
non-Widget `UpdateAnnotations` command. Ordinary signatures and DocMDP P=1 or
P=2 permit no current mutation. See the authoritative
[incremental publication and Existing Signature guide](docs/incremental-signature-policy.md).

The Document Engine also exposes backend-neutral PDF Values and validated
Document Patches (T09), page manipulation/merge/split (T10), document
metadata/outlines/destinations/attachments (T11), and supported annotations
and inert local GoTo Actions (T12). T12 covers Text, Stamp, Highlight,
FileAttachment, standalone Widget, and Link annotations; bounded queries;
resource-free normal appearances; non-form flattening; and destination-aware
move, copy, merge, split, and removal behavior. It never executes an Action,
and unsupported Action graphs are preserved only when no semantic rewrite is
required or rejected before mutation. See the authoritative
[annotations and document Actions guide](docs/annotations-actions.md) for the
exact allowlist, appearance operators, Forms boundary, failure policy,
page-operation rules and the 12-member Stable/Preview Annotation mapping, and [page manipulation](docs/page-manipulation.md) for the
six Native Commands and the bounded Stable Migration Facade mapping. The
[metadata, navigation and attachments guide](docs/metadata-navigation.md)
defines the T11 Native and Stable Migration Facade contracts.

T13 adds the bounded `ExtractTextAndStructure` Document Query. Its detached
results retain deterministic page/content execution order, unrotated page-
space geometry, exact source-code bytes with explicit mapping confidence,
marked-content nesting and MCIDs, and Tagged PDF hierarchy, role resolution,
language inheritance, Alt, and ActualText. Missing and contradictory Unicode
mappings remain uncertain and diagnostic; no reading order, whitespace, OCR,
font-program guess, unbounded page-tree or content-array traversal, font-
program decode, encoding or width-array traversal, CID width materialization,
malformed explicit Unicode destination, or unbounded `ToUnicode` range
expansion is accepted. See the
[text and logical-structure guide](docs/text-logical-structure.md) for the
coordinate system, ordering, all mandatory limits, safe failures, and the
version-1 unsupported cases. The #75 working implementation includes the six
matching read-only Facade members described there; independent qualification
and Stable manifest promotion remain pending.

T14 adds the bounded `ExtractImagesAndResources` Document Query. Its detached
inventory walks effective page and nested Form resources deterministically,
keeps existing indirect Object References while giving direct declarations no
fabricated identity, and reports declaration-reachable page usage. Image
records classify dimensions, color spaces, filters and effective decoding
parameters, explicit, subsidiary, and JPX-embedded masks, and encoded/decoded
availability; explicitly selected available bytes are bounded, defensive, and
usable after the Session closes. Valid bounded ICCBased profiles additionally
expose their stream identity, decoded byte length, and SHA-256.
Font records expose BaseFont, embedding, subset, declaration, and page-usage
information. See the authoritative
[image and resource extraction guide](docs/image-resource-extraction.md) for
ordering, identity, byte lifecycle, all mandatory limits, safe failures, and
the version-1 unsupported cases.

T17 adds the immutable `CanvasProgram` under
`net.zerocloud.pdf.composition` and the page-targeted `DrawCanvas` command
under its `command` subpackage for low-level vector paths and explicitly
positioned encoded glyphs. It covers
lines, cubic curves, stroke, both fill and clipping winding rules, affine
transforms, nested graphics state, all eight text rendering modes, and reuse
of an existing Session-owned Font resource. See the authoritative
[Canvas vector and positioned-text guide](docs/canvas-vector-positioned-text.md)
for the closed state machine, coordinates, resource rules, limits,
preservation proof, publication policy, and downstream exclusions.

T18 extends that seam with `CanvasProgram.version2()` and mandatory
`CanvasResourceLimits`: bounded JPEG pass-through, PNG/TIFF normalization to
8-bit DeviceRGB, raw samples, same-Session existing-image borrowing, Device,
calibrated and ICCBased fill/stroke color, explicit and soft masks, alpha,
standard blend modes, and reusable transparency groups. Optional TIFF support
is discoverable through a project-owned Query. See the authoritative
[Canvas images, color, and transparency guide](docs/canvas-images-colors-transparency.md)
for the exact format/filter matrix, ownership, reuse, accounting, failure,
preservation, and codec-availability contracts.

T19 adds a separate `DrawPositionedUnicodeText` command for deterministic unshaped
Unicode text backed only by caller-supplied `FontSource` declarations or an
explicit, declaration-ordered `ReferenceFontSet` in the Workflow Environment.
Version 1 supports bounded standalone quadratic TrueType programs, strict
primary-first fallback, embedding permissions, subsetting or documented full
embedding, source metrics, ToUnicode, and same-Session resource reuse. The
four non-clipping text modes are supported; clipping modes are rejected. The
offline defaults contain no fonts and never scan installed fonts or resolve a
network source. See the authoritative
[explicit font loading and positioned Unicode text guide](docs/font-loading.md)
for API use, ownership, the closed format matrix, exact limits, stable
failures, publication policy, evidence status, and exclusions.

T30 adds `Barcode1D`, optional explicit-font `BarcodeText`, and
`DrawBarcode1D.version1` for all Reference Suite one-dimensional families:
Code128/GS1/raw and function variants, Code39/Full ASCII, Codabar, retail
EAN/UPC and supplements, ITF, MSI, POSTNET and PLANET. Bars are PDF vectors;
dimensions, checksums, labels and affine placement are explicit. Both Workflow
profiles are supported. See the [barcode contract](docs/one-dimensional-barcodes.md)
and [fixed T30 profile](capabilities/profiles/T30-one-dimensional-barcodes.md).
The capability remains experimental while standards and dependency gates are open.

T31 adds immutable `Barcode2D`, `DrawBarcode2D.version1` and
`MeasureBarcode2D.version1` for QR, DataMatrix ECC200 and PDF417. Symbols use
shared vector Form XObjects, with strict character encoding/ECI, explicit ECC,
compaction, size, typed control headers, color and affine placement. Both
Workflow profiles are supported. See the
[two-dimensional barcode contract](docs/two-dimensional-barcodes.md) and
[fixed T31 profile](capabilities/profiles/T31-two-dimensional-barcodes.md).
Independent standards certification and compatible-status dependency gates
remain open; the capability is experimental.

Successful `WorkflowOutcome` values identify the capability, the actual
selected execution profile, the selected Save Mode, safe diagnostics, and every Target
receipt, plus any declaration-ordered Capability Provider selections. They
also report the optional Workflow Transaction Identity and detached Folio-
owned resource high-water observations. Identified Worker workflows can query
their environment-local `RUNNING`, `RECOVERABLE`, `COMPLETED`, or `FAILED`
status and ordered receipts through `DocumentWorkflow.lookupTransaction`.
Final and mismatched identities fail before callback or publication; possibly
partial streams are final and never replayed. A
deterministic deadline Clock is configured through
`WorkflowEnvironment.withClock(clock)` or `WorkflowEnvironment.builder()` and
supplied when constructing a workflow; `DocumentWorkflow` does not accept a
raw Clock.

Callers moving from the T01 request factories should follow the
[0.x T03 migration note](docs/migrations/0.x-t03-document-workflow.md): every
factory call now receives an explicit `SaveMode`.

## Project information

- Repository: <https://github.com/zerocloud-sdk/folio-pdf>
- Issue tracker: <https://github.com/zerocloud-sdk/folio-pdf/issues>
- Temporary public and security contact: <mabaiqiu@gmail.com>
- License: [Apache License 2.0](LICENSE)
- Chinese usage guide: [docs/zh-CN/getting-started.md](docs/zh-CN/getting-started.md)
- Contribution and clean-room rules: [CONTRIBUTING.md](CONTRIBUTING.md)
- Dependency licenses: [DEPENDENCIES.md](DEPENDENCIES.md)

The authoritative specifications, Javadoc, ADRs, and capability records are in
English. Translations are usage guidance and defer to those English contracts.

T03 certification uses independently provisioned pdfcpu and Arlington checkers in the acceptance boundary.
See [the pinned tool setup and certification commands](docs/t03-certification.md).
