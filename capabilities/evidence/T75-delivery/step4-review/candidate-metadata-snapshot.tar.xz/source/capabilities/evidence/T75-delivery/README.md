# T75 extraction delivery evidence

Issue: [#75](https://github.com/zerocloud-sdk/folio-pdf/issues/75).
Fixed implementation and review baseline:
`5b1603c435f11c40368f75b7b9a2777c9c5e9761`.

This directory preserves development observations and independent review
history. The frozen public contract is [T13 certification](../../../docs/t13-certification.md).
Candidate-specific certification is governed by the separate
[Foundation evidence authority](../../foundation-evidence.yaml).
Development PASS records, historical archives and synthetic collector protocol
fixtures do not certify a later candidate.

The original baseline passed the focused Native extraction CI suites on all
four JDKs but failed the inventory generated-readiness check in all four jobs.
That failure was reproduced locally and remains part of the delivery history;
the baseline full build is not represented as passing.

The main evidence groups are:

- `encoding-independent-review`, `facade-independent-review` and
  `corpus-independent-review`: public behavior, frozen member set and original
  corpus review.
- `font-corpus-r1` and `font-corpus-r2`: original embedded-font qualification.
- `standards-r1` through `standards-r12`: independently reviewed declaration,
  font-program, content and logical-structure predicates and retained controls.
- `semantic-controls-r1` and `visual-controls-r1`: source-derived defects and
  separate independent graph and raster expectations.
- `recorder-r1` through `recorder-r5`: original production, original-byte
  retention, tool/publication identity and whole-run evidence qualification.
- [recorder-r6](recorder-r6/README.md): public Foundation collector RED/GREEN
  history, detailed four-chain checks and independent review closure.
- [step4-review](step4-review/README.md): complete review against the fixed
  baseline, optional-declaration fixes, public regressions and candidate
  sequencing review.

Each archive identity file records the original location, archive digest and
member digests. Archive retention compared every member byte-for-byte with its
original source. Local paths in original logs and receipts are preserved as
historical observations. The corresponding archives retain their original
bytes even after the local temporary directories are removed.

Final candidate certification, complete validation and fresh Standards and Spec
reviews are separate delivery gates. The authorized DCO commit, push and issue
closure require all of them to pass; development evidence cannot replace them.
