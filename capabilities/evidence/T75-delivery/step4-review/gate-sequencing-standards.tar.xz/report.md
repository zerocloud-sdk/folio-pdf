**允许这一候选冻结顺序，但不能把 `compatible` 当作无证据占位。** 原 Goal 的 Step 4 明确先完成独立资格及 inventory/contract 同步，Step 5 才冻结、stage 并收集最终认证；没有要求提前再跑一套八组合 raw。见 [原 Goal:48](/home/ubuntu/.codex/attachments/77353239-0dda-4ee1-b4bb-ce7fb3fa0f9b/pasted-text-1.txt:48)。

`compatible` 必须已有真实四条 mandatory chain 的 PASS、兼容依赖及实质关闭的 promotion gates；这依据 [状态规则:305](/home/ubuntu/IdeaProjects/open-pdf/capabilities/README.md:305) 和 [ADR-0011](/home/ubuntu/IdeaProjects/open-pdf/docs/adr/0011-make-the-capability-matrix-the-coverage-authority.md:3)。现有资格记录只有实际覆盖的范围，不能补写或预测缺失 PASS。当前行为修复、公开 GREEN 和独立发现闭环仍须先完成。

可把最终平台列表随未提交候选一并冻结，作为等待全部八组合验证的候选声明；它不能被报道为已经获得环境认证。最终认证权威仍须依据实际环境、候选和全部控制/工具/身份记录填入 `foundation-evidence.yaml`，符合 [ADR-0040](/home/ubuntu/IdeaProjects/open-pdf/docs/adr/0040-certify-only-observed-foundation-environments.md:3)。候选声明只有最终成功后才能成为交付声明；失败不得标记完成或提交/推送/关闭。

这一顺序保留现有设计：Matrix/Facade/profile 被纳入 contract hash，而可变 evidence index 排除以避免自引用，见 [身份契约:101](/home/ubuntu/IdeaProjects/open-pdf/docs/foundation-readiness.md:101)。静态阅读确认 recorder 先读取 provisional index 的身份，所有八组合成功且身份未变后才发布观察索引。无需降低 readiness/validation 门槛。

可以澄清本任务新写的 T13 开头，分别说明已有行为证据支持候选状态、最终环境认证尚待八组合；不能改变 ADR 或认证要求。任何冻结后影响身份的编辑仍须刷新证据。未运行测试/认证或修改项目文件；本判断不认证既有资格结果，也不勾选完成标准。
