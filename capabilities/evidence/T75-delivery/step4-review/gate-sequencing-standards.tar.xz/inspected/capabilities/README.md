# Compatibility inventories

Folio PDF keeps separate behavioral and Facade YAML authorities, with a
source-traceable Foundation obligation, environment and evidence inventory.
The checked-in YAML is
normative; files below `docs/generated/` are deterministic views and must
never be edited by hand.

## Commands

Validate both authorities and every referenced repository file:

```text
./scripts/inventory validate
```

Regenerate the human-readable views:

```text
./scripts/inventory generate
```

The outputs are:

- `docs/generated/capability-matrix.md`
- `docs/generated/facade-surface.md`
- `docs/generated/foundation-readiness.md`

Run `./scripts/inventory readiness` for the Foundation 0.1.0 release result.
Any missing required behavior, compatible dependency, independent evidence,
exact Ubuntu/JDK environment or Stable Facade mapping returns nonzero.
`validate` and normal `verify` may pass while Foundation remains not ready.
See [the evidence and identity contract](../docs/foundation-readiness.md).

For candidate-bound T03, T09, T10, T11, T12 and T13 four-chain certification, use the isolated
runner described by the [transaction](../docs/t03-certification.md),
[values](../docs/t09-certification.md), [page](../docs/t10-certification.md),
[metadata](../docs/t11-certification.md), [annotation](../docs/t12-certification.md)
and [text](../docs/t13-certification.md)
contracts. Older aggregate records retain their historical identities and cannot
certify a later candidate.

Record the historical built-in T03 blank-document, T18 Canvas-image, T19 explicit-font,
T23 rendering, T24 paragraph-composition, T25 advanced-pagination,
T26/T27 table composition/pagination, seven T28 Unicode, four T29 shaping,
and T30 one-dimensional barcode
Acceptance Profiles with the pinned external syntax validator, independent
renderer, raster comparator, and project semantic assertions:

```text
./scripts/provision-qpdf /path/to/qpdf-12.4.0-bin-linux-x86_64.zip
./scripts/provision-pdfium /path/to/pdfium-webassembly-linux-amd64
./scripts/provision-imagemagick /path/to/ImageMagick-7.1.2-30-gcc-x86_64.AppImage
export FOLIO_HARFBUZZ_HELPER=/explicit/folio-harfbuzz-10.2.0/bin/folio-harfbuzz
export FOLIO_SHAPING_PYTHON=/absolute/python-with-fonttools-4.59.2
./scripts/acceptance /new/evidence-directory
```

To record only T30 into a fresh directory, use the same three provisioned
external tools and the repository-only Maven profile:

```text
./mvnw -B -ntp -pl pdf-acceptance -am -Pacceptance-t30-record -DskipTests \
  -Dacceptance.output=/new/t30-evidence-directory verify
```

T30 generates 116 public Workflow pages per execution profile and an
independent reference PDF from ZXing/GS1/USPS module expectations. All 232
product pages undergo independent PDF-path and actual PDFium-raster decoding;
230 captions are checked against literal content and independently read Noto
font metrics. Every pair of 288-DPI product/reference rasters is compared with
ImageMagick AE at zero fuzz and a zero-pixel threshold. The recorder retains
PDFs, actual/reference/difference PNGs, observed geometry, raw tool findings,
tool identities, source and artifact hashes. It refuses to replace existing
T30 evidence and does not require HarfBuzz or fontTools. Missing required tools
remain indeterminate. Independent standards evidence and compatible-status
dependency gates remain open, so this capability is experimental. See the
[T30 profile](profiles/T30-one-dimensional-barcodes.md) and
[delivery record](evidence/T30-one-dimensional-barcodes.md).

Provisioning is deliberately offline. The operator supplies each release
asset locally; none of these commands downloads it. For qpdf,
`scripts/provision-qpdf` verifies the official 12.4.0 Linux x86-64 archive at SHA-256
`a3bca240f3bb61efdc3a90be89d1da4ed5e125326c3458c4e62df53ff4f153e3`
and verifies the extracted `bin/qpdf` SHA-256
`9ac787a28597e8428289a12ba3fedafd74bdfb4b4da1be814722faf76f14f21b`
before placing it in the ignored `.build-cache/qpdf/12.4.0` directory.
`scripts/qpdf-pin.properties` is the single operational pin authority and
also fixes the repository wrapper path consumed by the canonical command.

The PDFium renderer is the MIT-licensed pdfium-cli v0.11.2 WebAssembly Linux
x86-64 release containing BSD-3-Clause PDFium Chromium build 7881. Its direct
executable release asset has both distribution and executable SHA-256
`3ef3375c429ce665e834f933a028225bf28ac837695aaa69c6fc21facf6780ab`.
The ImageMagick 7.1.2-30 GCC x86-64 AppImage is under the ImageMagick License;
its direct executable release asset has both distribution and executable
SHA-256
`372af8a3fd61ef5f15c6331cde3e21f840eb165d8b533f34ed05d68736dd682e`.
`scripts/pdfium-pin.properties` and `scripts/imagemagick-pin.properties` are
their operational authorities and pair each distribution identity with its
repository wrapper. The exact linked modules and bundled components are
recorded in the pinned
[PDFium](../docs/third-party/pdfium-cli-v0.11.2.md) and
[ImageMagick](../docs/third-party/imagemagick-7.1.2-30-appimage.md) notice
manifests. The provisioners verify the supplied asset, reported version, and
executable hash before placing it under the ignored `.build-cache/` tree. The
wrappers recheck digest markers and executable hashes and never search `PATH`
for a fallback.

The normal build, published artifacts, and inventory commands neither download
nor require qpdf, pdfcpu, Arlington, PDFium, or ImageMagick. Missing, unreadable,
incorrectly versioned, digest-unmarked, or unqualified tools record the
applicable chain as `indeterminate`, never `pass`.

T20 and T21 currently record implementation evidence only. Neither adds an
acceptance artifact to `scripts/acceptance` or claims an independent syntax,
standards, semantic, or visual chain. Their Capability Matrix states therefore
remain `experimental`, irrespective of repository, isolation, protocol, and
cross-JDK test results.

The acceptance command creates the blank PDF through
`DocumentWorkflow.execute`, computes its ID-neutral input SHA-256, runs
`qpdf --check` on the unmodified artifact, and then reopens that same artifact
through the public workflow to assert the committed one-page sequence and
readable object graph; text order is not applicable because the profile emits
no text. The input hash replaces only the two hexadecimal trailer `/ID` values
with ASCII zeroes before hashing. This preserves reproducible evidence
metadata while honoring issue #1's explicit exclusion of byte-identical PDF
output; every other PDF byte remains hash-significant, and the file handed to
qpdf and PDFium is never normalized or rewritten. A repeat-run command test
requires the T06/T07 records and raw findings to reproduce exactly. The command
also drives the T10 page/merge/split, T11 metadata, T12 annotation/Action,
T13 text/structure, T14 image/resource, T15 incremental-publication, and T16
version/password-security
profiles to create paired
project-owned products and runs the same pinned qpdf syntax check on each.
The T13 producer also evaluates the
finished in-Session state through `ExtractTextAndStructure` before publication;
its tagged product includes MarkInfo, page StructParents, a ParentTree, and
bidirectional structure-parent links. The T14 producer similarly evaluates a
filtered image and subset font plus a
nested Form and soft mask through `ExtractImagesAndResources`. The T15 pair is
one public-workflow original and its two-page appended revision; the producer
requires exact original-prefix retention, a non-empty suffix, a committed
receipt, and public reopen before qpdf sees both unchanged files. These
implementation probes are not recorded as independent semantic chains.
The T16 pair is a public-workflow PDF 1.7 ADBE Extension Level 8 product and a
PDF 2.0 product, both using the secure V=5/R=6 AESV3 default. The producer
reopens each with user and owner credentials before qpdf runs `--check` plus
`--show-encryption`. qpdf receives the user credential through a temporary
password file that is deleted after inspection; the recorded invocation hides
its path and password-valued tool output is replaced with `<redacted>`.
The T17 producer appends two Canvas Programs to a project-authored page and
retains the unchanged result as one artifact covering lines, a cubic curve,
stroke, both fill and clip winding rules, an affine transform, nested graphics
state, all eight text rendering modes, explicit glyph matrices, Font resource
reuse, and preservation of existing content and resources. Pinned qpdf checks
that unchanged artifact for syntax. A distinct project-test producer reopens
it through public Folio PDF queries and compares project-owned semantic
expectations without using PDFBox as an oracle.
The T18 producer appends a version-2 Canvas Program to project-authored
existing content and resources. Its one unchanged artifact covers JPEG, PNG
alpha, single-image TIFF, raw and borrowed existing images; Device,
calibrated, and ICCBased fill/stroke color; explicit and soft masks; alpha,
Multiply blend mode, reusable isolated Transparency Groups, resource reuse,
and preservation. Pinned qpdf checks syntax, a distinct project-test producer
reopens it through T09/T14 public queries, and PDFium/ImageMagick supplies the
independent visual chain. The optional TwelveMonkeys TIFF provider is a direct
repository-acceptance runtime so this artifact always exercises the available
codec path.
The T19 producer uses only two project-authored, hash-pinned TrueType fixtures
configured as a Reference Font Set. Its unchanged artifact exercises strict
primary-first A/U+03A9/B fallback, embedding, subsetting, source widths,
ToUnicode extraction, and repeated resource reuse. Pinned qpdf checks syntax,
a distinct project-test producer reopens it through public T13/T14 and bounded
inspection APIs, and PDFium/ImageMagick supplies the independent visual chain
without consulting host fonts.
The command records tool identity, version and distribution digest, exact or
documented ID-neutral input SHA-256 values, raw findings, chain-level results,
and the applicable determination beneath the requested
output directory. qpdf is syntax evidence only: its success is not a PDF
standards-conformance result and cannot satisfy the independent standards,
semantic, or visual chains.

For ordinary rewrite products, the ID-neutral policy requires exactly one
two-value trailer `/ID`. T15 may contain an `/ID` in more than one revision, so
its revision-aware policy replaces every hexadecimal two-value trailer `/ID`
with equal-length ASCII zeroes before hashing. Every other byte remains
hash-significant, and normalization is never applied to a qpdf input.

AES-256 authentication entries, identifiers, and ciphertext are intentionally
randomized, so T16 records a reproducible SHA-256 of the non-secret public
version, handler, scope, permission, and page-count observation instead of
claiming byte-identical encrypted output. The encrypted files handed to qpdf
are not normalized or rewritten. This observation hash is an input-identity
policy for the syntax run, not independent semantic or cryptographic proof.

For T07, PDFium receives that exact workflow-produced PDF and renders its one
effective MediaBox page at 144 DPI into an opaque sRGB RGB PNG of exactly
`1224x1584` pixels. The project-owned profile at
`capabilities/profiles/T03-document-blank-visual.properties` fixes the page
box, color, font and antialiasing policies, dimensions, expected-raster hash,
ImageMagick AE metric with fuzz `0%`, and zero-pixel capability and renderer-
agreement thresholds. The expected raster is a project-defined all-white
image; it is not Reference Suite output.

With the pinned ImageMagick asset provisioned, its exact bytes reproduce with:

```text
./scripts/container-bin/imagemagick -size 1224x1584 xc:'#ffffff' -colorspace sRGB -alpha off -type TrueColor -depth 8 -strip PNG24:capabilities/expected/T03-document-blank-144dpi-srgb.png
```

The resulting SHA-256 is
`c7bbf03603aee1dba4ef80c9eee9abb93b7f3adfb94b84e4abf0203d78f89011`.

T18 uses the same page box, 144 DPI, opaque sRGB RGB PNG dimensions, pinned
tools, and zero-fuzz AE metric. Its profile is
`capabilities/profiles/T18-canvas-images-colors-transparency-visual.properties`.
The project-owned, visually reviewed PDFium expected raster is
`capabilities/expected/T18-canvas-images-colors-transparency-144dpi-srgb.png`,
SHA-256
`4027a0a929494c49051a3039be5bd1c06d2a6624ba7c161acb8c1bfe0780024a`.
The authoritative PDFium comparison threshold is AE `0`. The secondary
PDFBox-renderer disagreement ceiling is AE `2500` (less than 0.13 percent of
the 1,938,816-pixel raster), accommodating bounded renderer color-management
and antialiasing variation while still forcing review above that fixed
capability-specific tolerance. ImageMagick HDRI decimal AE values are parsed
exactly rather than rounded.

T19 uses the same dimensions, color policy, tools, AE-0 authority threshold,
and 2,500-pixel secondary renderer-review ceiling. Its profile is
`capabilities/profiles/T19-font-loading-embedding-subsetting-visual.properties`.
The project-owned, visually reviewed PDFium expected raster is
`capabilities/expected/T19-font-loading-embedding-subsetting-144dpi-srgb.png`,
SHA-256
`d5a0c880a7a58bd0de6a1b7e887b6fe6b5a73f14608355434ee8cf022eb04a31`.
Its font policy permits only the two embedded project-authored subsets and
forbids system-font participation.

The harness validates PNG structure, dimensions, color type, and decodability
before comparison. ImageMagick receives raster paths only and produces
reviewable red/white difference artifacts. A threshold mismatch is `fail`.
Apache PDFBox Renderer 3.0.8 supplies a secondary raster only to detect
implementation-renderer disagreement; disagreement is review-required and
`indeterminate`, never `pass`. Unexpected tool results, invalid metrics,
missing difference output, or unusable rasters are also `indeterminate`.

`./scripts/inventory check` validates the authorities and fails if either
generated file is missing or stale. The repository root command
`./mvnw -B -ntp verify` invokes that check through the internal
`pdf-inventory-tool` build module. The tool is skipped for Maven install and
deploy and is not part of the Native Interface, BOM, or published product
artifacts.

## Capability Matrix schema

`capability-matrix.yaml` is the behavioral authority. Its top level fixes
`schema-version`, `release-train`, and the literal authority
`behavioral-capability`. Each capability requires:

- a unique lowercase `id` and owning `context`;
- a summary and Reference Suite source/role that identify the inventory input
  without treating another implementation as an oracle;
- at least one Native Interface mapping;
- exact `stable` and `preview` facade-surface ID lists;
- limitations, Dependency Gates, promotion gates, and certified platforms;
- one uniquely identified Acceptance Profile, implementation `evidence`, independent
  `acceptance-evidence`, provenance, and one declared state.

Repository paths are relative, use forward slashes, cannot escape the
repository lexically or through symbolic links, and must name existing regular
files. Unknown schema fields, duplicate identifiers, and mismatched release
trains fail validation. The inventory Release Train must also equal the project
version declared by the repository root `pom.xml`.

Every Dependency Gate has `capability` and `required-status: compatible`.
Targets must exist, the dependency graph must be acyclic, and a `compatible`
or `limited` capability cannot pass while a required capability is not
`compatible`.

## Capability states and evidence

Every Acceptance Profile declares the mandatory independent evidence chains.
`syntax`, `standards`, `semantic`, and `visual` are always mandatory; `human`
is additionally mandatory where the profile requires human review. Each
recorded chain has one result (`pass`, `fail`, or `indeterminate`) and its own
repository evidence record plus a versioned producer `kind`, `name`, and
`version`. Syntax, standards, and visual chains require external-tool
producers; semantic chains require project-test producers; human chains
require human-review producers. Independent chains cannot share a producer
name or canonical record, and cannot reuse an implementation or profile file
through an alternate relative spelling or in-repository symbolic link.

Profile evidence records carry exact `Status`, `Capability`, and
`Acceptance Profile` and `Release train` metadata. Independent chain records
carry exact `Capability`, `Acceptance Profile`, `Profile record`,
`Release train`, `Chain`, `Result`, and producer metadata. Each metadata label
must occur exactly once. Validation rejects missing, duplicate, or conflicting
metadata and values that disagree with the Capability Matrix.

| State | Required evidence | Claims and gates |
| --- | --- | --- |
| `planned` | No implementation evidence, Acceptance Evidence, or evidence record. | No certified platform claim. Future mandatory chains are still declared. |
| `experimental` | At least one implementation evidence item and an evidence record. Acceptance chains may be absent, partial, failing, or indeterminate. | No certified platform claim. Open Dependency or promotion gates may remain. |
| `compatible` | Implementation evidence plus `pass` records for every mandatory Acceptance Evidence chain. Implementation tests alone are insufficient. | Every Dependency Gate is `compatible` and no promotion gate remains open. |
| `limited` | The same complete mandatory Acceptance Evidence required for `compatible`. | At least one explicit limitation, every Dependency Gate is `compatible`, and no promotion gate remains open. |

The Acceptance Profile `state` must equal the capability `status`. Promotion is
conservative: complete evidence permits a state but never automatically
changes it.

## Facade Surface Manifest schema

`facade-surface.yaml` is the source-surface authority. It fixes the same schema
version and Release Train and uses the literal authority
`migration-source-surface`. Each unique stable surface ID records:

- Reference Suite type, member descriptor, and source relationship status;
- Folio PDF type and member mapping;
- generic and exception contracts;
- one or more behavioral capability IDs;
- stable or preview availability through its containing list.

Stable surfaces may reference only `compatible` capabilities. Preview surfaces
may reference only `compatible` or `experimental` capabilities. A surface
cannot appear in both lists. These are disjoint availability tiers: the Stable
artifact exposes the `stable` list, and the Preview artifact exposes the union
of `stable` and `preview`. Preview may have no additions; it still contains every
Stable mapping. Stable currently contains 139 entries and Preview has no
additions. The T70 lifecycle family contributes 12 entries; T72 contributes 17
page, merger, and splitter entries; and T73 contributes 34 metadata, outline,
destination, and attachment entries.

Reference types must be below `com.itextpdf.*`. Their Folio PDF types must
preserve the exact suffix below `net.zerocloud.pdf.itext7.*`, so the declared
mapping remains eligible for mechanical import-prefix replacement.
`reference.status` is `direct` by default, `adapted` when the declared Folio
shape intentionally differs, or `folio-extension` when Folio adds coordination
surface within a public Reference namespace. A Folio extension records no
invented Reference member.

The Capability Matrix facade ID lists and manifest references must agree
exactly. Every capability must either have at least one corresponding surface
or one explicit `excluded-capabilities` entry with a ticket and reason; it
cannot have both. This rule gives every generated capability entry an accurate
facade backlink while every generated surface or exclusion links to its
behavioral capability.

## Authority boundaries

The Capability Matrix answers whether behavior has the required evidence. The
Facade Surface Manifest answers which migration source shapes exist. A method
mapping without passing behavioral evidence is not compatible, and behavioral
coverage without a surface entry does not lower source-migration effort.
Generated Markdown is review material, not a third authority.

The T02 validator and generator evidence is recorded in
`capabilities/evidence/T02-inventory-authorities.md`.

The current T06 syntax and semantic, T07 visual, and overall records are
`capabilities/evidence/T06-document-blank-syntax.md`,
`capabilities/evidence/T06-document-blank-semantic.md`,
`capabilities/evidence/T07-document-blank-visual.md`, and
`capabilities/evidence/T06-document-blank-determination.md`. Syntax and
semantic pass for their shared artifact, and visual passes against that same
PDF. Standards evidence is absent, so the overall profile remains
`indeterminate` and the capability remains `experimental`.

T10 has separate aggregate syntax, standards, semantic, and visual records at
`capabilities/evidence/T72-pages-{syntax,standards,semantic,visual}.md`. The
Foundation inventory binds those claims to each exact candidate, configuration,
Ubuntu/JDK identity, execution profile, eight Native/Facade products, raw report,
and real negative control. The aggregate records alone cannot certify a later
candidate. T10 is `compatible`; the unfinished Foundation obligations listed by
`./scripts/inventory readiness` remain release blockers.

T11 has separate aggregate syntax, standards, semantic, and visual records at
`capabilities/evidence/T73-metadata-{syntax,standards,semantic,visual}.md`.
The Foundation inventory binds those claims to the exact candidate, four
Ubuntu/JDK identities, both Native execution profiles, eight Native products,
the separately exercised IN_PROCESS Facade products, qualified tools, raw
reports, and real negative controls. Use the
[T11 certification contract](../docs/t11-certification.md) and
`scripts/t03-foundation.py --obligation metadata` to reproduce that routing;
transactions, values, and pages must be refreshed for the same candidate. T11
is `compatible` and contributes 34 Stable Migration Facade entries.

The T12 through T16 profiles have one passing qpdf syntax record for each pair
of public-workflow products. Their mandatory standards, semantic, and visual
Acceptance Evidence chains remain absent. T17 has passing syntax and
project-owned semantic records, while its mandatory standards and visual
chains remain absent. T18 has passing syntax, project-owned semantic, and
independent visual records, while its mandatory standards chain remains
absent. Their Dependency Gates remain open while prerequisites are
`experimental`; none is promoted beyond `experimental`. T19 likewise has
passing syntax, project semantic, and independent visual records, while its
mandatory standards chain and T13/T14/T17 compatible-status Dependency Gates
remain open.

The T08 release-gate evidence is recorded in
`capabilities/evidence/T08-secure-maven-central-rehearsal.md`. T08 validates a
non-publishing Maven Central rehearsal and protected production staging
contract. It does not add a behavioral capability, Native Interface member, or
Migration Facade surface, so the Capability Matrix and Facade Surface
authorities remain unchanged.

## T23 public Rendering acceptance

The same `scripts/acceptance OUTPUT_DIRECTORY` command now records T23 page
rendering plus the reused T18 image/color/transparency and T19 embedded-font
corpora. T23 invokes the production `DocumentWorkflow.execute` / `RenderPage`
Query and consumes `RenderedPage` PNG bytes; the acceptance-only
`ImplementationRenderer` remains an auxiliary producer for older tickets.
PDFium receives `--render-annotations` to match T23's SHOW policy.

The three `profiles/T23-*-visual.properties` authorities pin the ID-neutral
PDF input hash, expected raster hash, page/box/DPI/scale/rounding, opaque white
sRGB output, annotation policy, diagnostic set, and fixed thresholds. The
existing tool pin authorities supply exact versions and artifact hashes. A
mismatched input, missing tool, or unresolved renderer disagreement cannot
pass. The [T23 evidence](evidence/T23-page-rendering.md) retains original tool
results and both expected and renderer difference PNGs, and lists the open
formal evidence, dependency, and promotion gates. The status is experimental.

## T24 paragraph composition acceptance

The same acceptance command records a mixed paragraph flowing through two
explicit areas on page 1 and onto page 2, using only the two hash-pinned T19
project fonts. The [T24 record](evidence/T24-paragraph-composition.md) defines
hand-calculated glyph and graphic geometry, a `0.0001`-point tolerance, and
both 144-DPI sRGB page profiles. Each page requires PDFium/ImageMagick AE `0`;
secondary PDFBox disagreement is bounded separately at AE `2500`.

Generate into an independent temporary directory to preserve existing evidence:

```sh
t24_output=$(mktemp -d)
./scripts/acceptance "$t24_output"
```

This produces both the actual paragraph PDF and a separate reference PDF
positioned directly from `T24ParagraphExpectations` through T19/Canvas. The
reference never invokes paragraph layout. Its expected rasters reproduce with:

```sh
./scripts/container-bin/pdfium render "$t24_output/artifacts/T24-paragraph-composition-reference.pdf" "$t24_output/reference-page-1.png" --dpi 144 --file-type png --pages 1
./scripts/container-bin/pdfium render "$t24_output/artifacts/T24-paragraph-composition-reference.pdf" "$t24_output/reference-page-2.png" --dpi 144 --file-type png --pages 2
```

Their SHA-256 values must equal the two `T24-*-visual.properties` authorities
before adopting a regenerated expected image. Retain only the T24 records and
artifacts for this capability. Negative controls verify that moved geometry
and deleted text fail the independent semantic oracle; missing pinned tools
produce indeterminate chains. Standards, compatible-status dependencies and
Foundation font/platform certification remain open.


T25 records twelve independent paragraph pagination profiles, each with two
selected pages: indentation, tabs (six field-placement variants), keep-with-next,
keep-together, widows, orphans, WRAP/REJECT/VISIBLE overflow, buffered relayout,
immediate flush and post-publication rejection. The numeric oracle is
`T25ParagraphExpectations`; reference PDFs are authored by positioned-text
commands without invoking paragraph composition. Every glyph, page box, text
sequence, advance and baseline is checked after reopening the actual product.
Each page pins 144 DPI, opaque white sRGB, its expected raster SHA-256, AE 0
with zero fuzz, and the existing secondary-renderer agreement bound of 2500.
The [T25 profile record](evidence/T25-paragraph-pagination.md) links every
independent chain and describes the outstanding standards and platform gates.
The `--reference DIRECTORY` form of `T25ParagraphEvidenceCommand` regenerates
only the hand-positioned PDFs; it does not adopt actual layout output as a golden.


## T26 bounded table acceptance

The same `scripts/acceptance OUTPUT_DIRECTORY` command records three pages:
fixed point/percentage/AUTO column widths, content-driven automatic widths,
and a complete grid with rowspan and colspan. The
[T26 profile record](evidence/T26-table-composition.md) links passing syntax,
semantic and visual chains while retaining the open standards, dependency and
Foundation typography/platform gates.

`T26TableExpectations` fixes every scalar and cell-border rectangle before
actual table rendering. Its reference producer invokes AddBlankPage, T19
positioned text and Canvas, and never invokes table layout. Profiles require
144 DPI, opaque-white sRGB, 1224x1584 pixels, zero-fuzz AE 0 and at most 2500
secondary changed RGB pixels. All three page comparisons are mandatory.

Use a fresh output directory to preserve earlier ticket evidence:

```sh
t26_output=$(mktemp -d)
./scripts/acceptance "$t26_output"
./scripts/container-bin/pdfium render "$t26_output/artifacts/T26-table-composition-reference.pdf" "$t26_output/reference-page-1.png" --dpi 144 --file-type png --pages 1
```

Repeat the reference render with pages 2 and 3. The three hashes must equal
`profiles/T26-table-composition-page-*-visual.properties` before adopting any
regenerated expected image. The `--reference OUTPUT.pdf` mode of
`T26TableEvidenceCommand` authors only the independent reference. Negative
controls move geometry, remove text or alter border color on each page; missing
pinned tools remain indeterminate. Retain only T26 outputs for this capability.

## T27 table pagination acceptance

The same recorder also produces nineteen T27 pages covering FIXED/AUTO
pagination, split rows, continued spans, repeated and omitted headers/footers,
keeps, buffered relayout, VISIBLE overflow, unsplittable rows, and incremental
flush before all rows arrive. The [T27 contract](../docs/table-pagination.md)
declares every breakpoint, scalar position and inside-border rectangle.
`T27TableExpectations` supplies those independent values; the reference producer
uses only AddBlankPage, positioned text and Canvas. Its nineteen expected PNG
hashes are pinned in `profiles/T27-table-pagination-page-*-visual.properties`.

Use a new temporary directory with `./scripts/acceptance OUTPUT_DIRECTORY`
and retain only T27 outputs for this ticket. The separate
`T27TableEvidenceCommand --reference OUTPUT.pdf` form authors only the reference;
render pages 1 through 19 with the pinned PDFium wrapper. Expected images are
never copied from actual paginator output. All nineteen pages require the
predeclared 144-DPI opaque-white sRGB profile, zero-fuzz AE 0, zero changed RGB
pixels and the separate secondary-renderer bound of 2500. Missing tools remain
indeterminate. The [T27 delivery record](evidence/T27-table-pagination.md)
tracks actual chain results and the outstanding compatibility gates.

## T28 Unicode composition acceptance

The recorder produces seven profiles using the complete pinned static Noto
fonts: Latin, Greek, Cyrillic, CJK SC, TC, JP and KR. The
[reference declaration](profiles/T28-unicode-reference.md) fixes logical input,
visual order, clusters, lines, font selection and all thresholds before the
implementation is run. The offline `scripts/t28-unicode-reference.py NEW_DIRECTORY`
command uses fontTools 4.59.2 and original source metrics to write an independent
PDF directly; it uses neither Folio composition nor ICU.

Run `./scripts/acceptance NEW_OUTPUT_DIRECTORY` and retain only T28 outputs.
All seven pages require the fixed 0.0001-point geometry tolerance, 144-DPI
opaque-white sRGB, zero-fuzz AE 0, zero changed primary RGB pixels and at most
12,000 secondary changed pixels. Public observers also reject displaced marks,
reversed RTL letters, the wrong regional font and shifted geometry. The
[delivery record](evidence/T28-unicode.md) links syntax, semantic, geometry,
visual and verification evidence. Missing tools remain indeterminate; shaping,
full Foundation font/platform certification and compatibility promotion remain
outside this ticket's demonstrated evidence.

## T29 explicit native shaping acceptance

The [frozen four-script reference](profiles/T29-shaping-reference.md) fixes
Arabic, Hebrew, Devanagari and Thai before product comparisons. Official
HarfBuzz 10.2.0 `hb-shape` supplies source GIDs, UTF-16 clusters, direction and
signed advances/offsets. A separate fontTools/raw-PDF writer supplies the eight
reference pages without calling the product adapter or layout engine.

Use the [explicit native installation procedure](../docs/harfbuzz-shaping.md)
and export the two executable paths shown above. The same acceptance entry
records five behavior chains (`native`, `semantic`, `syntax`, `subsets`,
`visual`) and a separate `installation` traceability record. Every page keeps
the original 0.0001-point geometry tolerance, 144-DPI opaque-white sRGB,
zero-fuzz AE 0 primary threshold and 3000 changed-pixel secondary limit. No
expected value comes from a product recording.

The installation observer verifies the installer receipt, source and actual
artifact hashes. On Linux it starts the explicit helper, records live
`/proc/PID/maps` files and hashes, then closes that probe without shaping.
This separate startup observation uses the inherited loader environment; it
does not inspect each Workflow subprocess. Changed helper/engine bytes fail.
`LD_PRELOAD` or `LD_AUDIT` can interpose symbols, so those environments remain
INDETERMINATE even if the expected library is mapped. Missing Python, malformed
or incomplete receipts, and unavailable observations cannot produce PASS.

The recorder states Worker applicability and completed mode coverage. A
missing required Linux Worker keeps the IN_PROCESS artifact but leaves
combined product evidence INDETERMINATE. The existing other-platform Worker
exclusion records its original T29 scope. For Foundation 0.1.0, ADR-0040
requires actual Ubuntu 24.04/Linux x86-64 JDK 8/11/17/21 evidence; Windows
x86-64 and macOS x86-64/arm64 remain uncertified and are not required release
gates. The current observer and pinned raster-tool assets are Linux-specific;
installation alone supplies no execution certification. The historical
[T29 delivery record](evidence/T29-shaping.md) retains its original findings,
and the Foundation obligation inventory governs subsequent #93 certification.

The `acceptance-t29-record` Maven profile is the dedicated platform entry:

```sh
./mvnw -B -ntp -pl pdf-acceptance -am -Pacceptance-t29-record \
  -DskipTests -Dacceptance.output=/new/t29-evidence verify
```

Use `mvnw.cmd` on Windows with host-specific absolute executable/output paths.
This profile keeps current dependencies in the reactor and records only T29.
The canonical acceptance command still records T29 with the other suites.
No Windows or macOS execution is claimed from these instructions.
