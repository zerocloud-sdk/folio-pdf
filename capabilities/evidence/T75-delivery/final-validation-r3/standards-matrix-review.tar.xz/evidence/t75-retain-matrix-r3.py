"""Operational retention of one completed r3 matrix; never executes validation."""
from collections import Counter
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import shutil
import sys
import tempfile
import xml.etree.ElementTree as ET
import yaml

sys.dont_write_bytecode = True
root = Path('/home/ubuntu/IdeaProjects/open-pdf')
destination = root / 'capabilities/evidence/T75-delivery/final-validation-r3'
prefix = Path('/tmp/t75-final-jdk-matrix-r3')


def read_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


result_path = Path(str(prefix) + '-result.json')
assert result_path.is_file(), 'Matrix has not completed; leave its reports untouched'
result = json.loads(result_path.read_text())
assert result['returncode'] == 0, result
assert result['command'] == ['./scripts/verify-jdk-matrix.sh'], result
log_path = Path(str(prefix) + '.log')
log = log_path.read_text()
parts = re.split(r'^==> Verifying Folio PDF on JDK ', log, flags=re.M)[1:]
assert len(parts) == 4
runs = []
last_rows = []
for expected, part in zip((8, 11, 17, 21), parts):
    assert part.startswith(str(expected) + ' ('), part[:200]
    header = part.splitlines()[0]
    assert '@sha256:' in header
    rows = re.findall(r'Tests run: (\d+), Failures: (\d+), Errors: (\d+), Skipped: (\d+).* -- in ([\w.]+)', part)
    totals = [sum(int(row[i]) for row in rows) for i in range(4)]
    assert totals == [1504, 0, 0, 4], (expected, totals)
    assert len(rows) == 87, (expected, len(rows))
    assert re.findall(r'BUILD (SUCCESS|FAILURE)', part) == ['SUCCESS']
    modules = re.findall(r'^\[INFO\] Folio PDF .* SUCCESS .*$', part, flags=re.M)
    assert len(modules) == 10, (expected, modules)
    assert not re.search(r'^\[ERROR\]', part, flags=re.M)
    native = [row for row in rows if row[-1] == 'net.zerocloud.pdf.consumer.TextStructureExtractionWorkflowTest']
    assert len(native) == 1 and native[0][:4] == ('115', '0', '0', '0')
    runs.append({'jdk-major': expected, 'header': header, 'test-totals': dict(zip(('tests', 'failures', 'errors', 'skipped'), totals)),
                 'class-results': len(rows), 'reactor-results': modules, 'build-result': 'SUCCESS'})
    last_rows = rows

foundation = read_module('foundation_retention_inputs', root / 'scripts/t03-foundation.py')
contract = yaml.safe_load((root / 'capabilities/foundation-release.yaml').read_text())
frozen_inputs = json.loads((destination / 'source-and-contract-inputs.json').read_text())
assert foundation.capture_build_inputs(root, contract) == frozen_inputs
host = json.loads((destination / 'host-full-verify-receipt.json').read_text())
reports = []
xml_rows = []
skipped = []
for item in host['reports']:
    path = root / item['path']
    assert path.is_file(), path
    reports.append({'path': item['path'], 'sha256': digest(path)})
    if path.name.startswith('TEST-') and path.suffix == '.xml':
        suite = ET.parse(path).getroot()
        xml_rows.append(tuple(suite.attrib.get(k, '0') for k in ('tests', 'failures', 'errors', 'skipped')) + (suite.attrib['name'],))
        properties = {p.attrib['name']: p.attrib['value'] for p in suite.findall('./properties/property')}
        assert properties['java.specification.version'] == '21', (path, properties.get('java.version'))
        for case in suite.findall('testcase'):
            if case.find('skipped') is not None:
                skipped.append({'report': item['path'], 'class': case.attrib['classname'], 'method': case.attrib['name'],
                                'message': case.find('skipped').attrib.get('message', '')})
assert Counter(xml_rows) == Counter(last_rows)
assert len(reports) == 177 and len(xml_rows) == 87 and len(skipped) == 4
helper = Path(result['explicit-environment']['FOLIO_HARFBUZZ_HELPER'])
assert digest(helper) == host['helper-sha256']
assert not (destination / 'jdk-matrix.tar.xz').exists()
original = Path(tempfile.mkdtemp(prefix='t75-final-jdk-matrix-r3-green-'))
for source in (log_path, Path(str(prefix) + '-command.json'), result_path, destination / 'source-and-contract-inputs.json'):
    shutil.copyfile(source, original / source.name)
    assert digest(source) == digest(original / source.name)
for item in reports:
    target = original / item['path']
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(root / item['path'], target)
    assert digest(target) == item['sha256']
receipt = {'command': result['command'], 'actual-command-result': result, 'result': 'pass', 'runs': runs,
           'original-log': str(log_path), 'original-log-sha256': digest(log_path),
           'source-and-contract-inputs-unchanged': True, 'source-input-count': len(frozen_inputs['inputs']),
           'contract-input-count': len(frozen_inputs['contract-inputs']), 'helper-sha256': digest(helper),
           'retained-jdk21-reports': reports, 'skipped-cases': skipped,
           'report-boundary': 'The serial matrix overwrites shared Maven reports. These 177 retained original reports are from the final JDK21 run; all 87 XML suite results exactly match that run in the complete log. Earlier per-JDK XML reports are not claimed as separately retained.',
           'skip-boundary': 'Three unselected opt-in Worker scale tests and one unselected T30 offline raster test remain skipped. Independent text tool qualification and final certification are separate gates.'}
(original / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
retention = read_module('t75_existing_retention', root / 'capabilities/evidence/T75-delivery/recorder-r4/retain-programs.py')
retention.destination = destination
identity = retention.archive('jdk-matrix', original)
(destination / 'jdk-matrix-archive-identity.json').write_text(json.dumps(identity, indent=2) + '\n')
(destination / 'jdk-matrix-receipt.json').write_bytes((original / 'receipt.json').read_bytes())
for source in (log_path, Path(str(prefix) + '-command.json'), result_path):
    shutil.copyfile(source, destination / source.name)
    assert digest(source) == digest(destination / source.name)
Path('/tmp/t75-final-matrix-r3-original-path.txt').write_text(str(original) + '\n')
print('All four JDK runs pass; actual outer exit 0; 177 final JDK21 reports retained; inputs unchanged:', original)
