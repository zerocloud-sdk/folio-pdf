# T75 validation after Worker batch-test closure

The independent six-file Worker batch correction and full 126-case development
regression are retained in `../worker-batch-timeout`. This directory records
fresh complete validation of those reviewed source and contract identities.
The preceding inventory generate, validate and check commands all passed.

`source-and-contract-inputs.json` freezes the 1,933 source and 30 contract
inputs before the new complete host verification. The host Java version and
original inventory commands, logs, exits and hashes are retained separately.
The new complete host run passed: 1,504 tests, zero failures, zero errors and
four existing opt-in skips, with actual process exit 0 and all ten reactor
modules successful. `host-full-verify.tar.xz` retains the original command,
output, process receipt and 177 report files; its archive identity and receipt
record byte verification and unchanged source and contract inputs. The four-JDK
matrix is now running against those same inputs. A fresh candidate and actual
48-tuple certification remain pending. Earlier successful runs in
`../final-validation` retain their original pre-split input identities.
