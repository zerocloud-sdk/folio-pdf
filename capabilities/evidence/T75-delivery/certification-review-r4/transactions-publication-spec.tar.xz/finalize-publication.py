from reviewlib import *
context=obj(BASE/'context.json');inspection=obj(BASE/'actual-publication-inspection.json');closure=obj(BASE/'stdout-routing-diagnostic-closure.json');schema=obj(BASE/'actual-publication-schema-inspection.json')
eq(schema['errors'],[],'command original schema gate');eq(closure['errors'],[],'stdout routing narrow closure');eq(closure['remaining-findings'],[],'no unresolved finding')
eq(inspection['errors'],closure['original-two-diagnostics'],'original diagnostic history remains exact')
eq(sha(BASE/'actual-publication-inspection.json'),closure['original-inspection']['sha256'],'original publication inspection unchanged')
run_names=['inspect-publication-result.json','audit-publication-result.json','stdout-routing-closure-result.json'];runs=[]
for name in run_names:
 r=obj(BASE/name);eq(r['returncode'],1 if name=='audit-publication-result.json' else 0,'actual original reader result '+name)
 for stream in ['stdout','stderr']:eq(sha(BASE/r[stream]['path']),r[stream]['sha256'],'retained original complete '+stream+' '+name)
 runs.append({'path':name,'sha256':sha(BASE/name),'returncode':r['returncode'],'disposition':'Two extra stdout-duplication reader requirements, closed by the separate routing inspection' if r['returncode'] else 'completed'})
for key in ['transactions-actual-outer-exit','transactions-eight-exact-publication','existing-text-eight-preservation']:eq(inspection['approvals'][key],True,key+' observed')
for key in ['values-or-other-obligations','all48-inventory-index-delivery','completion-criteria-marked']:eq(inspection['approvals'][key],False,key+' excluded')
authority=inspection['current-authority-observation'];eq(sha(BASE/authority['copy']),authority['sha256'],'dated captured current authority bytes retained')
seen={}
for path in sorted(BASE.glob('*-read-identities.json')):
 for r in obj(path):
  if r['path'] in seen:eq(r,seen[r['path']],'same inspected original across readers '+r['path'])
  seen[r['path']]=r
for row in seen.values():
 if row['path']==authority['original']:
  eq(row['sha256'],authority['sha256'],'mutable authority observation was captured exactly')
  continue
 value=read(Path(row['path']));eq({'path':row['path'],'bytes':len(value),'sha256':digest(value)},row,'unchanged inspected immutable original '+row['path'])
copy_rows=schema['copies']+obj(BASE/'selected-publication-copy-identities.json')+[closure['exact-source-routing']['copy']]
for row in copy_rows:
 value=read(BASE/row['copy']);eq(digest(value),row['sha256'],'exact selected original copy '+row['copy']);eq(len(value),row['bytes'],'selected copy size '+row['copy'])
require(not errors,'Unresolved publication finalization inconsistency '+str(errors[:2]))
catalog=sorted(files.values(),key=lambda r:r['path'])
for row in catalog:
 if row['path']==authority['original']:row['observation-boundary']='Mutable authority path; exact bytes are the retained current-observation snapshot. Later additions are permitted and not compared as immutable source.'
save('complete-inspected-input-identities.json',catalog)
draft=read(BASE/'publication-report-draft.md');words=len(draft.decode().split());require(words<400,'Report must be under 400 words')
with (BASE/'report.md').open('xb') as h:h.write(draft)
components=[{'path':n,'sha256':sha(BASE/n)} for n in ['actual-publication-schema-inspection.json','actual-publication-inspection.json','stdout-routing-diagnostic-closure.json']]
receipt={'reviewer':'/root/final_spec','axis':'Spec','sealed-utc':now(),'scope':context['scope'],'baseline':context['baseline'],'candidate':CID,'contract':TID,'actual-command':inspection['actual-command'],'actual-result':inspection['actual-result'],'complete-original-log-sha256':inspection['complete-original-log-sha256'],'original-command-retention':{'directory':schema['original-directory'],'count':10,'archive':inspection['original-command-archive'],'archive-member-identities':{'path':'actual-command-archive-member-identities.json','sha256':sha(BASE/'actual-command-archive-member-identities.json')}},'actual-stored-suite-transcripts':closure['actual-stored-suite-transcripts'],'actual-outer-log-protocol':closure['actual-full-outer-log'],'dated-authority':inspection['dated-authority'],'current-authority-observation':authority,'own-transactions-index-sha256':inspection['own-index-sha256'],'preserved-text-index-sha256':inspection['preserved-text-index-sha256'],'exact-reviewed-published-subsets':{'transactions':8,'text':8},'record-count':inspection['record-count'],'configuration-count':inspection['configuration-count'],'records-and-report-bindings':inspection['checked-records-and-reports'],'configuration-bindings':inspection['checked-configurations'],'observed-environment-bindings':inspection['environment-observations'],'current-staged-input-counts':inspection['current-staged-input-counts'],'actual-Facade-mode':inspection['actual-Facade-mode'],'closed-raw-review':inspection['closed-raw-review'],'raw-qualification-replayed':False,'five-file-source-review-repeated':False,'complete-inspected-input-identities':{'path':'complete-inspected-input-identities.json','sha256':sha(BASE/'complete-inspected-input-identities.json'),'paths':len(catalog)},'selected-original-copies':{'count':len(copy_rows),'total-files-under-originals':sum(p.is_file() for p in (BASE/'originals').rglob('*')),'whole-raw-tree-duplicated':False},'completed-components':components,'actual-original-reader-results':runs,'reader-diagnostics':{'original':'actual-publication-inspection.json','original-result':'audit-publication-result.json','actual-original-reader-exit':1,'original-reader-errors':2,'original-stdout-stderr-retained':True,'closure':'stdout-routing-diagnostic-closure.json','closure-result':'stdout-routing-closure-result.json','closed-reader-errors':2,'nature':'An extra log duplication assumption imposed by the reader, not missing certification output. Actual subprocess output is retained in tuple files; the complete outer log has its thirteen original progress/completion lines.','certification-exit':0,'original-overwrites':False},'findings':[],'approvals':inspection['approvals'],'repository-mutations':False,'project-executions':False,'report-sha256':sha(BASE/'report.md'),'report-words':words,'retention':'All original reader command/stdout/stderr/results and diagnostics retained. The final archive-manifest.json excludes itself and will include finalization outputs after they close. The earlier raw packet remains unchanged.'}
save('receipt.json',receipt)
print(json.dumps({'result':'CLEAN','scope':context['scope'],'report-words':words,'input-paths':len(catalog),'report-sha256':sha(BASE/'report.md'),'receipt-sha256':sha(BASE/'receipt.json'),'transactions-eight-publication-approved':True,'prior-text-eight-preserved':True,'all48-delivery-approved':False,'findings':[]}))
