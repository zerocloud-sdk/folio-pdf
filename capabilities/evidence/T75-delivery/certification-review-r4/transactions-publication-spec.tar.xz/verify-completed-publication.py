from pathlib import Path
import json,hashlib
b=Path(__file__).parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r=json.loads((b/'receipt.json').read_bytes());assert r['findings']==[] and r['report-words']<400
assert sha(b/'report.md')==r['report-sha256']
assert r['record-count']==32 and r['configuration-count']==8
assert r['approvals']['transactions-actual-outer-exit'] and r['approvals']['transactions-eight-exact-publication'] and r['approvals']['existing-text-eight-preservation']
assert not r['approvals']['values-or-other-obligations'] and not r['approvals']['all48-inventory-index-delivery']
a=json.loads((b/'finalize-publication-result.json').read_bytes());assert a['returncode']==0
for stream in ['stdout','stderr']:assert sha(b/a[stream]['path'])==a[stream]['sha256']
for c in r['completed-components']:assert sha(b/c['path'])==c['sha256']
cat=r['complete-inspected-input-identities'];assert sha(b/cat['path'])==cat['sha256']
assert r['reader-diagnostics']['original-reader-errors']==r['reader-diagnostics']['closed-reader-errors']==2
print(json.dumps({'result':'CLEAN','scope':'r4 transactions actual outer exit and publication only; exact prior text8 preservation','report-sha256':sha(b/'report.md'),'receipt-sha256':sha(b/'receipt.json'),'input-catalog-sha256':cat['sha256'],'input-paths':cat['paths'],'original-reader-diagnostics-preserved-and-closed':True,'all48-delivery-approved':False}))
