from reviewlib import *
import tarfile,io,re
from collections import Counter
raw_known={'report.md':'8e5f29d3b378c76ca2298bc2a5e6f07ff23a81d2ad1c45458fbf7e2c868b23ac','receipt.json':'c955b2dc0e10c15ee24f83c5a468f6a19266383fbcca98ddb77beca80b9d3c4f','archive-manifest.json':'d23c04b8cf0b3187128abc5aca5571127da42bd87d69d595bc878e8aa1e22ef8','complete-inspected-input-identities.json':'ce104554989a49d3c3e0ced99c42a479fffa0b081fcb0183fa455c7d25483694'}
for name,h in raw_known.items():eq(sha(RAW/name),h,'unchanged closed raw review '+name)
rawreceipt=obj(RAW/'receipt.json');eq(rawreceipt['findings'],[],'closed raw review findings');eq(rawreceipt['approvals']['transactions-eight-raw-and-own-index'],True,'existing raw gate closed')
eq(rawreceipt['approvals']['transactions-authority-publication'],False,'original deferred publication report preserved')
eq((rawreceipt['candidate'],rawreceipt['contract']),(CID,TID),'same current raw candidate and contract')
manifest=obj(RAW/'archive-manifest.json');eq(manifest['excluded-paths'],['archive-manifest.json'],'raw self exclusion')
physical={str(p.relative_to(RAW)):p for p in RAW.rglob('*') if p.is_file()}
rows={r['path']:r for r in manifest['members']};eq(set(rows),set(physical)-{'archive-manifest.json'},'raw original complete membership');eq(len(rows),723,'raw manifest count')
for name,r in rows.items():
 data=read(physical[name]);eq({'path':name,'bytes':len(data),'sha256':digest(data)},r,'unchanged sealed raw original '+name)
rawarchive=REPO/'capabilities/evidence/T75-delivery/certification-review-r4/transactions-eight-tuples-spec.tar.xz'
eq(sha(rawarchive),'08dd20cfd3fa865b54f6383cb9daa9c9ade50053463d0480bb0875e144b4a244','raw original archive SHA')
rawarchiverows=[]
with tarfile.open(fileobj=io.BytesIO(read(rawarchive)),mode='r:xz') as tar:
 members=tar.getmembers();eq(len(members),724,'raw actual archive members');eq({m.name for m in members},set(physical),'exact raw archive membership')
 for m in members:
  require(m.isfile(),'Only ordinary raw-review archive files')
  data=tar.extractfile(m).read();eq(data,read(physical[m.name]),'byte-exact archived raw original '+m.name)
  rawarchiverows.append({'path':m.name,'bytes':len(data),'sha256':digest(data)})
save('closed-raw-review-archive-member-identities.json',rawarchiverows)
command=obj(ORIGINAL/'command.json');result=obj(ORIGINAL/'result.json');log=read(ORIGINAL/'command.log').decode()
eq(command['command'],['/usr/bin/python3','scripts/t03-foundation.py','certify',str(ROOT.relative_to(REPO)),'--obligation','transactions'],'actual original outer argv')
eq(command['cwd'],str(REPO),'actual cwd');eq(command['explicit-environment'],{'FOLIO_HARFBUZZ_HELPER':str(REPO/'.build-cache/harfbuzz/10.2.0-final/bin/folio-harfbuzz')},'actual explicit helper')
for key,value in command.items():eq(result[key],value,'actual result preserves invocation '+key)
eq(result['returncode'],0,'actual outer exit zero');eq(result['started-utc'],'2026-09-13T19:42:22.210574+00:00','actual start');eq(result['completed-utc'],'2026-09-13T20:08:32.754733+00:00','actual completion')
require(isinstance(result['command-pid'],int) and result['command-pid']>0,'Retained actual command PID')
end='Recorded exactly eight T03 certifications; retained 8 current certifications for other obligations.'
eq(log.rstrip().splitlines()[-1],end,'complete original outer completion line')
observed_times=[float(x) for x in re.findall(r'Time: ([0-9.]+)\n\nOK \(34 tests\)',log)]
eq(observed_times,[t['time-seconds'] for t in rawreceipt['actual-eight-formal-suites']],'outer transcript matches each original current formal suite')
eq(len(re.findall(r'OK \(34 tests\)',log)),8,'eight original suites in complete merged log')
eq('FAILURES!!!' in log,False,'no hidden formal failure in complete merged log')
retention=obj(ORIGINAL/'receipt.json');eq(retention['actual-result'],result,'retention binds original outer result');eq(retention['actual-exit'],0,'retained actual exit');eq(retention['observed-tuples'],8,'retained tuples');eq(retention['matching-pass-records'],32,'retained chain count');eq((retention['candidate'],retention['contract']),(CID,TID),'retained identities')
for name in ['command.json','result.json','command.log']:
 expected=Path('/tmp/t75-final-transactions-certify-r4'+('.log' if name=='command.log' else '-'+name))
 eq(read(expected),read(ORIGINAL/name),'unchanged actual prefix original '+name)
index=obj(ROOT/'observed-index.json');eq(sha(ROOT/'observed-index.json'),rawreceipt['observed-index-sha256'],'own-index remains exactly reviewed')
eq(read(ROOT/'observed-index.json'),read(ORIGINAL/'observed-index.json'),'retention own-index byte exact')
eq(obj(ORIGINAL/'identities.json'),{'Candidate':CID,'Contract':TID},'actual retained identity pair')
textindex=obj(CURRENT/'text/observed-index.json');textsha=sha(CURRENT/'text/observed-index.json')
eq(textsha,rawreceipt['prior-text-publication-linkage']['prior-text-own-index-sha256'],'unchanged closed text index')
eq(read(ROOT/'prior-index.sha256'),read(ORIGINAL/'prior-index.sha256'),'original prior index digest retained')
eq(read(ROOT/'prior-index.sha256').decode().strip(),textsha,'publisher started from reviewed text8 authority')
expected={'transactions':index['certifications'],'text':textindex['certifications']}
for name,certs in expected.items():eq(len(certs),8,'exact required subset count '+name);eq({c['obligation'] for c in certs},{name},'own-index obligation scope '+name)
dated=document(ORIGINAL/'authority-at-retention.yaml');eq(Counter(c['obligation'] for c in dated['certifications']),{'text':8,'transactions':8},'dated actual published sixteen')
authority_path=REPO/'capabilities/foundation-evidence.yaml';authority_bytes=read(authority_path);current=json.loads(authority_bytes);observed_at=now()
currentcopy=BASE/'originals/authority-current-observation.yaml';currentcopy.parent.mkdir(exist_ok=True)
with currentcopy.open('xb') as h:h.write(authority_bytes)
for label,a in [('dated',dated),('current-observation',current)]:
 eq(a['schema-version'],1,label+' authority schema');eq(a['candidate'],index['candidate'],label+' exact current candidate')
 for obligation,certs in expected.items():
  subset=[c for c in a['certifications'] if c['obligation']==obligation]
  eq(subset,certs,label+' exact eight published '+obligation+' with original ordered configs/records')
 eq(len({(c['obligation'],c['environment'],c['execution-profile']) for c in a['certifications']}),len(a['certifications']),label+' unique publication tuples')
oldcatalog={r['path']:r for r in obj(RAW/'complete-inspected-input-identities.json')}
rawcatalog={r['path']:r for r in obj(RAW/'complete-current-raw-tree-identities.json')}
def rawref(ref):
 p=REPO/ref['path'];h=sha(p);eq(h,ref['sha256'],'published original reference '+ref['path'])
 eq(h,rawcatalog[ref['path']]['sha256'],'published reference remains raw-reviewed '+ref['path']);return p
copies=[];checkedrecords=[];checkedconfigs=[];checkedenvironments=[]
for cert in index['certifications']:
 configpath=rawref(cert['configuration']);config=obj(configpath)
 eq(config['candidate-sha256'],CID,'configuration candidate');eq(config['execution-profile'],cert['execution-profile'],'configuration Native profile')
 eq(config['settings']['providers'],'none; Stable Facade execution is IN_PROCESS','actual Facade configuration')
 scope=configpath.parent
 for name in ['contract-tests-command.json','contract-tests.txt','recorder.txt']:
  p=scope/name;eq(sha(p),rawcatalog[str(p.relative_to(REPO))]['sha256'],'closed actual tuple command/output '+str(p))
 for api,mode in [('native',cert['execution-profile']),('facade','IN_PROCESS')]:
  p=scope/'observations'/api/'semantic.txt';eq(sha(p),rawcatalog[str(p.relative_to(REPO))]['sha256'],'unchanged public '+api+' observation')
  eq('Public Native reopen; execution='+mode+'\n' in read(p).decode(),True,'actual public mode '+api)
 checkedconfigs.append({'tuple':scope.name,'configuration':cert['configuration'],'actual-Native-mode':cert['execution-profile'],'actual-Facade-mode':'IN_PROCESS'})
 copies.append(copy(configpath,'published-configurations/'+scope.name+'.json'))
 for ref in cert['records']:
  p=rawref(ref);record=obj(p);eq(record['result'],'pass','published pass '+str(p));eq((record['candidate-sha256'],record['contract-sha256']),(CID,TID),'published exact identities')
  eq(record['execution-profile'],cert['execution-profile'],'published actual Native mode');eq(record['execution-configuration-sha256'],cert['configuration']['sha256'],'published config binding')
  eq(record['environment-sha256'],config['environment-sha256'],'published environment binding')
  rp=rawref(record['report']);checkedrecords.append({'record':ref,'report':record['report'],'profile':cert['execution-profile'],'chain':record['chain'],'result':'pass'})
  copies.append(copy(p,'published-records/'+scope.name+'/'+p.name));copies.append(copy(rp,'published-reports/'+scope.name+'/'+rp.name))
for major in [8,11,17,21]:
 envbefore=ROOT/('jdk'+str(major)+'-environment/environment.yaml');env=obj(envbefore)
 for suffix in ['', '-after']:
  d=ROOT/('jdk'+str(major)+'-environment'+suffix);names=[]
  for p in sorted(d.iterdir()):
   if p.is_file():eq(sha(p),rawcatalog[str(p.relative_to(REPO))]['sha256'],'unchanged original environment '+str(p));names.append(p.name)
  eq(len(names),10 if suffix else 11,'actual observed environment originals');checkedenvironments.append({'directory':str(d.relative_to(REPO)),'raw-file-count':len(names),'unchanged-to-complete-raw-review':True,'returned-identity':env})
 eq(sha(envbefore),next(e['record']['sha256'] for e in index['environments'] if e['profile'].endswith('-jdk'+str(major))),'own-index observed environment binding')
for label,a in [('dated',dated),('current-observation',current)]:
 for e in a['environments']:
  p=REPO/e['record']['path'];eq(sha(p),e['record']['sha256'],label+' published environment reference')
  major=int(e['profile'].rsplit('jdk',1)[1]);eq(obj(p),obj(ROOT/('jdk'+str(major)+'-environment/environment.yaml')),label+' published identity equals observed environment')
buildpath=REPO/'capabilities/evidence/T75-delivery/final-candidate-r4/build-inputs.json';build=obj(buildpath)
eq(sha(buildpath),'64cb458acef6c0e98aa5b0dbf8023d85fe569fa2269eb6c3c343959779325e02','frozen stage identity')
eq(read(buildpath),read(REPO/'target/foundation-0.1.0/build-inputs.json'),'current staged receipt copy')
eq(build['candidate'],index['candidate'],'published candidate equals fresh actual staged candidate')
counts={}
for label,rows in [('sources',build['candidate']['inputs']),('contracts',build['contract-inputs']),('artifacts',build['candidate']['artifacts']),('harness',build['harness'])]:
 counts[label]=len(rows)
 for r in rows:
  p=REPO/r['path'];eq(sha(p),r['sha256'],'unchanged current frozen '+label+' '+r['path']);eq(r['sha256'],oldcatalog[str(p)]['sha256'],'current input lineage '+r['path'])
eq(counts,{'sources':1933,'contracts':30,'artifacts':23,'harness':24},'exact frozen input inventory')
canonical=lambda kind,rows:''.join(kind+' '+r['path']+' '+r['sha256']+'\n' for r in sorted(rows,key=lambda r:r['path']))
eq(digest(('release '+build['candidate']['release']+'\n'+canonical('input',build['candidate']['inputs'])+canonical('artifact',build['candidate']['artifacts'])).encode()),CID,'canonical published candidate SHA')
eq(digest(canonical('contract',build['contract-inputs']).encode()),TID,'canonical published contract SHA')
for name in ['report.md','receipt.json','archive-manifest.json']:
 copies.append(copy(RAW/name,'closed-raw-review/'+name))
for name in ['observed-index.json','identities.json','prior-index.sha256']:
 copies.append(copy(ROOT/name,'published-index/'+name))
copies.append(copy(CURRENT/'text/observed-index.json','preserved-text-own-index.json'))
for path in [REPO/'docs/t03-certification.md',Path('/home/ubuntu/.codex/attachments/77353239-0dda-4ee1-b4bb-ce7fb3fa0f9b/pasted-text-1.txt')]:copies.append(copy(path,'requirements/'+path.name))
copies.append(copy(buildpath,'current-stage/build-inputs.json'))
save('selected-publication-copy-identities.json',copies)
finish('actual-publication-inspection',{'actual-command':command,'actual-result':result,'complete-original-log-sha256':sha(ORIGINAL/'command.log'),'actual-formal-times':observed_times,'actual-completion-line':end,'retained-original-count':10,'original-command-archive':{'path':str((REPO/'capabilities/evidence/T75-delivery/final-certification-r4/transactions-command.tar.xz').relative_to(REPO)),'sha256':sha(REPO/'capabilities/evidence/T75-delivery/final-certification-r4/transactions-command.tar.xz')},'dated-authority':{'path':str(ORIGINAL/'authority-at-retention.yaml'),'sha256':sha(ORIGINAL/'authority-at-retention.yaml'),'exact-subsets':{'text':8,'transactions':8}},'current-authority-observation':{'original':str(authority_path),'observed-at-utc':observed_at,'copy':str(currentcopy.relative_to(BASE)),'sha256':digest(authority_bytes),'exact-reviewed-subsets':{'text':8,'transactions':8},'other-obligation-records':'Excluded from this audit, whether already present or added later.','mutable-source-path-not-a-frozen-input':True},'own-index-sha256':sha(ROOT/'observed-index.json'),'preserved-text-index-sha256':textsha,'configuration-count':len(checkedconfigs),'record-count':len(checkedrecords),'checked-configurations':checkedconfigs,'checked-records-and-reports':checkedrecords,'environment-observations':checkedenvironments,'current-staged-input-counts':counts,'closed-raw-review':{'directory':str(RAW),'known-original-hashes':raw_known,'archive':str(rawarchive.relative_to(REPO)),'archive-sha256':sha(rawarchive),'archive-members':len(rawarchiverows),'diagnostics-and-corrections-preserved':True,'raw-details-replayed':False},'actual-Facade-mode':'IN_PROCESS','same-T03-non-atomic-multi-Target-contract':True,'no-new-source-review':True,'no-project-executions':True,'no-repository-mutations':True,'findings':[],'approvals':{'transactions-actual-outer-exit':True,'transactions-eight-exact-publication':True,'existing-text-eight-preservation':True,'values-or-other-obligations':False,'all48-inventory-index-delivery':False,'completion-criteria-marked':False}})
