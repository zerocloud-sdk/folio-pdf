from reviewlib import *
import tarfile,io
archive=REPO/'capabilities/evidence/T75-delivery/final-certification-r4/transactions-command.tar.xz'
eq(sha(archive),'9edc3be5a95403688d353a5e066a49512dcb1c6e7eeae7c289d99c849079c84e','actual transaction command archive identity')
physical={str(p.relative_to(ORIGINAL)):p for p in ORIGINAL.rglob('*') if p.is_file()}
eq(len(physical),10,'actual retained original member count')
rows=[];copies=[];schemas={}
with tarfile.open(fileobj=io.BytesIO(read(archive)),mode='r:xz') as tar:
 members=tar.getmembers();eq(len(members),10,'actual archive member count');eq({m.name for m in members},set(physical),'exact command archive membership')
 for m in members:
  require(m.isfile(),'Command archive plain files only')
  data=tar.extractfile(m).read();eq(data,read(physical[m.name]),'archived actual original bytes '+m.name)
  rows.append({'path':m.name,'bytes':len(data),'sha256':digest(data)})
  copies.append(copy(physical[m.name],'actual-command-retention/'+m.name))
  if m.name.endswith(('.json','.yaml')):
   value=document(physical[m.name]);schemas[m.name]={'type':type(value).__name__,'keys':list(value) if isinstance(value,dict) else None}
   if isinstance(value,dict) and 'certifications' in value:schemas[m.name]['obligations']={k:sum(c['obligation']==k for c in value['certifications']) for k in {c['obligation'] for c in value['certifications']}}
for label,path in [('command','/tmp/t75-final-transactions-certify-r4-command.json'),('result','/tmp/t75-final-transactions-certify-r4-result.json'),('log','/tmp/t75-final-transactions-certify-r4.log')]:
 p=Path(path);h=sha(p);matching=[r['path'] for r in rows if r['sha256']==h];eq(len(matching),1,'actual prefix has exactly one retained original '+label)
 copies.append(copy(p,'actual-prefix/'+label+('.log' if label=='log' else '.json')))
 schemas[label+'-direct-match']=matching
save('actual-command-archive-member-identities.json',rows)
finish('actual-publication-schema-inspection',{'archive':str(archive.relative_to(REPO)),'archive-sha256':sha(archive),'original-directory':str(ORIGINAL),'original-files':sorted(physical),'schemas':schemas,'copies':copies})
print(json.dumps({'retained-member-names':sorted(physical),'schemas':schemas},ensure_ascii=False))
