from pathlib import Path
import hashlib,json,datetime,yaml
BASE=Path(__file__).parent
REPO=Path('/home/ubuntu/IdeaProjects/open-pdf')
ROOT=REPO/'capabilities/evidence/T75-foundation-20260914-r4/transactions'
CURRENT=ROOT.parent
CID='ab18cc9c0473730a6aabec5d12e3172f22bea23a0a0f9529052a2bc186cbfc1b'
TID='3de508f79fcbef7258feee8abc013d6f02b000840cac1cb263cb0d6f927b8f2b'
RAW=Path('/tmp/t75-final-spec-r4-transactions-eight-1imjlw_l')
ORIGINAL=Path('/tmp/t75-final-transactions-certified-r4-pj5b_vlc')
files={};errors=[]
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
digest=lambda b:hashlib.sha256(b).hexdigest()
def read(p):
 p=Path(p)
 allowed=p==CURRENT/'text/observed-index.json' or (p.parent.name in ['jdk8-environment','jdk11-environment','jdk17-environment','jdk21-environment'] and p.name=='environment.yaml' and p.parent.parent==CURRENT/'text')
 if p.is_relative_to(CURRENT) and not p.is_relative_to(ROOT) and not allowed:raise ValueError('Excluded other-obligation raw path: '+str(p))
 data=p.read_bytes();row={'path':str(p),'bytes':len(data),'sha256':digest(data)}
 if str(p) in files and files[str(p)]!=row:errors.append({'where':str(p),'detail':'Input changed during current reader'})
 files[str(p)]=row;return data
def sha(p):return digest(read(p))
def obj(p):return json.loads(read(p))
def document(p):return yaml.safe_load(read(p))
def eq(a,b,where):
 if a!=b:errors.append({'where':str(where),'actual':a,'expected':b})
def require(ok,message):
 if not ok:raise ValueError(message)
def save(name,data):
 with (BASE/name).open('x') as h:json.dump(data,h,ensure_ascii=False,indent=2);h.write('\n')
def copy(p,name):
 data=read(p);target=BASE/'originals'/name;target.parent.mkdir(parents=True,exist_ok=True)
 with target.open('xb') as h:h.write(data)
 return {'original':str(p),'copy':str(target.relative_to(BASE)),'bytes':len(data),'sha256':digest(data)}
def finish(name,data):
 data['errors']=errors;save(name+'.json',data);save(name+'-read-identities.json',list(files.values()))
 print(json.dumps({'output':name+'.json','errors':len(errors),'read-files':len(files)}))
 if errors:raise SystemExit(1)
