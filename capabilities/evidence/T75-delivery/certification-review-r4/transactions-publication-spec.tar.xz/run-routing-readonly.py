from pathlib import Path
import json, sys, datetime, hashlib, subprocess
b = Path(__file__).parent
assert len(sys.argv) == 2 and sys.argv[1] in ['inspect-publication.py', 'audit-publication.py', 'finalize-publication.py', 'stdout-routing-closure.py']
p = b / sys.argv[1]
stem = p.stem
names = {k: b / (stem + '-' + v) for k, v in [('command', 'command.json'), ('stdout', 'stdout.txt'), ('stderr', 'stderr.txt'), ('result', 'result.json')]}
if any((p.exists() for p in names.values())):
    raise FileExistsError('Exclusive output already exists')
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
m = {'command': [sys.executable, '-B', str(p)], 'cwd': str(b), 'started-utc': now(), 'script-sha256': sha(p), 'reader-library-sha256': sha(b / 'reviewlib.py'), 'boundary': 'Read-only T03 publication inspection with exclusive /tmp outputs. No project/certifier/test/observer execution or repository mutation.'}
with names['command'].open('x') as h:
    json.dump(m, h, indent=2)
    h.write('\n')
with names['stdout'].open('xb') as out, names['stderr'].open('xb') as err:
    r = subprocess.run(m['command'], cwd=b, stdout=out, stderr=err)
m.update({'returncode': r.returncode, 'completed-utc': now(), 'stdout': {'path': names['stdout'].name, 'sha256': sha(names['stdout'])}, 'stderr': {'path': names['stderr'].name, 'sha256': sha(names['stderr'])}})
with names['result'].open('x') as h:
    json.dump(m, h, indent=2)
    h.write('\n')
print(names['stdout'].read_text())
print(names['stderr'].read_text())
print(json.dumps(m))
sys.exit(r.returncode)
