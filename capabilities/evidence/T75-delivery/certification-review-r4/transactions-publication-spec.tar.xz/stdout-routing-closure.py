from reviewlib import *
import ast,re
original=obj(BASE/'actual-publication-inspection.json');raw=obj(RAW/'receipt.json')
expected=[{'where':'outer transcript matches each original current formal suite','actual':[],'expected':[t['time-seconds'] for t in raw['actual-eight-formal-suites']]},{'where':'eight original suites in complete merged log','actual':0,'expected':8}]
eq(original['errors'],expected,'exact original two stdout-routing reader diagnostics')
actual=obj(BASE/'audit-publication-result.json');eq(actual['returncode'],1,'original independent reader actual exit retained')
for stream in ['stdout','stderr']:eq(sha(BASE/actual[stream]['path']),actual[stream]['sha256'],'original reader complete '+stream)
p=REPO/'scripts/t03-foundation.py';source=read(p).decode();tree=ast.parse(source)
run=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='run_logged');certify=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='certify')
runtext=ast.get_source_segment(source,run);certifytext=ast.get_source_segment(source,certify)
eq('stdout=log, stderr=subprocess.STDOUT' in runtext,True,'actual child merged output routed exclusively to requested file')
eq('with Path(path).open(\'wb\') as log:' in runtext,True,'actual original log binary write route')
eq('if check and result.returncode:' in runtext,True,'actual nonzero child guard')
eq("run_logged(test_command, scope / 'contract-tests.txt', cwd=root," in certifytext,True,'actual contract log route')
eq("if 'OK (' + str(case['test-count']) + ' tests)' not in (scope / 'contract-tests.txt').read_text():" in certifytext,True,'actual complete-suite guard')
eq("report['findings'] += [reference(root, scope / 'contract-tests.txt'), reference(root, scope / 'contract-tests-command.json')]" in certifytext,True,'original suite logs published under semantic references')
outer=read(ORIGINAL/'command.log').decode();lines=[]
for major in [8,11,17,21]:
 lines.append('T03 environment JDK '+str(major))
 for mode in ['IN_PROCESS','HARDENED_WORKER']:lines.append('T03 certification JDK '+str(major)+' / '+mode)
lines.append('Recorded exactly eight T03 certifications; retained 8 current certifications for other obligations.')
eq(outer.splitlines(),lines,'actual full outer log exactly matches its thirteen progress/completion lines')
observations=[]
for t in raw['actual-eight-formal-suites']:
 p=REPO/t['tuple']/'contract-tests.txt';text=read(p).decode()
 eq(sha(p),t['contract-tests-sha256'],'actual unchanged previously reviewed tuple transcript')
 match=re.fullmatch(r'JUnit version 4\.13\.2\n\.{34}\nTime: ([0-9.]+)\n\nOK \(34 tests\)\n\n',text)
 require(match is not None,'Complete actual stored T03 suite transcript')
 eq(float(match[1]),t['time-seconds'],'actual stored suite time')
 observations.append({'tuple':t['tuple'],'path':str(p.relative_to(REPO)),'sha256':sha(p),'tests':34,'time-seconds':float(match[1]),'raw-gate-linkage':'Already independently closed; only original transcript identity and location checked here.'})
copied=copy(REPO/'scripts/t03-foundation.py','stdout-routing-source/t03-foundation.py')
finish('stdout-routing-diagnostic-closure',{'original-inspection':{'path':'actual-publication-inspection.json','sha256':sha(BASE/'actual-publication-inspection.json')},'original-reader-result':actual,'original-two-diagnostics':expected,'correct-disposition':'Reader imposed an extra duplication requirement. The actual certifier writes child stdout plus stderr into each contract-tests.txt and prints thirteen progress/completion lines to the outer log. The complete retained child logs, semantic references, actual outer exit0 and original merged outer output are all present. No certification failure, missing original output, or source change.','actual-full-outer-log':{'sha256':sha(ORIGINAL/'command.log'),'lines':len(lines)},'actual-stored-suite-transcripts':observations,'exact-source-routing':{'path':str((REPO/'scripts/t03-foundation.py').relative_to(REPO)),'sha256':sha(REPO/'scripts/t03-foundation.py'),'run-logged-lines':[run.lineno,run.end_lineno],'certify-lines':[certify.lineno,certify.end_lineno],'copy':copied},'all-other-original-publication-bindings':'Passed in the unchanged original inspection; no repeat of raw rules/RGB or five-file source review.','remaining-findings':[],'project-executions':False,'original-overwrites':False})
