from reviewlib import *
import tarfile, re
CID = 'ab18cc9c0473730a6aabec5d12e3172f22bea23a0a0f9529052a2bc186cbfc1b'
TID = '3de508f79fcbef7258feee8abc013d6f02b000840cac1cb263cb0d6f927b8f2b'
INDEX_SHA = '1c2417c868e977908834f7405d222435a1692297103766758e6316346d87cb61'
D = REPO / 'capabilities/evidence/T75-delivery/final-certification-r4'
command = obj(Path('/tmp/t75-final-text-certify-r4-command.json'))
result = obj(Path('/tmp/t75-final-text-certify-r4-result.json'))
log = read(Path('/tmp/t75-final-text-certify-r4.log'))
argv = ['/usr/bin/python3', 'scripts/t03-foundation.py', 'certify', 'capabilities/evidence/T75-foundation-20260914-r4/text', '--obligation', 'text']
eq(command['command'], argv, 'actual outer argv')
eq(command['cwd'], str(REPO), 'actual cwd')
eq(command['started-utc'], '2026-09-13T17:01:21.422612+00:00', 'actual start')
eq({key: result[key] for key in command}, command, 'outer result retains exact original command fields')
eq(result['returncode'], 0, 'actual process exit')
eq(result['completed-utc'], '2026-09-13T19:42:21.433418+00:00', 'actual completion')
expected_log = []
for major in [8, 11, 17, 21]:
    expected_log += ['T13 environment JDK ' + str(major), 'T13 certification JDK ' + str(major) + ' / IN_PROCESS', 'T13 certification JDK ' + str(major) + ' / HARDENED_WORKER']
expected_log.append('Recorded exactly eight T13 certifications; retained 0 current certifications for other obligations.')
eq(log.decode(), '\n'.join(expected_log) + '\n', 'complete actual stdout/stderr log')
for actual_path, retained in [(Path('/tmp/t75-final-text-certify-r4-command.json'), 'command.json'), (Path('/tmp/t75-final-text-certify-r4-result.json'), 'result.json'), (Path('/tmp/t75-final-text-certify-r4.log'), 'command.log')]:
    eq(read(actual_path), read(ORIGINAL / retained), 'original retained byte equality: ' + retained)
eq(read(D / 'text-command.json'), read(ORIGINAL / 'command.json'), 'adjacent command original')
eq(read(D / 'text-result.json'), read(ORIGINAL / 'result.json'), 'adjacent result original')
eq(read(D / 'text-receipt.json'), read(ORIGINAL / 'receipt.json'), 'adjacent retention receipt original')
runner = read(ORIGINAL / 't75-run-retained.py').decode()
require('stderr=subprocess.STDOUT' in runner and "result['returncode'] = process.wait()" in runner, 'Original runner must preserve merged real process output and actual wait status')
retention = obj(ORIGINAL / 'receipt.json')
eq(retention['actual-result'], result, 'retention binds real outer result')
eq(retention['actual-exit'], 0, 'retention actual exit')
eq(retention['authority-counts'], {'text': 8}, 'dated published count; prior candidate entries not reused')
eq(retention['candidate'], CID, 'retention candidate')
eq(retention['contract'], TID, 'retention contract')
aid = obj(D / 'text-command-archive-identity.json')
eq(aid['original'], str(ORIGINAL), 'archive original directory')
eq(aid['symbolic_links'], [], 'archive no symlinks')
archive = D / 'text-command.tar.xz'
eq(sha(archive), '9161669a04935232a3785ea29542cf0f80ac77177a1544db6fb114674874d2f7', 'known original publication archive identity')
eq(sha(archive), aid['sha256'], 'retention archive declared identity')
members = []
with tarfile.open(archive, 'r:xz') as stream:
    for member in stream:
        if member.isdir():
            continue
        eq(member.isfile(), True, 'regular publication archive member')
        data = stream.extractfile(member).read()
        members.append({'path': member.name, 'size': len(data), 'sha256': digest(data)})
eq(members, aid['members'], 'all publication archive member identities and order')
eq(len(members), 10, 'ten actual original archive members')
eq({row['path'] for row in members}, {p.name for p in ORIGINAL.iterdir() if p.is_file()}, 'complete original publication directory coverage')
for row in members:
    data = read(ORIGINAL / row['path'])
    eq({'size': len(data), 'sha256': digest(data)}, {'size': row['size'], 'sha256': row['sha256']}, 'archive versus original ' + row['path'])
for row in retention['original-copies']:
    eq(sha(ORIGINAL / row['copy']), row['sha256'], 'retention copy identity ' + row['copy'])
    if row['copy'] != 'authority-at-retention.yaml':
        eq(sha(Path(row['original'])), row['sha256'], 'still-current retained original ' + row['copy'])
index_data = read(TEXT / 'observed-index.json')
eq(digest(index_data), INDEX_SHA, 'unchanged independently reviewed observed index')
eq(read(ORIGINAL / 'observed-index.json'), index_data, 'published original own observation index')
eq(read(ORIGINAL / 'authority-at-retention.yaml'), index_data, 'dated authority byte-exact own index')
index = json.loads(index_data)
authority = obj(REPO / 'capabilities/foundation-evidence.yaml')
text_subset = [row for row in authority['certifications'] if row['obligation'] == 'text']
eq(text_subset, index['certifications'], 'current exact eight text certifications')
eq(authority['candidate'], index['candidate'], 'current published candidate remains current r4')
eq(len(text_subset), 8, 'eight published text records')
eq(len(index['environments']), 4, 'four observed environments')
copies = [copy_original(REPO / 'capabilities/foundation-evidence.yaml', 'authority-at-publication-corrected-inspection.json')]
last = Path('/tmp/t75-final-spec-r4-text-last-three-9alkqepg')
last_receipt = obj(last / 'receipt.json')
eq(sha(last / 'receipt.json'), '0d6d4f9253c3b6e96e00f51a3b822612f131e517905bcce304f66c2bb207a68c', 'last raw review receipt identity')
eq(last_receipt['raw-observed-index']['sha256'], INDEX_SHA, 'closed raw review index')
eq(last_receipt['approvals']['linked-all-eight-raw-tuples'], True, 'prior complete raw eight approval')
eq(last_receipt['approvals']['outer-exit-publication'], False, 'original publication deferral preserved')
catalog_ref = last_receipt['complete-current-input-catalog']
eq(sha(last / catalog_ref['path']), catalog_ref['sha256'], 'original complete raw identity catalog')
raw_catalog = {row['path']: row for row in obj(last / catalog_ref['path'])}

def bound(path):
    data = read(path)
    prior = raw_catalog.get(str(path))
    require(prior is not None, 'Unreviewed current raw binding ' + str(path))
    eq(digest(data), prior['sha256'], 'unchanged reviewed raw identity ' + str(path))
    eq(len(data), prior['bytes'], 'unchanged reviewed raw length ' + str(path))
    return data
links = []
environments = []
tools = set()
for env in index['environments']:
    env_path = REPO / env['record']['path']
    data = bound(env_path)
    eq(digest(data), env['record']['sha256'], 'index environment original identity')
    observed = json.loads(data)
    eq(observed['profile'], env['profile'], 'index observed environment profile')
    major = observed['identity']['jdk-major']
    before = TEXT / ('jdk' + str(major) + '-environment')
    after = TEXT / ('jdk' + str(major) + '-environment-after')
    for folder in [before, after]:
        for path in sorted(folder.iterdir()):
            if path.is_file():
                bound(path)
    eq((after / 'environment.yaml').exists(), False, 'AFTER protocol does not write duplicate environment.yaml')
    eq(len([p for p in before.iterdir() if p.is_file()]), 11, 'complete BEFORE originals')
    eq(len([p for p in after.iterdir() if p.is_file()]), 10, 'complete AFTER originals')
    tools.update((tool['id'] for tool in observed['tools']))
    environments.append({'profile': env['profile'], 'record': env['record'], 'identity': observed['identity'], 'before-original-files': 11, 'after-original-files': 10, 'tool-identities': observed['tools'], 'equality-linkage': 'Raw BEFORE/AFTER original identities unchanged from completed independent reconstruction/equality review.'})
for cert in index['certifications']:
    config_path = REPO / cert['configuration']['path']
    config_data = bound(config_path)
    eq(digest(config_data), cert['configuration']['sha256'], 'published execution configuration original')
    scope = config_path.parent
    logdata = bound(scope / 'contract-tests.txt').decode()
    eq(bool(re.search('OK \\(126 tests\\)', logdata)), True, 'actual126 completed suite remains unchanged')
    bound(scope / 'contract-tests-command.json')
    bound(scope / 'recorder.txt')
    bound(scope / 'observations/retained-files.sha256')
    bound(scope / 'observations/result.properties')
    eq(len(cert['records']), 4, 'four published chains')
    chain_links = []
    for reference, chain in zip(cert['records'], ['syntax', 'standards', 'semantic', 'visual']):
        record_path = REPO / reference['path']
        data = bound(record_path)
        eq(digest(data), reference['sha256'], 'published original chain SHA')
        record = json.loads(data)
        for key, value in {'obligation': 'text', 'candidate-sha256': CID, 'contract-sha256': TID, 'execution-profile': cert['execution-profile'], 'execution-configuration-sha256': cert['configuration']['sha256'], 'chain': chain, 'result': 'pass'}.items():
            eq(record[key], value, 'published record ' + key)
        envref = next((row['record'] for row in index['environments'] if row['profile'] == cert['environment']))
        eq(record['environment-sha256'], envref['sha256'], 'record actual observed environment')
        report_data = bound(REPO / record['report']['path'])
        eq(digest(report_data), record['report']['sha256'], 'unchanged complete original report')
        chain_links.append({'record': reference, 'report': record['report'], 'producer': record['producer'], 'result': 'pass'})
    links.append({'scope': str(scope.relative_to(REPO)), 'native-profile': cert['execution-profile'], 'actual-facade-profile': 'IN_PROCESS', 'configuration': cert['configuration'], 'formal-tests': 126, 'seconds': float(re.search('Time:\\s*([0-9.]+)', logdata)[1]), 'chains': chain_links, 'behavior-boundary': 'Existing complete formal/raw Spec review, including actual IN_PROCESS Facade, ownership, all-or-nothing outcomes, full controls and RGB, is unchanged; no replay of those raw details.'})
eq(retention['tuples'], [{'scope': row['scope'], 'formal-tests': 126, 'seconds': row['seconds']} for row in links], 'retained actual timing/count observations')
adjacent_logs = [path for path in sorted(D.glob('text*.log')) if path.is_file()]
for path in adjacent_logs:
    eq(read(path), log, 'adjacent original merged log')
    copies.append(copy_original(path, 'delivery/' + path.name))
docs = []
for path in [D / 'README.md', REPO / 'capabilities/evidence/T75-delivery/final-execution-receipt.md']:
    content = read(path).decode()
    eq(CID in content, True, 'delivery text names current identity')
    eq('other five' in content or 'values, pages,' in content, True, 'delivery text preserves remaining-obligation boundary')
    docs.append({'path': str(path.relative_to(REPO)), 'sha256': sha(path), 'boundary': 'Current introduction distinguishes historical r3 from r4 text-only actual publication; independent publication review is accurately pending at its recorded observation.'})
if not adjacent_logs:
    errors.append({'where': str(D / 'README.md'), 'detail': 'The current prose promises an adjacent log, but no text*.log file exists alongside the archive; original merged log remains complete inside the ten-member archive and /tmp originals.'})
finish('publication-corrected-inspection', {'created-utc': now(), 'candidate': CID, 'contract': TID, 'actual-command': command, 'actual-result': result, 'actual-log-sha256': digest(log), 'original-command-archive-sha256': sha(archive), 'original-command-archive-members': members, 'dated-authority-sha256': INDEX_SHA, 'observed-index-sha256': INDEX_SHA, 'current-authority-observed-utc': now(), 'current-authority-sha256': sha(REPO / 'capabilities/foundation-evidence.yaml'), 'current-authority-obligation-counts': {kind: sum((row['obligation'] == kind for row in authority['certifications'])) for kind in sorted({row['obligation'] for row in authority['certifications']})}, 'exact-text-certifications': text_subset, 'records': sum((len(row['chains']) for row in links)), 'configurations': len(links), 'observed-environments': environments, 'distinct-tool-ids': sorted(tools), 'unchanged-formal-and-record-links': links, 'raw-detail-replay': False, 'actual-facade-mode': 'IN_PROCESS', 'copies': copies, 'current-documentation': docs, 'adjacent-original-logs': [str(path.relative_to(REPO)) for path in adjacent_logs], 'retained-prior-candidate-certifications': 0, 'remaining-five-obligations-refreshed': False, 'boundary': 'Only text actual exit/publication. Later authority additions may occur; text subset must remain byte/value-identical. Other raw scopes and final inventory/all48/delivery are excluded.'})
