from auditlib import *
import io,tarfile,yaml
from collections import Counter
copies=[];archives=[];member_catalog=[]

def archive_check(section,prefix,original,pinned,count):
 path=DELIVERY/section/(prefix+'.tar.xz');metadata=DELIVERY/section/(prefix+'-archive-identity.json');meta=obj(metadata)
 eq(sha(path),pinned,'pinned retained archive '+str(path));eq(meta['sha256'],pinned,'archive metadata identity');eq(meta['original'],str(original),'archive original directory')
 expected={x['path']:x for x in meta['members']};eq(len(expected),len(meta['members']),'unique archive members');eq(len(expected),count,'expected original member count');eq(meta['symbolic_links'],[],'no archive symbolic links')
 actual=[]
 with tarfile.open(fileobj=io.BytesIO(read(path)),mode='r:xz') as t:
  for m in t:
   if m.isdir():continue
   eq(m.isfile(),True,'ordinary retained archive member '+m.name);rp=PurePosixPath(m.name);eq(rp.is_absolute() or '..' in rp.parts,False,'safe retained member path')
   b=t.extractfile(m).read();row=expected[m.name];h=hashlib.sha256(b).hexdigest()
   eq(len(b),row['size'],'archive member size '+m.name);eq(h,row['sha256'],'archive member hash '+m.name);eq(read(original/m.name),b,'unchanged original member '+str(original/m.name));actual.append(m.name)
   member_catalog.append({'archive':str(path),'original':str(original/m.name),'member':m.name,'bytes':len(b),'sha256':h})
 eq(set(actual),set(expected),'complete archive members');eq({str(q.relative_to(original)) for q in original.rglob('*') if q.is_file()},set(expected),'exact original packet membership')
 value={'path':str(path),'sha256':sha(path),'metadata':str(metadata),'metadata-sha256':sha(metadata),'original':str(original),'members':len(actual),'byte-exact':True};archives.append(value)
 copies.append(copy(metadata,Path('archive-identities')/metadata.name));return value,meta
command_archive,command_meta=archive_check('final-certification-r4','annotations-command',COMMAND,'2327cdaffecb692e9cdeca503dfdff45752a691877f924ecd681b15fcd730b91',10)
raw_archive,raw_meta=archive_check('certification-review-r4','annotations-eight-tuples-spec',RAW,'8dc9405652fe8af3f2c53d6279271e64186f177a2bd6a5e3fff70f8fb6636574',1486)
metadata_archive,metadata_meta=archive_check('certification-review-r4','metadata-publication-spec',META,'3b6893481086767e6f0ce30577b43c3651f85ab5d9d7d9146aa5cafe00adb4a2',77)
raw_pins={'report.md':'bf727825a8bad25002f340127501df333b70f59ef91c1c4205d0e7318e1973a1','receipt.json':'0baaedb202aae59d351786b6c9889c28a502b9e202e3acb79fabe4d4994bfb45'}
manifest_matches=[r['path'] for r in raw_meta['members'] if r['sha256']=='92624faff536d9a812d2350b7e27c7fa354967d2fb93501b26beecc2399067c1'];eq(len(manifest_matches),1,'original raw manifest uniquely pinned');raw_pins[manifest_matches[0]]='92624faff536d9a812d2350b7e27c7fa354967d2fb93501b26beecc2399067c1'
for n,h in raw_pins.items():eq(sha(RAW/n),h,'raw original pinned '+n);copies.append(copy(RAW/n,Path('closed-raw-review')/n))
raw=obj(RAW/'receipt.json');eq(raw['findings'],[],'raw findings closed');eq(raw['scope']['raw-eight-gate-closed'],True,'raw8 closed');eq(raw['scope']['own-index-gate-closed'],True,'own index closed');eq(raw['scope']['actual-publication-gate-closed'],False,'prior report retains deferred publication');eq(raw['candidate-sha256'],CID,'raw candidate');eq(raw['contract-sha256'],CT,'raw contract')
for k in ['all-eight-inspection','all-eight-inspection-actual-result','complete-original-raw-root-catalog','requirements']:
 r=raw[k];eq(sha(r['path']),r['sha256'],'closed raw linkage '+k)
 if k in ['all-eight-inspection-actual-result','requirements']:copies.append(copy(r['path'],Path('closed-raw-review')/Path(r['path']).name))
eq(obj(raw['all-eight-inspection-actual-result']['path'])['returncode'],0,'raw independent audit actual0')
for r in raw['source-and-validation-lineage'].values():
 if isinstance(r,dict) and 'path' in r:eq(sha(r['path']),r['sha256'],'source and validation closed lineage');copies.append(copy(r['path'],Path('source-lineage')/Path(r['path']).name))
incident=raw['historical-retention-limitation']['original-incident'];eq(sha(incident['path']),incident['sha256'],'historical incident unchanged');copies.append(copy(incident['path'],'historical-boundary/reader-output-incident-and-closure.json'))
for n in sorted(x['path'] for x in command_meta['members']):copies.append(copy(COMMAND/n,Path('actual-command-retention')/n))
for rel,suffix in [('command.json','-command.json'),('result.json','-result.json'),('command.log','.log')]:
 p=Path('/tmp/t75-final-annotations-certify-r4'+suffix);eq(read(p),read(COMMAND/rel),'exact actual original outer '+rel);copies.append(copy(p,Path('actual-prefix')/p.name))
command=obj(COMMAND/'command.json');result=obj(COMMAND/'result.json');retention=obj(COMMAND/'receipt.json')
eq(command['command'],['/usr/bin/python3','scripts/t03-foundation.py','certify',str(ROOT.relative_to(REPO)),'--obligation','annotations'],'actual full outer argv');eq(command['cwd'],str(REPO),'actual outer cwd');eq({k:v for k,v in result.items() if k not in ['command-pid','returncode','completed-utc']},command,'command/result fields');eq(result['returncode'],0,'actual outer exit0')
eq(command['started-utc'],'2026-09-13T22:22:04.576988+00:00','actual start');eq(result['completed-utc'],'2026-09-14T00:11:36.482684+00:00','actual completion');eq(retention['actual-result'],result,'retention actual result')
expected=[]
for j in [8,11,17,21]:expected+=['T12 environment JDK '+str(j),'T12 certification JDK '+str(j)+' / IN_PROCESS','T12 certification JDK '+str(j)+' / HARDENED_WORKER']
expected+=['Recorded exactly eight T12 certifications; retained 40 current certifications for other obligations.']
eq(read(COMMAND/'command.log').decode().splitlines(),expected,'complete13-line original protocol')
eq(obj(COMMAND/'identities.json'),{'Candidate':CID,'Contract':CT},'actual identity values')
for n in ['identities.json','observed-index.json','prior-index.sha256']:eq(read(COMMAND/n),read(ROOT/n),'retained and live own original '+n)
eq(sha(ROOT/'observed-index.json'),raw['own-index']['sha256'],'same own index as complete raw audit')
own=obj(ROOT/'observed-index.json');dated=yaml.safe_load(read(COMMAND/'authority-at-retention.yaml'));eq(len(own['certifications']),8,'own exact8');eq(len(dated['certifications']),48,'dated exact48');eq(dated['candidate'],own['candidate'],'dated candidate graph');eq(dated['environments'],own['environments'],'dated environment graph')
meta=obj(META/'receipt.json');eq(meta['findings'],[],'metadata prior closure clean');eq(meta['candidate'],CID,'metadata prior same candidate');eq(meta['contract'],CT,'metadata prior same contract');eq(meta['approvals']['metadata-eight-exact-publication'],True,'prior metadata closed')
prior_authority=Path(meta['dated-authority']['path']);eq(sha(prior_authority),meta['dated-authority']['sha256'],'preceding40 exact reviewed identity');eq(sha(prior_authority),read(ROOT/'prior-index.sha256').decode().strip(),'actual guard binds preceding40');prior=yaml.safe_load(read(prior_authority));eq(len(prior['certifications']),40,'prior exact40');eq(prior['certifications'],[x for x in dated['certifications'] if x['obligation']!='annotations'],'dated prior40 exact preservation')
copies.append(copy(prior_authority,'prior-publication/preceding-authority40.yaml'));copies.append(copy(META/'receipt.json','prior-publication/metadata-receipt.json'));copies.append(copy(META/'report.md','prior-publication/metadata-report.md'))
links={x['obligation']:x for x in meta['closed-prior-links']}
links['pages']={'obligation':'pages','original-directory':meta['closed-pages-publication']['directory'],'report-sha256':meta['closed-pages-publication']['report-sha256'],'receipt-sha256':meta['closed-pages-publication']['receipt-sha256']}
priorlinks=[];indexes={'annotations':own}
for obligation in ['text','transactions','values','pages','metadata']:
 if obligation=='metadata':d=META;receipt=meta;known_index=next(r['sha256'] for r in meta['actual-command-retention']['members'] if r['path']=='observed-index.json');link={'obligation':obligation,'original-directory':str(META),'report-sha256':sha(META/'report.md'),'receipt-sha256':sha(META/'receipt.json')}
 else:
  link=links[obligation];d=Path(link['original-directory'])
  for n in ['report','receipt']:eq(sha(d/(n+('.md' if n=='report' else '.json'))),link[n+'-sha256'],'unchanged closed prior '+obligation+' '+n)
  receipt=obj(d/'receipt.json');eq(receipt['findings'],[],'prior no findings '+obligation);eq(receipt['candidate'],CID,'prior same candidate '+obligation);eq(receipt['contract'],CT,'prior same contract '+obligation)
  known_index=link.get('own-index-sha256',receipt.get('own-index-sha256'))
  copies.append(copy(d/'receipt.json',Path('prior-publication')/(obligation+'-receipt.json')));copies.append(copy(d/'report.md',Path('prior-publication')/(obligation+'-report.md')))
 ip=ROOT.parent/obligation/'observed-index.json';eq(sha(ip),known_index,'unchanged reviewed own-index '+obligation);indexes[obligation]=obj(ip);copies.append(copy(ip,Path('prior-publication')/(obligation+'-observed-index.json')));priorlinks.append({**link,'own-index-sha256':sha(ip)})
counts=dict(Counter(x['obligation'] for x in dated['certifications']));eq(counts,{o:8 for o in indexes},'dated six exact subsets')
for obligation,index in indexes.items():eq([x for x in dated['certifications'] if x['obligation']==obligation],index['certifications'],'dated exact subset '+obligation);eq(index['candidate'],own['candidate'],'same frozen candidate graph '+obligation)
buildpath=DELIVERY/'final-candidate-r4/build-inputs.json';eq(sha(buildpath),'64cb458acef6c0e98aa5b0dbf8023d85fe569fa2269eb6c3c343959779325e02','stage pinned identity');build=obj(buildpath);eq(build['candidate'],own['candidate'],'stage candidate graph');groups={'sources':build['candidate']['inputs'],'contracts':build['contract-inputs'],'artifacts':build['candidate']['artifacts'],'harness':build['harness']};eq({k:len(v) for k,v in groups.items()},{'sources':1933,'contracts':30,'artifacts':23,'harness':24},'stage1933/30/23/24')
for group,rows in groups.items():
 for r in rows:eq(sha(REPO/r['path']),r['sha256'],'current staged '+group+' '+r['path'])
raw_files={str(REPO/x['path']):x for x in obj(raw['complete-original-raw-root-catalog']['path'])};eq(len(raw_files),53601,'closed raw catalog count');envs={x['profile']:x['record'] for x in own['environments']};records=[];configs=[];transcripts=[];environment_files=[]
def reviewed(p):
 p=Path(p);r=raw_files[str(p)];eq(sha(p),r['sha256'],'unchanged fully reviewed raw '+str(p));eq(len(read(p)),r['bytes'],'same raw size')
def ref(v,own_raw=False):
 rel=PurePosixPath(v['path']);eq(rel.is_absolute() or '..' in rel.parts,False,'canonical reference path');p=REPO/v['path'];eq(p.resolve(),p,'no linked reference');eq(sha(p),v['sha256'],'published reference exact SHA '+v['path'])
 if own_raw:reviewed(p)
 return p
suites={s['tuple']:s for s in raw['actual-formal-suite-observations']}
for cert in own['certifications']:
 mode=cert['execution-profile'];profile=cert['environment'];cp=ref(cert['configuration'],True);scope=cp.parent;c=obj(cp);eq(c['candidate-sha256'],CID,'config candidate');eq(c['execution-profile'],mode,'actual Native profile');eq(c['environment-sha256'],envs[profile]['sha256'],'config environment');eq(c['acceptance-profile'],'T12-annotations-document-actions','actual profile');eq(len(c['inputs']),156,'156 actual config inputs')
 for r in c['inputs']:eq(sha(REPO/r['path']),r['sha256'],'all current config inputs')
 eq(c['settings']['providers'],'none; Stable Facade execution is IN_PROCESS','actual Facade configuration');eq('Facade execution remains IN_PROCESS' in c['settings']['workflow-policy'],True,'actual Facade policy')
 cmdp=scope/'contract-tests-command.json';reviewed(cmdp);argv=obj(cmdp);eq(isinstance(argv,list),True,'actual formal argv array');eq(isinstance(c['command'],list),True,'actual recorder argv array');lp=scope/'contract-tests.txt';reviewed(lp);body=read(lp).decode();m=re.fullmatch(r'JUnit version 4\.13\.2\n.*\nTime: ([0-9.]+)\n\nOK \(47 tests\)\n\n',body,re.S);eq(m is not None,True,'complete actual47 JUnit transcript');eq('FAILURES!!!' in body,False,'no formal failure');s=suites[scope.name];eq(s['formal-command-sha256'],sha(cmdp),'closed actual command identity');eq(s['execution-configuration-sha256'],sha(cp),'closed actual recorder identity');eq(s['Native-mode'],mode,'selected Native mode');eq(s['actual-Facade-mode'],'IN_PROCESS','closed actual Facade');eq(float(m[1]) if m else None,s['formal-time-seconds'],'actual observed suite time')
 transcripts.append({'tuple':scope.name,'tests':47,'seconds':float(m[1]) if m else None,'sha256':sha(lp),'actual-Native-mode':mode,'actual-Facade-mode':'IN_PROCESS'})
 for p in [cp,cmdp,lp,scope/'recorder.txt']:reviewed(p);copies.append(copy(p,Path('current-tuples')/scope.name/p.name))
 seen=[]
 for rr in cert['records']:
  p=ref(rr,True);r=obj(p);seen.append(r['chain'])
  for k,v in {'obligation':'annotations','candidate-sha256':CID,'contract-sha256':CT,'environment-sha256':envs[profile]['sha256'],'execution-configuration-sha256':cert['configuration']['sha256'],'execution-profile':mode,'result':'pass','acceptance-profile':'T12-annotations-document-actions'}.items():eq(r[k],v,'actual record '+k)
  rp=ref(r['report'],True);report=obj(rp);eq(report['chain'],r['chain'],'report chain');eq(report['result'],'pass','report pass');eq(report['negative-controls'],r['negative-controls'],'unaltered report/control references');ref(r['configuration'])
  for q in [p,rp]:copies.append(copy(q,Path('current-tuples')/scope.name/q.name))
  records.append({'tuple':scope.name,'chain':r['chain'],'record':rr,'report':r['report'],'qualified-raw-details-replayed':False})
 eq(sorted(seen),['semantic','standards','syntax','visual'],'exact four chains')
 configs.append({'tuple':scope.name,'configuration':cert['configuration'],'contract-command-sha256':sha(cmdp),'recorder-command-field':'execution.yaml:command','actual-Native-profile':mode,'actual-Facade-mode':'IN_PROCESS','input-count':len(c['inputs'])})
for j in [8,11,17,21]:
 for suffix,n in [('environment',11),('environment-after',10)]:
  d=ROOT/('jdk'+str(j)+'-'+suffix);entries=sorted(q for q in d.iterdir() if q.is_file());eq(len(entries),n,'complete env originals '+d.name)
  for p in entries:reviewed(p);copies.append(copy(p,Path('current-environments')/d.name/p.name));environment_files.append({'path':str(p.relative_to(REPO)),'bytes':len(read(p)),'sha256':sha(p)})
  if suffix=='environment':ref(envs['ubuntu-24.04-linux-x86-64-jdk'+str(j)],True)
  else:eq((d/'environment.yaml').exists(),False,'AFTER intentionally has no YAML')
eq(raw['exact-four-JDK-BEFORE-AFTER-reconstruction'],True,'closed exact four reconstructed environment equalities');eq(len(records),32,'annotation32 records/reports');eq(len(configs),8,'annotation8 configs');eq(len(environment_files),84,'annotation84 env originals')
root_names=sorted(Path(x).name for x in raw_files if Path(x).parent==ROOT);eq(sorted(p.name for p in ROOT.iterdir() if p.is_file()),root_names,'unchanged root file membership')
for n in root_names:reviewed(ROOT/n)
prior_config=[];prior_records=[];prior_env=[]
for obligation,index in indexes.items():
 if obligation=='annotations':continue
 env={x['profile']:x['record'] for x in index['environments']}
 for x in index['environments']:p=ref(x['record']);prior_env.append({'obligation':obligation,'reference':x['record']})
 for cert in index['certifications']:
  cp=ref(cert['configuration']);c=obj(cp);eq(c['candidate-sha256'],CID,'preserved config candidate');eq(c['execution-profile'],cert['execution-profile'],'preserved config Native mode');eq(c['environment-sha256'],env[cert['environment']]['sha256'],'preserved config environment');prior_config.append({'obligation':obligation,'configuration':cert['configuration']})
  chains=[]
  for rr in cert['records']:
   p=ref(rr);r=obj(p);chains.append(r['chain'])
   for k,v in {'obligation':obligation,'candidate-sha256':CID,'contract-sha256':CT,'environment-sha256':env[cert['environment']]['sha256'],'execution-configuration-sha256':cert['configuration']['sha256'],'execution-profile':cert['execution-profile'],'result':'pass'}.items():eq(r[k],v,'preserved prior record '+k)
   ref(r['report']);prior_records.append({'obligation':obligation,'record':rr,'report':r['report'],'raw-replayed':False})
  eq(sorted(chains),['semantic','standards','syntax','visual'],'prior four chains unchanged')
eq(len(prior_records),160,'prior40/160 records preserved');eq(len(prior_config),40,'prior40 configurations preserved')
current_started=datetime.datetime.now(datetime.timezone.utc).isoformat();current_bytes=read(AUTHORITY);current=yaml.safe_load(current_bytes);current_completed=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (OUT/'authority-current-observation.yaml').open('xb') as f:f.write(current_bytes)
eq(current['candidate'],dated['candidate'],'current candidate unchanged');eq(current['environments'],dated['environments'],'current environment unchanged');eq(current['certifications'],dated['certifications'],'current exact48 equals dated publication snapshot')
for o,index in indexes.items():eq([x for x in current['certifications'] if x['obligation']==o],index['certifications'],'current exact published subset '+o)
source=read(REPO/'scripts/t03-foundation.py').decode();eq('stdout=log, stderr=subprocess.STDOUT' in source,True,'recorder merged output protocol');wrapper=read(COMMAND/'t75-run-retained.py').decode();eq('stderr=subprocess.STDOUT' in wrapper,True,'actual outer merged output protocol')
copies.append(copy(REPO/'docs/t12-certification.md','requirements/t12-certification.md'))
dump('publication-original-copy-identities.json',copies);dump('retained-archive-member-identities.json',member_catalog);dump('retained-archive-verification-identities.json',archives)
finish('actual-publication-inspection.json',{'scope':'Only r4 annotations actual outer exit/publication with prior40 exact preservation','candidate':CID,'contract':CT,'actual-command':command,'actual-result':result,'outer-log-lines':13,'outer-log-sha256':sha(COMMAND/'command.log'),'outer-stderr':'Merged into original log; formal47 details retained per tuple','original-command-retention':command_archive,'closed-raw-review':{'original':str(RAW),'pins':raw_pins,'archive':raw_archive,'own-index-sha256':sha(ROOT/'observed-index.json'),'references':101736,'raw-replayed':False,'deferred-report-unchanged':True},'closed-prior-metadata-archive':metadata_archive,'closed-prior-publications':priorlinks,'dated-authority':{'path':str(COMMAND/'authority-at-retention.yaml'),'sha256':sha(COMMAND/'authority-at-retention.yaml'),'exact-subsets':counts},'prior-authority':{'path':str(prior_authority),'sha256':sha(prior_authority),'prior40-preserved':True},'current-authority':{'snapshot':'authority-current-observation.yaml','sha256':hashlib.sha256(current_bytes).hexdigest(),'started-utc':current_started,'completed-utc':current_completed,'total-observed':48,'pass-records-observed':192,'exact-subsets':counts},'stage-counts':{k:len(v) for k,v in groups.items()},'actual-record-report-bindings':records,'actual-configurations':configs,'actual-formal-transcripts':transcripts,'actual-environment-files':environment_files,'before-after-equality-closed-with-all84-unchanged':True,'prior-record-report-bindings':prior_records,'prior-configuration-bindings':prior_config,'prior-environment-bindings':prior_env,'actual-Facade-mode':'IN_PROCESS','historical-boundary':raw['historical-retention-limitation'],'five-file-review-repeated':False,'final48-inventory-index-delivery-approved':False})
