from pathlib import Path
import subprocess,sys,json,hashlib,datetime
p=Path(__file__).parent
manifest=p/'manifest.json'
assert not manifest.exists()
r=subprocess.run([sys.executable,'-B',str(p/'run-readonly.py'),'seal-input-verify.py'],cwd=p)
if r.returncode:raise SystemExit(r.returncode)
rows=[]
for f in sorted(p.rglob('*')):
 if f.is_file():
  assert not f.is_symlink()
  b=f.read_bytes();rows.append({'path':str(f.relative_to(p)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
m={'schema-version':1,'original-directory':str(p),'created-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'excludes':['manifest.json'],'exclusion-reason':'Manifest explicitly excludes only itself. All retained original commands, scripts, stdout/stderr, actual results, copies and separate diagnostics/closures are included.','members-excluding-self':len(rows),'members-including-self':len(rows)+1,'bytes-excluding-self':sum(x['bytes'] for x in rows),'files':rows}
with manifest.open('x') as f:json.dump(m,f,indent=2);f.write('\n')
assert {str(f.relative_to(p)) for f in p.rglob('*') if f.is_file()}=={x['path'] for x in rows}|{'manifest.json'}
for x in rows:assert hashlib.sha256((p/x['path']).read_bytes()).hexdigest()==x['sha256']
print(json.dumps({'original-directory':str(p),'member-count':len(rows)+1,'manifest-count-excludes-itself':len(rows),'files':{n:{'path':str(p/n),'sha256':hashlib.sha256((p/n).read_bytes()).hexdigest(),'bytes':(p/n).stat().st_size} for n in ['report.md','receipt.json','manifest.json']},'result':'SEALED; bounded annotations publication only'},indent=2))
