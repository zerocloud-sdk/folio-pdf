from auditlib import *
v=obj(Path('/tmp/t75-final-spec-r4-pages-publication-blveufbw/receipt.json'))
def walk(v,path='$'):
 if isinstance(v,dict):
  for k,x in v.items():
   if 'index' in k:print(path+'.'+k,json.dumps(x))
   walk(x,path+'.'+k)
 elif isinstance(v,list):
  for i,x in enumerate(v):walk(x,path+'['+str(i)+']')
walk(v)
finish('pages-own-index-schema-inspection.json',{'keys':list(v),'original-diagnostic':obj(OUT/'actual-publication-inspection.json')['errors']})
