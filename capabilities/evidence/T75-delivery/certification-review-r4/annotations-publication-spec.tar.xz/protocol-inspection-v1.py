from pathlib import Path
import json
p=Path("/tmp/t75-final-spec-r4-annotations-publication-9wr02_ab/selected-protocol-originals")
for name in ["goal.txt","qualified-auditlib.py","qualified-wrapper.py","current-command.json","current-result.json","current-receipt.json","raw-review-receipt.json","metadata-publication-receipt.json"]:
 print("INPUT",name)
 print((p/name).read_text())
