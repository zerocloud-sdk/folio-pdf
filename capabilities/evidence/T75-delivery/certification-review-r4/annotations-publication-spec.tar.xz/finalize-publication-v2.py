from auditlib import *
import yaml
inspection=obj(OUT/'actual-publication-inspection.json');closure=obj(OUT/'reader-diagnostic-scoped-closure-inspection.json')
eq(closure['errors'],[],'scoped diagnostic closed');eq(obj(OUT/'reader-diagnostic-scoped-closure-result.json')['returncode'],0,'scoped closure actual0');eq(closure['open-current-findings'],0,'zero open findings')
inputs={}
for p in sorted(OUT.glob('*-read-identities.json')):
 for r in obj(p):
  key=r['path']
  if key in inputs:eq({k:v for k,v in inputs[key].items() if k!='mutable-original'},{k:v for k,v in r.items() if k!='mutable-original'},'same input across reads')
  inputs[key]=r
for r in obj(OUT/'protocol-original-copy-identities.json'):
 row={k:r[k] for k in ['path','bytes','sha256']};inputs[row['path']]=row
selected=[]
for r in obj(OUT/'publication-original-copy-identities.json'):
 original=Path(r['original']);copied=OUT/r['copy'];eq(sha(original),r['sha256'],'selected original still exact');eq(sha(copied),r['sha256'],'selected original retained exact');eq(len(read(copied)),r['bytes'],'selected size');selected.append(r)
for r in obj(OUT/'protocol-original-copy-identities.json'):
 eq(sha(r['path']),r['sha256'],'protocol original exact');eq(sha(r['copy']),r['sha256'],'protocol copy exact');selected.append({'original':r['path'],'copy':str(Path(r['copy']).relative_to(OUT)),'bytes':r['bytes'],'sha256':r['sha256']})
rechecked=0
for r in list(inputs.values()):
 p=Path(r['path'])
 if r.get('mutable-original'):continue
 eq(sha(p),r['sha256'],'final immutable input identity '+str(p));eq(len(read(p)),r['bytes'],'final immutable input size');rechecked+=1
current=read(AUTHORITY);eq(hashlib.sha256(current).hexdigest(),inspection['current-authority']['sha256'],'current authority remains dated48 at final observation')
with (OUT/'authority-final-observation.yaml').open('xb') as f:f.write(current)
reader_results=[]
for p in sorted(OUT.glob('*-result.json')):
 v=obj(p)
 if p.name in ['bounded-actual-schema-result.json','publication-audit-result.json']:eq(v['returncode'],1,'only diagnosed preserved original reader exit1')
 else:eq(v['returncode'],0,'every other original review command actual0')
 prefix=p.name.removesuffix('-result.json');record={'name':prefix,'actual-exit':v['returncode'],'actual-result':{'path':str(p),'sha256':sha(p)}}
 for label in ['command.json','stdout.txt','stderr.txt']:
  q=OUT/(prefix+'-'+label)
  if q.exists():record[label]={'path':str(q),'sha256':sha(q),'bytes':len(read(q))}
 reader_results.append(record)
if errors:finish('final-integrity-failed-inspection.json',{'result':'FAIL','rechecked':rechecked})
for r in files.values():
 if r['path'] not in inputs:inputs[r['path']]=r
catalog=sorted(inputs.values(),key=lambda r:r['path']);dump('input-identities.json',catalog);dump('selected-original-copy-identities.json',selected)
report='''CLEAN — r4 annotations/T12 actual publication only; no open findings.

The Goal requires “Refresh invalidated certifications rather than reusing stale hashes” (original attachment, lines 131–133). T12 requires records to bind actual products, candidate, contract and execution identity, while retaining prior obligations (docs/t12-certification.md:139–145). I verified the original command’s actual exit 0, 2026-09-13T22:22:04.576988Z → 2026-09-14T00:11:36.482684Z, and its complete 13-line publication protocol. All 10 retained command members are byte-exact.

The dated and current authorities contain the exact eight annotations certifications from the unchanged observed-index and preserve the prior forty against their reviewed indexes: 48 entries and 192 PASS records observed. This review binds annotations’ 32 records/reports, eight configurations, eight actual 47-test transcripts, and 84 original BEFORE/AFTER environment files to the sealed raw review. Current staged inputs remain 1,933 sources, 30 contracts, 23 artifacts and 24 harness files on candidate ab18cc9c0473730a6aabec5d12e3172f22bea23a0a0f9529052a2bc186cbfc1b / contract 3de508f79fcbef7258feee8abc013d6f02b000840cac1cb263cb0d6f927b8f2b. Facade execution remains actual IN_PROCESS, as required by T12:64–65.

The 1,486-member raw-review archive and 77-member metadata-publication archive match their originals. Raw rules/RGB were not replayed. Two reader schema diagnostics have preserved originals and separate passing closure; auxiliary display truncation left complete captured files intact. The historical r3 loss of two derived annotation summaries remains disclosed; no recovery is claimed.

Only annotations’ actual exit/publication gate is closed. Consolidated final validation, inventory/index/readiness and delivery approval remain outside this review. No completion criteria were marked and no repository or tracker changes were made.
'''
with (OUT/'report.md').open('x') as f:f.write(report)
eq(len(report.split())<400,True,'under400 word report')
receipt={'schema-version':1,'review-axis':'Spec','created-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'result':'CLEAN','findings':[],'hard-findings':0,'open-findings':0,'scope':'Only r4 annotations actual outer exit/publication and exact preservation of prior40','fixed-baseline':'5b1603c435f11c40368f75b7b9a2777c9c5e9761','candidate':CID,'contract':CT,'actual-command':inspection['actual-command'],'actual-result':inspection['actual-result'],'original-outer-log-lines':13,'original-outer-log-sha256':inspection['outer-log-sha256'],'outer-stderr':inspection['outer-stderr'],'command-retention':inspection['original-command-retention'],'closed-raw-review':inspection['closed-raw-review'],'closed-prior-metadata-archive':inspection['closed-prior-metadata-archive'],'closed-prior-publications':inspection['closed-prior-publications'],'dated-authority':inspection['dated-authority'],'prior-authority':inspection['prior-authority'],'current-authority-observation':inspection['current-authority'],'final-authority-observation':{'path':'authority-final-observation.yaml','sha256':hashlib.sha256(current).hexdigest(),'observed-utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},'counts':{'annotations-tuples':8,'annotations-records-and-reports':32,'annotations-configurations':8,'formal-tests-per-tuple':47,'formal-test-family-split':{'Native':36,'Stable-Facade':9,'artifact-contracts':2},'annotations-environment-originals':84,'prior-preserved-tuples':40,'prior-preserved-records':160,'prior-preserved-configurations':40,'observed-authority-tuples':48,'observed-PASS-records':192,'command-archive-members':10,'raw-review-archive-members':1486,'metadata-publication-archive-members':77,'stage':inspection['stage-counts']},'actual-formal-transcripts':inspection['actual-formal-transcripts'],'actual-Facade-mode':'IN_PROCESS','before-after-equality':'Closed raw reconstruction bound through all84 unchanged originals; AFTER intentionally has no environment.yaml.','publication-inspection':{'path':'actual-publication-inspection.json','sha256':sha(OUT/'actual-publication-inspection.json'),'original-exit':1,'only-diagnostic':'Pages prior receipt uses own-pages-index-sha256, not generic own-index-sha256. All other checks completed.'},'separate-diagnostic-closure':{'path':'reader-diagnostic-scoped-closure-inspection.json','sha256':sha(OUT/'reader-diagnostic-scoped-closure-inspection.json'),'actual-result':'reader-diagnostic-scoped-closure-result.json','actual-result-sha256':sha(OUT/'reader-diagnostic-scoped-closure-result.json'),'actual-exit':0,'original-diagnostics-overwritten':False},'input-catalog':{'path':'input-identities.json','sha256':sha(OUT/'input-identities.json'),'files':len(catalog),'immutable-inputs-rechecked':rechecked},'selected-originals':{'path':'selected-original-copy-identities.json','sha256':sha(OUT/'selected-original-copy-identities.json'),'copy-bindings':len(selected),'unique-copies':len({r['copy'] for r in selected})},'all-original-reader-command-results':reader_results,'raw-rules-RGB-replayed':False,'five-file-source-correction-reopened':False,'historical-retention-limitation':inspection['historical-boundary'],'no-current-output-overwrites':True,'approvals':{'annotations-actual-outer-exit':True,'annotations-eight-exact-publication':True,'prior40-exact-preservation':True,'other-obligations-reapproved':False,'consolidated-final48-validation-inventory-index-readiness-delivery':False,'completion-criteria-marked':False},'no-project-execution':True,'no-repository-Git-tracker-mutation':True,'progress-document-boundary':'Canonical README progress may advance after its dated retained copies; no equality requirement across observation times.','report':{'path':'report.md','sha256':sha(OUT/'report.md'),'words':len(report.split())},'manifest-contract':'manifest.json is created after final reader command/results and includes every retained file except itself.'}
dump('receipt.json',receipt)
finish('final-integrity-inspection.json',{'result':'CLEAN','input-catalog-count':len(catalog),'immutable-inputs-rechecked':rechecked,'selected-copy-bindings':len(selected),'readers':len(reader_results),'diagnosed-original-exit1-readers':['bounded-actual-schema','publication-audit'],'separate-closure-actual0':True,'report-sha256':sha(OUT/'report.md'),'receipt-sha256':sha(OUT/'receipt.json'),'report-words':len(report.split())})
