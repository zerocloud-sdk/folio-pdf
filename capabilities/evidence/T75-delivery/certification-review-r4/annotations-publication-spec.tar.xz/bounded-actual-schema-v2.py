from auditlib import *
import yaml
raw=obj(RAW/'receipt.json')
print('RAW SCOPE',json.dumps(raw['scope']))
for section,pattern in [('final-certification-r4','annotations-command-archive-identity.json'),('certification-review-r4','annotations-eight-tuples-spec-archive-identity.json'),('certification-review-r4','metadata-publication-spec-archive-identity.json')]:
 p=DELIVERY/section/pattern;v=obj(p);print('ARCHIVE',pattern,json.dumps({k:({'count':len(vv),'first':vv[0] if vv else None} if isinstance(vv,list) else vv) for k,vv in v.items()}))
own=obj(ROOT/'observed-index.json');print('CERT',json.dumps(own['certifications'][0]));print('ENV',json.dumps(own['environments'][0]))
cp=REPO/own['certifications'][0]['configuration']['path'];c=obj(cp);print('CONFIG',json.dumps({k:(len(v) if k=='inputs' else v) for k,v in c.items()}))
rp=REPO/own['certifications'][0]['records'][0]['path'];r=obj(rp);print('RECORD',json.dumps({k:(len(v) if isinstance(v,list) else v) for k,v in r.items()}))
rr=obj(REPO/r['report']['path']);print('REPORT',json.dumps({k:(len(v) if isinstance(v,list) else v) for k,v in rr.items()}))
print('OUTER LOG',read(COMMAND/'command.log').decode())
print('T12 REQUIREMENTS')
for i,line in enumerate(read(REPO/'docs/t12-certification.md').decode().splitlines(),1):
 if any(w in line.lower() for w in ['publish','47','in_process','revalidat','candidate','record','evidence']):print(str(i)+': '+line)
finish('bounded-actual-schema-v2-inspection.json',{'raw-keys':list(raw),'configuration-keys':list(c),'record-keys':list(r),'report-keys':list(rr)})
