from pathlib import Path,PurePosixPath
import hashlib,json,re,datetime
REPO=Path('/home/ubuntu/IdeaProjects/open-pdf');OUT=Path(__file__).parent
ROOT=REPO/'capabilities/evidence/T75-foundation-20260914-r4/annotations'
DELIVERY=REPO/'capabilities/evidence/T75-delivery';AUTHORITY=REPO/'capabilities/foundation-evidence.yaml'
CID='ab18cc9c0473730a6aabec5d12e3172f22bea23a0a0f9529052a2bc186cbfc1b';CT='3de508f79fcbef7258feee8abc013d6f02b000840cac1cb263cb0d6f927b8f2b'
RAW=Path('/tmp/t75-final-spec-r4-annotations-eight-2e38t91l');COMMAND=Path('/tmp/t75-final-annotations-certified-r4-4jvjl8vo')
META=Path('/tmp/t75-r4-metadata-publication-spec-q58y9z6e')
files={};errors=[]
def error(w,d):errors.append({'where':str(w),'detail':d})
def read(p):
 p=Path(p);data=p.read_bytes();row={'path':str(p),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
 if p==AUTHORITY:row['mutable-original']=True
 if str(p) in files and files[str(p)]!=row and p!=AUTHORITY:error(p,'identity changed during bounded reader')
 files[str(p)]=row;return data
def sha(p):return hashlib.sha256(read(p)).hexdigest()
def obj(p):return json.loads(read(p))
def eq(a,b,w):
 if a!=b:error(w,{'actual':a,'expected':b})
def dump(n,d):
 q=OUT/n;q.parent.mkdir(parents=True,exist_ok=True)
 with q.open('x') as f:json.dump(d,f,ensure_ascii=False,indent=2);f.write('\n')
def copy(p,n):
 data=read(p);q=OUT/'originals'/n;q.parent.mkdir(parents=True,exist_ok=True)
 with q.open('xb') as f:f.write(data)
 return {'original':str(p),'copy':str(q.relative_to(OUT)),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
def finish(n,d):
 d['errors']=errors;dump(n,d);dump(n.removesuffix('.json')+'-read-identities.json',list(files.values()))
 print(json.dumps({'inspection':n,'input-files':len(files),'errors':len(errors),'first-errors':errors[:3]},ensure_ascii=False))
 if errors:raise SystemExit(1)
