from auditlib import *
import yaml
p=OUT/'selected-protocol-originals/qualified-publication-reader.py'
print('QUALIFIED READER');print(read(p).decode())
raw=obj(RAW/'receipt.json');print('RAW RECEIPT',json.dumps(raw))
for name in ['annotations-command-archive-identity.json','annotations-command-receipt.json']:
 p=DELIVERY/'final-certification-r4'/name
 if p.exists():print('RETENTION',name,json.dumps(obj(p)))
print('RETENTION FILES',json.dumps([p.name for p in (DELIVERY/'final-certification-r4').iterdir() if p.name.startswith('annotations')]))
idx=obj(ROOT/'observed-index.json');print('OWN INDEX KEYS',list(idx));print('OWN CERT',json.dumps(idx['certifications'][0]));print('OWN ENV',json.dumps(idx['environments'][0]))
stage=obj(DELIVERY/'final-candidate-r4/build-inputs.json');print('STAGE SCHEMA',json.dumps({k:({'count':len(v),'first':v[0]} if isinstance(v,list) else {kk:({'count':len(vv),'first':vv[0]} if isinstance(vv,list) else vv) for kk,vv in v.items()}) for k,v in stage.items()}))
print('OUTER LOG',read(COMMAND/'command.log').decode())
for n in ['syntax.yaml','execution.yaml']:
 p=ROOT/'jdk8-in_process'/n;v=yaml.safe_load(read(p));print('TUPLE',n,json.dumps(v))
finish('actual-schema-v1-inspection.json',{'raw-receipt-keys':list(raw),'index-keys':list(idx),'certification-sample':idx['certifications'][0]})
