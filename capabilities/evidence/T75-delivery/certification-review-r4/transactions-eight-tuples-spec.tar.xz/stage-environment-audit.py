from auditlib import *
import ast,datetime,yaml
stage=REPO/'capabilities/evidence/T75-delivery/final-candidate-r4'
build=obj(stage/'build-inputs.json');candidate=build['candidate'];contract=build['contract-inputs']
validation=obj(REPO/'capabilities/evidence/T75-delivery/final-validation-r4/source-and-contract-inputs.json')
groups={'sources':candidate['inputs'],'contracts':contract,'artifacts':candidate['artifacts'],'harness':build['harness']};observed={}
for label,rows in groups.items():
 eq(len(rows),{'sources':1933,'contracts':30,'artifacts':23,'harness':24}[label],label+' current count')
 eq(len({r['path'] for r in rows}),len(rows),label+' unique input paths')
 for row in rows:eq(sha(REPO/row['path']),row['sha256'],label+':'+row['path'])
 observed[label]=len(rows)
eq({'inputs':candidate['inputs'],'contract-inputs':contract},validation,'current r4 host/matrix source and contract identities')
eq(sha(stage/'build-inputs.json'),'64cb458acef6c0e98aa5b0dbf8023d85fe569fa2269eb6c3c343959779325e02','frozen r4 staged identity')
eq(read(stage/'build-inputs.json'),read(REPO/'target/foundation-0.1.0/build-inputs.json'),'current staged build copy')
eq(candidate,obj(ROOT/'candidate-probe.json')['candidate'],'actual current transactions candidate probe')
old=obj(REPO/'capabilities/evidence/T75-delivery/final-candidate-r3/build-inputs.json')
closure=obj(REPO/'capabilities/evidence/T75-delivery/inventory-read-bound/independent-review-closure.json')
eq(contract,old['contract-inputs'],'unchanged r3 contract')
before={r['path']:r['sha256'] for r in old['candidate']['inputs']};current={r['path']:r['sha256'] for r in candidate['inputs']}
eq(set(before),set(current),'same source path universe')
delta=[{'path':n,'r3-sha256':before[n],'current-sha256':current[n],'bytes':files[str(REPO/n)]['bytes']} for n in sorted(current) if before[n]!=current[n]]
eq(delta,closure['source-delta'],'exact five independently reviewed r4 source changes')
eq(closure['spec-closed'] and closure['standards-closed'],True,'five-file two-axis closure')
canonical=lambda kind,rows:''.join(kind+' '+r['path']+' '+r['sha256']+'\n' for r in sorted(rows,key=lambda r:r['path']))
cid=lines_hash('release '+candidate['release']+'\n'+canonical('input',candidate['inputs'])+canonical('artifact',candidate['artifacts']));tid=lines_hash(canonical('contract',contract))
eq(cid,'ab18cc9c0473730a6aabec5d12e3172f22bea23a0a0f9529052a2bc186cbfc1b','canonical r4 candidate');eq(tid,'3de508f79fcbef7258feee8abc013d6f02b000840cac1cb263cb0d6f927b8f2b','unchanged canonical contract')
identitylog=read(ROOT/'candidate-identity.txt').decode();eq(re.search(r'^Candidate identity: ([a-f0-9]+)$',identitylog,re.M)[1],cid,'actual candidate');eq(re.search(r'^Contract identity: ([a-f0-9]+)$',identitylog,re.M)[1],tid,'actual contract')
eq(obj(stage/'t75-final-stage-r4-result.json')['returncode'],0,'current actual stage exit')
source = read(REPO / 'scripts/t03-foundation.py').decode()
tree = ast.parse(source)
literalcase = next((n.value for n in tree.body if isinstance(n, ast.Assign) and any((isinstance(t, ast.Name) and t.id == 'CERTIFICATION_CASES' for t in n.targets))))
textcase = next((v for k, v in zip(literalcase.keys, literalcase.values) if ast.literal_eval(k) == 'transactions'))
case = {ast.literal_eval(k): ast.literal_eval(v) for k, v in zip(textcase.keys, textcase.values) if ast.literal_eval(k) != 'test-classes'}
case['test-classes'] = ['net.zerocloud.pdf.consumer.' + n for n in ['BlankDocumentWorkflowTest', 'WorkflowLifecycleTest', 'WorkflowTransactionContractTest', 'WorkflowResourceOwnershipTest']] + ['net.zerocloud.pdf.itext7.consumer.BlankDocumentFacadeTest']
fn = next((n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'certification_tools'))
toolmeta = ast.literal_eval(next((n.value for n in fn.body if isinstance(n, ast.Assign) and any((isinstance(t, ast.Name) and t.id == 'external' for t in n.targets)))))
envprofiles = {p['identity']['jdk-major']: p for p in yaml.safe_load(read(REPO / 'capabilities/foundation-environments.yaml'))['profiles']}
tools = []
for t in toolmeta:
    pin = props(REPO / t['pin'])
    h = sha(REPO / t['path'])
    eq(h, pin[t['hash-key']], 'tool pin ' + t['id'])
    expected = {k: v for k, v in t.items() if k not in ('path', 'pin', 'hash-key')}
    expected['sha256'] = h
    tools.append(expected)
for label in ['t03', 't09', 't10', 't11', 't12', 't13']:
    tools.append({'id': 'folio-pdf-' + label, 'kind': 'project-test', 'version': '0.1.0', 'chains': ['semantic'], 'sha256': sha(REPO / 'target/foundation-0.1.0/harness/acceptance.jar')})
environments = []
for major, suffix in [(j, suffix) for j in [8, 11, 17, 21] for suffix in ['', '-after']]:
    name = 'jdk' + str(major) + '-environment' + suffix
    envprofile = envprofiles[major]
    envbefore = obj(ROOT / ('jdk' + str(major) + '-environment/environment.yaml'))
    eq(envprofile['identity'], envbefore['identity'], name + ' approved environment')
    eq(tools, envbefore['tools'], name + ' fifteen tool observations')
    d = ROOT / name
    osr = {k: v.strip('"') for k, v in props(d / 'os-release.txt').items()}
    jdk = {k: v.strip('"') for k, v in props(d / 'jdk-release.txt').items()}
    runtime = next((line.split('=', 1)[1].strip() for line in read(d / 'java-version.txt').decode().splitlines() if line.strip().startswith('java.runtime.version =')))
    image = read(d / 'image-digest.txt').decode().strip()
    arch = read(d / 'architecture.txt').decode().strip()
    n = obj(d / 'native-observation.json')
    eq(n['result'], 'pass', name + ' native observation')
    helperroot = REPO / '.build-cache/harfbuzz/10.2.0-final'
    eq(n['helper']['sha256'], sha(helperroot / 'bin/folio-harfbuzz'), name + ' helper actual')
    eq(n['installation']['sha256'], sha(helperroot / 'installation.json'), name + ' installed identity')
    eq(n['loaded_engine']['sha256'], sha(helperroot / 'lib/libharfbuzz.so.0.61020.0'), name + ' loaded engine identity')
    eq(n['observer']['sha256'], sha(REPO / 'scripts/t29-native-observation.py'), name + ' actual observer')
    eq(n['python']['sha256'], sha(Path('/usr/bin/python3.12')), name + ' Python executable')
    actual = {'os': osr['ID'], 'os-version': osr['VERSION_ID'], 'architecture': 'x86-64' if arch == 'x86_64' else arch, 'image': envprofile['identity']['image'].split('@')[0] + '@' + image, 'os-release-sha256': sha(d / 'os-release.txt'), 'jdk-major': int(runtime.split('.')[1] if runtime.startswith('1.') else runtime.split('.')[0]), 'jdk-vendor': jdk['IMPLEMENTOR'], 'jdk-build': runtime, 'java-sha256': read(d / 'java-executable.txt').decode().split()[0]}
    reconstructed = {'schema-version': 1, 'profile': envprofile['id'], 'identity': actual, 'host': {'kernel': read(d / 'kernel.txt').decode().strip(), 'architecture': actual['architecture']}, 'native-engine': {'name': 'harfbuzz', 'version': '10.2.0', 'helper-sha256': n['helper']['sha256'], 'library-sha256': n['loaded_engine']['sha256'], 'installation-sha256': n['installation']['sha256']}, 'tools': tools}
    eq(reconstructed, envbefore, name + ' reconstructed returned identity')
    inv = obj(d / 'invocation.json')
    eq(envprofile['identity']['image'] in inv, True, name + ' invocation image')
    eq('--network=none' in inv, True, name + ' no network')
    eq(read(d / 'observer.log'), b'', name + ' observer completed output')
    environments.append({'directory': str(d.relative_to(REPO)), 'reconstructed': reconstructed, 'raw-files': [{'name': p.name, 'sha256': sha(p)} for p in sorted(d.iterdir()) if p.is_file()]})
release = yaml.safe_load(read(REPO / 'capabilities/foundation-release.yaml'))
cp = sorted((p for p in release['required-artifacts'] if p.endswith('.jar') and (not p.endswith(('-sources.jar', '-javadoc.jar'))) and ('itext7-preview' not in p))) + [r['path'] for r in build['harness'] if r['path'].endswith('.jar')]
expectedinputs = set(cp + [r['path'] for r in build['harness']] + ['target/foundation-0.1.0/build-inputs.json', 'target/foundation-0.1.0/build-command.json', 'scripts/imagemagick-runtime.sha256'] + [t['pin'] for t in toolmeta])
for name in case['configuration-paths']:
    p = REPO / name
    expectedinputs.update((str(f.relative_to(REPO)) for f in p.rglob('*') if f.is_file())) if p.is_dir() else expectedinputs.add(name)
tuples = []
for major, mode in TUPLES:
    tuple_name = 'jdk' + str(major) + '-' + mode.lower()
    envprofile = envprofiles[major]
    scope = ROOT / tuple_name
    config = obj(scope / 'execution.yaml')
    command = obj(scope / 'contract-tests-command.json')
    log = read(scope / 'contract-tests.txt').decode()
    eq('OK (34 tests)' in log, True, mode + ' formal JUnit complete34')
    eq('FAILURES!!!' in log, False, mode + ' no failures')
    eq('I' in log.split('Time:')[0].replace('INFO', ''), False, mode + ' placeholder ignore check') if False else None
    expectedconfig = {'schema-version': 1, 'candidate-sha256': cid, 'environment-sha256': sha(ROOT / ('jdk' + str(major) + '-environment/environment.yaml')), 'acceptance-profile': case['profile'], 'execution-profile': mode, 'locale': 'en_US / C.UTF-8', 'timezone': 'UTC', 'settings': {'workflow-policy': case['workflow-policy'], 'fonts': case['fonts'], 'providers': 'none; Stable Facade execution is IN_PROCESS'}}
    subset(config, expectedconfig, mode + ' configuration')
    eq({r['path'] for r in config['inputs']}, expectedinputs, mode + ' exact configuration inventory')
    for r in config['inputs']:
        eq(sha(REPO / r['path']), r['sha256'], mode + ' config ' + r['path'])
    for c in [command, config['command']]:
        eq(c[c.index('-cp') + 1].split(':'), ['/workspace/' + p for p in cp], mode + ' exact staged classpath')
        eq(envprofile['identity']['image'] in c, True, mode + ' pinnedimage')
        eq('-Dfolio.t03.executionProfile=' + mode in c, True, mode + ' Native selection')
        eq('--network=none' in c, True, mode + ' network')
        eq(str(REPO) + ':/workspace:ro' in c, True, mode + ' readonly inputs')
    eq(command[command.index('-cp') + 2:], ['org.junit.runner.JUnitCore'] + case['test-classes'] + ['net.zerocloud.pdf.migration.itext7.contract.JarContractIT', 'net.zerocloud.pdf.migration.itext7.contract.ClasspathExclusivityIT'], mode + ' compiled contract classes')
    eq(config['command'][-5:], ['net.zerocloud.pdf.acceptance.T03EvidenceCommand', '/workspace', '/workspace/' + str(scope.relative_to(REPO)) + '/observations', mode, '0.1.0'], mode + ' actual recorder selection')
    tuples.append({'tuple': str(scope.relative_to(REPO)), 'contract-tests-sha256': sha(scope / 'contract-tests.txt'), 'tests': 34, 'time-seconds': float(re.search('Time: ([\\d.]+)', log)[1]), 'execution-configuration-sha256': sha(scope / 'execution.yaml'), 'configuration-inputs': len(config['inputs']), 'actual-native-mode': mode, 'actual-facade-mode': 'IN_PROCESS', 'staged-classpath-paths': cp})
testcounts = {}
for module, filename, expected in [('pdf-document', 'BlankDocumentWorkflowTest', 1), ('pdf-document', 'WorkflowLifecycleTest', 7), ('pdf-document', 'WorkflowTransactionContractTest', 16), ('pdf-document', 'WorkflowResourceOwnershipTest', 3), ('pdf-migration-itext7', 'BlankDocumentFacadeTest', 5)]:
    prefix = 'net/zerocloud/pdf/consumer/' if module == 'pdf-document' else 'net/zerocloud/pdf/itext7/consumer/'
    test = read(REPO / module / ('src/test/java/' + prefix + filename + '.java')).decode()
    count = len(re.findall('^    @Test(?:\\(|\\s*$)', test, re.M))
    eq(count, expected, 'current public T03 contract source count ' + filename)
    testcounts[filename] = count
request = read(REPO / 'pdf-document/src/test/java/net/zerocloud/pdf/consumer/T03Requests.java').decode()
eq('System.getProperty("folio.t03.executionProfile", "IN_PROCESS")' in request, True, 'actual Native selector source')
eq(case['test-count'], 34, 'exact current suite count')
eq(case.get('contract-timeout', 300), 300, 'existing aggregate timeout default')
finish('stage-environment-contract-inspection.json', {'created-utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'candidate-sha256': cid, 'contract-sha256': tid, 'input-counts': observed, 'matches-reviewed-r4-host-matrix-inputs': True, 'tools': tools, 'environment-observations': environments, 'tuples': tuples, 'public-contract-source-method-counts': testcounts, 'formal-aggregate-timeout-seconds': 300, 'deferred-environment-post-check': [], 'complete-eight-tuple-index-at-inspection': (ROOT / 'observed-index.json').exists()})
