from pathlib import Path
import hashlib, json, datetime
BASE = Path(__file__).parent
REPO = Path('/home/ubuntu/IdeaProjects/open-pdf')
ROOT = REPO / 'capabilities/evidence/T75-foundation-20260914-r4/transactions'
CURRENT = ROOT.parent
OLD = Path('/tmp/t75-final-spec-transactions-eight-5yptf21z')
files = {}
errors = []
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
digest = lambda data: hashlib.sha256(data).hexdigest()
def read(path):
    path = Path(path)
    if path.is_relative_to(CURRENT) and not path.is_relative_to(ROOT) and path != CURRENT / 'text/observed-index.json':
        raise ValueError('Other-obligation current raw contents are excluded: ' + str(path))
    data = path.read_bytes()
    row = {'path':str(path),'bytes':len(data),'sha256':digest(data)}
    if str(path) in files and files[str(path)] != row: errors.append({'where':str(path),'detail':'Bytes changed during an independent reader'})
    files[str(path)] = row
    return data
def sha(path): return digest(read(path))
def obj(path): return json.loads(read(path))
def eq(actual, expected, where):
    if actual != expected: errors.append({'where':str(where),'actual':actual,'expected':expected})
def require(value, detail):
    if not value: raise ValueError(detail)
def save(name, data):
    with (BASE / name).open('x') as handle:
        json.dump(data, handle, ensure_ascii=False, indent=2); handle.write('\n')
def copy_original(path, name):
    data = read(path)
    target = BASE / 'originals' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open('xb') as handle: handle.write(data)
    return {'original':str(path),'copy':str(target.relative_to(BASE)),'bytes':len(data),'sha256':digest(data)}
def finish(stem, data):
    data['errors'] = errors
    save(stem+'.json',data); save(stem+'-read-identities.json',list(files.values()))
    print(json.dumps({'output':stem+'.json','read-files':len(files),'errors':errors[:12],'error-count':len(errors)}))
