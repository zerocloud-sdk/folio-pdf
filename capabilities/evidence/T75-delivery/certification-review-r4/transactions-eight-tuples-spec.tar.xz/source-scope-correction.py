from readlib import *
original=obj(BASE/'public-controls-and-scope-alignment.json')
expected={'where':'current T03 public/profile/contract unchanged from r3 docs/foundation-readiness.md','actual':'23ac603f00d6789dd20f93b92ee2902f0f481198a63a05b2e23bf4275a4f2882','expected':'400ef2e6fe8834ba358677d09fc5a2b59dd5c053ff4978d32af4cb1e472354f7'}
eq(original['errors'],[expected],'exact original single reader diagnostic preserved')
closure=obj(REPO/'capabilities/evidence/T75-delivery/inventory-read-bound/independent-review-closure.json')
eq(closure['spec-closed'] and closure['standards-closed'],True,'existing five-file two-axis closure')
allowed={r['path']:r for r in closure['source-delta']}
require('docs/foundation-readiness.md' in allowed,'Explicit approved source delta must contain context doc')
before={r['path']:r['sha256'] for r in obj(REPO/'capabilities/evidence/T75-delivery/final-candidate-r3/build-inputs.json')['candidate']['inputs']}
after={r['path']:r['sha256'] for r in obj(REPO/'capabilities/evidence/T75-delivery/final-candidate-r4/build-inputs.json')['candidate']['inputs']}
unchanged=[];reviewed=[]
for r in original['unchanged-selected-T03-sources']:
 n=r['path'];h=sha(REPO/n);eq(h,after[n],'actual source matches r4 stage '+n)
 if before[n]==after[n]:unchanged.append({'path':n,'sha256':h})
 else:
  require(n in allowed,'Selected context source change requires existing explicit reviewed delta')
  eq(allowed[n]['r3-sha256'],before[n],'reviewed original '+n);eq(allowed[n]['current-sha256'],h,'reviewed current '+n)
  reviewed.append(allowed[n])
eq([r['path'] for r in reviewed],['docs/foundation-readiness.md'],'only already reviewed context documentation differs among selected sources')
finish('source-scope-diagnostic-closure',{'original-inspection':{'path':'public-controls-and-scope-alignment.json','sha256':sha(BASE/'public-controls-and-scope-alignment.json')},'original-actual-result':obj(BASE/'control-audit-inspected-result.json'),'original-diagnostic':expected,'disposition':'Reader scope assumption corrected; no candidate, source or certification defect. A general readiness context document was incorrectly grouped with unchanged T03 behavior sources.','existing-reviewed-five-file-closure-sha256':sha(REPO/'capabilities/evidence/T75-delivery/inventory-read-bound/independent-review-closure.json'),'unchanged-T03-selected-source-count':len(unchanged),'unchanged-T03-selected-sources':unchanged,'already-reviewed-context-source-delta':reviewed,'all-other-original-scope-checks':{'errors-excluding-exact-closed-diagnostic':[],'requirement-map':original['requirement-map'],'assigned-rules-per-checker':original['assigned-rules-per-checker'],'actual-negative-executions-per-checker':original['actual-negative-executions-per-checker'],'actual-executions-per-rule':original['actual-executions-per-rule']},'new-five-file-source-review':False,'new-project-execution':False,'original-overwrite':False,'remaining-findings':[]})
