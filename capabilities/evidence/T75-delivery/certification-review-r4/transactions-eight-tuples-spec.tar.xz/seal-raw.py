from pathlib import Path
import json, subprocess, sys, datetime, hashlib
base = Path(__file__).parent
script = base / 'verify-completed-raw.py'
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
sh = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
names = {k: base / ('finalization-' + v) for k, v in [('command', 'command.json'), ('stdout', 'stdout.txt'), ('stderr', 'stderr.txt'), ('result', 'result.json')]}
if any((p.exists() for p in names.values())) or (base / 'archive-manifest.json').exists():
    raise FileExistsError('Final original output exists; no overwrite')
meta = {'command': [sys.executable, '-B', str(script)], 'cwd': str(base), 'started-utc': now(), 'script-sha256': sh(script), 'boundary': 'Independent read-only final identity/parity audit and /tmp-only report sealing. No project commands or evidence mutation.'}
with names['command'].open('x') as f:
    json.dump(meta, f, indent=2)
    f.write('\n')
with names['stdout'].open('xb') as stdout, names['stderr'].open('xb') as stderr:
    r = subprocess.run(meta['command'], cwd=base, stdout=stdout, stderr=stderr)
meta.update({'returncode': r.returncode, 'completed-utc': now(), 'stdout-sha256': sh(names['stdout']), 'stderr-sha256': sh(names['stderr'])})
with names['result'].open('x') as f:
    json.dump(meta, f, indent=2)
    f.write('\n')
print(names['stdout'].read_text())
print(names['stderr'].read_text())
print(json.dumps(meta))
if r.returncode:
    sys.exit(r.returncode)
files = [{'path': str(p.relative_to(base)), 'bytes': p.stat().st_size, 'sha256': sh(p)} for p in sorted(base.rglob('*')) if p.is_file()]
manifest = {'schema-version': 1, 'original-review-directory': str(base), 'created-utc': now(), 'excluded-paths': ['archive-manifest.json'], 'exclusion-reason': 'The manifest excludes itself to avoid a circular SHA. All completed audit scripts, original commands/stdout/stderr/results, diagnostics, original copies, derived inspections, report and receipt are included. No later file will be written into this sealed directory.', 'member-count': len(files), 'members': files}
with (base / 'archive-manifest.json').open('x') as f:
    json.dump(manifest, f, indent=2)
    f.write('\n')
print(json.dumps({'directory': str(base), 'report': {'path': str(base / 'report.md'), 'sha256': sh(base / 'report.md')}, 'receipt': {'path': str(base / 'receipt.json'), 'sha256': sh(base / 'receipt.json')}, 'archive-manifest': {'path': str(base / 'archive-manifest.json'), 'sha256': sh(base / 'archive-manifest.json'), 'members-excluding-self': len(files)}, 'total-retained-files-including-manifest': len(files) + 1}))
