from readlib import *
import re, subprocess
paths=[
 'AGENTS.md','CONTEXT.md','CONTRIBUTING.md','docs/agents/domain.md','docs/agents/issue-tracker.md',
 'docs/t03-certification.md','docs/foundation-readiness.md',
 'capabilities/evidence/T03-document-workflow-transaction.md',
 'capabilities/evidence/T75-delivery/final-delivery-review-r3/historical-facade-counts.md',
 'pdf-document/src/test/java/net/zerocloud/pdf/consumer/T03Requests.java',
 'pdf-document/src/test/java/net/zerocloud/pdf/consumer/BlankDocumentWorkflowTest.java',
 'pdf-document/src/test/java/net/zerocloud/pdf/consumer/WorkflowLifecycleTest.java',
 'pdf-document/src/test/java/net/zerocloud/pdf/consumer/WorkflowTransactionContractTest.java',
 'pdf-document/src/test/java/net/zerocloud/pdf/consumer/WorkflowResourceOwnershipTest.java',
 'pdf-migration-itext7/src/test/java/net/zerocloud/pdf/itext7/consumer/BlankDocumentFacadeTest.java',
 'pdf-acceptance/src/main/java/net/zerocloud/pdf/acceptance/T03EvidenceCommand.java',
 'pdf-acceptance/src/main/java/net/zerocloud/pdf/acceptance/T03BlankSemantics.java',
 'pdf-acceptance/src/main/java/net/zerocloud/pdf/acceptance/StandardsEvidenceCommand.java',
 'pdf-acceptance/src/main/java/net/zerocloud/pdf/acceptance/VisualEvidenceRecorder.java',
 'pdf-acceptance/src/main/java/net/zerocloud/pdf/acceptance/EvidenceFiles.java',
 'pdf-acceptance/src/test/java/net/zerocloud/pdf/acceptance/T03EvidenceCommandTest.java',
 'pdf-acceptance/src/test/java/net/zerocloud/pdf/acceptance/T03BlankSemanticsTest.java',
 'scripts/t03-foundation.py',
 'capabilities/profiles/T03-standards/pdfcpu.properties',
 'capabilities/profiles/T03-standards/arlington.properties',
 'capabilities/profiles/T03-document-blank-visual.properties',
 'capabilities/facade-surface.yaml'
]
command=['rg','--files','pdf-migration-itext7','pdf-migration-itext7-preview']
started=now(); result=subprocess.run(command,cwd=str(REPO),capture_output=True)
with (BASE/'public-source-discovery-stdout.txt').open('xb') as h:h.write(result.stdout)
with (BASE/'public-source-discovery-stderr.txt').open('xb') as h:h.write(result.stderr)
save('public-source-discovery-command.json',{'command':command,'cwd':str(REPO),'started-utc':started})
save('public-source-discovery-result.json',{'returncode':result.returncode,'completed-utc':now(),'stdout-sha256':digest(result.stdout),'stderr-sha256':digest(result.stderr)})
require(result.returncode==0,'Read-only rg discovery must complete')
extra=[n for n in result.stdout.decode().splitlines() if n.endswith(('/JarContractIT.java','/ClasspathExclusivityIT.java','/PdfTextExtractor.java'))]
require(len(extra)==3,'Exactly actual two artifact sources plus added text Facade source')
paths+=extra
copies=[]; excerpts={}; annotations={}
for relative in paths:
 p=REPO/relative
 copies.append(copy_original(p,'current-contract-source/'+relative))
 lines=read(p).decode().splitlines()
 excerpts[relative]=[{'line':i,'text':line} for i,line in enumerate(lines,1) if re.search(r'@Test|public void |REQUIRED_RULES|IN_PROCESS|HARDENED_WORKER|10000|300|600|COMMITTED|NOT_ATTEMPTED|FAILED|assert|Unsupported|failure|ownership|atomic|19 types|105|21 types|157|20 classes|116|TextExtractor',line,re.I)]
 if p.suffix=='.java' and '/src/test/' in relative:
  annotations[relative]=[{'line':i,'text':line} for i,line in enumerate(lines,1) if '@Test' in line or re.search(r'public void [A-Za-z].*throws|public void [A-Za-z].*\(\)',line)]
for original,name in [
 (Path('/home/ubuntu/.codex/attachments/77353239-0dda-4ee1-b4bb-ce7fb3fa0f9b/pasted-text-1.txt'),'original-goal.txt'),
 (Path('/tmp/t75-issue-75-pre-freeze.json'),'issue-75-pre-freeze.json'),
 (Path('/tmp/t75-issue-1.json'),'issue-1.json')]:
 copies.append(copy_original(original,'requirements/'+name))
 eq(sha(original),'794423d41161169ea6a4fee993553f777d6249cb05c5fe4d34f59657ab18f83f','original Goal frozen SHA') if name=='original-goal.txt' else None
pub=Path('/tmp/t75-final-spec-r4-text-publication-qr473m_z')
receipt=obj(pub/'receipt.json')
save('prior-text-publication-schema.json',{'report-sha256':sha(pub/'report.md'),'receipt-sha256':sha(pub/'receipt.json'),'receipt':receipt,'top-level-files':[p.name for p in sorted(pub.iterdir()) if p.is_file()]})
save('public-source-excerpts.json',excerpts)
finish('public-source-scope-inspection',{'selected-source-copies':copies,'public-test-annotations':annotations,'scope':'Read-only source linkage and retained published T03 test intent; no test execution. Whole-JAR authority and historical family counts are distinct; no new T03 function asserted.','source-review-required':True})
