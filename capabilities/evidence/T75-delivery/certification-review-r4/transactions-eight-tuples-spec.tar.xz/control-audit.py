from auditlib import *
from collections import Counter
import yaml
counts=obj(OUT/'transactions-evidence-inspection.json')
eq(counts['errors'],[],'raw checks closed')
qualified=obj(OUT/'standards-negative-control-identities.json')
by_checker=Counter(r['checker'] for r in qualified);by_rule=Counter(r['rule'] for r in qualified)
for rule,count in by_rule.items():eq(count,16,'each assigned rule executed on all sixteen public products: '+rule)
eq(by_checker,{'pdfcpu':304,'arlington':48},'actual 19 plus 3 rule executions on sixteen products')
current=REPO/'capabilities/evidence/T75-delivery/final-candidate-r4/build-inputs.json'
staged=obj(current);old=obj(REPO/'capabilities/evidence/T75-delivery/final-candidate-r3/build-inputs.json')
before={r['path']:r['sha256'] for r in old['candidate']['inputs']};after={r['path']:r['sha256'] for r in staged['candidate']['inputs']}
source_rows=obj(OUT/'public-source-scope-inspection.json')['selected-source-copies']
unchanged=[]
for r in source_rows:
 p=Path(r['original'])
 if p.is_relative_to(REPO):
  n=str(p.relative_to(REPO))
  if n in before:
   eq(sha(p),after[n],'current selected source frozen identity '+n)
   eq(before[n],after[n],'current T03 public/profile/contract unchanged from r3 '+n)
   unchanged.append({'path':n,'sha256':after[n]})
anchors=[
 {'requirement':'Goal lines 131–133','quote':'Refresh invalidated certifications rather than reusing stale hashes.','evidence':'Current r4 stage, exact observed index and candidate-bound 32 chain records; no additional T03 functionality.'},
 {'requirement':'docs/t03-certification.md:14–21','quote':'COMMITTED/FAILED/NOT_ATTEMPTED receipts','evidence':'The 27 public Native tests, selected by the actual folio.t03.executionProfile property in each formal suite, include named primary input, bounded stream/channel/bytes, source/output ownership, callback and nested failures, inactive and cross-thread sessions, deterministic cancellation/deadline, resource exit categories, progress phases and exact ordered receipts.'},
 {'requirement':'WorkflowTransactionContractTest.java:341–395','quote':'multiTargetFailureReportsCommittedFailedAndNotAttemptedTargets','evidence':'One earlier target remains COMMITTED, the failing stream is FAILED with partial output possible, and the later target is NOT_ATTEMPTED with its previous bytes unchanged. T03 does not promise rollback across all Targets. Text extraction all-or-nothing is a separate previously reviewed obligation.'},
 {'requirement':'Goal lines 124–125; docs/t03-certification.md:23–31','quote':'The existing Facade uses IN_PROCESS; never relabel it as HARDENED_WORKER evidence.','evidence':'Five actual public Stable consumer tests per suite plus each retained Facade product reopen. Recorder explicitly passes IN_PROCESS to the Facade semantic inspection; the two Native profiles remain attributed only to Native operations.'},
 {'requirement':'docs/t03-certification.md:27–31; historical-facade-counts.md:20–35','quote':'Actual jar reflection checks Stable against the Stable tier and Preview against their union.','evidence':'The two compiled artifact test classes remain in all eight formal commands. Current whole authority is 21 types/157 members; historical 19/105 denotes lifecycle+values+pages. The actual coexistence probe enumerates 20 historical types in both jar orders; the added PdfTextExtractor delegates its initialization to PdfDocument in reviewed source. No claim of 21 individually executed coexistence probes.'},
 {'requirement':'docs/t03-certification.md:33–49','quote':'Each claimed rule has a hash-pinned, independently authored negative PDF with a required diagnostic.','evidence':'All 22 rule assignments match exact per-product controls; 352 fresh observations retain original control bytes and required diagnostics. Syntax has its separate non-PDF exit-2 control; public semantic has a separate known two-page fail; visual has its untouched source product with a separate one-black-pixel expected control.'},
 {'requirement':'docs/t03-certification.md:47–50','quote':'original 144 DPI, 1224×1584 opaque sRGB expected image, AE 0 and zero fuzz','evidence':'All own PNG SHA bindings checked; all 81 selected full RGB rasters decoded by the read-only reader, including all pixels of each expected/primary/secondary image and each one-pixel control. Comparisons are pixels, never cross-JDK compressed byte equality.'},
 {'requirement':'docs/t03-certification.md:72–74,101–111','quote':'Missing, mismatched, uncertain or uncovered observations cannot produce PASS.','evidence':'Exact complete arrays and references, separate producer assignments, input bounds, immutable tool/program/model pins, 300-second T03 suite guard and complete original current environment observations retained. AFTER identity is reconstructed from 10 raw files with no expected environment.yaml. Actual publication remains a separate excluded gate.'}
]
source=read(REPO/'pdf-acceptance/src/main/java/net/zerocloud/pdf/acceptance/T03EvidenceCommand.java').decode()
eq('Properties facade = record(root, facadeDirectory, WorkflowExecutionProfile.IN_PROCESS' in source,True,'actual recorder Facade supported mode')
finish('public-controls-and-scope-alignment.json',{'assigned-rules-per-checker':{'pdfcpu':len({r['rule'] for r in qualified if r['checker']=='pdfcpu'}),'arlington':len({r['rule'] for r in qualified if r['checker']=='arlington'})},'actual-negative-executions-per-checker':dict(by_checker),'actual-executions-per-rule':dict(by_rule),'unchanged-selected-T03-source-count':len(unchanged),'unchanged-selected-T03-sources':unchanged,'requirement-map':anchors,'manual-source-review':'No omission, scope expansion or incorrect promised behavior found in this unchanged T03 refresh. Earlier complete and incremental r4 source gates remain linked by the staged source identity. The current packet assesses actual raw evidence and own-index only.'})
