from readlib import *
import ast
SOURCE = BASE / 'originals/prior-reader-sources'
identities = []
def create(name, data, explanation, source):
    data = data.encode() if isinstance(data, str) else data
    ast.parse(data)
    with (BASE / name).open('xb') as handle: handle.write(data)
    identities.append({'source':str(source),'source-sha256':sha(source),'new':name,'new-sha256':digest(data),'adaptation':explanation})

lib = '''from readlib import *
from pathlib import PurePosixPath
import re
OUT = BASE
TUPLES = [(j,m) for j in [8,11,17,21] for m in ['IN_PROCESS','HARDENED_WORKER']]
def error(where,detail): errors.append({'where':str(where),'detail':detail})
def props(path):
 result={}
 for line in read(path).decode('utf-8').splitlines():
  if not line or line[0] in '#!':continue
  key,sep,value=line.partition('=')
  if not sep or key in result:error(path,'duplicate or malformed property '+key);continue
  result[key]=re.sub(r'\\\\(u[0-9a-fA-F]{4}|.)',lambda m:chr(int(m[1][1:],16)) if m[1].startswith('u') and len(m[1])==5 else {'t':'\\t','n':'\\n','r':'\\r','f':'\\f'}.get(m[1],m[1]),value)
 return result
def subset(actual,expected,where):
 for key,value in expected.items():eq(actual.get(key),value,str(where)+':'+key)
def lines_hash(text):return digest(text.encode())
def dump(name,value):save(name,value)
original_finish=finish
def finish(name,result):original_finish(name.removesuffix('.json'),result)
'''
create('auditlib.py',lib,'Original property decoding/comparison helpers retained; all reads delegate to the new guarded r4 readlib, and every output uses exclusive creation.',SOURCE/'auditlib.py')

old = read(SOURCE/'evidence-audit.py')
tree = ast.parse(old)
class VisualSummary(ast.NodeTransformer):
    count = 0
    def visit_Call(self,node):
        self.generic_visit(node)
        if isinstance(node.func,ast.Name) and node.func.id=='fields' and node.args and isinstance(node.args[0],ast.Name) and node.args[0].id=='rec':
            mapping=node.args[1]
            require(isinstance(mapping,ast.Call) and isinstance(mapping.func,ast.Name) and mapping.func.id=='dict' and isinstance(mapping.args[0],ast.Name) and mapping.args[0].id=='hashes','Unexpected summary binding expression')
            mapping.args[0]=ast.parse("{key:value for key,value in hashes.items() if key in ('Expected raster SHA-256','PDFium raster SHA-256','Implementation raster SHA-256')}",mode='eval').body
            self.count+=1
        return node
adapt=VisualSummary();tree=adapt.visit(tree);require(adapt.count==1,'Exactly one previously diagnosed summary expression is adapted')
create('reference-audit.py',ast.unparse(ast.fix_missing_locations(tree))+'\n','Only the already closed T03 visual.md summary schema difference is applied: three duplicated summary raster hashes, while all five original hashes remain checked in visual.txt and complete report arrays. ROOT comes from guarded r4 auditlib. No original control/rule/public-outcome validation is removed.',SOURCE/'evidence-audit.py')
create('rgb-audit.py',read(SOURCE/'raster-audit.py'),'Byte-exact qualified PNG CRC/bounded-decompression/full prescribed RGB reader; only imported auditlib selects the new r4 root and exclusive outputs.',SOURCE/'raster-audit.py')

old_stage=ast.parse(read(SOURCE/'stage-audit.py'))
start=next(i for i,node in enumerate(old_stage.body) if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='source' for t in node.targets))
tail=ast.Module(body=old_stage.body[start:],type_ignores=[])
class StageLabel(ast.NodeTransformer):
    count=0
    def visit_Constant(self,node):
        if node.value=='matches-worker-batch-host-matrix-inputs':self.count+=1;return ast.copy_location(ast.Constant('matches-reviewed-r4-host-matrix-inputs'),node)
        return node
label=StageLabel();tail=label.visit(tail);require(label.count==1,'One historical scope label changed')
header='''from auditlib import *
import ast,datetime,yaml
stage=REPO/'capabilities/evidence/T75-delivery/final-candidate-r4'
build=obj(stage/'build-inputs.json');candidate=build['candidate'];contract=build['contract-inputs']
validation=obj(REPO/'capabilities/evidence/T75-delivery/final-validation-r4/source-and-contract-inputs.json')
groups={'sources':candidate['inputs'],'contracts':contract,'artifacts':candidate['artifacts'],'harness':build['harness']};observed={}
for label,rows in groups.items():
 eq(len(rows),{'sources':1933,'contracts':30,'artifacts':23,'harness':24}[label],label+' current count')
 eq(len({r['path'] for r in rows}),len(rows),label+' unique input paths')
 for row in rows:eq(sha(REPO/row['path']),row['sha256'],label+':'+row['path'])
 observed[label]=len(rows)
eq({'inputs':candidate['inputs'],'contract-inputs':contract},validation,'current r4 host/matrix source and contract identities')
eq(sha(stage/'build-inputs.json'),'64cb458acef6c0e98aa5b0dbf8023d85fe569fa2269eb6c3c343959779325e02','frozen r4 staged identity')
eq(read(stage/'build-inputs.json'),read(REPO/'target/foundation-0.1.0/build-inputs.json'),'current staged build copy')
eq(candidate,obj(ROOT/'candidate-probe.json')['candidate'],'actual current transactions candidate probe')
old=obj(REPO/'capabilities/evidence/T75-delivery/final-candidate-r3/build-inputs.json')
closure=obj(REPO/'capabilities/evidence/T75-delivery/inventory-read-bound/independent-review-closure.json')
eq(contract,old['contract-inputs'],'unchanged r3 contract')
before={r['path']:r['sha256'] for r in old['candidate']['inputs']};current={r['path']:r['sha256'] for r in candidate['inputs']}
eq(set(before),set(current),'same source path universe')
delta=[{'path':n,'r3-sha256':before[n],'current-sha256':current[n],'bytes':files[str(REPO/n)]['bytes']} for n in sorted(current) if before[n]!=current[n]]
eq(delta,closure['source-delta'],'exact five independently reviewed r4 source changes')
eq(closure['spec-closed'] and closure['standards-closed'],True,'five-file two-axis closure')
canonical=lambda kind,rows:''.join(kind+' '+r['path']+' '+r['sha256']+'\\n' for r in sorted(rows,key=lambda r:r['path']))
cid=lines_hash('release '+candidate['release']+'\\n'+canonical('input',candidate['inputs'])+canonical('artifact',candidate['artifacts']));tid=lines_hash(canonical('contract',contract))
eq(cid,'ab18cc9c0473730a6aabec5d12e3172f22bea23a0a0f9529052a2bc186cbfc1b','canonical r4 candidate');eq(tid,'3de508f79fcbef7258feee8abc013d6f02b000840cac1cb263cb0d6f927b8f2b','unchanged canonical contract')
identitylog=read(ROOT/'candidate-identity.txt').decode();eq(re.search(r'^Candidate identity: ([a-f0-9]+)$',identitylog,re.M)[1],cid,'actual candidate');eq(re.search(r'^Contract identity: ([a-f0-9]+)$',identitylog,re.M)[1],tid,'actual contract')
eq(obj(stage/'t75-final-stage-r4-result.json')['returncode'],0,'current actual stage exit')
'''
create('stage-environment-audit.py',header+ast.unparse(ast.fix_missing_locations(tail))+'\n','Fresh r4 stage/five-file lineage prelude replaces obsolete r3 Worker-batch prelude. All original T03 tool, BEFORE/AFTER reconstruction, exact classpath/settings/source-count and300s guard checks remain in the unchanged AST tail, with one truthful lineage label update.',SOURCE/'stage-audit.py')

old_config=ast.parse(read(SOURCE/'complete-config-audit.py'))
end=next(i for i,node in enumerate(old_config.body) if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='prior' for t in node.targets))
body=ast.Module(body=old_config.body[:end],type_ignores=[])
class ConfigStage(ast.NodeTransformer):
    count=0
    def visit_Constant(self,node):
        if node.value=='capabilities/evidence/T75-delivery/final-candidate-r3/build-inputs.json':self.count+=1;return ast.copy_location(ast.Constant('capabilities/evidence/T75-delivery/final-candidate-r4/build-inputs.json'),node)
        return node
switch=ConfigStage();body=switch.visit(body);require(switch.count==1,'One exact configuration stage path update')
ending="""
finish('complete-config-and-index-inspection.json',{'actual-complete-command-observations':commandobservations,'exact-observed-certifications':len(expectedcerts),'exact-observed-chain-records':sum(len(c['records']) for c in expectedcerts),'observed-index-sha256':sha(ROOT/'observed-index.json'),'publication-conclusion':'Excluded from this packet even if the outer process completes. Prior text publication linkage is independently checked in its own component.','other-obligations-approved':False})
"""
create('complete-config-audit.py',ast.unparse(ast.fix_missing_locations(body))+'\n'+ending,'Original full recorder/formal argv and complete configuration/own-index checks retained; exactly one r4 stage-path literal changes. Obsolete r3 text-publication tail is replaced by an explicit raw-only boundary; fresh r4 text linkage is separate.',SOURCE/'complete-config-audit.py')
finish('reader-adaptation-inspection',{'created-utc':now(),'prepared-readers':identities,'original-reader-diagnostic-closure':{'path':str(SOURCE/'visual-summary-closure-audit.py'),'sha256':sha(SOURCE/'visual-summary-closure-audit.py')},'candidate-scope':'r4 transactions only','all-new-files-exclusive':True,'original-prior-reader-files-unchanged':True})
