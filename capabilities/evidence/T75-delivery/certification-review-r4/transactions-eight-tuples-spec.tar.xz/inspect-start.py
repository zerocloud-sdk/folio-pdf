from readlib import *
old_names = sorted(path.name for path in OLD.iterdir())
copies = []
for path in sorted(OLD.glob('*.py')):
    copies.append(copy_original(path, 'prior-reader-sources/'+path.name))
for name in ['report.md','receipt.json']:
    copies.append(copy_original(OLD/name,'prior-reader-sources/'+name))
for name in ['docs/t03-certification.md','capabilities/evidence/T03-document-lifecycle.md','CONTRIBUTING.md']:
    path = REPO / name
    if path.is_file(): copies.append(copy_original(path,'contracts/'+name.replace('/','--')))
tuples = []
for major in [8,11,17,21]:
    for mode in ['IN_PROCESS','HARDENED_WORKER']:
        scope = ROOT/('jdk'+str(major)+'-'+mode.lower())
        chains = {}
        for chain in ['syntax','standards','semantic','visual']:
            record = obj(scope/(chain+'.yaml'))
            report = obj(REPO/record['report']['path'])
            chains[chain]={'record-keys':list(record),'report-keys':list(report),'record-result':record.get('result'),'report-arrays':{key:len(value) for key,value in report.items() if isinstance(value,list)},'report-reference':record['report']}
        tuples.append({'scope':str(scope.relative_to(REPO)),'direct-names':sorted(path.name for path in scope.iterdir()),'formal-log':read(scope/'contract-tests.txt').decode(),'chains':chains})
index = obj(ROOT/'observed-index.json')
save('starting-schema-details.json',{'old-original-packet-direct-names':old_names,'tuples':tuples,'index-keys':list(index),'candidate-keys':list(index['candidate']),'first-certification':index['certifications'][0],'first-environment':index['environments'][0]})
finish('starting-schema-inspection',{'created-utc':now(),'prior-original-packet':str(OLD),'copied-prior-reader-sources':copies,'tuples':len(tuples),'actual-records':sum(len(row['chains']) for row in tuples),'detail-file':'starting-schema-details.json','scope':'Eight complete transactions raw tuples only; actual publication remains excluded.'})
