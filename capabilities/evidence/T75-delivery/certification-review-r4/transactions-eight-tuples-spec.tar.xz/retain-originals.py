from auditlib import *
from collections import Counter
copies=[];copied=set()
def retain(p,label):
 p=Path(p)
 if str(p) in copied:return
 copied.add(str(p));copies.append(copy_original(p,label))
rootnames=sorted(p.name for p in ROOT.iterdir() if p.is_file())
for name in rootnames:retain(ROOT/name,'current-raw/root/'+name)
envfiles=[]
for major in [8,11,17,21]:
 for suffix in ['', '-after']:
  d=ROOT/('jdk'+str(major)+'-environment'+suffix)
  rows=sorted(p for p in d.iterdir() if p.is_file())
  eq(len(rows),10 if suffix else 11,str(d)+' protocol file count')
  eq((d/'environment.yaml').exists(),not bool(suffix),str(d)+' only BEFORE YAML')
  for p in rows:retain(p,'current-raw/'+str(p.relative_to(ROOT)));envfiles.append(str(p))
for major,mode in TUPLES:
 scope=ROOT/('jdk'+str(major)+'-'+mode.lower());obs=scope/'observations'
 for p in sorted(scope.iterdir()):
  if p.is_file():retain(p,'current-raw/'+str(p.relative_to(ROOT)))
 for api in ['native','facade']:
  d=obs/api
  for name in ['blank.pdf','result.properties','syntax.txt','syntax.md','standards.txt','semantic.txt','visual.txt','visual.md']:
   retain(d/name,'current-raw/'+str((d/name).relative_to(ROOT)))
  for checker in ['pdfcpu','arlington']:
   for name in ['standards.properties','findings.txt']:
    p=d/checker/name;retain(p,'current-raw/'+str(p.relative_to(ROOT)))
 for name in ['blank.pdf','invalid.pdf','two-pages.pdf','one-pixel-control.properties','one-pixel-control.png','result.properties','syntax.txt','standards.txt','semantic.txt','visual.txt']:
  p=obs/'negative'/name;retain(p,'current-raw/'+str(p.relative_to(ROOT)))
C=REPO/'capabilities/profiles/T03-standards'
for checker in ['pdfcpu','arlington']:
 p=props(C/(checker+'.properties'))
 for rule in p['required-rules'].split(','):
  control=C/p['negative.'+rule+'.path']
  retain(control,'authored-control-authority/'+str(control.relative_to(C)))
  d=ROOT/'jdk8-in_process/observations/native'/checker
  for name in ['control-'+rule+'.pdf','negative-'+rule+'.txt']:
   q=d/name;retain(q,'selected-original-control-observations/'+checker+'/'+name)
retain(REPO/'capabilities/expected/T03-document-blank-144dpi-srgb.png','original-canonical-blank-raster.png')
for name in ['build-inputs.json','t75-final-stage-r4-command.json','t75-final-stage-r4-result.json']:
 p=REPO/'capabilities/evidence/T75-delivery/final-candidate-r4'/name
 retain(p,'stage/'+name)
for relative in ['capabilities/evidence/T75-delivery/final-validation-r4/source-and-contract-inputs.json','capabilities/evidence/T75-delivery/inventory-read-bound/independent-review-closure.json']:
 retain(REPO/relative,'source-lineage/'+Path(relative).name)
physical=[]
for p in sorted(ROOT.rglob('*')):
 require(not p.is_symlink(),'No linked file in complete raw root')
 if p.is_file():
  data=read(p);physical.append({'path':str(p.relative_to(REPO)),'bytes':len(data),'sha256':digest(data)})
save('complete-current-raw-tree-identities.json',physical)
save('selected-current-original-copy-identities.json',copies)
save('auxiliary-display-boundary.json',{'scope':'Auxiliary model-facing display only; no certification or saved derived artifact was lost or overwritten.','occurrence':'An exec_command printed the complete prior-text-publication-schema.json and transactions-evidence-inspection.json; the tool display exceeded its 11000-token return budget and the surrounding batch display budget.','actual-command-result':'Returned exit code 0; the original full auxiliary stdout was not independently retained. It is not represented as recovered bytes.','complete-prior-saved-inputs':[{'path':str(OUT/name),'sha256':sha(OUT/name)} for name in ['prior-text-publication-schema.json','transactions-evidence-inspection.json']],'formal-reader-originals':'The formal source/reference readers had already retained their full command/stdout/stderr/result and complete JSON before this display. Their original bytes remain intact.','resolution':'Inspected bounded fields from the already complete saved inputs. This is no new certification failure, reader-assertion failure, or extra gate.'})
finish('selected-original-retention-inspection.json',{'copies':len(copies),'complete-current-raw-files':len(physical),'complete-current-raw-bytes':sum(r['bytes'] for r in physical),'root-original-files':rootnames,'environment-original-files':len(envfiles),'tuple-original-files':sum('/jdk' in r['path'] and '-environment' not in r['path'] for r in physical),'no-full-raw-copy':True,'selection':'All own root records, tuple command/config/suite/chain/report records; all raw environments; exact positive PDF and textual outcomes per API/tuple; separate control findings; authored control authority and one complete actual rule-control sample set; canonical expected RGB, source/contract copies and stage lineage. All other raw file bytes remain in the certification tree and are bound by the complete path/size/SHA catalog.','excluded':'Current outer stdout/result/authority publication and every changing other-obligation raw scope are excluded.'})
