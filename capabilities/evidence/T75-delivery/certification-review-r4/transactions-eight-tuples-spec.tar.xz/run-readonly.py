from pathlib import Path
import hashlib, json, subprocess, sys, datetime
base = Path(__file__).parent
name = sys.argv[1]
allowed = {'inspect-start.py','reference-audit.py','control-audit.py','public-audit.py','rgb-audit.py','stage-environment-audit.py','prior-text-linkage-audit.py','retain-originals.py','finalize-raw.py'}
if name not in allowed: raise ValueError('Unauthorized reader filename')
prefix = name.removesuffix('.py')
outputs = {key:base/(prefix+'-'+suffix) for key,suffix in [('command','command.json'),('stdout','stdout.txt'),('stderr','stderr.txt'),('result','result.json')]}
if any(path.exists() for path in outputs.values()): raise FileExistsError('Original audit output exists; choose a fresh script/batch, never overwrite')
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
sha = lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
command = {'command':[sys.executable,'-B',str(base/name)],'cwd':str(base),'started-utc':now(),'script-sha256':sha(base/name),'readlib-sha256':sha(base/'readlib.py'),'boundary':'Independent read-only raw evidence inspection; exclusive /tmp outputs. No project tests, Maven, tools, certifier, observer, inventory or repository mutation.'}
with outputs['command'].open('x') as handle: json.dump(command,handle,indent=2);handle.write('\n')
with outputs['stdout'].open('xb') as stdout,outputs['stderr'].open('xb') as stderr:
    result=subprocess.run(command['command'],cwd=base,stdout=stdout,stderr=stderr)
command.update({'returncode':result.returncode,'completed-utc':now(),'stdout':{'path':outputs['stdout'].name,'bytes':outputs['stdout'].stat().st_size,'sha256':sha(outputs['stdout'])},'stderr':{'path':outputs['stderr'].name,'bytes':outputs['stderr'].stat().st_size,'sha256':sha(outputs['stderr'])}})
with outputs['result'].open('x') as handle:json.dump(command,handle,indent=2);handle.write('\n')
print(outputs['stdout'].read_text());print(outputs['stderr'].read_text());print(json.dumps(command));sys.exit(result.returncode)
