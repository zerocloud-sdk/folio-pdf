from pathlib import Path
import datetime,hashlib,json,sys
OUT=Path(__file__).parent
REPO=Path('/home/ubuntu/IdeaProjects/open-pdf')
ROOT=REPO/'capabilities/evidence/T75-foundation-20260913-r3/transactions'
errors=[]
def dump(n,d): (OUT/n).write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
def digest(p):
 h=hashlib.sha256();size=0
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''): h.update(b);size+=len(b)
 return h.hexdigest(),size
def eq(a,b,w):
 if a!=b:errors.append({'where':w,'actual':a,'expected':b})
merged={}
for m in sorted(OUT.glob('*-read-identities.json')):
 for e in json.loads(m.read_bytes()):
  p=e['path']
  if p in merged: eq(e['sha256'],merged[p]['sha256'],'same observed identity '+p);eq(e['bytes'],merged[p]['bytes'],'same observed size '+p)
  else:merged[p]={'path':p,'sha256':e['sha256'],'bytes':e['bytes'],'observed-in':[]}
  merged[p]['observed-in'].append(m.name)
copied=[]
for n in ['source-copy-identities.json','publication-original-copy-identities.json']:
 for e in json.loads((OUT/n).read_bytes()):
  h,z=digest(OUT/e['copy']);eq(h,e['sha256'],'exact original copy '+e['copy']);eq(z,e['bytes'],'original copy size '+e['copy']);copied.append(e)
  if e['path'] in merged:eq(e['sha256'],merged[e['path']]['sha256'],'copy matches original read '+e['path'])
  else:merged[e['path']]={'path':e['path'],'sha256':e['sha256'],'bytes':e['bytes'],'observed-in':[n]}
rehashed=0
for p,e in sorted(merged.items()):
 h,z=digest(Path(p));eq(h,e['sha256'],'unchanged original '+p);eq(z,e['bytes'],'unchanged original size '+p);rehashed+=1
original=json.loads((OUT/'original-tuple-file-identities.json').read_bytes())
expectedpaths={str(REPO/e['path']):e['sha256'] for e in original}
actualpaths={str(p) for j in [8,11,17,21] for m in ['in_process','hardened_worker'] for p in (ROOT/f'jdk{j}-{m}').rglob('*') if p.is_file()}
eq(actualpaths,set(expectedpaths),'complete eight original tuple tree membership')
for p,h in expectedpaths.items():eq(merged[p]['sha256'],h,'same original tuple identity '+p)
index=json.loads((ROOT/'observed-index.json').read_bytes())
textroot=REPO/'capabilities/evidence/T75-foundation-20260913-r3/text';textindex=json.loads((textroot/'observed-index.json').read_bytes())
authoritypath=REPO/'capabilities/foundation-evidence.yaml';authoritybytes=authoritypath.read_bytes();authority=json.loads(authoritybytes)
key=lambda c:(c['environment'],c['execution-profile'])
counts={}
for name,expected in [('transactions',index),('text',textindex)]:
 actual=[c for c in authority['certifications'] if c['obligation']==name];counts[name]=len(actual);eq(sorted(actual,key=key),sorted(expected['certifications'],key=key),'final exact authority subset '+name)
eq(authority['candidate'],index['candidate'],'same authority candidate')
counts['other']=len(authority['certifications'])-sum(counts.values())
(OUT/'publication-originals/final-authority-snapshot.json').write_bytes(authoritybytes)
authorityref={'path':str(authoritypath),'copy':'publication-originals/final-authority-snapshot.json','sha256':hashlib.sha256(authoritybytes).hexdigest(),'bytes':len(authoritybytes),'at-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'counts':counts,'other-obligation-additions-permitted':True}
prior=json.loads((OUT/'publication-authority-identity.json').read_bytes());h,z=digest(OUT/prior['copy']);eq(h,prior['sha256'],'prior authority snapshot retained');eq(z,prior['bytes'],'prior authority snapshot size')
phases={'stage-environment-contract-inspection.json':0,'transactions-evidence-inspection.json':32,'complete-config-and-index-inspection.json':0,'complete-rgb-raster-inspection.json':0,'visual-summary-schema-closure.json':0,'original-source-copy-inspection.json':1,'outer-command-interpretation-closure.json':0,'transactions-publication-inspection.json':0}
for name,count in phases.items():eq(len(json.loads((OUT/name).read_bytes())['errors']),count,'preserved original phase diagnostic count '+name)
eq(json.loads((OUT/'visual-summary-schema-closure.json').read_bytes())['all-original-diagnostics-accounted-for'],True,'all original schema diagnostics closed')
eq(json.loads((OUT/'outer-command-interpretation-closure.json').read_bytes())['all-original-copy-reader-diagnostics-accounted-for'],True,'all original argv diagnostics closed')
identities=sorted(merged.values(),key=lambda e:e['path']);dump('inspected-input-identities.json',identities);dump('final-authority-identity.json',authorityref)
result={'created-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'unique-original-identities-rehashed':rehashed,'total-original-bytes-rehashed':sum(e['bytes'] for e in identities),'byte-exact-original-copies':len(copied),'selected-source-copies':1332,'outer-completed-original-copies':3,'authority-snapshots':2,'original-eight-tuple-files':len(expectedpaths),'all-original-tree-membership-and-identities-unchanged':not errors,'final-authority':authorityref,'preserved-original-reader-diagnostics':{'summary-schema':32,'relative-interpreter-spelling':1},'separate-reader-diagnostic-closures-complete':True,'transactions-only-publication-and-retained-text-subset':True,'all48-or-final-delivery-approved':False,'errors':errors}
dump('final-identity-inspection.json',result);print(json.dumps(result,ensure_ascii=False));sys.exit(bool(errors))
