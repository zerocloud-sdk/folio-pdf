from pathlib import Path
import datetime,hashlib,json
out=Path(__file__).parent
def obj(n):return json.loads((out/n).read_bytes())
def identity(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def dump(n,d):(out/n).write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
report='''CLEAN — eight actual r3 transactions/T03 tuples and their publication pass this bounded Spec review. The original certifier exited 0 at 2026-09-13T09:18:12.417480Z. Authority contains exactly the eight unchanged transaction certifications and preserves the eight previously reviewed text certifications. Earlier pending observations remain archived.

Goal lines 131–133 require “Refresh invalidated certifications rather than reusing stale hashes” and prohibit additional functionality through revalidation. This refresh matches that scope and `docs/t03-certification.md:14–57,101–111`.

Baseline: `5b1603c435f11c40368f75b7b9a2777c9c5e9761`. Candidate: `e2dd9ebbeae5668ccc8e2985ccd8af17c8921d1ec5e12e0c913cbd1fa00dfbd6`; contract: `3de508f79fcbef7258feee8abc013d6f02b000840cac1cb263cb0d6f927b8f2b`. Current 1,933 source inputs, 30 contracts, 23 artifacts and 24 harness inputs match the reviewed r3 stage, source closures and refreshed host/matrix identity boundary.

All eight formal suites passed 34 tests each: 27 Native, five public Stable Facade and two actual-artifact tests. Source review preserves ordered target receipts, failure/cancellation/deadline behavior and caller ownership. Publication remains deliberately non-atomic across Targets. The actual Facade mode is IN_PROCESS in both Native modes, satisfying Goal lines 124–125. All four pinned JDK environments, before/after identities, commands, configurations, classpaths and tool identities match; the T03 aggregate guard remains 300 seconds.

All 32 chain records, exact report arrays and original references were checked. Each tuple contains 150 original files, including 138 observation files and 191 report references. T03 has no producer manifest requirement. Its 22-rule union (19 pdfcpu plus three Arlington), 16 public products and 352 qualified negative controls are complete. Separate syntax, semantic and visual negatives retain expected failures. Eighty-one complete RGB raster observations establish canonical white 1224×1584 output and the one-black-pixel control; exact original PDF/PNG hashes remain authoritative.

Final recheck covered 3,978 unchanged identities. The 32 summary-schema and one interpreter-spelling reader diagnostics are preserved and separately closed against the existing T03 contract. No project execution or repository mutation occurred. This review does not approve other obligations, all 48 tuples or final delivery.
'''
(out/'report.md').write_text(report)
assert len(report.split())<400
phase_names=['stage-audit','evidence-audit','complete-config-audit','raster-audit','visual-summary-closure-audit','scope-source-audit','outer-command-closure-audit','publication-audit','finalize-audit']
phases=[]
for n in phase_names:
 result=obj(n+'-result.json');assert result['returncode']==0
 phases.append({'name':n,'script':identity(out/(n+'.py')),'command':identity(out/(n+'-command.json')),'output':identity(out/(n+'-output.txt')),'result':identity(out/(n+'-result.json')),'actual-returncode':result['returncode'],'started-utc':result['started-utc'],'completed-utc':result['completed-utc']})
final=obj('final-identity-inspection.json');assert final['errors']==[]
stage=obj('stage-environment-contract-inspection.json');config=obj('complete-config-and-index-inspection.json');pub=obj('transactions-publication-inspection.json')
receipt={'created-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reviewer':'independent Spec subagent /root/final_spec','verdict':'CLEAN within exact eight r3 transactions/T03 observation and publication scope; prior text8 retained','baseline':obj('scope.json')['baseline'],'candidate-sha256':stage['candidate-sha256'],'contract-sha256':stage['contract-sha256'],'report':identity(out/'report.md'),'report-word-count':len(report.split()),'original-goal':identity(Path('/home/ubuntu/.codex/attachments/77353239-0dda-4ee1-b4bb-ce7fb3fa0f9b/pasted-text-1.txt')),'original-scope':identity(out/'scope.json'),'authorized-publication-supplement':identity(out/'scope-publication-amendment.json'),'input-counts':stage['input-counts'],'staged-build-inputs':identity(Path('/home/ubuntu/IdeaProjects/open-pdf/capabilities/evidence/T75-delivery/final-candidate-r3/build-inputs.json')),'formal-tuples':stage['tuples'],'aggregate-timeout-seconds':300,'public-contract-source-method-counts':stage['public-contract-source-method-counts'],'observed-index-sha256':config['observed-index-sha256'],'closed-prior-text-review':config['closed-text-linkage'],'actual-publication':pub,'final-identity-recheck':final,'inspected-input-identities':identity(out/'inspected-input-identities.json'),'copied-original-source-identities':identity(out/'source-copy-identities.json'),'completed-outer-original-copies':identity(out/'publication-original-copy-identities.json'),'actual-independent-review-phases':phases,'original-reader-diagnostics-and-separate-closures':[{'original':identity(out/'transactions-evidence-inspection.json'),'original-count':32,'closure':identity(out/'visual-summary-schema-closure.json'),'classification':'Reader added duplicate raw difference SHA summary fields absent from original T03 schema; all authoritative report/raw references valid.'},{'original':identity(out/'original-source-copy-inspection.json'),'original-count':1,'closure':identity(out/'outer-command-interpretation-closure.json'),'classification':'Reader expected relative python3 spelling; original explicit /usr/bin/python3 resolves to the same observed executable.'}],'original-pending-observations-preserved':[identity(out/'outer-publication-progress-observation.json'),identity(out/'outer-log-progress-snapshot.txt')],'validation-boundary':'Only independent read-only source, retained original evidence, SHA and complete PNG byte inspection; no Maven, project CLI, certifier, environment observer, tests, probes, renderers, Git/tracker/repo mutation. Existing T03 Linux descriptor condition retained; no extra assertion about JUnit assumption counts.','other-obligations-all48-or-final-delivery-approved':False,'completion-criteria-marked':False}
dump('receipt.json',receipt)
manifest=[]
for p in sorted(out.rglob('*')):
 if p.is_file() and p.name!='archive-manifest.json':
  d=identity(p);d['path']=str(p.relative_to(out));manifest.append(d)
dump('archive-manifest.json',{'created-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'root':str(out),'entries':manifest,'file-count':len(manifest),'total-bytes':sum(e['bytes'] for e in manifest),'exclusion':'archive-manifest.json self-reference only'})
print(json.dumps({'report':identity(out/'report.md'),'receipt':identity(out/'receipt.json'),'archive-manifest':identity(out/'archive-manifest.json'),'report-word-count':len(report.split()),'archive-file-count':len(manifest),'archive-total-bytes':sum(e['bytes'] for e in manifest)},indent=2))
