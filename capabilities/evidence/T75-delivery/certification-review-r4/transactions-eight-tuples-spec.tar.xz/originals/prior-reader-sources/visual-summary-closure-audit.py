from auditlib import *
prior=OUT/'transactions-evidence-inspection.json';old=obj(prior);expected={};observations=[]
for major,mode in TUPLES:
 scope=ROOT/('jdk'+str(major)+'-'+mode.lower());report=obj(scope/'visual-report.json')
 for api in ['native','facade']:
  d=scope/'observations'/api;raw=read(d/'visual.txt').decode();summary=read(d/'visual.md').decode()
  for label,name in [('Difference','difference'),('Renderer difference','renderer-difference')]:
   p=d/('T07-document-blank-'+name+'.png');h=sha(p);key=label+' raster SHA-256';where=str(d/'visual record binding')+' '+key;expected[where]={'actual':[],'expected':[h]}
   eq(re.findall(r'^'+re.escape(key)+r': `([^`\r\n]*)`$',raw,re.M),[h],str(p)+' exact original raw finding identity');eq({'path':str(p.relative_to(REPO)),'sha256':h} in report['findings'],True,str(p)+' authoritative report retains exact original raster reference');eq(re.findall(r'^'+re.escape(key)+r': `([^`\r\n]*)`$',summary,re.M),[],str(p)+' observed existing T03 summary schema')
   observations.append({'path':str(p.relative_to(REPO)),'sha256':h,'raw-finding-sha256':sha(d/'visual.txt'),'authoritative-report-sha256':sha(scope/'visual-report.json'),'original-summary-omits-duplicated-SHA-field':True})
eq(len(old['errors']),32,'exact original review schema diagnostic count');eq({e['where']:e['detail'] for e in old['errors']},expected,'all original diagnostics concern only extra summary field assumptions')
finish('visual-summary-schema-closure.json',{'scope':'Only original T03 summary schema diagnostics from the independent reader','original-diagnostic-report':{'path':str(prior),'sha256':sha(prior),'diagnostic-count':len(old['errors'])},'classification':'The reader incorrectly required raw visual.txt difference-SHA fields to be duplicated in the existing T03 visual.md summary. T03 authority is the complete report JSON with original raw findings and file references; all actual differences are SHA-bound there. No T13 summary-format requirement is added to this existing obligation.','all-original-diagnostics-accounted-for':True,'observations':observations,'project-evidence-modified-or-reexecuted':False})
