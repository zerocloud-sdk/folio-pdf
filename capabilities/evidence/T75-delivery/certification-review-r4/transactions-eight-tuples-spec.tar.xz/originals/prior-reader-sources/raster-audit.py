from auditlib import *
import zlib,struct
C=REPO/'capabilities/expected/T03-document-blank-144dpi-srgb.png';width,height=1224,1584;stride=width*3;WHITE=b'\xff'*stride;BLACK_FIRST=b'\x00'*3+WHITE[3:];ZERO=b'\x00'*stride;cache={};encoded_cache={};observations=[]
def filtered(current,previous,kind):
 key=(current[:3],previous[:3],previous is ZERO,kind)
 if key in cache:return cache[key]
 row=bytearray(stride)
 for x,v in enumerate(current):
  a=current[x-3] if x>=3 else 0;b=previous[x];c=previous[x-3] if x>=3 else 0
  if kind==0:predict=0
  elif kind==1:predict=a
  elif kind==2:predict=b
  elif kind==3:predict=(a+b)//2
  else:
   p=a+b-c;pa,pb,pc=abs(p-a),abs(p-b),abs(p-c);predict=a if pa<=pb and pa<=pc else b if pb<=pc else c
  row[x]=(v-predict)&255
 cache[key]=bytes(row);return cache[key]
def inspect(p,oneblack=False):
 data=read(p);h=hashlib.sha256(data).hexdigest();key=(h,oneblack)
 if key not in encoded_cache:
  eq(data[:8],b'\x89PNG\r\n\x1a\n',str(p)+' original PNG signature');pos=8;compressed=[];chunks=[]
  while pos<len(data):
   n=int.from_bytes(data[pos:pos+4],'big');kind=data[pos+4:pos+8];payload=data[pos+8:pos+8+n];crc=data[pos+8+n:pos+12+n];eq(len(payload),n,str(p)+' original chunk length');eq(zlib.crc32(kind+payload)&0xffffffff,int.from_bytes(crc,'big'),str(p)+' original chunk CRC');chunks.append(kind.decode())
   if kind==b'IHDR':eq(list(struct.unpack('>IIBBBBB',payload)),[width,height,8,2,0,0,0],str(p)+' complete opaque RGB8 input format')
   elif kind==b'IDAT':compressed.append(payload)
   elif kind==b'IEND':eq(pos+12,len(data),str(p)+' no trailing PNG data');break
   pos+=n+12
  eq(chunks[0],'IHDR',str(p)+' original IHDR');eq(chunks[-1],'IEND',str(p)+' original IEND');eq('tRNS' in chunks,False,str(p)+' opaque PNG input');expectedlength=height*(stride+1);inflater=zlib.decompressobj();scanlines=inflater.decompress(b''.join(compressed),expectedlength+1);eq(len(scanlines),expectedlength,str(p)+' complete bounded decompression');eq(inflater.eof and not inflater.unused_data and not inflater.unconsumed_tail,True,str(p)+' exact bounded zlib stream')
  previous=ZERO
  for y in range(height):
   start=y*(stride+1);kind=scanlines[start];eq(kind in range(5),True,str(p)+' original PNG filter');current=BLACK_FIRST if oneblack and y==0 else WHITE;eq(scanlines[start+1:start+1+stride],filtered(current,previous,kind),str(p)+' complete prescribed RGB row '+str(y));previous=current
  rgb=hashlib.sha256();rgb.update(BLACK_FIRST if oneblack else WHITE)
  for y in range(1,height):rgb.update(WHITE)
  encoded_cache[key]={'encoded-sha256':h,'decoded-prescribed-rgb-sha256':rgb.hexdigest(),'opaque-RGB-pixel-count':width*height,'expected-black-pixels':1 if oneblack else 0,'all-other-pixels-white':True,'original-chunks':chunks}
 observations.append({'path':str(p.relative_to(REPO)),**encoded_cache[key]})
inspect(C)
for major,mode in TUPLES:
 obs=ROOT/('jdk'+str(major)+'-'+mode.lower())/'observations'
 for api in ['native','facade']:
  for name in ['expected','pdfium','implementation']:inspect(obs/api/('T07-document-blank-'+name+'.png'))
 negative=obs/'negative';inspect(negative/'one-pixel-control.png',True);inspect(negative/'T07-document-blank-expected.png',True)
 for name in ['pdfium','implementation']:inspect(negative/('T07-document-blank-'+name+'.png'))
finish('complete-rgb-raster-inspection.json',{'method':'Read-only PNG CRC and bounded decompression followed by complete original filter-byte verification against prescribed all-white RGB or exactly one black pixel at (0,0). No renderer or project/image tool executed; no PNG modified.','input-raster-observations':len(observations),'distinct-encoded-and-prescribed-raster-pairs':len(encoded_cache),'observations':observations,'difference-raster-boundary':'Original comparator difference rasters retain their own hashes and process findings; their optimized grayscale/palette encoding is not confused with the opaque RGB8 comparator inputs.'})
