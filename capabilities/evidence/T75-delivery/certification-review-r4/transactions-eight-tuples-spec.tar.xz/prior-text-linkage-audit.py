from readlib import *
import tarfile, io
pub=Path('/tmp/t75-final-spec-r4-text-publication-qr473m_z')
known={'report.md':'7c904da466cd5ffa3618fa4f2b28291b3898aba21260c2577d96d94d1d275f08','receipt.json':'78c5e2b5c593bdfac465d3ba192f58ea7d189561d00324870399125d0337ad30','archive-manifest.json':'18ba64144b98d6a70db43bd70524abef8471c61f05615501a595b1844a0baf4b','complete-inspected-input-identities.json':'76a78732af80f61062b80179d684d3d327fe81261b8e489ea11195254d8964ee'}
for name,h in known.items():eq(sha(pub/name),h,'unchanged closed text publication original '+name)
manifest=obj(pub/'archive-manifest.json')
eq(manifest['excluded-paths'],['archive-manifest.json'],'prior manifest explicit self exclusion')
members={r['path']:r for r in manifest['members']}
actual={str(p.relative_to(pub)):p for p in pub.rglob('*') if p.is_file()}
eq(set(members),set(actual)-{'archive-manifest.json'},'complete original prior packet membership')
eq(manifest['member-count'],len(members),'prior counted manifest membership')
for name,r in members.items():
 data=read(actual[name]);eq({'path':name,'bytes':len(data),'sha256':digest(data)},r,'unchanged prior packet '+name)
archive=REPO/'capabilities/evidence/T75-delivery/certification-review-r4/text-publication-spec.tar.xz'
eq(sha(archive),'bdcca3024295ef7f006ccec8b87d357a6b2c49317f0cc395faec8ae592744855','closed original text publication archive')
archiverows=[]
with tarfile.open(fileobj=io.BytesIO(read(archive)),mode='r:xz') as tar:
 archived=tar.getmembers();eq(len(archived),111,'actual prior archive members')
 eq({m.name for m in archived},set(actual),'exact prior archive physical membership')
 for m in archived:
  require(m.isfile(),'Only plain prior archive files')
  data=tar.extractfile(m).read();eq(data,read(actual[m.name]),'byte-exact original prior archive '+m.name)
  archiverows.append({'path':m.name,'bytes':len(data),'sha256':digest(data)})
receipt=obj(pub/'receipt.json')
CID='ab18cc9c0473730a6aabec5d12e3172f22bea23a0a0f9529052a2bc186cbfc1b';TID='3de508f79fcbef7258feee8abc013d6f02b000840cac1cb263cb0d6f927b8f2b'
eq(receipt['candidate'],CID,'prior text same r4 candidate');eq(receipt['contract'],TID,'prior text same contract')
eq(receipt['approvals']['text-eight-actual-outer-exit'],True,'prior actual outer gate closed')
eq(receipt['approvals']['text-eight-authority-publication'],True,'prior exact text publication closed')
eq(receipt['approvals']['transactions-raw'],False,'prior text scope did not certify these transactions')
eq(receipt['approvals']['all48-final-delivery'],False,'prior no global delivery approval')
textindex=CURRENT/'text/observed-index.json'
eq(sha(textindex),receipt['unchanged-observed-index-sha256'],'prior actual text own index remains exact')
index=obj(textindex);eq(len(index['certifications']),8,'prior exactly eight text')
eq({c['obligation'] for c in index['certifications']},{'text'},'prior text only index')
eq(index['candidate'],obj(ROOT/'observed-index.json')['candidate'],'new transactions own-index same actual staged candidate')
priorindex=read(ROOT/'prior-index.sha256').decode().strip()
eq(priorindex,receipt['dated-authority-sha256'],'actual transactions started from reviewed exact text authority')
outer=Path('/tmp/t75-final-transactions-certify-r4-command.json')
command=obj(outer)
eq(command['command'],['/usr/bin/python3','scripts/t03-foundation.py','certify',str(ROOT.relative_to(REPO)),'--obligation','transactions'],'actual new outer invocation only')
eq(command['cwd'],str(REPO),'actual outer cwd')
eq(command['explicit-environment'],{'FOLIO_HARFBUZZ_HELPER':str(REPO/'.build-cache/harfbuzz/10.2.0-final/bin/folio-harfbuzz')},'actual explicit native observer helper')
selected=[]
for name in ['report.md','receipt.json','archive-manifest.json']:
 selected.append(copy_original(pub/name,'prior-text-publication/'+name))
selected.append(copy_original(outer,'actual-invocation/transactions-command.json'))
for name in ['text-publication-spec-report.md','text-publication-spec-receipt.json','text-publication-spec-archive-identity.json']:
 selected.append(copy_original(archive.parent/name,'prior-text-publication-repo/'+name))
save('prior-text-original-archive-members.json',archiverows)
finish('prior-text-publication-linkage-inspection',{'closed-original-directory':str(pub),'closed-original-hashes':known,'archive':{'path':str(archive.relative_to(REPO)),'sha256':sha(archive),'actual-members':len(archiverows)},'prior-text-own-index-sha256':sha(textindex),'transactions-prior-index-sha256':priorindex,'exact-same-candidate-contract':True,'prior-text-actual-public-mode':receipt['public-mode'],'prior-source-and-raw-lineage':receipt['complete-original-raw-review-linkage'],'prior-diagnostic-boundary':receipt['reader-diagnostics'],'actual-transactions-invocation':command,'selected-original-copies':selected,'current-transactions-actual-result-and-authority':'Intentionally unread/excluded, even when parent reports completion. Separate publication review required.','text-raw-detail-replay':False,'other-current-raw-read':False})
