from auditlib import *
import ast
stage = obj(OUT / 'stage-environment-contract-inspection.json')
eq(stage['errors'], [], 'current stage inspection')
tree = ast.parse(read(REPO / 'scripts/t03-foundation.py').decode())
literalcase = next((n.value for n in tree.body if isinstance(n, ast.Assign) and any((isinstance(t, ast.Name) and t.id == 'CERTIFICATION_CASES' for t in n.targets))))
casenode = next((v for k, v in zip(literalcase.keys, literalcase.values) if ast.literal_eval(k) == 'transactions'))
case = {ast.literal_eval(k): ast.literal_eval(v) for k, v in zip(casenode.keys, casenode.values) if ast.literal_eval(k) != 'test-classes'}
case['test-classes'] = ['net.zerocloud.pdf.consumer.' + n for n in ['BlankDocumentWorkflowTest', 'WorkflowLifecycleTest', 'WorkflowTransactionContractTest', 'WorkflowResourceOwnershipTest']] + ['net.zerocloud.pdf.itext7.consumer.BlankDocumentFacadeTest']
classpath = ':'.join(('/workspace/' + p for p in stage['tuples'][0]['staged-classpath-paths']))
configuration_inputs = obj(ROOT / 'jdk8-in_process/execution.yaml')['inputs']
testclasses = case['test-classes'] + ['net.zerocloud.pdf.migration.itext7.contract.JarContractIT', 'net.zerocloud.pdf.migration.itext7.contract.ClasspathExclusivityIT']
commandobservations = []

def exact_commands(scope, mode, environment, configuration_sha):
    inside = '/workspace/' + str(scope.relative_to(REPO))
    image = environment['identity']['image']
    options = ['-Xmx1024m', '-Duser.language=en', '-Duser.country=US', '-Duser.timezone=UTC', '-Dfolio.harfBuzzHelper=/folio-harfbuzz/bin/folio-harfbuzz', '-Dfolio.t03.executionProfile=' + mode]
    command = ['podman', 'run', '--rm', '--network=none', '--userns=keep-id', '--volume', str(REPO) + ':/workspace:ro', '--volume', str(REPO / '.build-cache/harfbuzz/10.2.0-final') + ':/folio-harfbuzz:ro', '--volume', '/usr/bin/python3.12:/usr/bin/python3.12:ro', '--volume', '/usr/lib/python3.12:/usr/lib/python3.12:ro', '--volume', str(Path('/lib/x86_64-linux-gnu/libexpat.so.1').resolve()) + ':/lib/x86_64-linux-gnu/libexpat.so.1:ro', '--workdir', '/workspace', '--env', 'LANG=C.UTF-8', '--env', 'LC_ALL=C.UTF-8', '--env', 'TZ=UTC', '--env', 'FOLIO_HARFBUZZ_HELPER=/folio-harfbuzz/bin/folio-harfbuzz', '--volume', str(scope) + ':' + inside + ':rw', image]
    recorder = command + ['java'] + options + ['-cp', classpath, 'net.zerocloud.pdf.acceptance.T03EvidenceCommand', '/workspace', inside + '/observations', mode, '0.1.0']
    testoptions = ['-DrepositoryRoot=/workspace', '-DartifactPath=/workspace/target/foundation-0.1.0/artifacts/pdf-migration-itext7-preview-0.1.0.jar', '-DstableArtifactPath=/workspace/target/foundation-0.1.0/artifacts/pdf-migration-itext7-0.1.0.jar', '-DdocumentArtifactPath=/workspace/target/foundation-0.1.0/artifacts/pdf-document-0.1.0.jar', '-DtestClassesPath=/workspace/target/foundation-0.1.0/harness/facade-tests.jar']
    tests = command + ['java'] + options + testoptions + ['-cp', classpath, 'org.junit.runner.JUnitCore'] + testclasses
    config = obj(scope / 'execution.yaml')
    eq(config, {'schema-version': 1, 'candidate-sha256': stage['candidate-sha256'], 'environment-sha256': configuration_sha, 'acceptance-profile': case['profile'], 'execution-profile': mode, 'command': recorder, 'java-options': options, 'locale': 'en_US / C.UTF-8', 'timezone': 'UTC', 'settings': {'workflow-policy': case['workflow-policy'], 'fonts': case['fonts'], 'providers': 'none; Stable Facade execution is IN_PROCESS'}, 'inputs': configuration_inputs}, scope / 'complete configuration and recorder arguments')
    eq(obj(scope / 'contract-tests-command.json'), tests, scope / 'complete actual formal test arguments')
    commandobservations.append({'tuple': scope.name, 'recorder-arguments': len(recorder), 'contract-arguments': len(tests), 'java-options': options, 'actual-native-mode': mode, 'actual-facade-mode': 'IN_PROCESS', 'complete-command-arrays-match': True})
build = obj(REPO / 'capabilities/evidence/T75-delivery/final-candidate-r4/build-inputs.json')
index = obj(ROOT / 'observed-index.json')
expectedenv = []
expectedcerts = []

def ref(p):
    return {'path': str(p.relative_to(REPO)), 'sha256': sha(p)}
for major in [8, 11, 17, 21]:
    envpath = ROOT / ('jdk' + str(major) + '-environment/environment.yaml')
    env = obj(envpath)
    envref = ref(envpath)
    name = 'ubuntu-24.04-linux-x86-64-jdk' + str(major)
    expectedenv.append({'profile': name, 'record': envref})
    for mode in ['IN_PROCESS', 'HARDENED_WORKER']:
        scope = ROOT / ('jdk' + str(major) + '-' + mode.lower())
        exact_commands(scope, mode, env, envref['sha256'])
        expectedcerts.append({'obligation': 'transactions', 'environment': name, 'execution-profile': mode, 'configuration': ref(scope / 'execution.yaml'), 'records': [ref(scope / (chain + '.yaml')) for chain in ['syntax', 'standards', 'semantic', 'visual']]})
eq(index, {'schema-version': 1, 'candidate': build['candidate'], 'environments': expectedenv, 'certifications': expectedcerts}, 'exact complete transactions observed index')
eq(obj(ROOT / 'identities.json'), {'Candidate': stage['candidate-sha256'], 'Contract': stage['contract-sha256']}, 'observed certifier identities')

finish('complete-config-and-index-inspection.json',{'actual-complete-command-observations':commandobservations,'exact-observed-certifications':len(expectedcerts),'exact-observed-chain-records':sum(len(c['records']) for c in expectedcerts),'observed-index-sha256':sha(ROOT/'observed-index.json'),'publication-conclusion':'Excluded from this packet even if the outer process completes. Prior text publication linkage is independently checked in its own component.','other-obligations-approved':False})
