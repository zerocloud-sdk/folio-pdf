from readlib import *
from pathlib import PurePosixPath
import re
OUT = BASE
TUPLES = [(j,m) for j in [8,11,17,21] for m in ['IN_PROCESS','HARDENED_WORKER']]
def error(where,detail): errors.append({'where':str(where),'detail':detail})
def props(path):
 result={}
 for line in read(path).decode('utf-8').splitlines():
  if not line or line[0] in '#!':continue
  key,sep,value=line.partition('=')
  if not sep or key in result:error(path,'duplicate or malformed property '+key);continue
  result[key]=re.sub(r'\\(u[0-9a-fA-F]{4}|.)',lambda m:chr(int(m[1][1:],16)) if m[1].startswith('u') and len(m[1])==5 else {'t':'\t','n':'\n','r':'\r','f':'\f'}.get(m[1],m[1]),value)
 return result
def subset(actual,expected,where):
 for key,value in expected.items():eq(actual.get(key),value,str(where)+':'+key)
def lines_hash(text):return digest(text.encode())
def dump(name,value):save(name,value)
original_finish=finish
def finish(name,result):original_finish(name.removesuffix('.json'),result)
