from pathlib import Path
b=Path('/tmp/t75-final-spec-r4-transactions-eight-1imjlw_l')
s=r"""from readlib import *
import re
from collections import Counter
CID='ab18cc9c0473730a6aabec5d12e3172f22bea23a0a0f9529052a2bc186cbfc1b';TID='3de508f79fcbef7258feee8abc013d6f02b000840cac1cb263cb0d6f927b8f2b';BASELINE='5b1603c435f11c40368f75b7b9a2777c9c5e9761'
component_names=['starting-schema-inspection.json','reader-adaptation-inspection.json','stage-environment-contract-inspection.json','transactions-evidence-inspection.json','complete-rgb-raster-inspection.json','complete-config-and-index-inspection.json','public-source-scope-inspection.json','prior-text-publication-linkage-inspection.json','selected-original-retention-inspection.json','source-scope-diagnostic-closure.json']
components=[];data={}
for name in component_names:
 value=obj(BASE/name);eq(value.get('errors',[]),[],name+' no unresolved reader error');data[name]=value
 components.append({'path':name,'sha256':sha(BASE/name)})
closure=data['source-scope-diagnostic-closure.json'];eq(closure['remaining-findings'],[],'explicit source diagnostic closure')
eq(sha(BASE/'public-controls-and-scope-alignment.json'),closure['original-inspection']['sha256'],'unchanged original source-scope diagnostic')
components.append({'path':'public-controls-and-scope-alignment.json','sha256':sha(BASE/'public-controls-and-scope-alignment.json'),'disposition':'One original reader scope diagnostic retained, closed separately by source-scope-diagnostic-closure.json; not relabeled as an error-free original run.'})
actual_runs=[]
for p in sorted(BASE.glob('*-result.json')):
 r=obj(p);eq(r['returncode'],0,p.name+' actual read-only process exit')
 for stream in ['stdout','stderr']:
  if isinstance(r.get(stream),dict):
   row=r[stream];eq(sha(BASE/row['path']),row['sha256'],p.name+' complete original '+stream)
  elif stream+'-sha256' in r:
   q=BASE/(p.name.removesuffix('-result.json')+'-'+stream+'.txt');eq(sha(q),r[stream+'-sha256'],p.name+' original '+stream)
 actual_runs.append({'path':p.name,'sha256':sha(p),'returncode':r['returncode']})
raw=data['transactions-evidence-inspection.json'];stage=data['stage-environment-contract-inspection.json'];rgb=data['complete-rgb-raster-inspection.json'];config=data['complete-config-and-index-inspection.json'];retained=data['selected-original-retention-inspection.json'];textlink=data['prior-text-publication-linkage-inspection.json']
eq(stage['candidate-sha256'],CID,'final candidate');eq(stage['contract-sha256'],TID,'final contract')
eq(stage['input-counts'],{'sources':1933,'contracts':30,'artifacts':23,'harness':24},'actual frozen input groups')
eq(len(raw['tuples']),8,'eight raw tuples');eq(config['exact-observed-chain-records'],32,'exact observed records')
eq(config['exact-observed-certifications'],8,'exact own-index certifications')
eq(sha(ROOT/'observed-index.json'),config['observed-index-sha256'],'own index unchanged at closure')
root_catalog=obj(BASE/'complete-current-raw-tree-identities.json')
current_paths={str(p.relative_to(REPO)) for p in ROOT.rglob('*') if p.is_file()}
eq(current_paths,{r['path'] for r in root_catalog},'complete immutable raw root membership unchanged')
for r in root_catalog:
 value=read(REPO/r['path']);eq(len(value),r['bytes'],'final original raw bytes '+r['path']);eq(digest(value),r['sha256'],'final original raw SHA '+r['path'])
all_seen={}
for p in sorted(BASE.glob('*-read-identities.json')):
 rows=obj(p)
 for row in rows:
  if row['path'] in all_seen:eq(row,all_seen[row['path']],'identical original input across every completed reader '+row['path'])
  all_seen[row['path']]=row
for row in all_seen.values():
 value=read(Path(row['path']));eq({'path':row['path'],'bytes':len(value),'sha256':digest(value)},row,'unchanged complete inspected source/input '+row['path'])
copies=obj(BASE/'selected-current-original-copy-identities.json')+data['public-source-scope-inspection.json']['selected-source-copies']+textlink['selected-original-copies']
for r in copies:
 value=read(BASE/r['copy']);eq(digest(value),r['sha256'],'retained selected copy '+r['copy']);eq(len(value),r['bytes'],'retained selected copy size '+r['copy']);eq(value,read(Path(r['original'])),'selected copy remains byte-exact original '+r['copy'])
require(not errors,'Final raw identity/coverage check has unresolved errors: '+str(errors[:3]))
inspection={'created-utc':now(),'candidate':CID,'contract':TID,'all-completed-reader-results':actual_runs,'complete-raw-root-unchanged':True,'complete-raw-files':len(root_catalog),'source-artifact-harness-current':True,'original-overwrites':False,'unresolved-findings':[],'errors':errors}
save('final-raw-consistency-inspection.json',inspection)
components.append({'path':'final-raw-consistency-inspection.json','sha256':sha(BASE/'final-raw-consistency-inspection.json')})
input_catalog=sorted(files.values(),key=lambda r:r['path']);save('complete-inspected-input-identities.json',input_catalog)
report='''Spec review: CLEAN — no actionable finding in the eight r4 T03 transactions raw tuples and their own observed-index. Fixed baseline: `'''+BASELINE+'''`; candidate: `'''+CID+'''`; contract: `'''+TID+'''`.

Goal:131–133 requires “Refresh invalidated certifications rather than reusing stale hashes.” Current 1,933 source, 30 contract, 23 artifact and 24 harness identities match the frozen r4 stage. T03 behavior and contracts remain unchanged; the five reviewed inventory corrections are explicitly linked. The closed text publication packet and its 111-member archive remain byte-exact.

`docs/t03-certification.md:14–31` governs the actual 34-case suites: 27 Native, five public Stable Facade and two actual-jar tests, across all four JDKs and both Native profiles. Source/reopen, ownership, resource closure, deterministic failure and ordered Receipt coverage remains intact. Multi-Target failure permits an earlier COMMITTED Target and preserves later NOT_ATTEMPTED bytes. Goal:124–125 requires “never relabel it as HARDENED_WORKER evidence”: Facade creation/reopen is actually IN_PROCESS in both Native tuples. Historical 19/105 family counts do not limit the current 21/157 jar authority; the coexistence probe remains 20 individually exercised types plus the reviewed added-type delegation.

`docs/t03-certification.md:33–50` requires separate chains and “a hash-pinned, independently authored negative PDF with a required diagnostic.” All 32 PASS records, exact report arrays and 1,528 report references bind 16 products. The complete raw root contains 1,289 files: 1,200 tuple files (1,104 observations), 84 environment files and five root records. All 22 rules (19 pdfcpu, three Arlington), 352 rule-control executions and separate syntax/semantic/visual controls match. Full decoded RGB validation covers 81 inputs, zero-error positives and the one-black-pixel control, using each PNG’s own SHA.

All four BEFORE/AFTER identities, 15 tools and exact command/configuration/classpath bindings agree. The source-scope reader diagnostic is preserved with its narrow correction; auxiliary display truncation did not affect retained JSON or original reader outputs.

This read-only closure approves raw eight-tuples/own-index only. Actual outer exit/publication requires separate independent review, even after the parent’s completion notification. Other obligations, final inventory/index and delivery remain excluded; no Goal criterion is marked complete.
'''
words=len(report.split());require(words<400,'Spec report must remain under 400 words')
with (BASE/'report.md').open('x') as h:h.write(report)
receipt={'reviewer':'/root/final_spec','axis':'Spec','sealed-utc':now(),'scope':'Exactly current r4 transactions/T03 eight complete raw tuples and own-index; actual outer exit and authority publication excluded by explicit parent instruction','baseline':BASELINE,'candidate':CID,'contract':TID,'raw-root':str(ROOT.relative_to(REPO)),'observed-index-sha256':config['observed-index-sha256'],'current-input-counts':stage['input-counts'],'actual-eight-formal-suites':stage['tuples'],'formal-contract-counts':{'Native':27,'StableFacade':5,'artifact':2,'each-total':34},'formal-timeout-seconds':stage['formal-aggregate-timeout-seconds'],'current-configurations':config['actual-complete-command-observations'],'record-count':32,'configuration-count':8,'records-and-reports':raw['tuples'],'complete-raw-tree':{'path':'complete-current-raw-tree-identities.json','sha256':sha(BASE/'complete-current-raw-tree-identities.json'),'files':retained['complete-current-raw-files'],'bytes':retained['complete-current-raw-bytes'],'tuple-files':raw['physical-original-file-count'],'observation-files':sum(r['observation-files'] for r in raw['tuples']),'environment-files':84,'root-record-files':retained['root-original-files'],'original-retained-files-manifests':sum(r['original-manifests'] for r in raw['tuples']),'T03-manifest-boundary':'T03 has no T13 producer-manifest requirement; all complete report references and original exact product SHA remain required and checked.'},'report-reference-occurrences':sum(r['report-reference-count'] for r in raw['tuples']),'record-and-report-reference-occurrences':sum(r['record-report-reference-occurrences'] for r in raw['tuples']),'qualified-rule-count':raw['required-standards-rules'],'qualified-rule-assignments':closure['all-other-original-scope-checks']['assigned-rules-per-checker'],'qualified-negative-executions':raw['qualified-negative-controls'],'current-Arlington-model-files':raw['current-Arlington-model-files'],'public-products':raw['positive-public-products'],'separate-visual-observations':raw['separate-visual-observations'],'complete-decoded-RGB':{'observations':rgb['input-raster-observations'],'distinct-encoded-and-prescribed-raster-pairs':rgb['distinct-encoded-and-prescribed-raster-pairs'],'difference-raster-boundary':rgb['difference-raster-boundary'],'own-PNG-identities-required':True,'cross-JDK-PNG-byte-equality-required':False},'observed-environments':stage['environment-observations'],'tools':stage['tools'],'deferred-environment-post-check':[],'actual-Facade-mode':'IN_PROCESS','T03-multiple-Target-boundary':'Ordered non-atomic multi-Target publication, including COMMITTED / FAILED (partial output possible) / NOT_ATTEMPTED; no new rollback promise.','source-scope-requirement-map':closure['all-other-original-scope-checks']['requirement-map'],'source-review-lineage':{'existing-five-file-closure-sha256':closure['existing-reviewed-five-file-closure-sha256'],'selected-T03-unchanged-source-count':closure['unchanged-T03-selected-source-count'],'selected-reviewed-context-delta':closure['already-reviewed-context-source-delta'],'new-functionality-approved':False},'prior-text-publication-linkage':textlink,'completed-components':components,'completed-readonly-command-results':actual_runs,'complete-inspected-input-identities':{'path':'complete-inspected-input-identities.json','sha256':sha(BASE/'complete-inspected-input-identities.json'),'paths':len(input_catalog)},'selected-original-copies':{'identity-record':'selected-current-original-copy-identities.json','current-raw-stage-profile-selected-copies':len(obj(BASE/'selected-current-original-copy-identities.json')),'total-original-files-retained':sum(p.is_file() for p in (BASE/'originals').rglob('*')),'all-listed-copy-byte-identities-verified':len(copies),'whole-raw-tree-duplicated':False},'reader-diagnostics':{'historical-T03-visual-schema-adaptation':{'path':'reader-adaptation-inspection.json','sha256':sha(BASE/'reader-adaptation-inspection.json'),'boundary':'Qualified original T03 reader retained and adapted before current execution to require only the three summary raster hashes that T03 visual.md actually duplicates; all five raw visual.txt/report hashes and full RGB checks remain mandatory.'},'unexecuted-source-presence-draft':{'path':'unexecuted-scope-draft-correction.json','sha256':sha(BASE/'unexecuted-scope-draft-correction.json'),'original-draft-overwritten':False},'actual-single-source-scope-diagnostic':{'original':'public-controls-and-scope-alignment.json','closure':'source-scope-diagnostic-closure.json','closure-sha256':sha(BASE/'source-scope-diagnostic-closure.json'),'original-process-returncode':0,'original-reader-error-count':1,'closed-reader-scope-errors':1,'certification-failures':0},'auxiliary-display-boundary':{'path':'auxiliary-display-boundary.json','sha256':sha(BASE/'auxiliary-display-boundary.json'),'full-auxiliary-stdout-retained':False,'complete-underlying-JSON-and-formal-reader-outputs-retained':True,'recovered-original-stdout-claim':False}},'parent-notification-boundary':'Parent later reported transactions actual exit0 at 2026-09-13T20:08:32.754733Z. This packet intentionally does not inspect that result, outer stdout, or current authority; a separate publication review is required.','findings':[],'approvals':{'transactions-eight-raw-and-own-index':True,'transactions-actual-outer-exit':False,'transactions-authority-publication':False,'other-current-obligations':False,'all48-final-inventory-index-delivery':False,'completion-criteria-marked':False},'repository-mutations':False,'project-executions':False,'report-sha256':sha(BASE/'report.md'),'report-words':words,'retention':'Exclusive outputs only. Original reader diagnostics and corrected interpretations remain separate. The final archive-manifest.json excludes itself and is created only after all original finalization command/stdout/stderr/result files are closed.'}
save('receipt.json',receipt)
print(json.dumps({'result':'CLEAN','scope':'r4 transactions eight raw tuples and own-index only','report-words':words,'complete-inspected-input-paths':len(input_catalog),'raw-files':len(root_catalog),'report-sha256':sha(BASE/'report.md'),'receipt-sha256':sha(BASE/'receipt.json'),'findings':[],'actual-publication-approved':False}))
"""
with (b/'finalize-raw.py').open('x') as h:h.write(s)
v=r'''from pathlib import Path
import hashlib,json
b=Path(__file__).parent
sh=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r=json.loads((b/'receipt.json').read_bytes())
assert sh(b/'report.md')==r['report-sha256'] and r['report-words']<400
assert r['findings']==[] and r['record-count']==32 and r['configuration-count']==8
assert r['approvals']['transactions-eight-raw-and-own-index']
assert not r['approvals']['transactions-actual-outer-exit']
assert not r['approvals']['transactions-authority-publication']
assert not r['approvals']['all48-final-inventory-index-delivery']
actual=json.loads((b/'finalize-raw-result.json').read_bytes());assert actual['returncode']==0
for stream in ['stdout','stderr']:assert sh(b/actual[stream]['path'])==actual[stream]['sha256']
for c in r['completed-components']:assert sh(b/c['path'])==c['sha256']
cat=r['complete-inspected-input-identities'];assert sh(b/cat['path'])==cat['sha256']
raw=r['complete-raw-tree'];assert sh(b/raw['path'])==raw['sha256']
assert len(json.loads((b/raw['path']).read_bytes()))==raw['files']==1289
print(json.dumps({'result':'CLEAN','scope':'r4 transactions eight raw tuples/own-index only','report-sha256':sh(b/'report.md'),'receipt-sha256':sh(b/'receipt.json'),'input-catalog-sha256':cat['sha256'],'input-paths':cat['paths'],'raw-files':raw['files'],'preserved-and-closed-reader-diagnostic':True,'auxiliary-display-boundary-disclosed':True,'actual-publication-approved':False,'all48-delivery-approved':False}))
'''
with (b/'verify-completed-raw.py').open('x') as h:h.write(v)
