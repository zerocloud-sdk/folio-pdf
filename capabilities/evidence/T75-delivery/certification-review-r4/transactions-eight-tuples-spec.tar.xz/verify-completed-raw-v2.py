from pathlib import Path
import hashlib, json
b = Path(__file__).parent
sh = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
r = json.loads((b / 'receipt.json').read_bytes())
assert sh(b / 'report.md') == r['report-sha256'] and r['report-words'] < 400
assert r['findings'] == [] and r['record-count'] == 32 and (r['configuration-count'] == 8)
assert r['approvals']['transactions-eight-raw-and-own-index']
assert not r['approvals']['transactions-actual-outer-exit']
assert not r['approvals']['transactions-authority-publication']
assert not r['approvals']['all48-final-inventory-index-delivery']
actual = json.loads((b / 'finalize-raw-v2-result.json').read_bytes())
assert actual['returncode'] == 0
for stream in ['stdout', 'stderr']:
    assert sh(b / actual[stream]['path']) == actual[stream]['sha256']
for c in r['completed-components']:
    assert sh(b / c['path']) == c['sha256']
cat = r['complete-inspected-input-identities']
assert sh(b / cat['path']) == cat['sha256']
raw = r['complete-raw-tree']
assert sh(b / raw['path']) == raw['sha256']
assert len(json.loads((b / raw['path']).read_bytes())) == raw['files'] == 1289
print(json.dumps({'result': 'CLEAN', 'scope': 'r4 transactions eight raw tuples/own-index only', 'report-sha256': sh(b / 'report.md'), 'receipt-sha256': sh(b / 'receipt.json'), 'input-catalog-sha256': cat['sha256'], 'input-paths': cat['paths'], 'raw-files': raw['files'], 'preserved-and-closed-reader-diagnostic': True, 'auxiliary-display-boundary-disclosed': True, 'actual-publication-approved': False, 'all48-delivery-approved': False}))
