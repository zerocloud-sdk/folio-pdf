from auditlib import *
from collections import Counter
stage = obj(OUT / 'stage-environment-contract-inspection.json')
eq(stage['errors'], [], 'closed staged identity inspection')
CID = stage['candidate-sha256']
TID = stage['contract-sha256']
P = 'T03-document-workflow-transaction'
profile = REPO / 'capabilities/evidence/T03-document-workflow-transaction.md'
C = REPO / 'capabilities/profiles/T03-standards'
vprofile = props(REPO / 'capabilities/profiles/T03-document-blank-visual.properties')
qpin = props(REPO / 'scripts/qpdf-pin.properties')
ppin = props(REPO / 'scripts/pdfium-pin.properties')
mpin = props(REPO / 'scripts/imagemagick-pin.properties')
gold = REPO / 'capabilities/expected/T03-document-blank-144dpi-srgb.png'
eq(sha(gold), vprofile['EXPECTED_RASTER_SHA256'], 'frozen all-white raster authority')
source = read(REPO / 'pdf-acceptance/src/main/java/net/zerocloud/pdf/acceptance/T03EvidenceCommand.java').decode()
rules = set(re.findall('"([a-z]+(?:-[a-z]+)+)"', source.split('REQUIRED_RULES =', 1)[1].split('private static final String[] CHAINS', 1)[0]))
profiles = {c: props(C / (c + '.properties')) for c in ['pdfcpu', 'arlington']}
pins = {c: props(REPO / ('scripts/' + c + '-pin.properties')) for c in profiles}
eq(set().union(*(set(p['required-rules'].split(',')) for p in profiles.values())), rules, 'complete hard-coded T03 required rule union')
eq(len(rules), 22, 'twenty-two required rules')
model = (REPO / 'scripts' / pins['arlington']['model']).resolve()
model_files = sorted(model.glob('*.tsv'))
eq(0 < len(model_files) <= 2048, True, 'bounded actual Arlington model')
modelidentity = ''.join((p.name + ' ' + sha(p) + '\n' for p in model_files))
eq(lines_hash(modelidentity), pins['arlington']['model-sha256'], 'current complete Arlington model SHA')
eq(any((p.is_symlink() for p in model_files)), False, 'model no symlinks')
for c, pin in pins.items():
    eq(sha((REPO / 'scripts' / pin['executable']).resolve()), pin['sha256'], 'current checker executable ' + c)
    eq(pin['timeout-ms'], '10000', 'unchanged checker timeout')
    eq(pin['max-output-bytes'], '1048576', 'unchanged checker output bound')
allrefs = []
physicalrows = []
tuples = []
products = []
negatives = []
visual = []

def ref(p):
    return {'path': str(p.relative_to(REPO)), 'sha256': sha(p)}

def refs(value, owner):
    if isinstance(value, dict):
        if isinstance(value.get('path'), str) and isinstance(value.get('sha256'), str):
            name = value['path']
            q = PurePosixPath(name)
            p = REPO / name
            eq(not q.is_absolute() and '..' not in q.parts and (q.as_posix() == name), True, str(owner) + ' canonical reference')
            eq(p.resolve(), p, str(owner) + ' no linked reference')
            eq(sha(p), value['sha256'], str(owner) + ' exact referenced original')
            yield {'owner': str(owner.relative_to(REPO)), 'path': name, 'sha256': value['sha256']}
        for v in value.values():
            yield from refs(v, owner)
    elif isinstance(value, list):
        for v in value:
            yield from refs(v, owner)

def md(s, key):
    return re.findall('^' + re.escape(key) + ': `([^`\\r\\n]*)`$', s, re.M)

def fields(s, expected, where):
    for k, v in expected.items():
        eq(md(s, k), [str(v)], str(where) + ' ' + k)

def neutral(p):
    b = bytearray(read(p))
    matches = list(re.finditer(b'/ID\\s*\\[\\s*<([0-9A-Fa-f]+)>\\s*<([0-9A-Fa-f]+)>\\s*\\]', b))
    eq(len(matches), 1, str(p) + ' exactly one legacy diagnostic ID')
    for match in matches:
        for i in [1, 2]:
            b[match.start(i):match.end(i)] = b'0' * (match.end(i) - match.start(i))
    return hashlib.sha256(b).hexdigest()

def visual_check(d, h, negative=False):
    txt = read(d / 'visual.txt').decode()
    wanted = 'fail' if negative else 'pass'
    expected = sha(d / 'T07-document-blank-expected.png')
    eq(expected, sha(d / 'one-pixel-control.png') if negative else sha(gold), str(d) + ' exact expected raster source')
    hashes = {label + ' raster SHA-256': sha(d / ('T07-document-blank-' + name + '.png')) for label, name in [('Expected', 'expected'), ('PDFium', 'pdfium'), ('Implementation', 'implementation'), ('Difference', 'difference'), ('Renderer difference', 'renderer-difference')]}
    fields(txt, dict(hashes, **{'Input ID-neutral SHA-256': neutral(d / 'blank.pdf'), 'Profile': P, 'DPI': 144, 'Raster dimensions': '1224x1584', 'Comparison metric': 'AE', 'Comparison fuzz percent': 0, 'Comparison threshold': 0, 'Renderer agreement threshold': 0, 'Expected comparison AE': 1 if negative else 0, 'Renderer agreement AE': 0, 'Review required': 'false', 'PDFium CLI version': ppin['PDFIUM_CLI_VERSION'], 'PDFium engine version': ppin['PDFIUM_ENGINE_VERSION'], 'ImageMagick version': mpin['IMAGEMAGICK_VERSION'], 'Implementation renderer version': '3.0.8', 'Final determination': wanted}), d / 'original raw visual finding')
    for k, field in [('PAGE_BOX', 'Page box'), ('COLOR_POLICY', 'Color policy'), ('FONT_POLICY', 'Font policy'), ('ANTIALIASING_POLICY', 'Antialiasing policy')]:
        fields(txt, {field: vprofile[k]}, d / 'profile setting')
    comparison = 'magick compare -metric AE -fuzz 0% -highlight-color #ff0000 -lowlight-color #ffffff -define png:exclude-chunk=time,date '
    eq(md(txt, 'Invocation'), ['pdfium --version', 'pdfium render blank.pdf T07-document-blank-pdfium.png --dpi 144 --file-type png --pages first', 'magick --version', comparison + 'T07-document-blank-expected.png T07-document-blank-pdfium.png T07-document-blank-difference.png', comparison + 'T07-document-blank-pdfium.png T07-document-blank-implementation.png T07-document-blank-renderer-difference.png'], str(d) + ' exact five original tool invocations')
    codes = md(txt, 'Exit code')
    eq(len(codes), 5, str(d) + ' process count')
    eq(codes[:3], ['0', '0', '0'], str(d) + ' observed tool exits')
    eq(codes[4], '0', str(d) + ' exact secondary comparator')
    eq(codes[3] in (['0', '1'] if negative else ['0']), True, str(d) + ' primary comparator exit permits tiny normalized AE')
    stdout = re.findall('### Standard output\\n\\n```text\\n(.*?)\\n```', txt, re.S)
    stderr = re.findall('### Standard error\\n\\n```text\\n(.*?)\\n```', txt, re.S)
    eq(len(stdout), 5, str(d) + ' complete stdout')
    eq(len(stderr), 5, str(d) + ' complete stderr')
    eq(stdout[0].strip(), 'pdfium version ' + ppin['PDFIUM_CLI_VERSION'], str(d) + ' actual PDFium version')
    eq(stdout[1].strip(), 'Rendered page 1 into T07-document-blank-pdfium.png', str(d) + ' actual render')
    eq(stdout[2].startswith('Version: ImageMagick ' + mpin['IMAGEMAGICK_VERSION'] + ' '), True, str(d) + ' actual comparator version')
    eq(stdout[3:], ['', ''], str(d) + ' comparator stdout')
    eq(stderr[:3], ['', '', ''], str(d) + ' process stderr')
    eq(stderr[4], '0 (0)', str(d) + ' actual secondary AE zero')
    eq(bool(re.fullmatch('1 \\([0-9.eE+-]+\\)', stderr[3])) if negative else stderr[3] == '0 (0)', True, str(d) + ' actual primary AE')
    if not negative:
        eq(txt.startswith('Input exact SHA-256: ' + h + '\n'), True, str(d) + ' exact product identity')
        rec = read(d / 'visual.md').decode()
        fields(rec, dict({key: value for key, value in hashes.items() if key in ('Expected raster SHA-256', 'PDFium raster SHA-256', 'Implementation raster SHA-256')}, **{'Result': 'pass', 'Producer': 'pdfium-cli', 'PDFium executable SHA-256': ppin['PDFIUM_EXECUTABLE_SHA256'], 'ImageMagick executable SHA-256': mpin['IMAGEMAGICK_EXECUTABLE_SHA256']}), d / 'visual record binding')
    visual.append({'tuple': d.relative_to(ROOT).parts[0], 'directory': str(d.relative_to(ROOT)), 'verdict': wanted, 'actual-primary-AE': 1 if negative else 0, 'actual-secondary-AE': 0, 'exact-original-raster-hashes': hashes, 'raw-sha256': sha(d / 'visual.txt')})
for major, mode in TUPLES:
    name = 'jdk' + str(major) + '-' + mode.lower()
    scope = ROOT / name
    obs = scope / 'observations'
    physical = sorted((p for p in scope.rglob('*') if p.is_file()))
    eq(any((p.is_symlink() for p in scope.rglob('*'))), False, name + ' no original symlinks')
    physicalrows.extend(({'tuple': name, **ref(p)} for p in physical))
    eq(props(obs / 'result.properties'), {c: 'pass' for c in ['syntax', 'standards', 'semantic', 'visual']}, name + ' aggregate completed four chains')
    eq(read(scope / 'recorder.txt'), b'', name + ' recorder original stdout')
    eq(bool(re.fullmatch('JUnit version 4\\.13\\.2\\n\\.{34}\\nTime: [0-9.]+\\n\\nOK \\(34 tests\\)\\n\\n', read(scope / 'contract-tests.txt').decode())), True, name + ' full actual 34 without skipped tests')
    for api in ['native', 'facade']:
        d = obs / api
        h = sha(d / 'blank.pdf')
        eq(props(d / 'result.properties'), {'syntax': 'pass', 'standards': 'pass', 'semantic': 'pass', 'visual': 'pass', 'input-sha256': h}, str(d) + ' exact original product result')
        eq(read(d / 'blank.pdf').startswith(b'%PDF-1.7'), True, str(d) + ' actual PDF version')
        idh = neutral(d / 'blank.pdf')
        syntax = read(d / 'syntax.txt').decode()
        eq(syntax.startswith('Input exact SHA-256: ' + h + '\n'), True, str(d) + ' qpdf product binding')
        fields(syntax, {'Input ID-neutral SHA-256': idh, 'Tool': 'qpdf', 'Tool version': qpin['QPDF_VERSION'], 'Distribution SHA-256': qpin['QPDF_ARCHIVE_SHA256'], 'Invocation': 'qpdf --check blank.pdf', 'Exit code': '0'}, d / 'syntax raw')
        eq('No syntax or stream encoding errors found; the file may still contain\nerrors that qpdf cannot detect' in syntax, True, str(d) + ' actual qpdf completion')
        eq(re.findall('## Standard error\\n\\n```text\\n(.*?)\\n```', syntax, re.S), [''], str(d) + ' actual syntax stderr')
        fields(read(d / 'syntax.md').decode(), {'Result': 'pass'}, d / 'syntax record')
        expectedmode = mode if api == 'native' else 'IN_PROCESS'
        eq(read(d / 'semantic.txt').decode(), 'Input exact SHA-256: ' + h + '\nPublic Native reopen; execution=' + expectedmode + '\nresult=pass\nAssertions: exactly one Page; Catalog keys Type/Pages; Pages keys Type/Kids/Count; Page keys Type/Parent/MediaBox/Resources; MediaBox [0 0 612 792]; empty Resources.\n', str(d) + ' complete public minimal semantic observation')
        combined = ''
        for checker in ['pdfcpu', 'arlington']:
            q = profiles[checker]
            pin = pins[checker]
            folder = d / checker
            expected = {'result': 'pass', 'profile': P, 'covered-rules': q['required-rules'], 'executable-sha256': pin['sha256'], 'model-sha256': pin.get('model-sha256', 'none'), 'patch-sha256': 'none', 'input-sha256': h, 'pin-sha256': sha(REPO / ('scripts/' + checker + '-pin.properties')), 'profile-sha256': sha(C / (checker + '.properties'))}
            eq(props(folder / 'standards.properties'), expected, str(folder) + ' actual independently qualified checker binding')
            raw = read(folder / 'findings.txt').decode()
            version, sep, validation = raw.partition('\nValidation exit: ')
            eq(version.startswith('Version exit: 0\n') and pin['version'] in version, True, str(folder) + ' actual version')
            eq(bool(sep) and validation.startswith('0\n'), True, str(folder) + ' actual valid product process')
            positive = validation[2:].partition('\nNegative control ')[0].strip()
            eq('validation ok' in positive and 'validating(mode=strict)' in positive if checker == 'pdfcpu' else ' BEGIN - TestGrammar ' in positive and '\nEND\n' in positive and positive.endswith('DONE - 1 files processed') and ('Error:' not in positive) and ('Warning:' not in positive) and ('Info: Processing as PDF 1.7' in positive), True, str(folder) + ' actual positive independent finding')
            for rule in q['required-rules'].split(','):
                control = folder / ('control-' + rule + '.pdf')
                n = folder / ('negative-' + rule + '.txt')
                expectedhash = q['negative.' + rule + '.sha256']
                eq(sha(control), expectedhash, str(control) + ' retained original control bytes')
                eq(sha(C / q['negative.' + rule + '.path']), expectedhash, str(control) + ' independently authored fixture authority')
                diag = read(n).decode()
                eq(q['negative.' + rule + '.finding'] in diag, True, str(n) + ' required rule-specific diagnostic')
                eq(diag.startswith('exit=1\n') if checker == 'pdfcpu' else diag.startswith('exit=0\n') and '\nError: ' in diag, True, str(n) + ' actual detecting process result')
                eq('Negative control ' + rule + ' sha256=' + expectedhash + ' detected=true' in raw.splitlines(), True, str(n) + ' fresh detector qualified control')
                negatives.append({'tuple': name, 'product': api, 'checker': checker, 'rule': rule, 'control-sha256': expectedhash, 'diagnostic-sha256': sha(n)})
            combined += checker + '\n' + read(folder / 'standards.properties').decode() + raw
        eq(read(d / 'standards.txt').decode(), 'Input exact SHA-256: ' + h + '\n' + combined, str(d) + ' complete separate producer findings retained')
        visual_check(d, h)
        products.append({'tuple': name, 'api': api, 'actual-mode': expectedmode, 'pdf-sha256': h, 'legacy-diagnostic-only-ID-neutral-sha256': idh, 'public-observation': 'one Page; closed minimal Catalog/Pages/Page and empty Resources'})
    negative = obs / 'negative'
    eq(props(negative / 'result.properties'), {c: 'fail' for c in ['syntax', 'standards', 'semantic', 'visual']}, name + ' all separate controls detected')
    eq(read(negative / 'invalid.pdf'), b'This is intentionally not a PDF.\n', name + ' original non-PDF control')
    raw = read(negative / 'syntax.txt').decode()
    eq(raw.startswith('input-sha256=' + sha(negative / 'invalid.pdf') + '\nexit=2\n'), True, name + ' actual syntax control identity and exit')
    eq('unable to find trailer dictionary while recovering damaged file' in raw, True, name + ' actual syntax diagnostic')
    eq(read(negative / 'semantic.txt').decode(), 'Known two-page control; input-sha256=' + sha(negative / 'two-pages.pdf') + '\nobserved=fail\n', name + ' original two-page public semantic failure')
    eq(read(negative / 'standards.txt').decode(), 'Rule-specific negative observations are retained separately under native/{pdfcpu,arlington} and facade/{pdfcpu,arlington}.\n', name + ' standards independent controls location')
    eq(sha(negative / 'blank.pdf'), sha(obs / 'native/blank.pdf'), name + ' visual control uses unchanged Native product')
    cp = props(negative / 'one-pixel-control.properties')
    expectedcp = dict(vprofile, EXPECTED_RASTER='one-pixel-control.png', EXPECTED_RASTER_SHA256=sha(negative / 'one-pixel-control.png'))
    eq(cp, expectedcp, name + ' negative visual profile only substitutes defect raster')
    visual_check(negative, sha(negative / 'blank.pdf'), True)
    env = ROOT / ('jdk' + str(major) + '-environment')
    scope_refs = []
    reports = []
    for chain, producer in [('syntax', 'qpdf'), ('standards', 'arlington'), ('semantic', 'folio-pdf-t03'), ('visual', 'pdfium-cli')]:
        recordpath = scope / (chain + '.yaml')
        reportpath = scope / (chain + '-report.json')
        record = obj(recordpath)
        report = obj(reportpath)
        subset(record, {'schema-version': 1, 'obligation': 'transactions', 'acceptance-profile': P, 'release': '0.1.0', 'candidate-sha256': CID, 'contract-sha256': TID, 'environment-sha256': sha(env / 'environment.yaml'), 'execution-configuration-sha256': sha(scope / 'execution.yaml'), 'execution-profile': mode, 'chain': chain, 'result': 'pass', 'producer': producer}, recordpath)
        eq(record['report'], ref(reportpath), str(recordpath) + ' actual report')
        eq(record['configuration'], ref(profile), str(recordpath) + ' current profile')
        eq(record['negative-controls'], report['negative-controls'], str(recordpath) + ' all negative references')
        wanted = {'chain': chain, 'result': 'pass', 'products': [], 'findings': [], 'negative-controls': [ref(negative / (chain + '.txt'))]}
        for api in ['native', 'facade']:
            d = obs / api
            wanted['products'].append(ref(d / 'blank.pdf'))
            wanted['findings'] += [ref(d / (chain + '.txt')), ref(d / 'result.properties')]
            if (d / (chain + '.md')).is_file():
                wanted['findings'].append(ref(d / (chain + '.md')))
            if chain == 'visual':
                wanted['findings'] += [ref(p) for p in sorted(d.glob('*.png'))]
            if chain == 'standards':
                for checker in ['pdfcpu', 'arlington']:
                    f = d / checker
                    wanted['findings'] += [ref(f / 'standards.properties'), ref(f / 'findings.txt')]
                    for rule in profiles[checker]['required-rules'].split(','):
                        wanted['negative-controls'] += [ref(f / ('negative-' + rule + '.txt')), ref(f / ('control-' + rule + '.pdf'))]
        if chain == 'visual':
            wanted['negative-controls'] += [ref(p) for p in sorted(negative.glob('*.png'))] + [ref(negative / 'one-pixel-control.properties')]
        if chain == 'semantic':
            wanted['findings'] += [ref(scope / 'contract-tests.txt'), ref(scope / 'contract-tests-command.json')]
        wanted['environment-observations'] = [ref(p) for p in sorted(env.iterdir()) if p.is_file()]
        eq(report, wanted, str(reportpath) + ' exact full ordered required report arrays')
        currentrefs = list(refs(report, reportpath))
        scope_refs += currentrefs + list(refs(record, recordpath))
        reports.append({'chain': chain, 'record-sha256': sha(recordpath), 'report-sha256': sha(reportpath), 'report-references': len(currentrefs), 'counts': {k: len(v) for k, v in report.items() if isinstance(v, list)}})
    allrefs += scope_refs
    tuples.append({'tuple': name, 'physical-files': len(physical), 'observation-files': len([p for p in physical if p.is_relative_to(obs)]), 'original-manifests': len(list(scope.rglob('retained-files.sha256'))), 'reports': reports, 'report-reference-count': sum((r['report-references'] for r in reports)), 'record-report-reference-occurrences': len(scope_refs)})
finish('transactions-evidence-inspection.json', {'method': 'Read-only complete original tree SHA, exact report array/reference, original independent process findings and retained public semantic outcomes; no project/checker/test replay', 'tuples': tuples, 'physical-original-file-count': len(physicalrows), 'required-standards-rules': len(rules), 'current-Arlington-model-files': len(model_files), 'qualified-negative-controls': len(negatives), 'positive-public-products': products, 'separate-visual-observations': visual, 'boundary': 'Original T03 profile uses complete report references and embedded exact input SHA in raw reports, without T13 retained-files manifests. No T13 rule/manifest counts or additional feature scope are inferred.'})
dump('original-tuple-file-identities.json', physicalrows)
dump('original-report-reference-identities.json', allrefs)
dump('standards-negative-control-identities.json', negatives)
