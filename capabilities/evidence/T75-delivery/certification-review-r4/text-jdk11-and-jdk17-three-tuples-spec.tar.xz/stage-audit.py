from auditlib import *
MAJOR = TUPLES[0][0]
ENV = 'jdk' + str(MAJOR) + '-environment'
import ast, datetime, yaml, tarfile, io
D = REPO / 'capabilities/evidence/T75-delivery'
stage = D / 'final-candidate-r4'
build = obj(stage / 'build-inputs.json')
candidate = build['candidate']
contract = build['contract-inputs']
prior = obj(D / 'final-candidate-r3/build-inputs.json')
validation = obj(D / 'final-validation-r4/source-and-contract-inputs.json')
closure = obj(D / 'inventory-read-bound/independent-review-closure.json')
groups = {'sources': candidate['inputs'], 'contracts': contract, 'artifacts': candidate['artifacts'], 'harness': build['harness']}
for label, rows in groups.items():
    eq(len(rows), {'sources': 1933, 'contracts': 30, 'artifacts': 23, 'harness': 24}[label], label + ' count')
    eq(len({r['path'] for r in rows}), len(rows), label + ' unique paths')
    for r in rows:
        eq(sha(REPO / r['path']), r['sha256'], label + ':' + r['path'])
eq({'inputs': candidate['inputs'], 'contract-inputs': contract}, validation, 'exact host and matrix input identity')
eq(contract, prior['contract-inputs'], 'r3 contract unchanged')
old = {r['path']: r['sha256'] for r in prior['candidate']['inputs']}
new = {r['path']: r['sha256'] for r in candidate['inputs']}
eq(set(old), set(new), 'source input path universe')
delta = [{'path': n, 'r3-sha256': old[n], 'current-sha256': new[n], 'bytes': files[str(REPO / n)]['bytes']} for n in sorted(new) if old[n] != new[n]]
eq(delta, closure['source-delta'], 'exact five reviewed source changes')
eq(closure['spec-closed'] and closure['standards-closed'], True, 'independent two-axis increment closure')
for axis in ['spec', 'standards']:
    eq(sha(D / 'inventory-read-bound' / (axis + '-review-report.md')), closure[axis + '-report-sha256'], axis + ' independent source report identity')
eq(sha(stage / 'build-inputs.json'), '64cb458acef6c0e98aa5b0dbf8023d85fe569fa2269eb6c3c343959779325e02', 'frozen r4 build identity')
eq(read(stage / 'build-inputs.json'), read(REPO / 'target/foundation-0.1.0/build-inputs.json'), 'current staged build bytes')
eq(candidate, obj(ROOT / 'candidate-probe.json')['candidate'], 'actual candidate observation')
canonical = lambda kind, rows: ''.join((kind + ' ' + r['path'] + ' ' + r['sha256'] + '\n' for r in sorted(rows, key=lambda r: r['path'])))
cid = lines_hash('release ' + candidate['release'] + '\n' + canonical('input', candidate['inputs']) + canonical('artifact', candidate['artifacts']))
tid = lines_hash(canonical('contract', contract))
eq(cid, 'ab18cc9c0473730a6aabec5d12e3172f22bea23a0a0f9529052a2bc186cbfc1b', 'canonical candidate')
eq(tid, '3de508f79fcbef7258feee8abc013d6f02b000840cac1cb263cb0d6f927b8f2b', 'canonical contract')
identitylog = read(ROOT / 'candidate-identity.txt').decode()
eq(re.search('^Candidate identity: ([a-f0-9]+)$', identitylog, re.M)[1], cid, 'actual candidate probe identity')
eq(re.search('^Contract identity: ([a-f0-9]+)$', identitylog, re.M)[1], tid, 'actual contract probe identity')
stageresult = obj(stage / 't75-final-stage-r4-result.json')
eq(stageresult['returncode'], 0, 'actual stage exit')
eq(stageresult['command'], ['/usr/bin/python3', 'scripts/t03-foundation.py', 'stage', '--obligation', 'text'], 'actual stage command')
aid = obj(stage / 'original-archive-identities.json')['staged-build']
eq(sha(stage / aid['archive']), aid['sha256'], 'stage original archive identity')
members = []
with tarfile.open(stage / aid['archive'], 'r:xz') as archive:
    for m in archive:
        if m.isdir():
            continue
        eq(m.isfile(), True, 'stage archive regular member ' + m.name)
        b = archive.extractfile(m).read()
        members.append({'path': m.name, 'size': len(b), 'sha256': hashlib.sha256(b).hexdigest()})
eq(members, aid['members'], 'stage archive complete member identities and order')
for r in aid['members']:
    eq(sha(Path(aid['original']) / r['path']), r['sha256'], 'stage original ' + r['path'])
validationlinks = []
for kind, receiptname, reportname, reviewreceipt in [('host', 'host-full-verify-receipt.json', 'standards-host-review-report.md', 'standards-host-review-receipt.json'), ('matrix', 'jdk-matrix-receipt.json', 'standards-matrix-review-report.md', 'standards-matrix-review-receipt.json')]:
    d = D / 'final-validation-r4'
    r = obj(d / receiptname)
    s = obj(d / reviewreceipt)
    eq(r['actual-result']['returncode'], 0, kind + ' actual exit')
    eq(r['result'], 'pass', kind + ' receipt')
    eq(sha(Path(r['original-log'])), r['log-sha256'], kind + ' complete original log identity')
    eq(len(r['runs']), 1 if kind == 'host' else 4, kind + ' actual run count')
    for run in r['runs']:
        eq(run['totals'], {'tests': 1507, 'failures': 0, 'errors': 0, 'skipped': 4}, kind + ' complete counts')
        eq(run['class-results'], 87, kind + ' original class count')
    validationlinks.append({'kind': kind, 'receipt-sha256': sha(d / receiptname), 'independent-report-sha256': sha(d / reportname), 'independent-receipt-sha256': sha(d / reviewreceipt), 'actual-log-sha256': r['log-sha256'], 'actual-result': r['actual-result'], 'runs': [{k: run[k] for k in ['jdk-major', 'totals', 'class-results']} for run in r['runs']], 'original-XML-boundary': r['report-boundary']})
source = read(REPO / 'scripts/t03-foundation.py').decode()
tree = ast.parse(source)
node = next((n.value for n in tree.body if isinstance(n, ast.Assign) and any((isinstance(t, ast.Name) and t.id == 'CERTIFICATION_CASES' for t in n.targets))))
case = ast.literal_eval(next((v for k, v in zip(node.keys, node.values) if ast.literal_eval(k) == 'text')))
fn = next((n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'certification_tools'))
toolmeta = ast.literal_eval(next((n.value for n in fn.body if isinstance(n, ast.Assign) and any((isinstance(t, ast.Name) and t.id == 'external' for t in n.targets)))))
envbefore = obj(ROOT / 'jdk8-environment/environment.yaml')
envprofile = next((p for p in yaml.safe_load(read(REPO / 'capabilities/foundation-environments.yaml'))['profiles'] if p['identity']['jdk-major'] == MAJOR))
eq(envprofile['identity'], envbefore['identity'], 'approved pinned environment')
tools = []
for t in toolmeta:
    pin = props(REPO / t['pin'])
    h = sha(REPO / t['path'])
    eq(h, pin[t['hash-key']], 'tool executable pin ' + t['id'])
    expected = {k: v for k, v in t.items() if k not in ('path', 'pin', 'hash-key')}
    expected['sha256'] = h
    tools.append(expected)
for label in ['t03', 't09', 't10', 't11', 't12', 't13']:
    tools.append({'id': 'folio-pdf-' + label, 'kind': 'project-test', 'version': '0.1.0', 'chains': ['semantic'], 'sha256': sha(REPO / 'target/foundation-0.1.0/harness/acceptance.jar')})
eq(tools, envbefore['tools'], 'all actual tool identities')
environments = []
for phase in BATCH['environment-phases']:
    name = ENV + ('-after' if phase == 'after' else '')
    d = ROOT / name
    osr = {k: v.strip('"') for k, v in props(d / 'os-release.txt').items()}
    jdk = {k: v.strip('"') for k, v in props(d / 'jdk-release.txt').items()}
    runtime = next((line.split('=', 1)[1].strip() for line in read(d / 'java-version.txt').decode().splitlines() if line.strip().startswith('java.runtime.version =')))
    image = read(d / 'image-digest.txt').decode().strip()
    arch = read(d / 'architecture.txt').decode().strip()
    n = obj(d / 'native-observation.json')
    eq(n['result'], 'pass', name + ' native observation')
    helperroot = REPO / '.build-cache/harfbuzz/10.2.0-final'
    for label, path in [('helper', helperroot / 'bin/folio-harfbuzz'), ('installation', helperroot / 'installation.json'), ('loaded_engine', helperroot / 'lib/libharfbuzz.so.0.61020.0'), ('observer', REPO / 'scripts/t29-native-observation.py'), ('python', Path('/usr/bin/python3.12'))]:
        eq(n[label]['sha256'], sha(path), name + ' ' + label + ' actual bytes')
    actual = {'os': osr['ID'], 'os-version': osr['VERSION_ID'], 'architecture': 'x86-64' if arch == 'x86_64' else arch, 'image': envprofile['identity']['image'].split('@')[0] + '@' + image, 'os-release-sha256': sha(d / 'os-release.txt'), 'jdk-major': int(runtime.split('.')[1] if runtime.startswith('1.') else runtime.split('.')[0]), 'jdk-vendor': jdk['IMPLEMENTOR'], 'jdk-build': runtime, 'java-sha256': read(d / 'java-executable.txt').decode().split()[0]}
    reconstructed = {'schema-version': 1, 'profile': envprofile['id'], 'identity': actual, 'host': {'kernel': read(d / 'kernel.txt').decode().strip(), 'architecture': actual['architecture']}, 'native-engine': {'name': 'harfbuzz', 'version': '10.2.0', 'helper-sha256': n['helper']['sha256'], 'library-sha256': n['loaded_engine']['sha256'], 'installation-sha256': n['installation']['sha256']}, 'tools': tools}
    eq(reconstructed, envbefore, name + ' returned identity reconstructed')
    inv = obj(d / 'invocation.json')
    eq(envprofile['identity']['image'] in inv and '--network=none' in inv, True, name + ' actual image/network command')
    eq(read(d / 'observer.log'), b'', name + ' actual observer exit output')
    environments.append({'directory': str(d.relative_to(REPO)), 'reconstructed': reconstructed, 'raw-files': [{'name': p.name, 'sha256': sha(p)} for p in sorted(d.iterdir()) if p.is_file()]})
release = yaml.safe_load(read(REPO / 'capabilities/foundation-release.yaml'))
cp = sorted((p for p in release['required-artifacts'] if p.endswith('.jar') and (not p.endswith(('-sources.jar', '-javadoc.jar'))) and ('itext7-preview' not in p))) + [r['path'] for r in build['harness'] if r['path'].endswith('.jar')]
expectedinputs = set(cp + [r['path'] for r in build['harness']] + ['target/foundation-0.1.0/build-inputs.json', 'target/foundation-0.1.0/build-command.json', 'scripts/imagemagick-runtime.sha256'] + [t['pin'] for t in toolmeta])
for name in case['configuration-paths']:
    p = REPO / name
    expectedinputs.update((str(f.relative_to(REPO)) for f in p.rglob('*') if f.is_file())) if p.is_dir() else expectedinputs.add(name)
tuples = []
for major, mode in TUPLES:
    scope = ROOT / ('jdk' + str(major) + '-' + mode.lower())
    config = obj(scope / 'execution.yaml')
    command = obj(scope / 'contract-tests-command.json')
    log = read(scope / 'contract-tests.txt').decode()
    eq(bool(re.search('^OK \\(126 tests\\)$', log, re.M)), True, mode + ' actual full126')
    eq('FAILURES!!!' in log, False, mode + ' no actual failure')
    dots = log.split('Time:')[0].splitlines()
    eq(any(('I' in x for x in dots if re.fullmatch('[.EISF]+', x))), False, mode + ' no ignored JUnit case')
    expectedconfig = {'schema-version': 1, 'candidate-sha256': cid, 'environment-sha256': sha(ROOT / 'jdk8-environment/environment.yaml'), 'acceptance-profile': case['profile'], 'execution-profile': mode, 'locale': 'en_US / C.UTF-8', 'timezone': 'UTC', 'settings': {'workflow-policy': case['workflow-policy'], 'fonts': case['fonts'], 'providers': 'none; Stable Facade execution is IN_PROCESS'}}
    subset(config, expectedconfig, mode + ' actual configuration')
    eq({r['path'] for r in config['inputs']}, expectedinputs, mode + ' exact configuration inventory')
    for r in config['inputs']:
        eq(sha(REPO / r['path']), r['sha256'], mode + ' configuration input ' + r['path'])
    for c in [command, config['command']]:
        eq(c[c.index('-cp') + 1].split(':'), ['/workspace/' + p for p in cp], mode + ' exact staged classpath')
        eq(envprofile['identity']['image'] in c, True, mode + ' immutable image')
        eq('-Dfolio.t13.executionProfile=' + mode in c, True, mode + ' Native selection')
        eq('--network=none' in c, True, mode + ' network')
        eq(str(REPO) + ':/workspace:ro' in c, True, mode + ' readonly repository')
    eq(command[command.index('-cp') + 2:], ['org.junit.runner.JUnitCore'] + case['test-classes'] + ['net.zerocloud.pdf.migration.itext7.contract.JarContractIT', 'net.zerocloud.pdf.migration.itext7.contract.ClasspathExclusivityIT'], mode + ' actual compiled classes')
    eq(config['command'][-5:], ['net.zerocloud.pdf.acceptance.T13EvidenceCommand', '/workspace', '/workspace/' + str(scope.relative_to(REPO)) + '/observations', mode, '0.1.0'], mode + ' recorder arguments')
    tuples.append({'tuple': str(scope.relative_to(REPO)), 'contract-tests-sha256': sha(scope / 'contract-tests.txt'), 'tests': 126, 'time-seconds': float(re.search('Time: ([\\d.]+)', log)[1]), 'execution-configuration-sha256': sha(scope / 'execution.yaml'), 'configuration-inputs': len(config['inputs']), 'actual-native-mode': mode, 'actual-facade-mode': 'IN_PROCESS', 'staged-classpath-paths': cp})
test = read(REPO / 'pdf-document/src/test/java/net/zerocloud/pdf/consumer/TextStructureExtractionWorkflowTest.java').decode()
eq(len(re.findall('^    @Test(?:\\(|\\s*$)', test, re.M)), 115, 'Native unchanged115 method count')
eq('@Ignore' in test or 'Assume.' in test, False, 'Native no skip')
eq(case['test-count'], 126, 'actual126 plan')
eq(case['contract-timeout'], 600, 'formal600s aggregate guard')
for name in ['unbalancedSupportedOperatorStateCannotPublishPrefix', 'unbalancedGraphicsAndPositioningStateCannotPublishPrefix', 'unbalancedFormOperatorStateCannotPublishPrefix']:
    eq('@Test(timeout = 10000L)\n    public void ' + name in test, True, 'unchanged10000ms guard ' + name)
finish('stage-environment-contract-inspection.json', {'created-utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'candidate-sha256': cid, 'contract-sha256': tid, 'input-counts': {k: len(v) for k, v in groups.items()}, 'source-delta-from-r3': delta, 'contract-delta-from-r3': 0, 'stage-archive-members': members, 'validation-review-linkage': validationlinks, 'tools': tools, 'environment-observations': environments, 'tuples': tuples, 'formal-aggregate-timeout-seconds': 600, 'candidate-probe-boundary': 'Identity/readiness observation only; its recorded pre-certification NOT READY and probe build failure are not a stage failure or certification claim.', 'deferred': ['all-eight text raw evidence', 'actual outer text exit/publication', 'other obligations', 'all48/final delivery']})
