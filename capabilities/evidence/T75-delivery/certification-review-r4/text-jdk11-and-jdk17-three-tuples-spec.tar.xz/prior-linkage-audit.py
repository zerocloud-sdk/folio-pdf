from auditlib import *
import tarfile,datetime
prior=Path('/tmp/t75-final-spec-r4-text-jdk8-ojzgj2p9');d=REPO/'capabilities/evidence/T75-delivery/certification-review-r4';identity=obj(d/'text-jdk8-two-tuples-spec-archive-identity.json');archive=d/'text-jdk8-two-tuples-spec.tar.xz';eq(sha(archive),'6d88851038830d44e7472d16f1a76e22992039a3e7561d83b35a6e88fbf08708','archived prior packet identity');eq(sha(prior/'archive-manifest.json'),'94ad46d66d50c81739f9c9a20ab4a501f165f8ee21940f0df5926f9388b73132','original prior manifest');pm=obj(prior/'archive-manifest.json');eq(pm['excluded-paths'],['archive-manifest.json'],'prior self-exclusion explicit');members={r['path']:{'size':r['bytes'],'sha256':r['sha256']} for r in pm['members']};members['archive-manifest.json']={'size':(prior/'archive-manifest.json').stat().st_size,'sha256':sha(prior/'archive-manifest.json')};eq(len(members),1160,'all prior original packet members')
for n,r in members.items():eq(sha(prior/n),r['sha256'],'prior original packet '+n)
actual={}
with tarfile.open(archive,'r:xz') as t:
 for m in t:
  if m.isdir():continue
  eq(m.isfile(),True,'archived regular file '+m.name);b=t.extractfile(m).read();actual[m.name]={'size':len(b),'sha256':hashlib.sha256(b).hexdigest()}
eq(actual,members,'complete prior archive equals original manifest and originals')
for name,wanted in [('report.md','ad25c9d7729a9db4a27076bfb2cb798e466bba544b6f4c0efe47ba1359921246'),('receipt.json','0381554f386e9d1c35803b1f8d804fef091d32fe5efb5aa088662fa2985ee7dc')]:eq(sha(prior/name),wanted,'prior '+name+' original identity')
receipt=obj(prior/'receipt.json');eq(receipt['approval'],{'two-JDK8-raw-tuples':True,'all-text8':False,'outer-exit-publication':False,'all48':False,'final-inventory-delivery':False,'completion-criteria-marked':False},'prior approval boundary');catalog=prior/receipt['complete-input-catalog']['path'];eq(sha(catalog),receipt['complete-input-catalog']['sha256'],'prior complete input catalog');rows=obj(catalog);eq(len(rows),41634,'prior inspected original count');current=[]
for row in rows:
 p=Path(row['path']);b=read(p);eq(hashlib.sha256(b).hexdigest(),row['sha256'],'prior still-current original '+str(p));eq(len(b),row['bytes'],'prior original byte length '+str(p));current.append({k:row[k] for k in ['path','sha256','bytes']})
for n in ['text-jdk8-two-tuples-spec-report.md','text-jdk8-two-tuples-spec-receipt.json']:
 expected='report.md' if n.endswith('report.md') else 'receipt.json';eq(read(d/n),read(prior/expected),'repository archived prior '+expected)
finish('prior-two-tuple-identity-linkage.json',{'created-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'prior-directory':str(prior),'prior-archive-path':str(archive.relative_to(REPO)),'prior-archive-sha256':sha(archive),'prior-archive-files':len(actual),'prior-original-packet-files':len(members),'prior-manifest-excludes-only-itself':True,'prior-inspected-original-paths-rehashed':len(current),'prior-complete-input-catalog-sha256':sha(catalog),'prior-approval-boundary':receipt['approval'],'all-current-raw-and-stage-source-identities-unchanged':not errors,'boundary':'Identity linkage and original-byte comparison only; no replay of previous project producers or checkers. Original diagnostics and historical disclosures are preserved byte-for-byte.'})
