from pathlib import Path
import hashlib,json,datetime,subprocess
BASE=Path(__file__).parent;REPO=Path('/home/ubuntu/IdeaProjects/open-pdf');ROOT=REPO/'capabilities/evidence/T75-foundation-20260914-r4/text';OUT=BASE/'final-inspection';OUT.mkdir();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();digest=lambda b:hashlib.sha256(b).hexdigest();sh=lambda p:digest(p.read_bytes());load=lambda p:json.loads(p.read_bytes())
def save(p,j):
 with p.open('x') as f:json.dump(j,f,ensure_ascii=False,indent=2);f.write('\n')
def require(v,message):
 if not v:raise ValueError(message)
batches=[BASE/'batch-01-jdk8-in_process',BASE/'batch-03-jdk8-hardened_worker'];corrected=BASE/'batch-02-jdk8-in_process-reader-closure';tuples=[];stages=[];summaries=[];derived=[]
for batch in batches:
 stage=load(batch/'stage-environment-contract-inspection.json');stages.append(stage);require(stage['errors']==[],str(batch)+' stage errors');expected=[('complete-reference-inspection.json','reference'),('qualification-and-public-outcome-inspection.json','qualification'),('separate-chain-control-inspection.json','separate-controls'),('report-array-coverage-inspection.json','report-arrays'),('complete-original-rgb-inspection.json','complete-RGB'),('selected-original-copies.json','selected-copies')];items={}
 for name,kind in expected:
  p=batch/name;j=load(p);require(j['errors']==[],str(p)+' findings');derived.append({'path':str(p.relative_to(BASE)),'sha256':sh(p),'kind':kind});items[kind]=j
 commandpath=(corrected if batch==batches[0] else batch)/'exact-command-and-spec-linkage-inspection.json';require(load(commandpath)['errors']==[],str(commandpath)+' command errors');derived.append({'path':str(commandpath.relative_to(BASE)),'sha256':sh(commandpath),'kind':'exact-argv-and-spec-linkage'});tuples.extend(stage['tuples']);summaries.append({'tuple':stage['tuples'][0]['tuple'],'references':items['reference']['tuples'][0],'rules':{k:items['qualification'][k] for k in ['declaration-rules','program-rules','program-scopes','per-tuple-counts','original-program-receipts']},'separate-chain-counts':items['separate-controls']['counts'],'full-visual-observations':len(items['complete-RGB']['complete-visual-observations']),'full-prescribed-controls':len(items['complete-RGB']['prescribed-secondary-controls']),'all-original-PNGs':sum(r['path'].startswith(stage['tuples'][0]['tuple']+'/') for r in items['complete-RGB']['raster-files'])})
require([p['tests'] for p in tuples]==[126,126],'two actual full suites');require([p['time-seconds'] for p in tuples]==[9.693,422.287],'actual formal times');require(len(stages[1]['environment-observations'])==2,'complete before/after');require(stages[1]['environment-observations'][0]['reconstructed']==stages[1]['environment-observations'][1]['reconstructed'],'before-after equality');require(stages[0]['environment-observations'][0]['reconstructed']==stages[1]['environment-observations'][0]['reconstructed'],'between-batch environment equality')
original_diag=load(batches[0]/'exact-command-and-spec-linkage-inspection.json')['errors'];require(len(original_diag)==1 and original_diag[0]['detail']=={'actual':'','expected':'T13 certification evidence recorded'},'preserved reader diagnostic boundary');require(load(corrected/'exact-command-and-spec-linkage-inspection.json')['errors']==[],'corrected fresh read clean');require(load(BASE/'finalizer-bootstrap-parse-diagnostic.json')['audit-ran'] is False,'bootstrap failure remains a source-generation diagnostic')
catalog={};origins={}
for batch in batches+[corrected]:
 for path in sorted(batch.glob('*-read-identities.json')):
  for row in load(path):
   p=Path(row['path'])
   if p.is_relative_to(BASE):continue
   if str(p) in catalog:require(catalog[str(p)]==row,'conflicting identity '+str(p))
   catalog[str(p)]=row;origins.setdefault(str(p),[]).append(str(path.relative_to(BASE)))
for p,row in catalog.items():
 actual=Path(p).read_bytes();require(len(actual)==row['bytes'] and digest(actual)==row['sha256'],'original changed before seal '+p)
save(OUT/'complete-inspected-input-identities.json',[dict(row,read_identity_catalogs=origins[p]) for p,row in sorted(catalog.items())]);copyrecords=[]
for batch in batches:
 for row in load(batch/'selected-original-copies.json')['copies']:
  target=batch/row['copy'];require(sh(target)==row['sha256'],'copied original changed '+str(target));require(row['sha256']==catalog[row['original']]['sha256'],'copy differs from origin '+row['original']);copyrecords.append(dict(row,copy=str(target.relative_to(BASE))))
save(OUT/'selected-original-copy-identities.json',copyrecords)
parity=[]
for product in ['nested-split-type3','marked-structure','embedded-font-kinds','embedded-font-inheritance','uncertain-geometry']:
 values=[]
 for scope in ['jdk8-in_process','jdk8-hardened_worker']:
  for api in ['native','facade']:
   for name in ['observation.properties','reopened.properties']:
    p=ROOT/scope/'observations'/(api+'-'+product)/name;values.append(p.read_bytes())
 require(all(v==values[0] for v in values),'cross-profile public byte parity '+product);parity.append({'product':product,'public-and-reopened-outcomes':len(values),'exact-original-observer-byte-sha256':digest(values[0]),'equal':True})
save(OUT/'cross-profile-public-parity.json',parity)
commands=[]
for name,args in [('baseline-head',['git','rev-parse','HEAD']),('commits',['git','log','5b1603c435f11c40368f75b7b9a2777c9c5e9761..HEAD','--oneline']),('index',['git','diff','--cached','--name-status'])]:
 cmd={'command':args,'cwd':str(REPO),'started-utc':now()};save(OUT/(name+'-command.json'),cmd)
 with (OUT/(name+'-stdout.txt')).open('xb') as stdout,(OUT/(name+'-stderr.txt')).open('xb') as stderr:r=subprocess.run(args,cwd=REPO,stdout=stdout,stderr=stderr)
 cmd.update({'returncode':r.returncode,'completed-utc':now(),'stdout-sha256':sh(OUT/(name+'-stdout.txt')),'stderr-sha256':sh(OUT/(name+'-stderr.txt'))});save(OUT/(name+'-result.json'),cmd);require(r.returncode==0,'read-only git failed');commands.append(cmd)
require((OUT/'baseline-head-stdout.txt').read_text().strip()=='5b1603c435f11c40368f75b7b9a2777c9c5e9761','baseline HEAD changed');require((OUT/'commits-stdout.txt').read_bytes()==b'' and (OUT/'index-stdout.txt').read_bytes()==b'','unexpected committed/index delta')
status={'observed-utc':now(),'complete-eight-text-index-exists':(ROOT/'observed-index.json').exists(),'outer-result-exists':Path('/tmp/t75-final-text-certify-r4-result.json').exists(),'boundary':'Dated process snapshot only. Other six text tuples and whole-run publication are outside this two-tuple approval.'};snapshots=[]
for p in [Path('/tmp/t75-final-text-certify-r4-command.json'),Path('/tmp/t75-final-text-certify-r4.log'),Path('/tmp/t75-final-text-certify-r4-result.json')]:
 if p.is_file():
  b=p.read_bytes();dest=OUT/('outer-process-snapshot-'+p.name)
  with dest.open('xb') as f:f.write(b)
  snapshots.append({'source':str(p),'snapshot':str(dest.relative_to(BASE)),'bytes':len(b),'sha256':digest(b),'observation-utc':now(),'source-may-continue-changing':p.suffix=='.log'})
status['original-process-snapshots']=snapshots;save(OUT/'outer-process-observation.json',status)
report=f'''CLEAN for r4 text JDK8 IN_PROCESS ({tuples[0]['time-seconds']}s) and HARDENED_WORKER ({tuples[1]['time-seconds']}s). Both actual formal suites passed 126 tests: 115 Native, nine Stable Facade, two artifact contracts. Both have four complete PASS chains. No unresolved Spec finding.

Baseline/HEAD: `5b1603c435f11c40368f75b7b9a2777c9c5e9761`. Candidate: `ab18cc9c0473730a6aabec5d12e3172f22bea23a0a0f9529052a2bc186cbfc1b`. Contract: `3de508f79fcbef7258feee8abc013d6f02b000840cac1cb263cb0d6f927b8f2b`.

All 1,933 source, 30 contract, 23 artifact and 24 harness identities match the fresh successful stage. The r3 delta is exactly the five independently reviewed inventory-reader files; contracts are unchanged. Completed host/four-JDK 1507/0/0/4 verification links to original logs and independent Standards receipts. Earlier full-source, appearance, observer-budget and Worker-split reviews retain their boundaries. Formal 600s aggregate and three 10,000ms guards remain unchanged.

The Goal requires “Separate independent syntax, standards, semantic and visual chains” (85–86) and actual bound identities (88–91). Each tuple has 19,700 original files, 85 manifests including root, 38,069 report references, 334 declaration rules and 42 program rules; 3,340 declaration negatives, 1,650 program negatives and 1,730 complete program producer receipts. Full public/reopened values, receipts, separate syntax/Catalog/12 semantic/4 PDF-visual controls and three raster defects plus their edge-only positive match the frozen contract.

All 65 actual PNGs per tuple were decoded. Authored Type3 geometry, complete primary/secondary RGB and prescribed raster defects match their own raw hashes and bounds. Full command arrays, classpaths, settings, tool identities and reconstructed JDK8 BEFORE/AFTER observations agree. Public outcomes match across both Native profiles and actual IN_PROCESS Facade, satisfying Goal124–125.

One reader diagnostic wrongly required a recorder stdout message; the original remains intact and a separate fresh read closes it against valid silent success. A finalizer bootstrap quoting error occurred before file creation; its diagnostic is retained separately. No review output was overwritten; historical r3 disclosures remain unchanged.

Only these two raw tuples are closed. Complete text8, outer exit/publication, other obligations, all48 and final inventory/delivery remain unapproved. No project tests, observers, certifiers, renderers or repository mutations ran.
'''
require(len(report.split())<400,'report exceeds400 words')
with (BASE/'report.md').open('x') as f:f.write(report)
receipt={'reviewer':'/root/final_spec','axis':'Spec','scope':'Only complete r4 text JDK8 IN_PROCESS and HARDENED_WORKER original evidence','completed-utc':now(),'baseline':'5b1603c435f11c40368f75b7b9a2777c9c5e9761','candidate-sha256':stages[0]['candidate-sha256'],'contract-sha256':stages[0]['contract-sha256'],'input-counts':stages[0]['input-counts'],'source-delta':stages[0]['source-delta-from-r3'],'contract-delta':0,'tuples':tuples,'actual-counts-and-record-report-identities':summaries,'actual-environments':stages[1]['environment-observations'],'actual-formal-aggregate-guard-seconds':600,'actual-method-guard-ms':10000,'facade-mode':'IN_PROCESS','fresh-stage-original-members':stages[0]['stage-archive-members'],'validation-lineage':stages[0]['validation-review-linkage'],'read-only-inspections':derived,'cross-profile-public-parity':parity,'complete-input-catalog':{'path':str((OUT/'complete-inspected-input-identities.json').relative_to(BASE)),'sha256':sh(OUT/'complete-inspected-input-identities.json'),'unique-original-paths':len(catalog),'all-current-identities-unchanged':True},'selected-original-copies':{'path':str((OUT/'selected-original-copy-identities.json').relative_to(BASE)),'sha256':sh(OUT/'selected-original-copy-identities.json'),'count':len(copyrecords),'bytes':sum(x['bytes'] for x in copyrecords)},'diagnostics':{'unresolved':[],'original-reader-diagnostic':{'path':'batch-01-jdk8-in_process/exact-command-and-spec-linkage-inspection.json','sha256':sh(batches[0]/'exact-command-and-spec-linkage-inspection.json')},'separate-reader-correction':{'path':'silent-recorder-reader-correction.json','sha256':sh(BASE/'silent-recorder-reader-correction.json')},'fresh-corrected-result':{'path':'batch-02-jdk8-in_process-reader-closure/exact-command-and-spec-linkage-inspection.json','sha256':sh(corrected/'exact-command-and-spec-linkage-inspection.json')},'finalizer-bootstrap-diagnostic':{'path':'finalizer-bootstrap-parse-diagnostic.json','sha256':sh(BASE/'finalizer-bootstrap-parse-diagnostic.json'),'closure':'This newly authored finalizer successfully ran after the source-generation quoting error; no prior output existed.'},'certification-evidence-modified':False,'review-output-overwrites':False,'prior-r3-annotations-lost-derived-summaries':'Historical incident remains disclosed in original r3 review; no lost original bytes are claimed recovered or newly retained.'},'outer-process-boundary':status,'approval':{'two-JDK8-raw-tuples':True,'all-text8':False,'outer-exit-publication':False,'all48':False,'final-inventory-delivery':False,'completion-criteria-marked':False},'report-sha256':sh(BASE/'report.md'),'report-word-count':len(report.split()),'project-runs':[],'repository-mutations':[],'retention-boundary':'All executed independent audit scripts and their exact command/stdout/stderr/result files retained. Exploratory reads are backed by selected originals and full final identity catalogs. The bootstrap source-generation failure is separately disclosed. Archive manifest describes actual retained bytes and explicitly excludes itself.'};save(BASE/'receipt.json',receipt);print(json.dumps({'result':'CLEAN','directory':str(BASE),'report-sha256':sh(BASE/'report.md'),'receipt-sha256':sh(BASE/'receipt.json'),'inspected-originals':len(catalog),'selected-copies':len(copyrecords),'word-count':len(report.split())}))
