from pathlib import Path
import sys, subprocess, json, os, datetime, hashlib
base = Path(__file__).parent
batch = base / sys.argv[1]
name = sys.argv[2]
allowed = {'stage-audit-v2.py', 'exact-command-audit-v3.py', 'prior-linkage-audit.py', 'reference-audit.py', 'qualification-audit.py', 'chain-controls-audit.py', 'report-coverage-audit.py', 'full-rgb-audit.py', 'retain-originals.py'}
if name not in allowed or batch.parent != base or (not batch.is_dir()):
    raise ValueError('Unauthorized inspection script or directory')
prefix = name.removesuffix('.py')
paths = {k: batch / (prefix + '-' + s) for k, s in [('command', 'command.json'), ('stdout', 'stdout.txt'), ('stderr', 'stderr.txt'), ('result', 'result.json')]}
if any((x.exists() for x in paths.values())):
    raise FileExistsError('Original command output exists; choose a new batch or script, never overwrite')
cmd = [sys.executable, '-B', str(base / name)]
env = dict(os.environ, T75_REVIEW_BATCH=str(batch))
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
sh = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
meta = {'command': cmd, 'cwd': str(batch), 'started-utc': now(), 'script-sha256': sh(base / name), 'auditlib-sha256': sh(base / 'auditlib.py'), 'scope-file-sha256': sh(batch / 'scope.json'), 'explicit-environment': {'T75_REVIEW_BATCH': str(batch)}, 'boundary': 'Independent file inspection only; no project code, producer, tests, certifier or environment observer execution.'}
with paths['command'].open('x') as f:
    json.dump(meta, f, indent=2)
    f.write('\n')
with paths['stdout'].open('xb') as stdout, paths['stderr'].open('xb') as stderr:
    r = subprocess.run(cmd, cwd=batch, env=env, stdout=stdout, stderr=stderr)
meta.update({'returncode': r.returncode, 'completed-utc': now(), 'stdout': {'path': str(paths['stdout']), 'sha256': sh(paths['stdout']), 'bytes': paths['stdout'].stat().st_size}, 'stderr': {'path': str(paths['stderr']), 'sha256': sh(paths['stderr']), 'bytes': paths['stderr'].stat().st_size}})
with paths['result'].open('x') as f:
    json.dump(meta, f, indent=2)
    f.write('\n')
print(paths['stdout'].read_text())
print(paths['stderr'].read_text())
print(json.dumps(meta))
sys.exit(r.returncode)
