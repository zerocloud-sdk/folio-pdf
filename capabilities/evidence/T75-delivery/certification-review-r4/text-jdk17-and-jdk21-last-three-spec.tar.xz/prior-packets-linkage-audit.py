from auditlib import *
import tarfile, datetime

specs = obj(BASE / 'prior-packets-plan.json')
archive_root = REPO / 'capabilities/evidence/T75-delivery/certification-review-r4'
packets = []
union = {}
for spec in specs:
    prior = Path(spec['directory'])
    archive = archive_root / (spec['archive-stem'] + '.tar.xz')
    eq(sha(archive), spec['archive-sha256'], 'prior archive identity ' + str(archive))
    archive_identity = archive_root / (spec['archive-stem'] + '-archive-identity.json')
    archive_identity_hash = sha(archive_identity)
    eq(sha(prior / 'archive-manifest.json'), spec['manifest-sha256'], 'prior original manifest')
    pm = obj(prior / 'archive-manifest.json')
    eq(pm['excluded-paths'], ['archive-manifest.json'], 'manifest explicit self exclusion')
    members = {}
    for row in pm['members']:
        eq(row['path'] in members, False, 'duplicate manifest member')
        members[row['path']] = {'size': row['bytes'], 'sha256': row['sha256']}
    members['archive-manifest.json'] = {
        'size': (prior / 'archive-manifest.json').stat().st_size,
        'sha256': sha(prior / 'archive-manifest.json')}
    eq(len(members), spec['packet-files'], 'complete original packet size')
    for name, wanted in members.items():
        data = read(prior / name)
        eq({'size': len(data), 'sha256': hashlib.sha256(data).hexdigest()}, wanted,
           'unchanged original packet member ' + name)
    archived = {}
    with tarfile.open(archive, 'r:xz') as stream:
        for member in stream:
            if member.isdir():
                continue
            eq(member.isfile(), True, 'archived regular file ' + member.name)
            eq(member.name in archived, False, 'duplicate archive member ' + member.name)
            data = stream.extractfile(member).read()
            archived[member.name] = {'size': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
    eq(archived, members, 'whole archive byte equality to original packet')
    for name in ['report.md', 'receipt.json']:
        eq(sha(prior / name), spec[name + '-sha256'], 'prior original ' + name)
        copied = archive_root / (spec['archive-stem'] + ('-report.md' if name == 'report.md' else '-receipt.json'))
        eq(read(copied), read(prior / name), 'repository retained ' + name)
    receipt = obj(prior / 'receipt.json')
    eq(receipt[spec['approval-field']], spec['expected-approval'], 'prior exact approval boundary')
    catalog_ref = receipt[spec['catalog-field']]
    catalog = prior / catalog_ref['path']
    eq(sha(catalog), spec['catalog-sha256'], 'prior input catalog known identity')
    eq(sha(catalog), catalog_ref['sha256'], 'prior receipt binds input catalog')
    rows = obj(catalog)
    eq(len(rows), spec['input-count'], 'prior complete catalog count')
    for row in rows:
        name = row['path']
        wanted = {k: row[k] for k in ['path', 'bytes', 'sha256']}
        if name in union:
            eq(wanted, union[name], 'prior catalogs agree for shared original ' + name)
            continue
        data = read(Path(name))
        eq(len(data), row['bytes'], 'prior original length ' + name)
        eq(hashlib.sha256(data).hexdigest(), row['sha256'], 'prior original bytes ' + name)
        union[name] = wanted
    packets.append({'directory': str(prior), 'archive': str(archive.relative_to(REPO)),
                    'archive-sha256': spec['archive-sha256'],
                    'archive-identity-sha256': archive_identity_hash,
                    'original-packet-files': len(members), 'archive-files': len(archived),
                    'original-report-sha256': spec['report.md-sha256'],
                    'original-receipt-sha256': spec['receipt.json-sha256'],
                    'input-catalog-sha256': sha(catalog), 'input-catalog-count': len(rows),
                    'approval-boundary': receipt[spec['approval-field']]})

finish('prior-five-tuples-identity-linkage.json', {
    'created-utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'prior-packets': packets, 'unique-prior-original-inputs-rehashed': len(union),
    'all-original-packet-files': sum(p['original-packet-files'] for p in packets),
    'all-current-original-identities-unchanged': not errors,
    'boundary': 'Two original Spec packets and their five raw tuples only. Whole original archives and complete original input catalogs are rehashed without project execution or replay of checkers. Prior scope deferrals, reader diagnostics and historical loss disclosures remain unchanged.'})
