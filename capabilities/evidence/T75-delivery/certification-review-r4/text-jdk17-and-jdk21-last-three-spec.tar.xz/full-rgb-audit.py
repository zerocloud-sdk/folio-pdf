from auditlib import *
import struct,zlib
C=REPO/'capabilities/profiles/T13-text';corpus=obj(C/'corpus.json');decoded={};pngs=[];visuals=[];controls=[]
def png(p,strict=False):
 if str(p) in decoded:return decoded[str(p)]
 data=read(p);eq(data[:8],b'\x89PNG\r\n\x1a\n',str(p)+' PNG signature');eq(len(data)<=4*1024*1024,True,str(p)+' bounded retained PNG');pos=8;chunks=[];blocks=[];palette=None;header=None;ended=False;idatclosed=False
 while pos<len(data):
  length=int.from_bytes(data[pos:pos+4],'big');kind=data[pos+4:pos+8];payload=data[pos+8:pos+8+length];crc=data[pos+8+length:pos+12+length];eq(len(payload),length,str(p)+' complete chunk');eq(zlib.crc32(kind+payload)&0xffffffff,int.from_bytes(crc,'big'),str(p)+' CRC');chunks.append(kind.decode());eq(kind in ([b'IHDR',b'IDAT',b'IEND'] if strict else [b'IHDR',b'PLTE',b'IDAT',b'IEND',b'sRGB',b'cHRM',b'bKGD',b'tEXt']),True,str(p)+' known opaque chunk');
  if kind==b'IHDR':eq(header,None,str(p)+' one header');header=struct.unpack('>IIBBBBB',payload)
  elif kind==b'PLTE':palette=[payload[i:i+3] for i in range(0,len(payload),3)];eq(len(payload)%3,0,str(p)+' complete palette')
  elif kind==b'IDAT':eq(idatclosed,False,str(p)+' contiguous IDAT');blocks.append(payload)
  elif blocks:idatclosed=True
  if kind==b'IEND':eq(length,0,str(p)+' empty end');eq(pos+12,len(data),str(p)+' no trailing PNG bytes');ended=True;break
  pos+=length+12
 eq(ended and chunks[0]=='IHDR',True,str(p)+' complete PNG');w,h,depth,color,compress,filtering,interlace=header;eq([w,h,compress,filtering,interlace],[240,200,0,0,0],str(p)+' fixed raster dimensions');eq((depth,color) in ([(8,2)] if strict else [(8,2),(1,0),(1,3)]),True,str(p)+' observed supported format');channels=3 if color==2 else 1;bits=channels*depth;stride=(w*bits+7)//8;bpp=max(1,(bits+7)//8);size=h*(stride+1);inflater=zlib.decompressobj();raw=inflater.decompress(b''.join(blocks),size+1);eq(len(raw),size,str(p)+' decoded size');eq(inflater.eof and not inflater.unused_data and not inflater.unconsumed_tail,True,str(p)+' complete bounded zlib');scan=bytearray(h*stride)
 for y in range(h):
  f=raw[y*(stride+1)];eq(f in range(5),True,str(p)+' valid row filter')
  for x,v in enumerate(raw[y*(stride+1)+1:(y+1)*(stride+1)]):
   off=y*stride+x;a=scan[off-bpp] if x>=bpp else 0;b=scan[off-stride] if y else 0;c=scan[off-stride-bpp] if y and x>=bpp else 0
   if f==0:pred=0
   elif f==1:pred=a
   elif f==2:pred=b
   elif f==3:pred=(a+b)//2
   else:
    base=a+b-c;dist=[abs(base-a),abs(base-b),abs(base-c)];pred=[a,b,c][dist.index(min(dist))]
   scan[off]=(v+pred)&255
 if color==2:pixels=bytes(scan)
 else:
  pixels=bytearray()
  for y in range(h):
   for x in range(w):
    idx=(scan[y*stride+x//8]>>(7-x%8))&1;pixels.extend(palette[idx] if color==3 else bytes([idx*255])*3)
  pixels=bytes(pixels)
 record={'path':str(p.relative_to(REPO)),'sha256':sha(p),'bytes':len(data),'dimensions':[w,h],'depth':depth,'color-type':color,'chunks':chunks,'decoded-rgb-sha256':hashlib.sha256(pixels).hexdigest()};pngs.append(record);decoded[str(p)]=(pixels,record);return pixels,record
def differences(a,b):return [i//3 for i in range(0,len(a),3) if a[i:i+3]!=b[i:i+3]]
def edge(pixel):
 x=pixel%240;y=pixel//240
 return any(-1<=x-ox<17 and -1<=y-oy<25 and not (1<=x-ox<15 and 1<=y-oy<23) for ox,oy in [(20,136),(60,136),(100,136),(20,56),(70,48),(120,56),(170,48)])
def compare_equal(a,b,where):eq(hashlib.sha256(a).hexdigest(),hashlib.sha256(b).hexdigest(),where+' complete RGB')
for major,mode in TUPLES:
 tn='jdk'+str(major)+'-'+mode.lower();obs=ROOT/tn/'observations'
 for transcript in sorted(obs.rglob('page-1-visual.txt')):
  d=transcript.parent;raw=read(transcript).decode();product=re.search(r'^Profile: `T13-text-logical-structure-(.+)-page-1`$',raw,re.M)[1];definition=corpus['products'][product]['visual'][0];authority,ar=png(C/definition['raster']);eq(ar['sha256'],definition['raster-sha256'],str(d)+' authored authority identity');expected,er=png(d/'page-1-expected.png');primary,pr=png(d/'page-1-pdfium.png');secondary,sr=png(d/'page-1-implementation.png');compare_equal(expected,authority,str(d)+' retained frozen raster');verdict=props(d/'result.properties')['visual'];changed=differences(expected,primary);secondarychanged=differences(primary,secondary);recorded=[int(re.search(r'^Exact changed RGB pixels, '+k+r': ([0-9]+)$',raw,re.M)[1]) for k in ['expected to PDFium','PDFium to secondary']];eq([len(changed),len(secondarychanged)],recorded,str(d)+' exact original RGB counts');eq(len(changed)==0,verdict=='pass',str(d)+' actual pixel verdict');eq(len(secondarychanged)<=definition['renderer-agreement-threshold'],True,str(d)+' secondary pixel bound')
  if product in ['nested-split-type3','marked-structure']:
   literal=bytearray(b'\xff\xff\xff'*48000)
   for x,y,w,h,r,g,b in definition['paints']:
    for yy in range(200-2*(y+h),200-2*y):
     for xx in range(2*x,2*(x+w)):o=(yy*240+xx)*3;literal[o:o+3]=bytes([r,g,b])
   compare_equal(authority,literal,str(d)+' exact original literal geometry')
  if product=='embedded-font-kinds' and verdict=='pass':
   outside=sum(not edge(x) for x in secondarychanged);eq(outside,0,str(d)+' secondary differences confined to original glyph shells');fp=props(d/'font-raster-agreement.properties');eq(fp['changed-pixels'],str(len(secondarychanged)),str(d)+' original secondary count');eq(fp['outside-edge-pixels'],str(outside),str(d)+' original outside-shell count')
  for n in ['difference','renderer-difference']:png(d/('page-1-'+n+'.png'))
  visuals.append({'tuple':tn,'directory':str(d.relative_to(ROOT)),'product':product,'verdict':verdict,'independent-exact-primary-changed-RGB-pixels':len(changed),'independent-exact-secondary-changed-RGB-pixels':len(secondarychanged),'authoritative-raster-sha256':ar['sha256'],'no-cross-JDK-compressed-byte-equality-required':True})
 d=obs/'negative/visual/raster';original,orig=png(d/'original.png',True);authority,auth=png(C/corpus['products']['embedded-font-kinds']['visual'][0]['raster']);compare_equal(original,authority,tn+' original control frozen pixels');eq(orig['sha256'],auth['sha256'],tn+' control original raw authority')
 for name,expectedcounts in [('edge-only',(1,0)),('missing-glyph',(432,308)),('interior-hole',(1,1)),('outside-ink',(1,1))]:
  pixels,r=png(d/name/'secondary.png',True);expected=bytearray(original);positions=[(20,136)] if name=='edge-only' else [(23,139)] if name=='interior-hole' else [(1,1)] if name=='outside-ink' else [(x,y) for y in range(135,161) for x in range(19,37)]
  for x,y in positions:i=(y*240+x)*3;expected[i:i+3]=b'\x00\x00\x00' if name=='outside-ink' else b'\xff\xff\xff'
  compare_equal(pixels,expected,tn+'/'+name+' entire specified defect');diff=differences(original,pixels);counts=(len(diff),sum(not edge(x) for x in diff));eq(counts,expectedcounts,tn+'/'+name+' independent complete counts');expectedprops={'profile':'T13-text-logical-structure-embedded-font-kinds-page-1','raster-agreement':'pass' if name=='edge-only' else 'fail','primary-sha256':orig['sha256'],'secondary-sha256':r['sha256'],'changed-pixels':str(counts[0]),'outside-edge-pixels':str(counts[1])};eq(props(d/name/'result.properties'),expectedprops,tn+'/'+name+' own recorded bytes and correct result');controls.append({'tuple':tn,'control':name,'secondary-sha256':r['sha256'],'decoded-rgb-sha256':r['decoded-rgb-sha256'],'independent-counts':list(counts),'whole-prescribed-RGB-matches':pixels==bytes(expected)})
 eq({str(p) for p in obs.rglob('*.png')},set(k for k in decoded if Path(k).is_relative_to(obs)),tn+' every original PNG decoded')
read(REPO/'docs/t13-certification.md');read(REPO/'pdf-acceptance/src/main/java/net/zerocloud/pdf/acceptance/T13FontRasterAgreement.java');read(REPO/'pdf-acceptance/src/main/java/net/zerocloud/pdf/acceptance/T13NegativeControls.java');prior=Path('/tmp/t75-final-spec-r3-three-tuples-smdhs3w8/raster-control-method-closure.json');pc=obj(prior);eq(pc['errors'],[],'prior interpretation closure');eq(pc['all-original-diagnostics-accounted-for'],True,'prior diagnostic preservation');finish('complete-original-rgb-inspection.json',{'method':'Read-only PNG CRC, bounded decompression, unfiltering and RGB comparison. No project renderer or checker ran; original PNG bytes never edited. All original positive/negative product, difference and raster-control PNGs decoded.','prior-compressed-byte-assumption-diagnostic-closure':{'path':str(prior),'sha256':sha(prior)},'raster-files':pngs,'complete-visual-observations':visuals,'prescribed-secondary-controls':controls})
