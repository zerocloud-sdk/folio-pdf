from pathlib import Path
import datetime, hashlib, json, re, subprocess

BASE = Path(__file__).parent
REPO = Path('/home/ubuntu/IdeaProjects/open-pdf')
ROOT = REPO / 'capabilities/evidence/T75-foundation-20260914-r4/text'
CID = 'ab18cc9c0473730a6aabec5d12e3172f22bea23a0a0f9529052a2bc186cbfc1b'
TID = '3de508f79fcbef7258feee8abc013d6f02b000840cac1cb263cb0d6f927b8f2b'
BASELINE = '5b1603c435f11c40368f75b7b9a2777c9c5e9761'
ASSIGNED = [(17, 'HARDENED_WORKER', 'batch-01-jdk17-hardened_worker'),
            (21, 'IN_PROCESS', 'batch-02-jdk21-in_process'),
            (21, 'HARDENED_WORKER', 'batch-03-jdk21-hardened_worker')]
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
digest = lambda b: hashlib.sha256(b).hexdigest()
sha = lambda p: digest(p.read_bytes())
load = lambda p: json.loads(p.read_bytes())

def require(value, message):
    if not value:
        raise ValueError(message)

def save(path, data):
    with path.open('x') as handle:
        json.dump(data, handle, ensure_ascii=False, indent=2)
        handle.write('\n')

# No final output is created until all three immutable scopes have passed.
for major, mode, batch in ASSIGNED:
    require((BASE / batch / 'completed-tuple-component-receipt.json').is_file(),
            'Assigned scope has no completed independent receipt: ' + batch)
OUT = BASE / 'final-inspection'
OUT.mkdir()
components = []
completed = []
stages = []
batches = [BASE / 'batch-00-prior-five-linkage']
for major, mode, batch in ASSIGNED:
    checkpoint = BASE / batch / 'completed-tuple-component-receipt.json'
    result = load(checkpoint)
    require(result['errors'] == [], 'Open component finding: ' + batch)
    require(result['tuple']['tuple'] == str((ROOT / ('jdk' + str(major) + '-' + mode.lower())).relative_to(REPO)), 'Wrong reviewed tuple')
    require(result['tuple']['tests'] == 126, 'Formal126 not complete')
    require(result['tuple']['actual-native-mode'] == mode and result['tuple']['actual-facade-mode'] == 'IN_PROCESS', 'Wrong actual public execution profile')
    require(result['candidate-sha256'] == CID and result['contract-sha256'] == TID, 'Wrong candidate/contract')
    bykind = {}
    for item in result['components']:
        path = BASE / item['path']
        require(sha(path) == item['sha256'], 'Changed completed reader component: ' + str(path))
        data = load(path)
        require(data['errors'] == [], 'Open reader finding: ' + str(path))
        bykind[item['component']] = data
    require(set(bykind) == {'stage', 'references', 'qualification', 'separate-controls', 'report-arrays', 'RGB', 'commands', 'original-copies'}, 'Incomplete independent reader set')
    stage = bykind['stage']
    require(stage['input-counts'] == {'sources': 1933, 'contracts': 30, 'artifacts': 23, 'harness': 24}, 'Wrong current staged input counts')
    stages.append(stage)
    completed.append(result)
    components.append({'path': str(checkpoint.relative_to(BASE)), 'sha256': sha(checkpoint)})
    batches.append(BASE / batch)

prior_path = BASE / 'batch-00-prior-five-linkage/prior-five-tuples-identity-linkage.json'
prior = load(prior_path)
require(prior['errors'] == [], 'Previous five raw tuples have unresolved identity linkage')
require(prior['all-original-packet-files'] == 2897, 'Incomplete previous packet retention')
old8 = load(Path(prior['prior-packets'][0]['directory']) / 'receipt.json')
old3 = load(Path(prior['prior-packets'][1]['directory']) / 'receipt.json')
old17_component = Path(prior['prior-packets'][1]['directory']) / 'batch-04-jdk17-in_process/stage-environment-contract-inspection.json'
old17_stage = load(old17_component)
environment_closures = []
for major, stage in [(17, stages[0]), (21, stages[2])]:
    observations = stage['environment-observations']
    require(len(observations) == 2, 'Missing BEFORE/AFTER raw environment: JDK' + str(major))
    require(observations[0]['reconstructed'] == observations[1]['reconstructed'], 'Before/after identity drift: JDK' + str(major))
    previous = old17_stage if major == 17 else stages[1]
    require(previous['environment-observations'][0]['reconstructed'] == observations[0]['reconstructed'], 'Cross-profile before identity drift: JDK' + str(major))
    environment_closures.append({'jdk-major': major, 'before-after-equal': True,
                                 'cross-profile-before-equal': True,
                                 'original-observations': observations,
                                 'boundary': 'AFTER identity reconstructed from its ten retained raw files; environment.yaml is intentionally absent.'})
save(OUT / 'final-environment-closures.json', environment_closures)

catalog = {}
origins = {}
for batch in batches:
    for identity_file in sorted(batch.glob('*-read-identities.json')):
        for row in load(identity_file):
            path = row['path']
            if Path(path).is_relative_to(BASE):
                continue
            wanted = {key: row[key] for key in ['path', 'bytes', 'sha256']}
            if path in catalog:
                require(catalog[path] == wanted, 'Conflicting inspected original: ' + path)
            catalog[path] = wanted
            origins.setdefault(path, []).append(str(identity_file.relative_to(BASE)))

def read_original(path, reason):
    data = path.read_bytes()
    row = {'path': str(path), 'bytes': len(data), 'sha256': digest(data)}
    if str(path) in catalog:
        require(catalog[str(path)] == row, 'Final original identity mismatch: ' + str(path))
    catalog[str(path)] = row
    origins.setdefault(str(path), []).append(reason)
    return data

def properties(data):
    result = {}
    for line in data.decode('utf-8').splitlines():
        if not line or line[0] in '#!':
            continue
        key, sep, value = line.partition('=')
        require(bool(sep) and key not in result, 'Invalid public property: ' + key)
        result[key] = re.sub(r'\\(u[0-9a-fA-F]{4}|.)', lambda m: chr(int(m[1][1:], 16)) if m[1].startswith('u') and len(m[1]) == 5 else {'t': '\t', 'n': '\n', 'r': '\r', 'f': '\f'}.get(m[1], m[1]), value)
    return result

old_parity = {row['product']: row for row in old8['cross-profile-public-parity']}
parity = []
for product in ['nested-split-type3', 'marked-structure', 'embedded-font-kinds', 'embedded-font-inheritance', 'uncertain-geometry']:
    values = []
    own_bytes = []
    for major in [8, 11, 17, 21]:
        for mode in ['IN_PROCESS', 'HARDENED_WORKER']:
            scope = ROOT / ('jdk' + str(major) + '-' + mode.lower())
            for api in ['native', 'facade']:
                for filename in ['observation.properties', 'reopened.properties']:
                    path = scope / 'observations' / (api + '-' + product) / filename
                    data = read_original(path, 'final all-eight public/reopened value comparison')
                    values.append(properties(data))
                    own_bytes.append({'path': str(path.relative_to(REPO)), 'sha256': digest(data)})
    require(all(value == values[0] for value in values), 'Cross-JDK/public profile value mismatch: ' + product)
    canonical = digest(json.dumps(values[0], sort_keys=True, separators=(',', ':')).encode())
    require(canonical == old_parity[product]['canonical-public-value-sha256'], 'Previously reviewed public value mismatch: ' + product)
    parity.append({'product': product, 'actual-public-and-reopened-observations': len(values),
                   'canonical-public-value-sha256': canonical,
                   'each-original-file-own-byte-identity': own_bytes,
                   'boundary': 'Java Properties timestamp comments are excluded only from parsed value equality; original bytes retain their individual SHA.'})
save(OUT / 'all-eight-public-value-parity.json', parity)

# The unpublished observation index may be inspected once the producer has
# retained it, but this never inspects or approves authority publication.
index_path = ROOT / 'observed-index.json'
index_summary = {'observed-utc': now(), 'exists': index_path.is_file(),
                 'publication-approved': False}
if index_path.is_file():
    index_bytes = read_original(index_path, 'completed all-eight raw observation index')
    index = json.loads(index_bytes)
    staged = json.loads(read_original(REPO / 'capabilities/evidence/T75-delivery/final-candidate-r4/build-inputs.json', 'observation-index staged candidate equality'))
    require(index['schema-version'] == 1 and index['candidate'] == staged['candidate'], 'Observation index candidate mismatch')
    expected_environments = []
    expected_certifications = []
    record_links = []
    for major in [8, 11, 17, 21]:
        profile = 'ubuntu-24.04-linux-x86-64-jdk' + str(major)
        env_path = ROOT / ('jdk' + str(major) + '-environment') / 'environment.yaml'
        env_hash = digest(read_original(env_path, 'raw index environment reference'))
        expected_environments.append({'profile': profile, 'record': {'path': str(env_path.relative_to(REPO)), 'sha256': env_hash}})
        for mode in ['IN_PROCESS', 'HARDENED_WORKER']:
            scope = ROOT / ('jdk' + str(major) + '-' + mode.lower())
            config_path = scope / 'execution.yaml'
            config_hash = digest(read_original(config_path, 'raw index execution reference'))
            refs = []
            for chain in ['syntax', 'standards', 'semantic', 'visual']:
                record_path = scope / (chain + '.yaml')
                data = read_original(record_path, 'all-eight original chain record linkage')
                record = json.loads(data)
                required = {'obligation': 'text', 'candidate-sha256': CID, 'contract-sha256': TID,
                            'execution-profile': mode, 'environment-sha256': env_hash,
                            'execution-configuration-sha256': config_hash,
                            'chain': chain, 'result': 'pass'}
                require(all(record.get(k) == value for k, value in required.items()), 'Raw index record binding mismatch: ' + str(record_path))
                report_path = REPO / record['report']['path']
                require(digest(read_original(report_path, 'all-eight report byte linkage')) == record['report']['sha256'], 'Report identity mismatch')
                refs.append({'path': str(record_path.relative_to(REPO)), 'sha256': digest(data)})
                record_links.append({'record': refs[-1], 'report': record['report'], 'native-profile': mode, 'facade-profile': 'IN_PROCESS'})
            expected_certifications.append({'obligation': 'text', 'environment': profile,
                                             'execution-profile': mode,
                                             'configuration': {'path': str(config_path.relative_to(REPO)), 'sha256': config_hash},
                                             'records': refs})
    require(index['environments'] == expected_environments, 'Observation index environment set/order mismatch')
    require(index['certifications'] == expected_certifications, 'Observation index exact eight/32 mismatch')
    with (OUT / 'observed-index-original.json').open('xb') as handle:
        handle.write(index_bytes)
    index_summary.update({'sha256': digest(index_bytes), 'certifications': len(expected_certifications),
                          'records': len(record_links), 'environments': len(expected_environments),
                          'all-eight-completed-original-links': record_links,
                          'boundary': 'Raw observed-index equality only. Actual outer result and published Foundation authority are reserved for a separate review.'})
save(OUT / 'raw-observed-index-linkage.json', index_summary)

for path, row in catalog.items():
    data = Path(path).read_bytes()
    require(len(data) == row['bytes'] and digest(data) == row['sha256'], 'Original changed before seal: ' + path)
save(OUT / 'complete-inspected-input-identities.json', [dict(row, read_identity_catalogs=origins[path]) for path, row in sorted(catalog.items())])
copies = []
for major, mode, batch in ASSIGNED:
    for row in load(BASE / batch / 'selected-original-copies.json')['copies']:
        target = BASE / batch / row['copy']
        require(sha(target) == row['sha256'], 'Selected original changed')
        require(catalog[row['original']]['sha256'] == row['sha256'], 'Selected original/catalog mismatch')
        copies.append(dict(row, copy=str(target.relative_to(BASE))))
save(OUT / 'selected-original-copy-identities.json', copies)

for name, argv in [('baseline-head', ['git', 'rev-parse', 'HEAD']),
                   ('commits', ['git', 'log', BASELINE + '..HEAD', '--oneline']),
                   ('index', ['git', 'diff', '--cached', '--name-status'])]:
    command = {'command': argv, 'cwd': str(REPO), 'started-utc': now()}
    save(OUT / (name + '-command.json'), command)
    with (OUT / (name + '-stdout.txt')).open('xb') as stdout, (OUT / (name + '-stderr.txt')).open('xb') as stderr:
        outcome = subprocess.run(argv, cwd=REPO, stdout=stdout, stderr=stderr)
    command.update({'returncode': outcome.returncode, 'completed-utc': now(),
                    'stdout-sha256': sha(OUT / (name + '-stdout.txt')),
                    'stderr-sha256': sha(OUT / (name + '-stderr.txt'))})
    save(OUT / (name + '-result.json'), command)
    require(outcome.returncode == 0, 'Read-only Git inspection failed')
require((OUT / 'baseline-head-stdout.txt').read_text().strip() == BASELINE, 'HEAD changed')
require((OUT / 'commits-stdout.txt').read_bytes() == b'' and (OUT / 'index-stdout.txt').read_bytes() == b'', 'Commit/index delta')

status = {'observed-utc': now(), 'actual-outer-result-exists': Path('/tmp/t75-final-text-certify-r4-result.json').is_file(),
          'outer-exit-inspected': False, 'authority-inspected': False,
          'outer-exit-publication-approved': False, 'final-inventory-delivery-approved': False,
          'reason': 'Actual outer-process and publication closure is a separate authorized review, even if the process completes while this raw packet is sealed.'}
snapshots = []
for path in [Path('/tmp/t75-final-text-certify-r4-command.json'), Path('/tmp/t75-final-text-certify-r4.log')]:
    if path.is_file():
        data = path.read_bytes()
        target = OUT / ('outer-process-snapshot-' + path.name)
        with target.open('xb') as handle:
            handle.write(data)
        snapshots.append({'original': str(path), 'snapshot': str(target.relative_to(BASE)), 'bytes': len(data), 'sha256': digest(data), 'observed-utc': now(), 'original-may-continue-changing': path.suffix == '.log'})
status['dated-original-process-snapshots'] = snapshots
save(OUT / 'deferred-publication-boundary.json', status)

counts = [{'tuple': row['tuple']['tuple'], 'formal-tests': row['tuple']['tests'],
           'time-seconds': row['tuple']['time-seconds'], 'observation-files': row['reference-summary']['physical-observation-files'],
           'manifests-including-root': row['reference-summary']['manifests-including-root'],
           'report-references': row['reference-summary']['report-reference-count'],
           'actual-PNGs': row['decoded-original-PNGs'], 'qualification-counts': row['qualification-counts'],
           'program-producer-receipts': row['program-producer-receipts']}
          for row in completed]
save(OUT / 'actual-last-three-tuple-counts.json', counts)
common = counts[0]
require(all(all(row[key] == common[key] for key in ['formal-tests', 'observation-files', 'manifests-including-root', 'report-references', 'actual-PNGs', 'program-producer-receipts']) for row in counts), 'Actual per-tuple counts differ; report needs individual counts')
brief = '; '.join('JDK' + str(major) + ' ' + mode + ' (' + str(row['time-seconds']) + 's)' for (major, mode, batch), row in zip(ASSIGNED, counts))
paragraphs = [
    'CLEAN for the final three r4 text raw tuples: ' + brief + '. Each actual formal suite passed 126 tests (115 Native, nine Stable Facade, two artifact contracts), with four complete PASS chains. No unresolved Spec finding.',
    'Baseline/HEAD: `' + BASELINE + '`. Candidate: `' + CID + '`. Contract: `' + TID + '`.',
    'All 1,933 source, 30 contract, 23 artifact and 24 harness identities match the reviewed r4 stage. The five-file inventory correction, prior full-source/appearance/observer/Worker-split reviews and successful host/four-JDK 1507/0/0/4 checks retain their original boundaries. Mandatory 600s aggregate and three 10,000ms guards remain unchanged.',
    'The Goal requires “Separate independent syntax, standards, semantic and visual chains” (85–86) and actual bound identities (88–91). Each tuple independently retains ' + format(common['observation-files'], ',') + ' observation files, ' + str(common['manifests-including-root']) + ' manifests including root, ' + format(common['report-references'], ',') + ' report references, all 334 declaration/42 program rules, 3,340 declaration negatives, 1,650 program negatives and 1,730 producer receipts. Separate syntax/Catalog, semantic, PDF-visual and raster defects and positive controls satisfy the frozen profile.',
    'All ' + str(common['actual-PNGs']) + ' actual PNGs per tuple were decoded against full prescribed RGB and geometry, retaining each PNG’s own SHA. Exact commands, classpaths, settings, tools and public/reopened outcomes match. Facade remains actual IN_PROCESS (Goal124–125). JDK17 and JDK21 BEFORE/AFTER identities reconstruct equally; this closes the earlier JDK17 deferral.',
    'Both prior packets, all 2,897 original packet files and their complete original input catalogs remain unchanged. Their reader diagnostics and historical loss disclosures are preserved. Cross-JDK public values agree across all eight raw tuples.',
    ('The complete raw observed-index matches eight configurations and 32 unchanged records. ' if index_summary.get('records') == 32 else 'The raw observed-index remains outside this packet because it was not yet retained. ') + 'Together with the prior five, this closes eight raw text tuple reviews only. Actual outer exit, authority publication, other obligations and final inventory/index/delivery require separate closure. No project executions or repository mutations ran.'
]
report = '\n\n'.join(paragraphs) + '\n'
require(len(report.split()) < 400, 'Report word limit exceeded')
with (BASE / 'report.md').open('x') as handle:
    handle.write(report)
receipt = {'reviewer': '/root/final_spec', 'axis': 'Spec', 'sealed-utc': now(),
           'scope': 'Final three r4 text raw tuples, linked to five prior raw tuples; publication excluded',
           'baseline': BASELINE, 'candidate-sha256': CID, 'contract-sha256': TID,
           'input-counts': stages[0]['input-counts'], 'reviewed-source-delta': stages[0]['source-delta-from-r3'],
           'contract-delta': 0, 'components': components, 'complete-tuple-summaries': completed,
           'prior-five-linkage': {'path': str(prior_path.relative_to(BASE)), 'sha256': sha(prior_path), 'inspection': prior},
           'completed-environment-closures': environment_closures, 'all-eight-public-value-parity': parity,
           'raw-observed-index': index_summary,
           'complete-current-input-catalog': {'path': 'final-inspection/complete-inspected-input-identities.json', 'sha256': sha(OUT / 'complete-inspected-input-identities.json'), 'original-paths': len(catalog), 'all-original-bytes-rechecked-unchanged': True},
           'selected-original-copies': {'path': 'final-inspection/selected-original-copy-identities.json', 'sha256': sha(OUT / 'selected-original-copy-identities.json'), 'count': len(copies), 'bytes': sum(row['bytes'] for row in copies)},
           'reader-diagnostics': {'unresolved': [], 'prior-diagnostics-preserved-byte-for-byte': True, 'review-files-overwritten': False, 'historical-annotations-loss': 'Prior r3 two lost derived summaries remain disclosed in their original packet; no recovery of those bytes is claimed.'},
           'deferred-gates': status,
           'approvals': {'assigned-three-raw-tuples': True, 'linked-all-eight-raw-tuples': True, 'JDK17-AFTER': True, 'JDK21-AFTER': True, 'outer-exit-publication': False, 'other-obligations': False, 'all48-final-delivery': False, 'completion-criteria-marked': False},
           'report-sha256': sha(BASE / 'report.md'), 'report-words': len(report.split()),
           'project-runs': [], 'repository-mutations': [],
           'retention': 'Exclusive /tmp outputs; selected original files and complete original SHA catalogs. Original audit scripts/commands/stdout/stderr/results retained. Final manifest explicitly excludes itself.'}
save(BASE / 'receipt.json', receipt)
print(json.dumps({'result': 'CLEAN', 'directory': str(BASE), 'report-sha256': sha(BASE / 'report.md'),
                  'receipt-sha256': sha(BASE / 'receipt.json'), 'original-paths-rehashed': len(catalog),
                  'selected-originals': len(copies), 'report-words': len(report.split()),
                  'raw-observed-index-records': index_summary.get('records')}))
