#!/usr/bin/env python3
"""Retain the actual r4 stage and require the previously verified source snapshot."""
import hashlib,importlib.util,json,shutil,tempfile
from pathlib import Path
import yaml
ROOT=Path('/home/ubuntu/IdeaProjects/open-pdf');DEST=ROOT/'capabilities/evidence/T75-delivery/final-candidate-r4';BASE=ROOT/'target/foundation-0.1.0';PREFIX=Path('/tmp/t75-final-stage-r4')
DEST.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def mod(name,p):
    spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
result=json.loads(Path(str(PREFIX)+'-result.json').read_bytes());assert result['returncode']==0
frozen_path=ROOT/'capabilities/evidence/T75-delivery/final-validation-r4/source-and-contract-inputs.json';frozen=json.loads(frozen_path.read_bytes())
f=mod('stage_inputs',ROOT/'scripts/t03-foundation.py');contract=yaml.safe_load((ROOT/'capabilities/foundation-release.yaml').read_bytes());assert f.capture_build_inputs(ROOT,contract)==frozen
build=f.require_staged_build(ROOT,contract,BASE/'build-inputs.json');assert build['candidate']['inputs']==frozen['inputs'] and build['contract-inputs']==frozen['contract-inputs']
assert (len(build['candidate']['inputs']),len(build['candidate']['artifacts']),len(build['harness']),len(build['contract-inputs']))==(1933,23,24,30)
for mode in ('host-full-verify','jdk-matrix'):
    rec=json.loads((frozen_path.parent/(mode+'-receipt.json')).read_bytes());assert rec['result']=='pass' and rec['source-and-contract-inputs-unchanged']
original=Path(tempfile.mkdtemp(prefix='t75-final-candidate-r4-'))
for src in [BASE/'build-inputs.json',BASE/'build-command.json',BASE/'build.txt',frozen_path,Path(str(PREFIX)+'.log'),Path(str(PREFIX)+'-command.json'),Path(str(PREFIX)+'-result.json'),Path('/tmp/t75-run-retained.py'),Path(__file__)]:
    shutil.copyfile(src,original/src.name);assert sha(src)==sha(original/src.name)
receipt={'fixed-review-baseline':'5b1603c435f11c40368f75b7b9a2777c9c5e9761','source-input-count':1933,'contract-input-count':30,'artifact-count':23,'harness-input-count':24,'matches-complete-host-and-four-jdk-source-contract-inputs':True,'build-inputs-sha256':sha(BASE/'build-inputs.json'),'build-command-sha256':sha(BASE/'build-command.json'),'actual-stage-result':result,'status':'Staged unsigned local candidate; actual certification remains separate.'}
(original/'freeze.json').write_text(json.dumps(receipt,indent=2)+'\n')
r=mod('stage_retention',ROOT/'capabilities/evidence/T75-delivery/recorder-r4/retain-programs.py');r.destination=DEST;identity=r.archive('staged-build',original)
with (DEST/'original-archive-identities.json').open('x') as out:out.write(json.dumps({'staged-build':identity},indent=2)+'\n')
for name in ('build-inputs.json','build-command.json','freeze.json','t75-final-stage-r4-command.json','t75-final-stage-r4-result.json','t75-final-stage-r4.log'):
    shutil.copyfile(original/name,DEST/name)
with Path('/tmp/t75-final-candidate-r4-original-path.txt').open('x') as out:out.write(str(original)+'\n')
print('Actual stage exit0; all1933/30/23/24 frozen identities matched completed host/matrix; original',original)
