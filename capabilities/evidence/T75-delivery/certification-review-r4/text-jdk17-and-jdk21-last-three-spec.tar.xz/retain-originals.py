from auditlib import *
MAJOR = TUPLES[0][0]
ENV = 'jdk' + str(MAJOR) + '-environment'
import datetime
selected = set()
base = REPO / 'capabilities/evidence/T75-delivery'
stage = base / 'final-candidate-r4'
build = obj(stage / 'build-inputs.json')
paths = ['AGENTS.md', 'CONTRIBUTING.md', 'CONTEXT.md', 'docs/agents/domain.md', 'docs/agents/issue-tracker.md', 'docs/t13-certification.md', 'docs/text-logical-structure.md', 'docs/foundation-readiness.md', 'capabilities/evidence/T13-text-logical-structure.md', 'capabilities/foundation-release.yaml', 'capabilities/foundation-requirements.yaml', 'capabilities/foundation-environments.yaml', 'capabilities/capability-matrix.yaml', 'capabilities/facade-surface.yaml', 'scripts/t03-foundation.py', 'scripts/t13_foundation_reports.py', 'pdf-acceptance/src/main/java/net/zerocloud/pdf/acceptance/T13EvidenceCommand.java', 'pdf-acceptance/src/main/java/net/zerocloud/pdf/acceptance/T13NegativeControls.java', 'pdf-acceptance/src/main/java/net/zerocloud/pdf/acceptance/T13FontRasterAgreement.java', 'pdf-document/src/test/java/net/zerocloud/pdf/consumer/TextStructureExtractionWorkflowTest.java', 'pdf-migration-itext7/src/test/java/net/zerocloud/pdf/itext7/consumer/TextStructureFacadeTest.java', 'capabilities/profiles/T13-text/corpus.json', 'capabilities/profiles/T13-text/corpus.properties', 'capabilities/profiles/T13-standards/required-rules.txt', 'capabilities/profiles/T13-standards/program-qualification.properties']
selected.update((REPO / n for n in paths))
for n in ['build-inputs.json', 'build-command.json', 'freeze.json', 'original-archive-identities.json', 'README.md', 't75-final-stage-r4-command.json', 't75-final-stage-r4-result.json']:
    selected.add(stage / n)
aid = obj(stage / 'original-archive-identities.json')['staged-build']
selected.update((Path(aid['original']) / r['path'] for r in aid['members']))
for folder in ['inventory-read-bound', 'final-validation-r4']:
    d = base / folder
    selected.update((p for p in d.iterdir() if p.is_file() and p.suffix in ['.json', '.md']))
for n in ['/home/ubuntu/.codex/attachments/77353239-0dda-4ee1-b4bb-ce7fb3fa0f9b/pasted-text-1.txt', '/tmp/t75-issue-75-pre-freeze.json', '/tmp/t75-issue-1.json', '/tmp/t75-final-spec-6avdtb8v/report.md', '/tmp/t75-final-spec-crosspage-closure-p2k77wkr/report.md', '/tmp/t75-final-spec-observer-closure-f22wcurv/report.md', '/tmp/t75-final-spec-worker-batch-l5vz0c63/report.md', '/tmp/t75-final-spec-r3-two-tuples-_xr8bj_5/report.md', '/tmp/t75-final-spec-r3-two-tuples-_xr8bj_5/receipt.json', '/tmp/t75-final-spec-r3-three-tuples-smdhs3w8/raster-control-method-closure.json', '/tmp/t75-final-spec-first-tuple-o2wpbwez/frozen-rule-control-expectations.json', '/tmp/t75-final-spec-first-tuple-o2wpbwez/completed-tuple-semantic-visual-syntax-inspection.json']:
    selected.add(Path(n))
selected.update([ROOT / 'candidate-identity.txt', ROOT / 'candidate-probe.json'])
for phase in BATCH['environment-phases']:
    d = ROOT / (ENV + ('-after' if phase == 'after' else ''))
    selected.update((p for p in d.iterdir() if p.is_file()))
for major, mode in TUPLES:
    scope = ROOT / ('jdk' + str(major) + '-' + mode.lower())
    obs = scope / 'observations'
    selected.update((p for p in scope.iterdir() if p.is_file()))
    selected.update((obs / n for n in ['result.properties', 'products.properties', 'retained-files.sha256']))
    for d in obs.iterdir():
        if not d.is_dir():
            continue
        selected.update((p for p in d.iterdir() if p.is_file() and p.name in ['result.properties', 'observation.properties', 'reopened.properties', 'publication.properties', 'extraction.pdf']))
        for chain in ['declarations', 'programs']:
            for n in ['result.properties', 'identities-before.properties', 'identities-after.properties']:
                p = d / chain / n
                if p.is_file():
                    selected.add(p)
    selected.update((p for p in obs.rglob('*.png')))
    selected.update((p for p in obs.rglob('page-1-visual.txt')))
    selected.update((p for p in obs.rglob('page-1-visual.md')))
    selected.update((p for p in (obs / 'negative').rglob('result.properties') if 'qualifications' not in p.parts))
    d = obs / 'native-marked-structure'
    for folder in [d / 'programs/input/content', d / 'programs/qualifications', d / 'declarations/pdfcpu']:
        if folder.is_dir():
            if folder.name == 'qualifications':
                folder = next((p for p in sorted(folder.iterdir()) if p.is_dir()))
            selected.update((p for p in folder.iterdir() if p.is_file() and p.stat().st_size <= 65536))
copies = []
for p in sorted(selected):
    b = read(p)
    rel = Path('repo') / p.relative_to(REPO) if p.is_relative_to(REPO) else Path('external') / p.relative_to('/')
    target = OUT / 'originals' / rel
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open('xb') as f:
        f.write(b)
    copies.append({'original': str(p), 'copy': str(target.relative_to(OUT)), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()})
finish('selected-original-copies.json', {'created-utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'selected-original-count': len(copies), 'selected-original-bytes': sum((r['bytes'] for r in copies)), 'copies': copies, 'boundary': 'Selected byte-exact immutable originals only. Full original paths/sizes/SHA catalogs cover the entire inspected tree, retained separately; no claim that the whole live tree was duplicated.'})
