from auditlib import *
MAJOR = TUPLES[0][0]
ENV = 'jdk' + str(MAJOR) + '-environment'
import ast, datetime
stage = obj(OUT / 'stage-environment-contract-inspection.json')
src = read(REPO / 'scripts/t03-foundation.py').decode()
tree = ast.parse(src)
node = next((n.value for n in tree.body if isinstance(n, ast.Assign) and any((isinstance(t, ast.Name) and t.id == 'CERTIFICATION_CASES' for t in n.targets))))
case = ast.literal_eval(next((v for k, v in zip(node.keys, node.values) if ast.literal_eval(k) == 'text')))
env = obj(ROOT / (ENV + '/environment.yaml'))
records = []
for major, mode in TUPLES:
    scope = ROOT / ('jdk' + str(major) + '-' + mode.lower())
    inside = '/workspace/' + scope.relative_to(REPO).as_posix()
    cp = ':'.join(('/workspace/' + p for p in stage['tuples'][0]['staged-classpath-paths']))
    base = ['podman', 'run', '--rm', '--network=none', '--userns=keep-id', '--volume', str(REPO) + ':/workspace:ro', '--volume', str(REPO / '.build-cache/harfbuzz/10.2.0-final') + ':/folio-harfbuzz:ro', '--volume', '/usr/bin/python3.12:/usr/bin/python3.12:ro', '--volume', '/usr/lib/python3.12:/usr/lib/python3.12:ro', '--volume', str(Path('/lib/x86_64-linux-gnu/libexpat.so.1').resolve()) + ':/lib/x86_64-linux-gnu/libexpat.so.1:ro', '--workdir', '/workspace', '--env', 'LANG=C.UTF-8', '--env', 'LC_ALL=C.UTF-8', '--env', 'TZ=UTC', '--env', 'FOLIO_HARFBUZZ_HELPER=/folio-harfbuzz/bin/folio-harfbuzz', '--volume', str(scope) + ':' + inside + ':rw', env['identity']['image']]
    options = ['-Xmx1024m', '-Duser.language=en', '-Duser.country=US', '-Duser.timezone=UTC', '-Dfolio.harfBuzzHelper=/folio-harfbuzz/bin/folio-harfbuzz', '-Dfolio.t13.executionProfile=' + mode]
    testoptions = ['-DrepositoryRoot=/workspace', '-DartifactPath=/workspace/target/foundation-0.1.0/artifacts/pdf-migration-itext7-preview-0.1.0.jar', '-DstableArtifactPath=/workspace/target/foundation-0.1.0/artifacts/pdf-migration-itext7-0.1.0.jar', '-DdocumentArtifactPath=/workspace/target/foundation-0.1.0/artifacts/pdf-document-0.1.0.jar', '-DtestClassesPath=/workspace/target/foundation-0.1.0/harness/facade-tests.jar']
    tests = base + ['java'] + options + testoptions + ['-cp', cp, 'org.junit.runner.JUnitCore'] + case['test-classes'] + ['net.zerocloud.pdf.migration.itext7.contract.JarContractIT', 'net.zerocloud.pdf.migration.itext7.contract.ClasspathExclusivityIT']
    recorder = base + ['java'] + options + ['-cp', cp, 'net.zerocloud.pdf.acceptance.T13EvidenceCommand', '/workspace', inside + '/observations', mode, '0.1.0']
    c = obj(scope / 'execution.yaml')
    eq(c['command'], recorder, mode + ' every actual recorder argv')
    eq(obj(scope / 'contract-tests-command.json'), tests, mode + ' every actual contract argv')
    eq(c['java-options'], options, mode + ' all actual JVM options')
    log = read(scope / 'recorder.txt').decode()
    eq(log.strip(), '', mode + ' actual successful recorder transcript')
    records.append({'tuple': scope.name, 'full-command-equality': True, 'recorder-argument-count': len(recorder), 'contract-argument-count': len(tests), 'actual-recorder-log-sha256': sha(scope / 'recorder.txt'), 'recorded-contract-command-sha256': sha(scope / 'contract-tests-command.json'), 'configuration-sha256': sha(scope / 'execution.yaml')})
links = []
for d in ['/tmp/t75-final-spec-6avdtb8v', '/tmp/t75-final-spec-crosspage-closure-p2k77wkr', '/tmp/t75-final-spec-observer-closure-f22wcurv', '/tmp/t75-final-spec-worker-batch-l5vz0c63', '/tmp/t75-final-spec-r3-two-tuples-_xr8bj_5', '/tmp/t75-final-spec-r3-three-tuples-smdhs3w8', '/tmp/t75-final-spec-r3-last-three-d_5tt9z2']:
    p = Path(d) / 'report.md'
    links.append({'path': str(p), 'sha256': sha(p), 'boundary': 'Historical review retained without rewriting or promotion to current candidate certification.'})
for n in ['AGENTS.md', 'CONTRIBUTING.md', 'CONTEXT.md', 'docs/agents/domain.md', 'docs/agents/issue-tracker.md', 'docs/t13-certification.md', 'docs/text-logical-structure.md', 'docs/foundation-readiness.md', 'capabilities/evidence/T13-text-logical-structure.md', 'capabilities/foundation-release.yaml', 'capabilities/foundation-requirements.yaml', 'capabilities/facade-surface.yaml', 'capabilities/capability-matrix.yaml', 'pdf-document/src/test/java/net/zerocloud/pdf/consumer/TextStructureExtractionWorkflowTest.java', 'pdf-migration-itext7/src/test/java/net/zerocloud/pdf/itext7/consumer/TextStructureFacadeTest.java']:
    read(REPO / n)
goal = Path('/home/ubuntu/.codex/attachments/77353239-0dda-4ee1-b4bb-ce7fb3fa0f9b/pasted-text-1.txt')
eq(sha(goal), '794423d41161169ea6a4fee993553f777d6249cb05c5fe4d34f59657ab18f83f', 'original Goal identity')
read(Path('/tmp/t75-issue-75-pre-freeze.json'))
read(Path('/tmp/t75-issue-1.json'))
finish('exact-command-and-spec-linkage-inspection.json', {'created-utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'commands': records, 'prior-review-linkage': links, 'mandatory-unclosed-gates': ['remaining text tuples outside this bounded packet', 'complete eight-text index and outer exit/publication', 'prior five obligations refreshed on r4', 'final inventory/readiness/diff and delivery'], 'criterion-completion-marked': False})
