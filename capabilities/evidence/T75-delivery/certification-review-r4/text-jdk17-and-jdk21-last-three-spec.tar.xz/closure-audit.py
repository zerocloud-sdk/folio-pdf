from auditlib import *
import datetime
components=obj(OUT/'components.json');data={};identities=[]
for name,rel in components.items():
 p=BASE/rel;j=obj(p);eq(j['errors'],[],name+' component closure');data[name]=j;identities.append({'component':name,'path':rel,'sha256':sha(p)})
stage=data['stage'];tuples=stage['tuples'];eq(len(tuples),1,'exactly one immutable actual tuple per component checkpoint');summary={'created-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'tuple':tuples[0],'candidate-sha256':stage['candidate-sha256'],'contract-sha256':stage['contract-sha256'],'input-counts':stage['input-counts'],'components':identities,'reference-summary':data['references']['tuples'][0],'qualification-counts':data['qualification']['per-tuple-counts'],'program-producer-receipts':data['qualification']['original-program-receipts'],'separate-controls':data['separate-controls']['counts'],'decoded-original-PNGs':sum(r['path'].startswith(tuples[0]['tuple']+'/') for r in data['RGB']['raster-files']),'environment-phases':BATCH['environment-phases'],'selected-originals':data['original-copies']['selected-original-count'],'actual-facade-profile':'IN_PROCESS','boundary':'Completed single tuple component checkpoint only; complete assigned-three/text8/outer publication/other obligations/final delivery not approved.'}
finish('completed-tuple-component-receipt.json',summary)
