from pathlib import Path,PurePosixPath
import hashlib,json,re,os
BASE=Path(__file__).parent
OUT=Path(os.environ['T75_REVIEW_BATCH'])
if not OUT.is_relative_to(BASE) or not OUT.is_dir():raise ValueError('Only existing unique review batch directories permitted')
BATCH=json.loads((OUT/'scope.json').read_bytes())
REPO=Path('/home/ubuntu/IdeaProjects/open-pdf')
ROOT=REPO/'capabilities/evidence/T75-foundation-20260914-r4/text'
TUPLES=[(int(a),b) for a,b in BATCH['tuples']]
ALLOWED=set(BATCH['allowed-root-items'])
files={};errors=[]
def error(where,detail):errors.append({'where':str(where),'detail':detail})
def read(p):
 p=Path(p)
 if p.is_relative_to(ROOT):
  rel=p.relative_to(ROOT)
  if rel.parts and rel.parts[0] not in ALLOWED:raise ValueError('Active or out-of-scope certification path prohibited: '+str(p))
 b=p.read_bytes();h=hashlib.sha256(b).hexdigest();k=str(p)
 if k in files and files[k]['sha256']!=h:error(p,'bytes changed during independent inspection')
 files[k]={'path':k,'sha256':h,'bytes':len(b)};return b
def sha(p):return hashlib.sha256(read(p)).hexdigest()
def obj(p):return json.loads(read(p))
def props(p):
 result={}
 for line in read(p).decode('utf-8').splitlines():
  if not line or line[0] in '#!':continue
  key,sep,val=line.partition('=')
  if not sep or key in result:error(p,'duplicate or malformed property '+key);continue
  result[key]=re.sub(r'\\(u[0-9a-fA-F]{4}|.)',lambda m:chr(int(m[1][1:],16)) if m[1].startswith('u') and len(m[1])==5 else {'t':'\t','n':'\n','r':'\r','f':'\f'}.get(m[1],m[1]),val)
 return result
def eq(actual,expected,where):
 if actual!=expected:error(where,{'actual':actual,'expected':expected})
def subset(actual,expected,where):
 for k,v in expected.items():eq(actual.get(k),v,str(where)+':'+k)
def lines_hash(text):return hashlib.sha256(text.encode()).hexdigest()
def dump(name,value):
 p=OUT/name
 if p.parent!=OUT:raise ValueError('Flat, exclusive output name required')
 with p.open('x') as f:json.dump(value,f,ensure_ascii=False,indent=2);f.write('\n')
def finish(name,result):
 result['errors']=errors;dump(name,result);dump(name.removesuffix('.json')+'-read-identities.json',list(files.values()));print(json.dumps({'file':name,'read-files':len(files),'errors':errors[:12],'error-count':len(errors)},ensure_ascii=False))
def manifest(p):
 entries={}
 for line in read(p).decode().splitlines():
  m=re.fullmatch(r'([0-9a-f]{64})  (.+)',line)
  if not m:error(p,'malformed manifest');continue
  h,n=m.groups();q=PurePosixPath(n)
  if q.is_absolute() or '..' in q.parts or q.as_posix()!=n or n in entries:error(p,'unsafe/duplicate manifest name '+n)
  entries[n]=h
 return entries
