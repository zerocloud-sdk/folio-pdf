from pathlib import Path,PurePosixPath
import hashlib,json,re,sys,atexit
REPO=Path('/home/ubuntu/IdeaProjects/open-pdf');OUT=Path(__file__).parent;ROOT=REPO/'capabilities/evidence/T75-foundation-20260914-r4/metadata'
AUTH_PATH=OUT/sys.argv[1];PHASE=sys.argv[2];AUTH=json.loads(AUTH_PATH.read_bytes());TUPLES=[tuple(t) for t in AUTH['tuples']];ALLOWED_TUPLES={f'jdk{j}-{m.lower()}' for j,m in AUTH.get('allowed-tuples',AUTH['tuples'])};ALLOWED_DIRS=ALLOWED_TUPLES|set(AUTH['environment-directories']);ALLOWED_ROOT=set(AUTH['root-files']);files={};errors=[]
def error(where,detail):errors.append({'where':str(where),'detail':detail})
def read(p):
 p=Path(p)
 if p.is_relative_to(ROOT):
  rel=p.relative_to(ROOT)
  if not rel.parts or (rel.parts[0] not in ALLOWED_DIRS and str(rel) not in ALLOWED_ROOT):raise PermissionError('Not authorized as complete for this phase: '+str(p))
 b=p.read_bytes();h=hashlib.sha256(b).hexdigest();k=str(p)
 if k in files and files[k]['sha256']!=h:error(p,'bytes changed during independent read')
 files[k]={'path':k,'sha256':h,'bytes':len(b)};return b
read(AUTH_PATH)
def sha(p):return hashlib.sha256(read(p)).hexdigest()
def obj(p):return json.loads(read(p))
def props(p):
 result={}
 for line in read(p).decode('utf-8').splitlines():
  if not line or line[0] in '#!':continue
  key,sep,val=line.partition('=')
  if not sep or key in result:error(p,'duplicate or malformed property '+key);continue
  result[key]=re.sub(r'\\(u[0-9a-fA-F]{4}|.)',lambda m:chr(int(m[1][1:],16)) if m[1].startswith('u') and len(m[1])==5 else {'t':'\t','n':'\n','r':'\r','f':'\f'}.get(m[1],m[1]),val)
 return result
def eq(a,b,w):
 if a!=b:error(w,{'actual':a,'expected':b})
def subset(actual,expected,where):
 for k,v in expected.items():eq(actual.get(k),v,str(where)+':'+k)
def lines_hash(s):return hashlib.sha256(s.encode()).hexdigest()
def dump(name,value):
 with (OUT/(PHASE+'-'+name)).open('x') as f:f.write(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def finish(name,result):
 result['errors']=errors;result['authorization']=str(AUTH_PATH);result['selected-tuples']=TUPLES;dump(name,result);dump(name.replace('.json','-read-identities.json'),list(files.values()));print(json.dumps({'file':PHASE+'-'+name,'read-files':len(files),'error-count':len(errors),'errors':errors[:3]},ensure_ascii=False))
def manifest(p):
 entries={}
 for line in read(p).decode().splitlines():
  m=re.fullmatch(r'([0-9a-f]{64})  (.+)',line)
  if not m:error(p,'malformed manifest');continue
  h,n=m.groups();q=PurePosixPath(n)
  if q.is_absolute() or '..' in q.parts or q.as_posix()!=n or n in entries:error(p,'unsafe/duplicate manifest name '+n)
  entries[n]=h
 return entries
@atexit.register
def save_reads():dump(Path(sys.argv[0]).stem+'-automatic-input-catalog.json',list(files.values()))
