from auditlib import *
import zlib,struct
from collections import Counter
C=REPO/'capabilities/profiles/T11-metadata';corpus=obj(C/'corpus.json');eq(sha(C/'corpus.json'),'83617b5340205c3ed2746329aecf7c7d0009fe7dc4555141cf162f3d14f1ae25','frozen independent corpus JSON');eq(sha(C/'corpus.properties'),'cf5c080324f0d18f5571d61c3019f9858dd1cd13f5c148a7aecbc5d1d4155f22','frozen semantic corpus properties')
flattened={}
def flatten(v,prefix=''):
 if isinstance(v,dict):
  for k,x in v.items():flatten(x,prefix+'.'+k if prefix else k)
 elif isinstance(v,list):
  flattened[prefix+'.count']=str(len(v))
  for i,x in enumerate(v):flatten(x,prefix+'.'+str(i))
 else:flattened[prefix]='' if v is None else str(v).lower() if isinstance(v,bool) else str(v)
flatten(corpus);eq(props(C/'corpus.properties'),flattened,'complete JSON/properties expectation identity')
for name,entry in corpus['sources'].items():eq(sha(C/entry['path']),entry['sha256'],'unaltered original authored PDF source '+name)
EXPECTED_PRODUCTS={'edited':['C','A','B','A'],'merged':['A','B','C','D'],'left':['A','B'],'right':['C','D']}
eq({k:v['pages'] for k,v in corpus['products'].items()},EXPECTED_PRODUCTS,'prescribed page order')
colours={'A':(255,0,0),'B':(0,255,0),'C':(0,0,255),'D':(0,0,0)}
rows={};page_summaries=[]
for name,colour in colours.items():
 info=corpus['pages'][name];eq([info[k] for k in ['media-box','crop-box','rotation','raster-width','raster-height']],[[0,0,120,100],[0,0,120,100],0,240,200],'authored geometry '+name);eq(info['paints'],[[10,20,40,30]+list(colour)],'authored rectangle '+name)
 eq(info['contents'],['q '+' '.join(str(c//255) for c in colour)+' rg 10 20 40 30 re f Q\n'],'all authored content operators '+name);eq(sha(C/info['raster']),info['raster-sha256'],'original corpus raster '+name)
 white=b'\xff'*720;painted=b'\xff'*60+bytes(colour)*80+b'\xff'*420;currentrows=[painted if 100<=y<160 else white for y in range(200)];rows[(name,False)]=currentrows
 pixels=Counter(tuple(r[x:x+3]) for r in currentrows for x in range(0,len(r),3));page_summaries.append({'page':name,'media-box':[0,0,120,100],'crop-box':[0,0,120,100],'rotation':0,'width':240,'height':200,'rectangle-pixel-columns-inclusive':[20,99],'rectangle-pixel-rows-inclusive':[100,159],'painted-pixels':4800,'white-pixels':43200,'prescribed-decoded-rgb-sha256':hashlib.sha256(b''.join(currentrows)).hexdigest(),'colour-pixel-counts':{','.join(map(str,c)):n for c,n in pixels.items()}})
rows[('C',True)]=list(rows[('C',False)]);rows[('C',True)][0]=b'\0'*3+rows[('C',True)][0][3:]
filter_cache={};encoded_cache={};observations=[]
def filtered(current,previous,kind):
 key=(current,previous,kind)
 if key in filter_cache:return filter_cache[key]
 out=bytearray(len(current))
 for x,v in enumerate(current):
  a=current[x-3] if x>=3 else 0;b=previous[x];c=previous[x-3] if x>=3 else 0
  if kind==0:predict=0
  elif kind==1:predict=a
  elif kind==2:predict=b
  elif kind==3:predict=(a+b)//2
  else:
   p=a+b-c;pa,pb,pc=abs(p-a),abs(p-b),abs(p-c);predict=a if pa<=pb and pa<=pc else b if pb<=pc else c
  out[x]=(v-predict)&255
 filter_cache[key]=bytes(out);return filter_cache[key]
def inspect(p,name,flipped=False):
 data=read(p);h=hashlib.sha256(data).hexdigest();key=(h,name,flipped);info=corpus['pages'][name];width,height=info['raster-width'],info['raster-height'];stride=width*3
 if key not in encoded_cache:
  eq(data[:8],b'\x89PNG\r\n\x1a\n',str(p)+' PNG signature');pos=8;compressed=[];chunks=[]
  while pos<len(data):
   n=int.from_bytes(data[pos:pos+4],'big');kind=data[pos+4:pos+8];payload=data[pos+8:pos+8+n];crc=data[pos+8+n:pos+12+n];eq(len(payload),n,str(p)+' original chunk length');eq(zlib.crc32(kind+payload)&0xffffffff,int.from_bytes(crc,'big'),str(p)+' original CRC');chunks.append(kind.decode())
   if kind==b'IHDR':eq(list(struct.unpack('>IIBBBBB',payload)),[width,height,8,2,0,0,0],str(p)+' opaque RGB8 comparator input')
   elif kind==b'IDAT':compressed.append(payload)
   elif kind==b'IEND':eq(pos+12,len(data),str(p)+' original PNG exact EOF');break
   pos+=n+12
  eq(chunks[0],'IHDR',str(p)+' first IHDR');eq(chunks[-1],'IEND',str(p)+' final IEND');eq('tRNS' in chunks,False,str(p)+' no transparency');expectedlength=height*(stride+1);inflater=zlib.decompressobj();scanlines=inflater.decompress(b''.join(compressed),expectedlength+1);eq(len(scanlines),expectedlength,str(p)+' bounded complete inflation');eq(inflater.eof and not inflater.unused_data and not inflater.unconsumed_tail,True,str(p)+' single exact finite zlib stream');previous=b'\0'*stride;filters=Counter()
  for y,current in enumerate(rows[(name,flipped)]):
   start=y*(stride+1);kind=scanlines[start];eq(kind in range(5),True,str(p)+' valid PNG filter');eq(scanlines[start+1:start+1+stride],filtered(current,previous,kind),str(p)+' all RGB bytes of row '+str(y));filters[kind]+=1;previous=current
  encoded_cache[key]={'encoded-sha256':h,'prescribed-decoded-rgb-sha256':hashlib.sha256(b''.join(rows[(name,flipped)])).hexdigest(),'page':name,'pixel-count':width*height,'width':width,'height':height,'single-pixel-flipped-at-0-0':flipped,'original-chunks':chunks,'original-filter-counts':dict(filters)}
 observations.append({'path':str(p.relative_to(REPO)),**encoded_cache[key]})
for name,info in corpus['pages'].items():inspect(C/info['raster'],name)
visual_profiles=[]
for product,page_names in EXPECTED_PRODUCTS.items():
 for page,name in enumerate(page_names,1):
  profile=C/'visual'/(product+'-page-'+str(page)+'.properties');actual=props(profile);info=corpus['pages'][name]
  expected={'PROFILE_ID':'T11-metadata-outlines-destinations-attachments-'+product+'-page-'+str(page),'PAGE_COUNT':str(len(page_names)),'PAGE_SELECTION':str(page),'PAGE_BOX':'effective CropBox [0 0 120 100] points','DPI':'144','COLOR_POLICY':'sRGB, opaque 8-bit RGB PNG after compositing over opaque white','FONT_POLICY':'not applicable; the artifact has no text or font resources and uses no system fonts','ANTIALIASING_POLICY':'pinned PDFium default smoothing; vector edges are axis-aligned','BACKGROUND':'opaque white (#ffffff)','RASTER_WIDTH':'240','RASTER_HEIGHT':'200','COMPARISON_METRIC':'AE','COMPARISON_FUZZ_PERCENT':'0','COMPARISON_THRESHOLD':'0','RENDERER_AGREEMENT_THRESHOLD':'0','EXPECTED_RASTER':'../'+info['raster'],'EXPECTED_RASTER_SHA256':info['raster-sha256']}
  eq(actual,expected,'all original T11 visual profile fields '+str(profile));visual_profiles.append({'path':str(profile.relative_to(REPO)),'sha256':sha(profile),'actual':actual,'geometric-page':name})
for major,mode in TUPLES:
 obs=ROOT/('jdk'+str(major)+'-'+mode.lower())/'observations'
 for api in ['native','facade']:
  for product,page_names in EXPECTED_PRODUCTS.items():
   for page,name in enumerate(page_names,1):
    for suffix in ['expected','pdfium','implementation']:inspect(obs/(api+'-'+product)/('page-'+str(page)+'-'+suffix+'.png'),name)
 neg=obs/'negative/visual';inspect(neg/'one-pixel-control.png','C',True);inspect(neg/'page-1-expected.png','C',True)
 for suffix in ['pdfium','implementation']:inspect(neg/('page-1-'+suffix+'.png'),'C')
finish('complete-rgb-raster-inspection.json',{'scope':'Only the explicit completed phase tuples and the frozen authored corpus','method':'Read-only PNG CRC and bounded zlib inflation; verify every original scanline byte against an independently constructed RGB grid from prescribed operators and geometry. Original per-file PNG SHA retained, without cross-JDK compressed-byte equality. No renderer, image utility or project command executed.','page-expectations':page_summaries,'complete-corpus-property-count':len(flattened),'visual-profiles':visual_profiles,'input-raster-observations':len(observations),'distinct-encoded-and-prescribed-raster-pairs':len(encoded_cache),'observations':observations,'difference-raster-boundary':'Comparator difference images retain original hashes and AE process findings. Their optimized grayscale/palette encoding need not match opaque RGB comparator inputs.'})

assert not errors
