from auditlib import *
src=obj(OUT/'frozen-source-contract-inspection.json');sections=[]
for entry in src['public-contract-methods']:
 path=REPO/entry['path'];lines=read(path).decode().splitlines();matches=[i for i,line in enumerate(lines) if re.search(r'64L? << 20|512L? << 20|64 \* 1024|512 \* 1024|[Xx]mp.{0,40}[Bb]ound|[Xx]mp.{0,40}[Ll]imit|[Xx]mp.{0,40}[Ll]arge',line)]
 for i in matches:
  start=max(0,i-8);end=min(len(lines),i+15);text='\n'.join(str(j+1)+': '+lines[j] for j in range(start,end));sections.append({'path':entry['path'],'start':start+1,'end':end,'text':text});print(entry['path'],text,sep='\n')
eq(bool(sections),True,'actual bounded XMP public test source located')
finish('public-xmp-boundary-inspection.json',{'sections':sections,'binding':'These exact public test sources were independently baseline-hash checked and occur in the actual 73-test command; the detailed source snippets are read-only protocol evidence, not a new full source review.'});assert not errors
