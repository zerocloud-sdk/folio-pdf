from auditlib import *
from collections import Counter
stage=obj(OUT/'frozen-stage-inspection.json');eq(stage['errors'],[],'closed stage proof');build=obj(REPO/'capabilities/evidence/T75-delivery/final-candidate-r4/build-inputs.json')
def ref(path):return {'path':str(path.relative_to(REPO)),'sha256':sha(path)}
expected_env=[];expected_certs=[]
for major in [8,11,17,21]:
 env=ROOT/f'jdk{major}-environment/environment.yaml';name=f'ubuntu-24.04-linux-x86-64-jdk{major}';expected_env.append({'profile':name,'record':ref(env)})
 for mode in ['IN_PROCESS','HARDENED_WORKER']:
  scope=ROOT/f'jdk{major}-{mode.lower()}';expected_certs.append({'obligation':'metadata','environment':name,'execution-profile':mode,'configuration':ref(scope/'execution.yaml'),'records':[ref(scope/(chain+'.yaml')) for chain in ['syntax','standards','semantic','visual']]})
index=obj(ROOT/'observed-index.json');eq(index,{'schema-version':1,'candidate':build['candidate'],'environments':expected_env,'certifications':expected_certs},'entire own observed index equals current stage and exactly reviewed8/32/environment/configuration references')
eq(obj(ROOT/'identities.json'),{'Candidate':stage['candidate-sha256'],'Contract':stage['contract-sha256']},'original current identity probe result')
finish('own-index-inspection.json',{'candidate-sha256':stage['candidate-sha256'],'contract-sha256':stage['contract-sha256'],'observed-index-sha256':sha(ROOT/'observed-index.json'),'identities-sha256':sha(ROOT/'identities.json'),'exact-environments':expected_env,'exact-certifications':expected_certs,'scope':'Only metadata own-index binding to the completed raw tuples. No authority, other obligation, outer command, inventory, or delivery assessment.'});assert not errors
