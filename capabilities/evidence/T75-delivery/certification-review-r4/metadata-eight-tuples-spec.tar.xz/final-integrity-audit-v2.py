from auditlib import *
from collections import Counter
scope=obj(OUT/'final-complete-scope-inspection.json');eq(scope['errors'],[],'complete raw8 own-index scope clean');eq(scope['finding-count'],0,'no scope findings')
prior={};catalog_sources=[]
for path in sorted(OUT.glob('*-automatic-input-catalog.json')):
 catalog_sources.append({'path':str(path),'sha256':sha(path)})
 for row in obj(path):
  key=row['path']
  if key in prior:eq(row['sha256'],prior[key]['sha256'],'unchanged exact input between completed phases '+key)
  prior[key]=row
for row in list(prior.values()):
 eq(sha(Path(row['path'])),row['sha256'],'final unmodified original input '+row['path'])
lineage=obj(OUT/'reader-lineage.json')
for row in lineage['sources']:eq(sha(Path(row['path'])),row['sha256'],'original inspected reader source lineage')
for name in ['stage-all-eight-audit.py','evidence-last-two-audit.py','reader-diagnostic-closures.json']:read(Path(lineage['original-reference-directory'])/name)
context=[Path('/home/ubuntu/.codex/attachments/77353239-0dda-4ee1-b4bb-ce7fb3fa0f9b/pasted-text-1.txt')]+[REPO/n for n in ['AGENTS.md','CONTRIBUTING.md','CONTEXT.md','docs/agents/issue-tracker.md','docs/agents/domain.md','docs/t11-certification.md','docs/foundation-readiness.md','capabilities/evidence/T11-metadata-outlines-destinations-attachments.md']]
for path in context:read(path)
eq(sha(context[0]),'794423d41161169ea6a4fee993553f777d6249cb05c5fe4d34f59657ab18f83f','originating Goal identity')
eq(read(OUT/'fixed-head-check.stdout.txt').decode().strip(),'5b1603c435f11c40368f75b7b9a2777c9c5e9761','fixed actual current HEAD');eq(read(OUT/'canonical-baseline-diff-check.stdout.txt'),b'','canonical baseline diff is empty; this is explicit uncommitted raw-evidence scope')
commands=[]
for path in sorted(OUT.glob('*.command.json')):
 label=path.name[:-len('.command.json')]
 if label=='final-integrity-check':continue
 command=obj(path);result=obj(OUT/(label+'.result.json'));read(OUT/(label+'.stdout.txt'));read(OUT/(label+'.stderr.txt'));code=result['actual_exit'];eq(code,2 if label=='boundary-source-navigation' else 0,'retained actual command result '+label);commands.append({'label':label,'command':command,'actual-result':result})
selected=set(context)
for major in [8,11,17,21]:
 selected.add(ROOT/f'jdk{major}-environment/environment.yaml')
 for suffix in ['', '-after']:selected.add(ROOT/f'jdk{major}-environment{suffix}/invocation.json')
 for mode in ['IN_PROCESS','HARDENED_WORKER']:
  base=ROOT/f'jdk{major}-{mode.lower()}'
  for name in ['execution.yaml','contract-tests.txt','contract-tests-command.json']:selected.add(base/name)
for name in ['observed-index.json','identities.json','candidate-probe.json','candidate-identity.txt']:selected.add(ROOT/name)
for chain in ['syntax','standards','semantic','visual']:
 selected.add(ROOT/'jdk8-in_process'/(chain+'.yaml'));selected.add(ROOT/'jdk8-in_process'/(chain+'-report.json'))
selected_rows=[]
for path in sorted(selected):
 data=read(path);rel=Path('selected-originals')/(path.relative_to(REPO) if path.is_relative_to(REPO) else Path('originating-goal.txt'));dest=OUT/rel;dest.parent.mkdir(parents=True,exist_ok=True)
 with dest.open('xb') as f:f.write(data)
 selected_rows.append({'source':str(path),'copy':str(rel),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
dump('selected-original-copies.json',selected_rows)
# Catalog every authoritative external and internal input read, preserving each exact original SHA.
all_inputs={**prior,**files};rows=[all_inputs[k] for k in sorted(all_inputs)];dump('input-catalog.json',rows)
finish('immutable-input-verification.json',{'scope':'Only the sealed authorized metadata raw8/own-index scope','prior-phase-catalogs':catalog_sources,'prior-distinct-inputs-rechecked':len(prior),'complete-input-count':len(rows),'complete-original-raw-inputs':sum(Path(k).is_relative_to(ROOT) for k in all_inputs),'selected-original-copies':len(selected_rows),'commands':commands,'closed-reader-diagnostics':[{'initial-command':'boundary-source-navigation','actual-exit':2,'cause':'Navigation guessed nonexistent build-tools acceptance paths.','closure-command':'boundary-source-navigation-corrected','closure-actual-exit':0,'original-source-inspection':'fixed-protocol-check','finding':False}],'discovery-boundary':'Initial stdin context/schema navigation retains command, full stdout/stderr and actual result. All decisive checks use retained named scripts; no conclusion depends on an unretained stdin program. Display limits never truncate the underlying original inputs or saved audit results.','historical-boundary':'No old live r3 raw tree is required or replayed; prior disclosed loss of two derived annotations summaries is unchanged, and no restoration is claimed.','prohibited-operations-executed':[],'outer-publication-approved':False});assert not errors
