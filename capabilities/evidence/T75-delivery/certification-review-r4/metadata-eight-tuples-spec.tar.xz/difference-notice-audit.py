from auditlib import *
from PIL import Image
from io import BytesIO
import struct,zlib
from collections import Counter
source=read(REPO/'pdf-acceptance/src/main/java/net/zerocloud/pdf/acceptance/StandardsEvidenceCommand.java').decode()
constant=source.split('private static final String PDFCPU_20_NOTICE =',1)[1].split(';',1)[0]
notice=''.join(json.loads(v) for v in re.findall(r'"(?:[^"\\]|\\.)*"',constant))
eq(notice.startswith('***************************** Disclaimer'),True,'actual retained PDFcpu 2.0 notice')
difference=[];positive=[];coverage=[]
white=bytes([255,255,255,255])*48000;red=bytes([255,0,0,255])+white[4:]
for major,mode in TUPLES:
 name=f'jdk{major}-{mode.lower()}';scope=ROOT/name;obs=scope/'observations';expected_png=set()
 for api in ['native','facade']:
  for product,page_count in [('edited',4),('merged',4),('left',2),('right',2)]:
   d=obs/(api+'-'+product);raw=read(d/'pdfcpu/findings.txt').decode();validation=raw.partition('\nValidation exit: ')[2];eq(validation.startswith('0\n'),True,str(d)+' actual positive exit');actual=validation[2:].partition('\nNegative control ')[0].strip()
   expected='validating(mode=strict) /workspace/'+str((d/'metadata.pdf').relative_to(REPO))+' ...\n\n'+notice+'\nvalidation ok';eq(actual,expected,str(d)+' entire original success output, exact notice only, no hidden finding');positive.append({'tuple':name,'product':api+'-'+product,'raw-sha256':sha(d/'pdfcpu/findings.txt'),'positive-text-sha256':lines_hash(actual),'notice-supplies-rule-coverage':False})
   for page in range(1,page_count+1):
    for suffix in ['expected','pdfium','implementation','difference','renderer-difference']:expected_png.add(d/f'page-{page}-{suffix}.png')
 neg=obs/'negative/visual';expected_png.add(neg/'one-pixel-control.png')
 for suffix in ['expected','pdfium','implementation','difference','renderer-difference']:expected_png.add(neg/f'page-1-{suffix}.png')
 actual_png={q for q in scope.rglob('*.png') if q.is_file()};eq(actual_png,expected_png,name+' complete actual PNG inventory: all comparator inputs and differences')
 for path in sorted(q for q in expected_png if q.name.endswith('-difference.png')):
  data=read(path);eq(data[:8],b'\x89PNG\r\n\x1a\n',str(path)+' signature');pos=8;kinds=[]
  while pos<len(data):
   n=int.from_bytes(data[pos:pos+4],'big');kind=data[pos+4:pos+8];payload=data[pos+8:pos+8+n];crc=int.from_bytes(data[pos+8+n:pos+12+n],'big');eq(zlib.crc32(kind+payload)&0xffffffff,crc,str(path)+' complete chunk CRC');kinds.append(kind.decode());pos+=n+12
   if kind==b'IEND':break
  eq(pos,len(data),str(path)+' exact PNG end');eq(kinds[0],'IHDR',str(path)+' first chunk');eq(kinds[-1],'IEND',str(path)+' final chunk');im=Image.open(BytesIO(data));eq(im.size,(240,200),str(path)+' prescribed dimensions');im.load();rgba=im.convert('RGBA').tobytes();is_control=path==neg/'page-1-difference.png';eq(rgba,red if is_control else white,str(path)+' every decoded RGBA byte');difference.append({'tuple':name,'path':str(path.relative_to(REPO)),'sha256':hashlib.sha256(data).hexdigest(),'original-mode':im.mode,'complete-decoded-rgba-sha256':hashlib.sha256(rgba).hexdigest(),'pixel-count':48000,'red-difference-pixels':1 if is_control else 0,'white-pixels':47999 if is_control else 48000,'opaque-alpha-pixels':48000,'negative-red-coordinate':[0,0] if is_control else None})
 coverage.append({'tuple':name,'all-original-png-files':len(actual_png),'RGB-input-files':76,'difference-RGBA-files':50})
finish('difference-and-notice-inspection.json',{'method':'All original difference PNG chunks/CRCs and complete RGBA bytes independently decoded read-only. Full raw positive pdfcpu stdout matched the exact pinned informational notice and exact product pathname; no notice counted as rule coverage. No renderer or product execution.','coverage':coverage,'complete-difference-observations':len(difference),'difference-observations':difference,'complete-positive-notice-observations':len(positive),'positive-observations':positive});assert not errors
