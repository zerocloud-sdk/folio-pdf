from auditlib import *
import subprocess,copy,datetime
BASE='5b1603c435f11c40368f75b7b9a2777c9c5e9761'
P='T11-metadata-outlines-destinations-attachments'
goal=Path('/home/ubuntu/.codex/attachments/77353239-0dda-4ee1-b4bb-ce7fb3fa0f9b/pasted-text-1.txt');eq(sha(goal),'794423d41161169ea6a4fee993553f777d6249cb05c5fe4d34f59657ab18f83f','original full Goal identity')
paths=set([REPO/'docs/t11-certification.md',REPO/'docs/metadata-navigation.md',REPO/'capabilities/evidence/T11-metadata-outlines-destinations-attachments.md',REPO/'capabilities/expected/T11-standards-findings.json',REPO/'scripts/t11-arlington-pin.properties',REPO/'build-tools/acceptance/arlington/t11-r1.patch',REPO/'pdf-document/src/test/java/net/zerocloud/pdf/consumer/DocumentMetadataWorkflowTest.java',REPO/'pdf-migration-itext7/src/test/java/net/zerocloud/pdf/itext7/consumer/DocumentMetadataFacadeTest.java'])
for d in ['capabilities/profiles/T11-metadata','capabilities/profiles/T11-standards']:
 paths.update(p for p in (REPO/d).rglob('*') if p.is_file())
paths.update((REPO/'pdf-acceptance/src').rglob('T11*.java'))
baselines=[]
for p in sorted(paths):
 relative=p.relative_to(REPO).as_posix();cmd=['git','show',BASE+':'+relative];r=subprocess.run(cmd,cwd=REPO,stdout=subprocess.PIPE,stderr=subprocess.PIPE);h=hashlib.sha256(r.stdout).hexdigest();eq(r.returncode,0,'read-only baseline '+relative);eq(sha(p),h,'existing T11 unchanged from fixed baseline '+relative);out=OUT/'baseline-source-copies'/relative;out.parent.mkdir(parents=True,exist_ok=True);
 with out.open('xb') as retained:retained.write(r.stdout);baselines.append({'command':cmd,'returncode':r.returncode,'stderr':r.stderr.decode(),'source':relative,'baseline-sha256':h,'current-sha256':sha(p),'baseline-copy':str(out.relative_to(OUT))})
C=REPO/'capabilities/profiles/T11-standards';assign=obj(C/'assignments.json');controls=obj(C/'controls.json');findings=obj(REPO/'capabilities/expected/T11-standards-findings.json');required=read(C/'required-rules.txt').decode().splitlines();eq(set(assign),set(required),'complete rule assignments');eq(set(controls),set(findings),'104 metadata controls and frozen exact diagnostics');groups=[]
for group,count in [('pdfcpu',31),('arlington-core',35),('arlington-metadata',104)]:
 p=props(C/(group+'.properties'));rules=p['required-rules'].split(',');eq(len(rules),count,'exact assigned count '+group);eq(p['covered-rules'],p['required-rules'],'no unqualified rule '+group);eq(len(set(rules)),count,'no duplicate rules '+group)
 if group=='arlington-metadata':eq(set(rules),set(controls),'complete 104 metadata controls')
 for rule in rules:
  a=assign[rule];eq(a['checker'],'pdfcpu' if group=='pdfcpu' else 'arlington','assigned independent checker '+rule)
  for field in ['path','sha256','finding']:eq(p['negative.'+rule+'.'+field],a[field],'profile assignment identity '+rule+'/'+field)
  eq(sha(C/a['path']),a['sha256'],'original source control '+rule)
  if rule in controls:
   eq({k:a[k] for k in controls[rule]},controls[rule],'metadata source assignment '+rule);eq(a['finding'],findings[rule],'frozen expected diagnostic '+rule)
 groups.append({'checker':group,'rule-count':count,'profile-sha256':sha(C/(group+'.properties'))})
corpus=obj(REPO/'capabilities/profiles/T11-metadata/corpus.json');dest=lambda p,s,params:dict(page=p,style=s,parameters=params)
base={'b':dest(1,'FIT_B',[]),'bh':dest(2,'FIT_BH',[None]),'bv':dest(3,'FIT_BV',[12]),'fit':dest(1,'FIT',[]),'h':dest(2,'FIT_H',[None]),'r':dest(1,'FIT_R',[1,2,80,90]),'shared':dest(2,'FIT',[]),'v':dest(3,'FIT_V',[None]),'xyz':dest(3,'XYZ',[None,90,1.25]),'z':dest(1,'FIT',[]),'za':dest(2,'FIT',[])}
merged=copy.deepcopy(base);merged['shared-1']=dest(4,'FIT',[]);edited=copy.deepcopy(base)
for v in edited.values():v['page']={1:2,2:3,3:1}[v['page']]
edited['xyz']=dest(1,'XYZ',[10,None,2]);left={k:copy.deepcopy(v) for k,v in merged.items() if v['page']<=2};right={k:dict(v,page=v['page']-2) for k,v in merged.items() if v['page']>=3}
item=lambda title,named=None,target=None,children=None:dict(title=title,named=named,destination=target,children=[] if children is None else children)
sections=lambda title,page:item(title,children=[item('Named B',named='shared'),item('Rectangle A',target=dest(page,'FIT_R',[1,2,80,90]))])
outline={'edited':[sections('Edited sections',2),item('Explicit C',target=dest(1,'XYZ',[10,None,2]))],'merged':[sections('Sections',1),item('Explicit C',target=dest(3,'XYZ',[None,90,1.25])),item('Appendix named',named='shared-1')],'left':[sections('Sections',1)],'right':[item('Explicit C',target=dest(1,'XYZ',[None,90,1.25])),item('Appendix named',named='shared-1')]}
def attachment(name,b,mime,description,relationship):return dict(name=name,hex=b.hex(),size=len(b),md5=hashlib.md5(b).hexdigest(),sha256=hashlib.sha256(b).hexdigest(),mime=mime,description=description,relationship=relationship)
secondary=attachment('secondary.bin',b'\0\1\xff','application/octet-stream','Secondary payload','Unspecified');standard=[attachment('payload.txt',b'abc','text/plain','Primary payload','Data'),attachment('payload.txt-1',b'hello\n','text/plain','Appendix payload','Supplement'),secondary];changed=[attachment('payload.txt',b'abc\0','application/octet-stream','Edited payload','Source'),secondary]
xmp='<x:xmpmeta xmlns:x="adobe:ns:meta/">\n<rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n<rdf:Description rdf:about="" xmlns:u="urn:folio:t73:unknown" u:opaque="keep"><u:value>{}</u:value></rdf:Description>\n</rdf:RDF>\n</x:xmpmeta>\n'
for product,destinations in [('edited',edited),('merged',merged),('left',left),('right',right)]:
 v=corpus['products'][product];eq(v['destinations'],destinations,'all eight destination styles nullable operands and page transforms '+product);eq(v['destination-order'],sorted(destinations,key=lambda k:k.encode('ascii')),'unsigned encoded name order '+product);eq(v['outlines'],outline[product],'complete ordered outline, named collision and pruning '+product);eq(v['attachments'],changed if product=='edited' else standard,'all detached payload bytes and metadata '+product);eq(v['info'],{'Custom':'Edited info','T73Keep':'Preserved info','Title':'Changed title'} if product=='edited' else {'Author':'Source author','Subject':'Appendix subject','T73Keep':'Preserved info','Title':'Source title'},'exact Info preserve/remove/fill '+product);eq(v['xmp'],xmp.format('edited' if product=='edited' else 'primary'),'exact XMP and unknown RDF '+product);eq([v['catalog-flag'],v['catalog-numbers'],v['xmp-marker']],[True,[1,2],'stream marker'],'unknown detached catalog and stream entries '+product)
methods=[]
for p in paths:
 if p.name in ['DocumentMetadataWorkflowTest.java','DocumentMetadataFacadeTest.java']:
  s=read(p).decode();catalog=re.findall(r'@Test(?:\([^)]*\))?\s+public void (\w+)\s*\(',s);eq(len(catalog),62 if p.name=='DocumentMetadataWorkflowTest.java' else 9,'actual current public source method coverage');eq('@Ignore' in s or 'Assume.' in s,False,'no hidden skip '+p.name);methods.append({'path':str(p.relative_to(REPO)),'sha256':sha(p),'count':len(catalog),'methods':catalog})

eq(len(baselines),155,'exact existing T11 frozen-source scope count')
finish('source-contract-inspection.json',{'baseline':BASE,'existing-T11-files-compared':len(baselines),'baseline-observations':baselines,'independent-checker-assignment-groups':groups,'original-corpus-complete-contract-values-checked':True,'public-contract-methods':methods,'boundary':'Exact frozen T11 source/contract continuity and independently prescribed corpus transformations only. No product execution, previous raw replay, or five-file inventory correction review.'})
assert not errors
