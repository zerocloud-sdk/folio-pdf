from auditlib import *
from PIL import Image
from io import BytesIO
from collections import Counter
sources={
'docs/t11-certification.md':[(90,120)],
'pdf-acceptance/src/main/java/net/zerocloud/pdf/acceptance/T11XmlSafetyProbe.java':[(229,273),(310,335)],
'pdf-acceptance/src/main/java/net/zerocloud/pdf/T11WorkerSafetyObserver.java':[(16,47)],
'pdf-acceptance/src/main/java/net/zerocloud/pdf/acceptance/StandardsEvidenceCommand.java':[(17,33),(210,230)],
'pdf-document/src/main/java/net/zerocloud/pdf/HardenedWorkerEngine.java':[(1040,1100)],
'pdf-document/src/main/java/net/zerocloud/pdf/HardenedWorkerMain.java':[(1565,1595)]}
for name,ranges in sources.items():
 lines=read(REPO/name).decode().splitlines();print('SOURCE',name,'SHA',sha(REPO/name))
 for start,end in ranges:print('\n'.join(str(i+1)+': '+lines[i] for i in range(start-1,min(end,len(lines)))))
base=ROOT/'jdk8-in_process/observations'
for sub in ['native-edited/page-1-difference.png','native-edited/page-1-renderer-difference.png','negative/visual/page-1-difference.png','negative/visual/page-1-renderer-difference.png']:
 data=read(base/sub);im=Image.open(BytesIO(data));im.load();print('PNG',sub,im.mode,im.size,Counter(im.convert('RGBA').getdata()))
raw=read(base/'native-edited/pdfcpu/findings.txt').decode();positive=raw.partition('\nValidation exit: ')[2][2:].partition('\nNegative control ')[0].strip();print('PDFCPU POSITIVE',repr(positive))
finish('protocol-originals-inspection.json',{'source-paths':list(sources),'diagnostic-closure':'The initial navigation command guessed nonexistent build-tools paths and returned 2. Actual paths were discovered with rg --files; the corrected navigation and this original-byte inspection succeed. No product or specification finding.'});assert not errors
