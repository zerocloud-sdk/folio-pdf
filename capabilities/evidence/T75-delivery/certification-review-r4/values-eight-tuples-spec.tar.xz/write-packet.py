from pathlib import Path
import json,hashlib,datetime
out=Path(__file__).parent;repo=Path('/home/ubuntu/IdeaProjects/open-pdf')
def obj(n):return json.loads((out/n).read_bytes())
def identity(p):
 b=p.read_bytes();return {'path':str(p),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def put(n,v):
 with (out/n).open('x') as f:f.write(v if isinstance(v,str) else json.dumps(v,ensure_ascii=False,indent=2)+'\n')
final=obj('final-input-inspection.json');assert final['errors']==[] and obj('final-input-check.result.json')['actual_exit']==0
stage=obj('stage-environment-contract-inspection-closed.json');evidence=obj('values-evidence-inspection.json');index=obj('complete-config-and-index-inspection.json');raw=obj('raw-preservation-inspection.json');png=obj('complete-png-union-inspection.json');public=obj('public-contract-inspection.json')
for data in [stage,evidence,index,raw,png,public]:assert data['errors']==[]
report='''No findings in the completed r4 values/T09 raw evidence and its own observed index. All eight raw tuples and their 32 chain records are closed within this scope. Actual outer success, authority publication, prerequisite publication and final delivery remain deferred to separate reviews, regardless of subsequent process completion.

This implements the Goal requirement to “refresh previously certified obligations invalidated by that candidate” under the existing T09 contract (`docs/t09-certification.md:12–61`), without adding functionality or imposing T13 producer-manifest requirements.

Fixed baseline and observed HEAD are `5b1603c435f11c40368f75b7b9a2777c9c5e9761`. The canonical baseline-to-HEAD diff is empty; the explicitly authorized review target is new precommit evidence. Candidate `ab18cc9c0473730a6aabec5d12e3172f22bea23a0a0f9529052a2bc186cbfc1b` and contract `3de508f79fcbef7258feee8abc013d6f02b000840cac1cb263cb0d6f927b8f2b` reconstruct correctly. All 1,933 source inputs, 30 contracts, 23 artifacts and 24 harness inputs match the current stage and frozen validation inputs. The already reviewed five-file inventory increment is correctly distinguished from r3.

Each Ubuntu 24.04/Linux x86-64 JDK 8/11/17/21 Native profile retains an actual 83-test transcript: 50 Native, 31 public Stable Facade and two artifact contracts, with no ignored tests. Exact commands, configurations, classpaths, immutable images, observed JDK builds, tool identities and all BEFORE/AFTER observations agree. Facade execution remains actual IN_PROCESS. Public observer bindings cover reopened values, receipts, ownership, bounds, stable failures and preserved Source bytes.

Each tuple contains 413 files, 399 observations and 463 report references; complete paths and hashes validate. All 51 rules (23 pdfcpu, 28 Arlington) qualify across 24 products with 1,224 actual illegal controls. Separate syntax, semantic and visual negatives fail correctly. Forty retained qpdf JSON observations prove final effective raw stream preservation; the incremental re-encoding control preserves the old prefix and decoded bytes but fails raw preservation. All 208 original PNGs plus the canonical golden were completely verified: 129 RGB inputs and 80 comparator rasters, including exact one-pixel defects.

Final inspection verifies 6,078 original input identities, including all 3,393 current values files. One reader-only Java pathname typo is preserved with its separate successful correction. No product execution, repository mutation or completion approval occurred.
'''
assert len(report.split())<400
put('report.md',report)
selected=[]
for p,name in [(Path('/home/ubuntu/.codex/attachments/77353239-0dda-4ee1-b4bb-ce7fb3fa0f9b/pasted-text-1.txt'),'goal.txt'),(repo/'AGENTS.md','AGENTS.md'),(repo/'CONTRIBUTING.md','CONTRIBUTING.md'),(repo/'docs/t09-certification.md','t09-certification.md'),(repo/'capabilities/evidence/T09-document-value-inspection-patch.md','T09-document-value-inspection-patch.md')]:
 d=out/'selected-originals'/name;d.parent.mkdir(exist_ok=True)
 with d.open('xb') as f:f.write(p.read_bytes())
 selected.append({'original':identity(p),'selected-copy':str(d.relative_to(out)),'copy-sha256':identity(d)['sha256']})
put('selected-copy-identities.json',selected)
commands=[]
for p in sorted(out.glob('*.command.json')):
 label=p.name[:-len('.command.json')];r=out/(label+'.result.json')
 assert r.exists(),label
 commands.append({'label':label,'command':identity(p),'stdout':identity(out/(label+'.stdout.txt')),'stderr':identity(out/(label+'.stderr.txt')),'actual-result':identity(r),'actual-exit':json.loads(r.read_bytes())['actual_exit']})
put('scope.json',{'scope':'Independent raw-only Spec review of current r4 values eight tuples and own observed-index; no source rewrite or product replay','fixed-baseline':'5b1603c435f11c40368f75b7b9a2777c9c5e9761','canonical-diff-command':'git diff 5b1603c435f11c40368f75b7b9a2777c9c5e9761...HEAD','commit-list-command':'git log 5b1603c435f11c40368f75b7b9a2777c9c5e9761..HEAD --oneline','canonical-diff-and-commit-list-empty':True,'explicit-working-tree-adaptation':'The parent assigned current newly collected values evidence, not an empty code diff. Full source Standards/Spec and five-file increment reviews were already closed.','candidate-sha256':stage['candidate-sha256'],'contract-sha256':stage['contract-sha256'],'writes':'Only this exclusive /tmp packet','historical-scope':'Reference reader source only; no r3 raw replay, recovery claim, or historical/publication approval','actual-outer-and-publication':'Outside this raw-only packet even when the process subsequently completes'})
put('receipt.json',{'created-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'review-axis':'Spec','finding-count':0,'review-result':'CLOSED: all eight current values raw tuples and own-index only','report-word-count':len(report.split()),'report':identity(out/'report.md'),'scope':identity(out/'scope.json'),'candidate-sha256':stage['candidate-sha256'],'contract-sha256':stage['contract-sha256'],'stage-input-counts':stage['input-counts'],'formal-observation-counts':{'tuples':8,'tests-per-tuple':83,'native-tests-per-tuple':50,'facade-tests-per-tuple':31,'actual-artifact-tests-per-tuple':2,'ignored-tests':0},'records':32,'report-reference-count-per-tuple':463,'qualified-rules':51,'qualified-rule-controls':1224,'positive-products':24,'raw-qpdf-observations':40,'all-png-observations':209,'complete-raw-tree-file-count':3393,'complete-original-input-file-count':6078,'input-catalog':identity(out/'input-catalog.json'),'raw-tree-input-catalog':identity(out/'raw-tree-input-catalog.json'),'closed-inspections':[identity(out/n) for n in final['closed-inspections']+['final-input-inspection.json']],'recorded-check-commands':commands,'diagnostic-closure':stage['original-reader-only-diagnostic'],'selected-originals':selected,'tool-display-boundary':final['display-boundary'],'deferred':['Actual outer-process result','Published authority and prior-authority compare/replace','Current prerequisite publication','Other obligations and all-48 certification','Inventory/readiness and final delivery approval'],'sealing':{'manifest':'artifact-manifest.json','manifest-excludes':'Only artifact-manifest.json itself; generated after all substantive recorded audit commands complete','no-full-raw-or-build-output-copies':True,'complete-input-catalog-and-selected-originals-retained':True}})
print('Raw-only report and receipt written; words='+str(len(report.split())))
