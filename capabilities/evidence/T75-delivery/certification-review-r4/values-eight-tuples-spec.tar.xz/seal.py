from pathlib import Path
import hashlib,json,sys
out=Path(__file__).parent
assert json.loads((out/'packet-finish.result.json').read_bytes())['actual_exit']==0
assert json.loads((out/'receipt.json').read_bytes())['finding-count']==0
assert not (out/'artifact-manifest.json').exists()
rows=[]
for p in sorted(out.rglob('*')):
 if not p.is_file():continue
 assert not p.is_symlink()
 b=p.read_bytes();rows.append({'path':str(p.relative_to(out)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
manifest={'schema-version':1,'scope':'Sealed independent r4 values raw-only Spec packet','excludes':['artifact-manifest.json'],'file-count-excluding-manifest':len(rows),'files':rows}
with (out/'artifact-manifest.json').open('x') as f:f.write(json.dumps(manifest,indent=2)+'\n')
assert len([p for p in out.rglob('*') if p.is_file()])==len(rows)+1
for name in ['report.md','receipt.json','input-catalog.json','raw-tree-input-catalog.json','artifact-manifest.json']:
 print(name,hashlib.sha256((out/name).read_bytes()).hexdigest())
print('files',len(rows)+1,'manifest-members',len(rows),'original-inputs',6078,'raw-values-inputs',3393)
