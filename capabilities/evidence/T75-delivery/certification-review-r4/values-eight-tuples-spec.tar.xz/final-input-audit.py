from auditlib import *
import datetime,sys
expected={};reviewreads={}
for c in sorted(OUT.glob('*-automatic-input-catalog.json')):
 for r in json.loads(c.read_bytes()):
  p=Path(r['path']);target=reviewreads if p.is_relative_to(OUT) else expected
  if str(p) in target:eq(target[str(p)]['sha256'],r['sha256'],'unchanged identity across independently recorded reads '+str(p))
  target[str(p)]=r
selected=[Path('/home/ubuntu/.codex/attachments/77353239-0dda-4ee1-b4bb-ce7fb3fa0f9b/pasted-text-1.txt'),Path('/home/ubuntu/.codex/skills/code-review/SKILL.md')]
selected += [REPO/n for n in ['AGENTS.md','CONTRIBUTING.md','CONTEXT.md','docs/agents/domain.md','docs/agents/issue-tracker.md','docs/t09-certification.md','docs/document-values.md','capabilities/evidence/T09-document-value-inspection-patch.md','capabilities/profiles/T09-standards/README.md','capabilities/profiles/T09-values-visual.properties','scripts/qpdf-pin.properties','capabilities/evidence/T75-delivery/final-candidate-r4/README.md','capabilities/evidence/T75-delivery/final-candidate-r4/freeze.json','capabilities/evidence/T75-delivery/final-candidate-r4/build-inputs.json','capabilities/evidence/T75-delivery/final-validation-r4/README.md','capabilities/evidence/T75-delivery/inventory-read-bound/README.md']]
old=Path('/tmp/t75-final-spec-values-eight-64rr4_uc')
selected += [old/n for n in ['auditlib.py','evidence-audit.py','complete-config-audit.py','raster-audit.py','raw-reader-pin-field-closure.json','scope.json','stage-audit.py','raw-preservation-closure-audit.py','source-contract-audit.py','report.md']]
selected += [Path(sys.executable).resolve()]
originals=[]
for p in sorted(set(Path(p) for p in expected)|set(selected)|set(p for p in ROOT.rglob('*') if p.is_file())):
 b=read(p);row={'path':str(p),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
 if str(p) in expected:eq(row['sha256'],expected[str(p)]['sha256'],'final unchanged original input '+str(p))
 originals.append(row)
for p,r in reviewreads.items():eq(sha(Path(p)),r['sha256'],'immutable prior independent inspection artifact '+p)
raw=[r for r in originals if Path(r['path']).is_relative_to(ROOT)]
eq(any(p.is_symlink() for p in ROOT.rglob('*')),False,'entire current values tree no symlinks')
inspections=['stage-environment-contract-inspection-closed.json','values-evidence-inspection.json','complete-config-and-index-inspection.json','raw-preservation-inspection.json','complete-rgb-raster-inspection.json','complete-png-union-inspection.json','public-contract-inspection.json']
for n in inspections:eq(obj(OUT/n)['errors'],[],'closed substantive inspection '+n)
commands=['stage-path-closure-check','evidence-check','config-index-check','raw-stream-check','rgb-check','difference-raster-check','public-contract-check']
for n in commands:eq(obj(OUT/(n+'.result.json'))['actual_exit'],0,'actual independent reader exit '+n)
rawrows=[{'path':str(Path(r['path']).relative_to(REPO)),'sha256':r['sha256'],'bytes':r['bytes']} for r in raw]
dump('raw-tree-input-catalog.json',{'scope':'Current r4 values tree only, no outer result or published authority','file-count':len(rawrows),'files':rawrows})
dump('input-catalog.json',{'scope':'Every original input whose content was read by the bounded raw review, plus complete current values tree. Source/artifact/tool inputs are hashed, not copied wholesale. Navigation-only names are not claims of content review. Derived reviewer input artifacts are independently covered by the final artifact manifest.','original-input-file-count':len(originals),'current-values-original-file-count':len(rawrows),'files':originals})
finish('final-input-inspection.json',{'completed-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reviewer-python':sys.version,'original-input-file-count':len(originals),'raw-values-file-count':len(rawrows),'all-original-inputs-unchanged':True,'closed-inspections':inspections,'actual-successful-reader-commands':commands,'reader-diagnostic-closure':'Original stage reader checked three expected source paths with an omitted /tools/ segment. Its actual exit 1 and sole diagnostic are unchanged; the separate exact path closure exited 0 without replaying stage or certification.','display-boundary':'The first broad rg filename navigation produced a large retained stdout; tool display was truncated. Later inspection used bounded exact inputs. Complete saved logs and catalogs remain intact. This is no evidence or scope finding.','deferred':'Actual outer result and authority publication, prior obligations/publication, readiness and final delivery remain outside this raw-only packet.'})
assert not errors
