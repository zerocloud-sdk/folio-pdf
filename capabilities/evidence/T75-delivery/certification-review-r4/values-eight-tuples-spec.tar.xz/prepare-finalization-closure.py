from pathlib import Path
out=Path(__file__).parent
original=(out/'write-packet.py').read_text()
prefix=original.split("report='''",1)[0]
prefix += "report=(out/'report.md').read_text()\nselected=obj('selected-copy-identities.json')\nassert obj('packet-write.result.json')['actual_exit']==1\nassert 'AssertionError: packet-write' in (out/'packet-write.stderr.txt').read_text()\nput('finalization-closure.json',{'classification':'Packet writer enumerated its own still-running wrapper command before that wrapper could save its result; it stopped after writing the valid raw report and selected copies. No substantive input audit failed and no repository input changed.','original-command':identity(out/'packet-write.command.json'),'original-script':identity(out/'write-packet.py'),'original-actual-result':identity(out/'packet-write.result.json'),'original-stderr':identity(out/'packet-write.stderr.txt'),'correction':'Reuse and verify the already written report/copies; collect only completed command results, explicitly deferring this finalizer own envelope to the artifact manifest. No output is overwritten.'})\n"
tail=original.split('commands=[]',1)[1]
needle="label=p.name[:-len('.command.json')];r=out/(label+'.result.json')\n assert r.exists(),label"
assert tail.count(needle)==1
tail=tail.replace(needle,"label=p.name[:-len('.command.json')];r=out/(label+'.result.json')\n if label=='packet-finish':\n  assert not r.exists(), 'current wrapper should still be running'\n  continue\n assert r.exists(),label")
needle="'diagnostic-closure':stage['original-reader-only-diagnostic'],"
assert tail.count(needle)==1
tail=tail.replace(needle,"'diagnostic-closure':stage['original-reader-only-diagnostic'],'packet-finalization-closure':identity(out/'finalization-closure.json'),'command-catalog-boundary':'Completed commands at receipt creation; packet-finish own command/stdout/stderr/actual result are retained later and included in the artifact manifest.',")
with (out/'finish-packet.py').open('x') as f:f.write(prefix+'commands=[]'+tail)
print('Prepared separate finalizer closure; original failed writer retained')
