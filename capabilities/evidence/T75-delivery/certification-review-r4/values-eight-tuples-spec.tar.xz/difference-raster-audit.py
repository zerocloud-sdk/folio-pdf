from auditlib import *
from PIL import Image
import PIL,io
inputs=obj(OUT/'complete-rgb-raster-inspection.json');eq(inputs['errors'],[],'complete independent opaque RGB input inspection')
width,height=1224,1584;white=b'\xff'*(width*height*3);red=b'\xff\x00\x00'+white[3:];observations=[];cache={}
for major,mode in TUPLES:
 obs=ROOT/('jdk'+str(major)+'-'+mode.lower())/'observations'
 for edition in ['source','native-rewrite','native-incremental','facade','negative']:
  for name in ['difference','renderer-difference']:
   p=obs/edition/('T09-values-'+name+'.png');data=read(p);h=hashlib.sha256(data).hexdigest();one=edition=='negative' and name=='difference';key=(h,one)
   if key not in cache:
    with Image.open(io.BytesIO(data)) as im:im.verify()
    with Image.open(io.BytesIO(data)) as im:
     im.load();eq(im.size,(width,height),str(p)+' complete image bounds');eq(im.format,'PNG',str(p)+' actual PNG format');rgb=im.convert('RGB').tobytes();alpha=im.convert('RGBA').getchannel('A').tobytes();eq(alpha==b'\xff'*(width*height),True,str(p)+' every decoded pixel opaque');eq(rgb==(red if one else white),True,str(p)+' exact entire RGB difference; one red pixel only in negative primary comparator');cache[key]={'original-mode':im.mode,'pixel-count':width*height,'decoded-rgb-sha256':hashlib.sha256(rgb).hexdigest(),'nonwhite-pixels':1 if one else 0,'red-pixel':{'x':0,'y':0} if one else None}
   observations.append({'path':str(p.relative_to(REPO)),'sha256':h,**cache[key]})
observed={str(REPO/o['path']) for o in inputs['observations']}|{str(REPO/o['path']) for o in observations};actual={str(p) for p in ROOT.rglob('*.png')}|{str(REPO/'capabilities/expected/T09-values-144dpi-srgb.png')};eq(observed,actual,'all original PNG paths fully decoded and inspected exactly once by union');eq(len(observations),80,'complete original comparator rasters');eq(len(observed),209,'complete 208 actual raw PNGs plus canonical golden')
finish('complete-png-union-inspection.json',{'method':'Independent complete RGB input row verification (129) plus full original comparator PNG decode to exact RGB/opaque alpha (80); every file SHA verified, no images changed or tools replayed.','pillow-version':PIL.__version__,'all-png-count':len(observed),'original-raw-png-count':len(observed)-1,'full-input-png-count':len(inputs['observations']),'full-difference-png-count':len(observations),'difference-raster-observations':observations})
assert not errors
