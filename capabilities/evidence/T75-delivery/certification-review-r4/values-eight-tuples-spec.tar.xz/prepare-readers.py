from pathlib import Path
import hashlib,json
out=Path(__file__).parent
old=Path('/tmp/t75-final-spec-values-eight-64rr4_uc')
def put(n,b):
 with (out/n).open('xb') as f:f.write(b if isinstance(b,bytes) else b.encode())
lib=(old/'auditlib.py').read_text()
assert lib.count("ROOT=REPO/'capabilities/evidence/T75-foundation-20260913-r3/values'")==1
lib=lib.replace("ROOT=REPO/'capabilities/evidence/T75-foundation-20260913-r3/values'","ROOT=REPO/'capabilities/evidence/T75-foundation-20260914-r4/values'")
lib=lib.replace("def dump(name,value):(OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\\n')","def dump(name,value):\n with (OUT/name).open('x') as f:f.write(json.dumps(value,ensure_ascii=False,indent=2)+'\\n')")
lib += "\nimport atexit,sys\n@atexit.register\ndef save_reads():\n dump(Path(sys.argv[0]).stem+'-automatic-input-catalog.json',list(files.values()))\n"
put('auditlib.py',lib)
for name in ['evidence-audit.py','raster-audit.py','raw-preservation-closure-audit.py']:put(name,(old/name).read_bytes())
s=(old/'complete-config-audit.py').read_text()
assert s.count("final-candidate-r3/build-inputs.json")==1
s=s.replace("final-candidate-r3/build-inputs.json","final-candidate-r4/build-inputs.json")
s=s.split("prior=Path('/tmp/t75-final-spec-transactions-eight-5yptf21z');",1)[0]
s += "finish('complete-config-and-index-inspection.json',{'actual-complete-command-observations':commandobservations,'exact-observed-certifications':len(expectedcerts),'exact-observed-chain-records':sum(len(c['records']) for c in expectedcerts),'observed-index-sha256':sha(ROOT/'observed-index.json'),'publication-conclusion':'Actual outer result, authority publication, transactions prerequisite and final delivery are outside this raw-only packet','other-obligations-approved':False})\n"
put('config-index-audit.py',s)
put('reader-lineage.json',json.dumps({'reference-directory':str(old),'reference-sources':[{'path':str(old/n),'sha256':hashlib.sha256((old/n).read_bytes()).hexdigest()} for n in ['auditlib.py','evidence-audit.py','raster-audit.py','raw-preservation-closure-audit.py','complete-config-audit.py','stage-audit.py','source-contract-audit.py']],'adaptation':'Current schema and real fields inspected before preparation. Evidence, full RGB and corrected raw-preservation logic retained verbatim; library targets only r4 values and refuses overwrite; configuration reader targets r4 build and deliberately removes all prior/publication work. Stage/current source binding gets a separate independent reader. No timestamps, rule names or tool field names globally rewritten.'},indent=2)+'\n')
print('prepared bounded readers')
