from auditlib import *
import ast,yaml,datetime
stage=REPO/'capabilities/evidence/T75-delivery/final-candidate-r4';build=obj(stage/'build-inputs.json');candidate=build['candidate'];contracts=build['contract-inputs'];freeze=obj(stage/'freeze.json');validation=obj(REPO/'capabilities/evidence/T75-delivery/final-validation-r4/source-and-contract-inputs.json')
eq({'inputs':candidate['inputs'],'contract-inputs':contracts},validation,'exact complete validated source/contract set')
counts={}
for label,rows in {'sources':candidate['inputs'],'contracts':contracts,'artifacts':candidate['artifacts'],'harness':build['harness']}.items():
 counts[label]=len(rows);eq(len({r['path'] for r in rows}),len(rows),label+' unique names')
 for r in rows:
  name=PurePosixPath(r['path']);eq(name.is_absolute() or '..' in name.parts,False,label+' canonical path');eq(sha(REPO/r['path']),r['sha256'],label+' original current bytes '+r['path'])
eq(counts,{'sources':1933,'contracts':30,'artifacts':23,'harness':24},'frozen complete inventory counts')
eq(sha(stage/'build-inputs.json'),'64cb458acef6c0e98aa5b0dbf8023d85fe569fa2269eb6c3c343959779325e02','actual r4 stage SHA');eq(sha(stage/'build-command.json'),freeze['build-command-sha256'],'frozen build invocation');eq(read(stage/'build-inputs.json'),read(REPO/'target/foundation-0.1.0/build-inputs.json'),'live staged input file');eq(read(stage/'build-command.json'),read(REPO/'target/foundation-0.1.0/build-command.json'),'live staged command file');eq(obj(stage/'t75-final-stage-r4-result.json')['returncode'],0,'original actual stage exit');eq(freeze['actual-stage-result'],obj(stage/'t75-final-stage-r4-result.json'),'original stage receipt')
canonical=lambda kind,rows:''.join(kind+' '+r['path']+' '+r['sha256']+'\n' for r in sorted(rows,key=lambda r:r['path']))
cid=lines_hash('release '+candidate['release']+'\n'+canonical('input',candidate['inputs'])+canonical('artifact',candidate['artifacts']));tid=lines_hash(canonical('contract',contracts))
eq(cid,'ab18cc9c0473730a6aabec5d12e3172f22bea23a0a0f9529052a2bc186cbfc1b','independently reconstructed current candidate');eq(tid,'3de508f79fcbef7258feee8abc013d6f02b000840cac1cb263cb0d6f927b8f2b','independently reconstructed current contract');eq(obj(ROOT/'candidate-probe.json'),{'schema-version':1,'candidate':candidate,'environments':[],'certifications':[]},'actual provisional candidate probe')
log=read(ROOT/'candidate-identity.txt').decode();eq(re.findall(r'^Candidate identity: ([a-f0-9]+)$',log,re.M),[cid],'actual candidate identity output');eq(re.findall(r'^Contract identity: ([a-f0-9]+)$',log,re.M),[tid],'actual contract identity output')
old=obj(REPO/'capabilities/evidence/T75-delivery/final-candidate-r3/build-inputs.json');oldsrc={r['path']:r['sha256'] for r in old['candidate']['inputs']};current={r['path']:r['sha256'] for r in candidate['inputs']};eq(set(oldsrc),set(current),'same bounded source path set');changed=sorted(k for k in current if oldsrc.get(k)!=current[k]);eq(changed,sorted(['PROVENANCE.md','build-tools/inventory/src/main/java/net/zerocloud/pdf/inventory/FoundationEvidence.java','build-tools/inventory/src/main/java/net/zerocloud/pdf/inventory/InventoryYaml.java','build-tools/inventory/src/test/java/net/zerocloud/pdf/inventory/FoundationReadinessCommandTest.java','docs/foundation-readiness.md']),'exact independently closed five-file increment');eq(old['contract-inputs'],contracts,'r3 to r4 unchanged T09/all contract bytes')
for name in ['README.md','standards-review-report.md','spec-review-report.md','diagnosis-and-validation-receipt.json']:
 read(REPO/'capabilities/evidence/T75-delivery/inventory-read-bound'/name)
source=read(REPO/'scripts/t03-foundation.py').decode();tree=ast.parse(source)
literalcase=next(n.value for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='CERTIFICATION_CASES' for t in n.targets));case_node=next(v for k,v in zip(literalcase.keys,literalcase.values) if ast.literal_eval(k)=='values');case={ast.literal_eval(k):ast.literal_eval(v) for k,v in zip(case_node.keys,case_node.values) if ast.literal_eval(k)!='test-classes'}
fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='certification_tools');toolmeta=ast.literal_eval(next(n.value for n in fn.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='external' for t in n.targets)))
observerfn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='observe_environment');observeshell=ast.literal_eval(next(n.value for n in observerfn.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='shell' for t in n.targets)))
envprofiles={p['identity']['jdk-major']:p for p in yaml.safe_load(read(REPO/'capabilities/foundation-environments.yaml'))['profiles']};tools=[]
for t in toolmeta:
 pin=props(REPO/t['pin']);h=sha(REPO/t['path']);eq(h,pin[t['hash-key']],'current actual tool binary '+t['id']);expected={k:v for k,v in t.items() if k not in ('path','pin','hash-key')};expected['sha256']=h;tools.append(expected)
for label in ['t03','t09','t10','t11','t12','t13']:tools.append({'id':'folio-pdf-'+label,'kind':'project-test','version':'0.1.0','chains':['semantic'],'sha256':sha(REPO/'target/foundation-0.1.0/harness/acceptance.jar')})
helper=REPO/'.build-cache/harfbuzz/10.2.0-final';environments=[]
def container(scope,image):
 inside='/workspace/'+str(scope.relative_to(REPO))
 return ['podman','run','--rm','--network=none','--userns=keep-id','--volume',str(REPO)+':/workspace:ro','--volume',str(helper)+':/folio-harfbuzz:ro','--volume','/usr/bin/python3.12:/usr/bin/python3.12:ro','--volume','/usr/lib/python3.12:/usr/lib/python3.12:ro','--volume',str(Path('/lib/x86_64-linux-gnu/libexpat.so.1').resolve())+':/lib/x86_64-linux-gnu/libexpat.so.1:ro','--workdir','/workspace','--env','LANG=C.UTF-8','--env','LC_ALL=C.UTF-8','--env','TZ=UTC','--env','FOLIO_HARFBUZZ_HELPER=/folio-harfbuzz/bin/folio-harfbuzz','--volume',str(scope)+':'+inside+':rw',image]
for major in [8,11,17,21]:
 env=envprofiles[major];before=obj(ROOT/('jdk'+str(major)+'-environment/environment.yaml'));observations=[]
 eq(before['identity'],env['identity'],'approved immutable tuple '+str(major));eq(before['tools'],tools,'exact 15 bound tool identities '+str(major))
 for suffix in ['', '-after']:
  d=ROOT/('jdk'+str(major)+'-environment'+suffix);osr={k:v.strip('"') for k,v in props(d/'os-release.txt').items()};jdk={k:v.strip('"') for k,v in props(d/'jdk-release.txt').items()};jtxt=read(d/'java-version.txt').decode();runtime=next(l.split('=',1)[1].strip() for l in jtxt.splitlines() if l.strip().startswith('java.runtime.version ='));digest=read(d/'image-digest.txt').decode().strip();arch=read(d/'architecture.txt').decode().strip();native=obj(d/'native-observation.json')
  eq(native['result'],'pass',str(d)+' live engine success');eq(native['loader_environment'],{},str(d)+' empty loader overrides');eq(native['helper']['sha256'],sha(helper/'bin/folio-harfbuzz'),str(d)+' mounted helper');eq(native['loaded_engine']['sha256'],sha(helper/'lib/libharfbuzz.so.0.61020.0'),str(d)+' actually loaded engine');eq(native['installation']['sha256'],sha(helper/'installation.json'),str(d)+' complete installed receipt');eq(native['installation']['receipt'],obj(helper/'installation.json'),str(d)+' exact installed receipt bytes object');eq(native['observer']['sha256'],sha(REPO/'scripts/t29-native-observation.py'),str(d)+' native observer');eq(native['python']['sha256'],sha(Path('/usr/bin/python3.12')),str(d)+' mounted observer Python')
  for item in native['loaded_files']:
   eq(item['path'] in native['process_maps'],True,str(d)+' actually mapped file '+item['path'])
   if item['path'].startswith('/folio-harfbuzz/'):
    eq(item['sha256'],sha(helper/item['path'][len('/folio-harfbuzz/'):]),str(d)+' mapped explicit installation hash')
  actual={'os':osr['ID'],'os-version':osr['VERSION_ID'],'architecture':'x86-64' if arch=='x86_64' else arch,'image':env['identity']['image'].split('@')[0]+'@'+digest,'os-release-sha256':sha(d/'os-release.txt'),'jdk-major':int(runtime.split('.')[1] if runtime.startswith('1.') else runtime.split('.')[0]),'jdk-vendor':jdk['IMPLEMENTOR'],'jdk-build':runtime,'java-sha256':read(d/'java-executable.txt').decode().split()[0]}
  reconstructed={'schema-version':1,'profile':env['id'],'identity':actual,'host':{'kernel':read(d/'kernel.txt').decode().strip(),'architecture':actual['architecture']},'native-engine':{'name':'harfbuzz','version':'10.2.0','helper-sha256':native['helper']['sha256'],'library-sha256':native['loaded_engine']['sha256'],'installation-sha256':native['installation']['sha256']},'tools':tools};eq(reconstructed,before,str(d)+' fully reconstructed actual before/after identity')
  inside='/workspace/'+str(d.relative_to(REPO));eq(obj(d/'invocation.json'),container(d,env['identity']['image'])+['sh','-c',observeshell,'t03-observe',inside],str(d)+' complete actual environment invocation');eq(read(d/'observer.log'),b'',str(d)+' clean original observer completion')
  observations.append({'directory':str(d.relative_to(REPO)),'created-utc':native['created_utc'],'identity':actual,'loaded-files':native['loaded_files'],'raw-files':[{'path':str(p.relative_to(REPO)),'sha256':sha(p)} for p in sorted(d.iterdir()) if p.is_file()]})
 eq(observations[0]['loaded-files'],observations[1]['loaded-files'],'exact before/after live loaded-library identities '+str(major));eq(observations[0]['created-utc']<observations[1]['created-utc'],True,'before precedes after '+str(major));environments+=observations
release=yaml.safe_load(read(REPO/'capabilities/foundation-release.yaml'));cp=sorted(p for p in release['required-artifacts'] if p.endswith('.jar') and not p.endswith(('-sources.jar','-javadoc.jar')) and 'itext7-preview' not in p)+[r['path'] for r in build['harness'] if r['path'].endswith('.jar')]
expectedinputs=set(cp+[r['path'] for r in build['harness']]+['target/foundation-0.1.0/build-inputs.json','target/foundation-0.1.0/build-command.json','scripts/imagemagick-runtime.sha256']+[t['pin'] for t in toolmeta])
for name in case['configuration-paths']:
 p=REPO/name
 expectedinputs.update(str(f.relative_to(REPO)) for f in p.rglob('*') if f.is_file()) if p.is_dir() else expectedinputs.add(name)
tuples=[]
for major,mode in TUPLES:
 scope=ROOT/('jdk'+str(major)+'-'+mode.lower());conf=obj(scope/'execution.yaml');eq({r['path'] for r in conf['inputs']},expectedinputs,scope.name+' exact complete execution-input set');eq(len(conf['inputs']),len(expectedinputs),scope.name+' unique complete execution inputs')
 for r in conf['inputs']:eq(sha(REPO/r['path']),r['sha256'],scope.name+' actual execution input '+r['path'])
 log=read(scope/'contract-tests.txt').decode();eq(bool(re.fullmatch(r'JUnit version 4\.13\.2\n\.{83}\nTime: [0-9.]+\n\nOK \(83 tests\)\n\n',log)),True,scope.name+' original complete formal suite zero-skips')
 tuples.append({'tuple':scope.name,'staged-classpath-paths':cp,'tests':83,'execution-configuration-sha256':sha(scope/'execution.yaml'),'configuration-inputs':len(conf['inputs']),'actual-native-mode':mode,'actual-facade-mode':'IN_PROCESS'})
eq(case['test-count'],83,'current required formal case count')
finish('stage-environment-contract-inspection.json',{'candidate-sha256':cid,'contract-sha256':tid,'input-counts':counts,'tuples':tuples,'environments':environments,'tools':tools,'changed-source-paths-since-r3':changed,'source-review-boundary':'Current identity checked; five-file source review already closed and read. No repeat full source code review.','outer-publication-reviewed':False})
assert not errors
