from auditlib import *
import tarfile,io,datetime
from collections import Counter
RAW=Path('/tmp/t75-r4-values-spec-58_zc8ru');DELIVERY=REPO/'capabilities/evidence/T75-delivery';retain=Path('/tmp/t75-final-values-certified-r4-sihb0x55');r4=DELIVERY/'final-certification-r4';reviews=DELIVERY/'certification-review-r4';CID='ab18cc9c0473730a6aabec5d12e3172f22bea23a0a0f9529052a2bc186cbfc1b';TID='3de508f79fcbef7258feee8abc013d6f02b000840cac1cb263cb0d6f927b8f2b'
rawpins={'report.md':'a65bebcb8b0b4a51e787f71f975c82ba28a53b80e13e108b51849c668acab243','receipt.json':'c06b3e9c0856f04af702314185b5620ab9cd53961c383bfe4f11e4ef7100d3f1','input-catalog.json':'04d5f1583974a51aebfc1b96092334a449b3ba87fa1d14cecbf16a1252b0bbc5','artifact-manifest.json':'ad188379bec109e7e37e3777b8ce7293c914f7c92996e71eacca9c163afc8ec0'}
for n,h in rawpins.items():eq(sha(RAW/n),h,'closed original raw review '+n)
rawreceipt=obj(RAW/'receipt.json');eq(rawreceipt['finding-count'],0,'closed raw review no findings');eq(rawreceipt['candidate-sha256'],CID,'raw candidate');eq(rawreceipt['contract-sha256'],TID,'raw contract');rawcatalog={r['path']:r for r in obj(RAW/'input-catalog.json')['files']};rawmanifest=obj(RAW/'artifact-manifest.json');eq(rawmanifest['excludes'],['artifact-manifest.json'],'raw manifest self exclusion');eq(len(rawmanifest['files']),157,'complete sealed raw manifest')
for r in rawmanifest['files']:eq(sha(RAW/r['path']),r['sha256'],'unchanged raw review artifact '+r['path'])
def unchanged(p,where):
 p=Path(p);eq(sha(p),rawcatalog[str(p)]['sha256'],where+' exact closed raw input')
def ref(p):return {'path':str(p.relative_to(REPO)),'sha256':sha(p)}
archivecatalog=[]
def inspect_archive(archive,idpath,expected_sha,count):
 identity=obj(idpath);eq(sha(archive),expected_sha,'actual retained archive '+archive.name);eq(identity['sha256'],expected_sha,'archive identity '+archive.name);original=Path(identity['original']);members=[]
 with tarfile.open(fileobj=io.BytesIO(read(archive)),mode='r:xz') as tar:
  for m in tar.getmembers():
   q=PurePosixPath(m.name);eq(m.isfile() and not q.is_absolute() and '..' not in q.parts and q.as_posix()==m.name,True,'regular canonical archive member '+m.name);data=tar.extractfile(m).read();p=original/m.name;eq(read(p),data,'exact archived original '+str(p));members.append({'path':m.name,'size':len(data),'sha256':hashlib.sha256(data).hexdigest()})
 eq(len(members),count,'retained member count '+archive.name);eq(len(set(m['path'] for m in members)),count,'unique archived paths '+archive.name);eq(members,identity['members'],'complete original archive catalog '+archive.name);eq(identity['symbolic_links'],[],'no archived symbolic links '+archive.name);eq({str(p.relative_to(original)) for p in original.rglob('*') if p.is_file()},{m['path'] for m in members},'all originals retained '+archive.name);archivecatalog.append({'archive':ref(archive),'original':str(original),'members':members});return original
inspect_archive(reviews/'values-eight-tuples-spec.tar.xz',reviews/'values-eight-tuples-spec-archive-identity.json','abc0ceedf5a506f2a47ab42ebc1952e282c057fc9f61694846f04883110343c1',158)
previous_review=inspect_archive(reviews/'transactions-publication-spec.tar.xz',reviews/'transactions-publication-spec-archive-identity.json','5e232cfe64c16e2cabf5eed05765aa5f3ed30af9559dea7cec8c043f6632fdfa',155)
for n,pin in [('report.md','146ac5ef8bafb7c16dbd01fdaedce0fc9ed9f4ff90f30d750bbb7c41347e856e'),('receipt.json','6c37100dd56159f0b4e8bcd803ca4d77eb36354e563a6c240db07855058c6122')]:
 eq(sha(previous_review/n),pin,'closed prior transactions publication '+n);eq(read(previous_review/n),read(reviews/('transactions-publication-spec-'+n)),'adjacent prior transactions '+n)
prevreview=obj(previous_review/'receipt.json');eq(prevreview['findings'],[],'closed prior transactions findings');eq(prevreview['approvals']['transactions-actual-outer-exit'],True,'prior actual transactions completion');eq(prevreview['approvals']['transactions-eight-exact-publication'],True,'prior transactions exact publication');eq(prevreview['approvals']['existing-text-eight-preservation'],True,'prior retained text publication')
eq(sha(reviews/'text-publication-spec.tar.xz'),'bdcca3024295ef7f006ccec8b87d357a6b2c49317f0cc395faec8ae592744855','closed text publication archive identity');read(reviews/'text-publication-spec-report.md');textreceipt=obj(reviews/'text-publication-spec-receipt.json')
for n in ['values-eight-tuples-spec-report.md','values-eight-tuples-spec-receipt.json']:
 eq(read(reviews/n),read(RAW/('report.md' if n.endswith('report.md') else 'receipt.json')),'adjacent current raw review original '+n)
actualoriginal=inspect_archive(r4/'values-command.tar.xz',r4/'values-command-archive-identity.json','2fe4155a3adb488afcbb474e1be0bd674dd9c42dbd918f70f576cbb7bc91f338',10);eq(actualoriginal,retain,'actual current retained command directory')
command=obj(Path('/tmp/t75-final-values-certify-r4-command.json'));result=obj(Path('/tmp/t75-final-values-certify-r4-result.json'));log=read(Path('/tmp/t75-final-values-certify-r4.log')).decode();expected_command=['/usr/bin/python3','scripts/t03-foundation.py','certify','capabilities/evidence/T75-foundation-20260914-r4/values','--obligation','values'];eq(command['command'],expected_command,'actual authorized certifier command');eq(command['cwd'],str(REPO),'actual certifier workspace');eq(command['explicit-environment'],{'FOLIO_HARFBUZZ_HELPER':str(REPO/'.build-cache/harfbuzz/10.2.0-final/bin/folio-harfbuzz')},'explicit mounted helper');eq(result,{**command,'command-pid':406349,'returncode':0,'completed-utc':'2026-09-13T20:40:57.802526+00:00'},'actual original outer completion');eq(command['started-utc'],'2026-09-13T20:08:33.154021+00:00','actual original outer start')
expected_lines=[]
for major in [8,11,17,21]:expected_lines += ['T09 environment JDK '+str(major),'T09 certification JDK '+str(major)+' / IN_PROCESS','T09 certification JDK '+str(major)+' / HARDENED_WORKER']
expected_lines += ['Recorded exactly eight T09 certifications; retained 16 current certifications for other obligations.'];eq(log,'\n'.join(expected_lines)+'\n','complete original thirteen-line outer stdout/stderr protocol')
for a,b in [('command.json','values-command.json'),('result.json','values-result.json'),('command.log','values-command.log'),('receipt.json','values-receipt.json')]:eq(read(retain/a),read(r4/b),'byte-exact adjacent '+b)
receipt=obj(retain/'receipt.json');eq(receipt['actual-result'],result,'retained actual result');eq(receipt['actual-exit'],0,'retained actual exit');eq(receipt['candidate'],CID,'retained candidate');eq(receipt['contract'],TID,'retained contract');eq(receipt['authority-counts'],{'text':8,'transactions':8,'values':8},'dated authority count receipt')
for row in receipt['original-copies']:
 data=read(retain/row['copy']);eq(hashlib.sha256(data).hexdigest(),row['sha256'],'actual original copy identity '+row['copy']);eq(len(data),row['bytes'],'actual original copy bytes '+row['copy'])
 if row['copy']!='authority-at-retention.yaml':eq(read(Path(row['original'])),data,'unchanged actual original '+row['original'])
source=read(REPO/'scripts/t03-foundation.py').decode();unchanged(REPO/'scripts/t03-foundation.py','unchanged actual certified runner');wrapper=read(retain/'t75-run-retained.py').decode()
for token in ["run_logged(test_command, scope / 'contract-tests.txt'", "merged = publish_index(root, output)", "os.replace(prepared, authority)", "if authority.read_bytes() != previous_bytes:", "os.fsync(descriptor)", "verified['certifications'] != fresh['certifications']"]:eq(token in source,True,'existing actual output/publication protocol '+token)
eq('stderr=subprocess.STDOUT' in wrapper and "result['returncode'] = process.wait()" in wrapper,True,'actual outer wrapper merges stdout/stderr and records child return status')
stage=DELIVERY/'final-candidate-r4/build-inputs.json';unchanged(stage,'unchanged staged build input declaration');build=obj(stage);eq(obj(ROOT/'observed-index.json')['candidate'],build['candidate'],'current own index actual staged candidate')
counts={}
for label,rows in {'sources':build['candidate']['inputs'],'contracts':build['contract-inputs'],'artifacts':build['candidate']['artifacts'],'harness':build['harness']}.items():
 counts[label]=len(rows)
 for r in rows:eq(sha(REPO/r['path']),r['sha256'],'current staged identity '+r['path']);eq(r['sha256'],rawcatalog[str(REPO/r['path'])]['sha256'],'same closed raw-stage input '+r['path'])
eq(counts,{'sources':1933,'contracts':30,'artifacts':23,'harness':24},'complete current staged identity counts')
own=obj(ROOT/'observed-index.json');unchanged(ROOT/'observed-index.json','sealed own current values index');eq(read(ROOT/'observed-index.json'),read(retain/'observed-index.json'),'actual retained own values index');eq(obj(ROOT/'identities.json'),{'Candidate':CID,'Contract':TID},'actual own certifier identities')
previous=Path(prevreview['dated-authority']['path']);prior=obj(previous);eq(sha(previous),prevreview['dated-authority']['sha256'],'closed prior authority');eq(read(ROOT/'prior-index.sha256').decode().strip(),sha(previous),'actual prior-authority guard input');eq(prior['candidate'],own['candidate'],'same candidate prior retained index')
indexes={'values':own}
for label,key in [('transactions','own-transactions-index-sha256'),('text','preserved-text-index-sha256')]:
 p=ROOT.parent/label/'observed-index.json';eq(sha(p),prevreview[key],'existing independently closed own index '+label);indexes[label]=obj(p)
 eq([c for c in prior['certifications'] if c['obligation']==label],indexes[label]['certifications'],'prior exact subset '+label)
dated=obj(retain/'authority-at-retention.yaml');eq(dated,{**own,'certifications':prior['certifications']+own['certifications']},'exact new authority: prior16 plus values8, current fresh environment records');eq(Counter(c['obligation'] for c in dated['certifications']),Counter({'text':8,'transactions':8,'values':8}),'exact dated 24 publication')
# Snapshot the mutable authority once. Later obligations are not inspected or approved.
start=datetime.datetime.now(datetime.timezone.utc).isoformat();authoritybytes=read(REPO/'capabilities/foundation-evidence.yaml');(OUT/'originals').mkdir();snapshot=OUT/'originals/authority-current-observation.yaml'
with snapshot.open('xb') as f:f.write(authoritybytes)
observed_at=datetime.datetime.now(datetime.timezone.utc).isoformat();current=json.loads(read(snapshot));eq(current['candidate'],own['candidate'],'observed authority current candidate')
for label,index in indexes.items():eq([c for c in current['certifications'] if c['obligation']==label],index['certifications'],'current unchanged exact reviewed subset '+label)
prior_records=[]
for label in ['text','transactions']:
 for c in indexes[label]['certifications']:
  eq(sha(REPO/c['configuration']['path']),c['configuration']['sha256'],'existing preserved configuration '+label)
  for r in c['records']:eq(sha(REPO/r['path']),r['sha256'],'existing preserved PASS record '+label);prior_records.append(r)
configs=[];records=[];environments=[];transcripts=[]
for c in own['certifications']:
 scope=REPO/Path(c['configuration']['path']).parent;confpath=REPO/c['configuration']['path'];unchanged(confpath,'values configuration '+scope.name);config=obj(confpath);eq(config['candidate-sha256'],CID,'actual candidate in config '+scope.name);eq(config['execution-profile'],c['execution-profile'],'actual selected Native profile '+scope.name);eq(config['settings']['providers'],'none; Stable Facade execution is IN_PROCESS','actual Facade scope '+scope.name);configs.append(c['configuration'])
 transcript=scope/'contract-tests.txt';unchanged(transcript,'formal transcript '+scope.name);txt=read(transcript).decode();eq(bool(re.fullmatch(r'JUnit version 4\.13\.2\n\.{83}\nTime: [0-9.]+\n\nOK \(83 tests\)\n\n',txt)),True,'actual full original formal suite '+scope.name);transcripts.append({'scope':str(scope.relative_to(REPO)),'formal-tests':83,'seconds':float(re.search(r'Time: ([0-9.]+)',txt)[1])})
 for r in c['records']:
  p=REPO/r['path'];unchanged(p,'sealed values chain '+str(p));eq(sha(p),r['sha256'],'published exact chain '+str(p));record=obj(p);subset(record,{'result':'pass','obligation':'values','candidate-sha256':CID,'contract-sha256':TID,'execution-profile':c['execution-profile'],'execution-configuration-sha256':c['configuration']['sha256']},str(p)+' actual published identity');reportpath=REPO/record['report']['path'];unchanged(reportpath,'sealed values report');eq(sha(reportpath),record['report']['sha256'],'actual report binding');records.append({'record':r,'report':record['report'],'chain':record['chain'],'profile':record['execution-profile']})
eq(transcripts,receipt['tuples'],'retained tuple/time summary matches exact stored JUnit transcripts')
for major in [8,11,17,21]:
 for suffix in ['', '-after']:
  d=ROOT/('jdk'+str(major)+'-environment'+suffix);rows=[]
  for p in sorted(d.iterdir()):
   if p.is_file():unchanged(p,'complete sealed environment observer '+str(p));rows.append(ref(p))
  environments.append({'directory':str(d.relative_to(REPO)),'files':rows})
eq(sum(len(e['files']) for e in environments),84,'complete eight BEFORE/AFTER observation directories');eq(len(records),32,'all values records bound');eq(len(configs),8,'all values configurations bound')
eq(obj(RAW/'final-input-inspection.json')['completed-utc']>result['completed-utc'],True,'closed complete raw audit already postdates actual outer completion')
dump('archive-member-catalog.json',archivecatalog)
finish('publication-inspection.json',{'scope':'Values actual outer exit/publication and preservation of prior text8+transactions8 only','candidate':CID,'contract':TID,'actual-command':command,'actual-result':result,'complete-original-outer-log-sha256':sha(retain/'command.log'),'original-outer-lines':len(log.splitlines()),'original-outer-stderr-policy':'Merged with stdout in the original command.log; child JUnit details are retained per tuple, never required twice.','actual-command-retention':{'original':str(retain),'archive':ref(r4/'values-command.tar.xz'),'original-file-count':10},'dated-authority':{'path':str(retain/'authority-at-retention.yaml'),'sha256':sha(retain/'authority-at-retention.yaml'),'exact-subsets':{'text':8,'transactions':8,'values':8}},'prior-authority':{'path':str(previous),'sha256':sha(previous)},'current-authority-observation':{'original':str(REPO/'capabilities/foundation-evidence.yaml'),'started-utc':start,'completed-utc':observed_at,'snapshot':str(snapshot.relative_to(OUT)),'sha256':sha(snapshot),'exact-reviewed-subsets':{'text':8,'transactions':8,'values':8},'other-obligation-names-excluded':sorted(set(c['obligation'] for c in current['certifications'])-set(indexes)),'mutable-original-not-a-frozen-input':True},'current-stage-input-counts':counts,'closed-raw-review-originals':rawpins,'values-configurations':configs,'values-records-and-reports':records,'formal-transcripts':transcripts,'before-after-environments':environments,'prior-record-identities-preserved':prior_records,'raw-or-RGB-rule-observations-replayed':False,'five-file-source-review-repeated':False,'deferred':['Other obligations','All48 certification','Inventory/readiness and final delivery','Completion marks'],'repository-mutations':False,'project-executions':False})
assert not errors
