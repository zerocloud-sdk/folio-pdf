from pathlib import Path
import hashlib, json
base = Path(__file__).parent
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
receipt = json.loads((base / 'receipt.json').read_bytes())
assert sha(base / 'report.md') == receipt['report-sha256']
assert receipt['findings'] == []
assert receipt['record-count'] == 32 and receipt['configuration-count'] == 8
assert receipt['approvals']['text-eight-actual-outer-exit']
assert receipt['approvals']['text-eight-authority-publication']
assert not receipt['approvals']['all48-final-delivery']
actual = json.loads((base / 'finalize-publication-result.json').read_bytes())
assert actual['returncode'] == 0
for stream in ['stdout','stderr']:
    assert sha(base / actual[stream]['path']) == actual[stream]['sha256']
for component in receipt['completed-components']:
    assert sha(base / component['path']) == component['sha256']
catalog = receipt['complete-inspected-input-identities']
assert sha(base / catalog['path']) == catalog['sha256']
print(json.dumps({'result':'CLEAN','scope':'r4 text actual publication only','report-sha256':sha(base/'report.md'),'receipt-sha256':sha(base/'receipt.json'),'input-catalog-sha256':catalog['sha256'],'input-paths':catalog['paths'],'preserved-diagnostic':True,'pre-packet-discovery-output-limitation-disclosed':True,'all48-delivery-approved':False}))
