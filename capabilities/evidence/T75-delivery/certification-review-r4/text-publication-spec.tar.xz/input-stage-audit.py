from reviewlib import *
import tarfile
D = REPO / 'capabilities/evidence/T75-delivery'
stage = D / 'final-candidate-r4'
build = obj(stage / 'build-inputs.json')
candidate = build['candidate']
contracts = build['contract-inputs']
groups = {'sources': candidate['inputs'], 'contracts': contracts,
          'artifacts': candidate['artifacts'], 'harness': build['harness']}
for kind, rows in groups.items():
    eq(len(rows), {'sources': 1933, 'contracts': 30, 'artifacts': 23, 'harness': 24}[kind], kind + ' count')
    eq(len({row['path'] for row in rows}), len(rows), kind + ' unique input paths')
    for row in rows: eq(sha(REPO / row['path']), row['sha256'], kind + ':' + row['path'])
canonical = lambda kind, rows: ''.join(kind + ' ' + row['path'] + ' ' + row['sha256'] + '\n' for row in sorted(rows, key=lambda row: row['path']))
cid = digest(('release ' + candidate['release'] + '\n' + canonical('input', candidate['inputs']) + canonical('artifact', candidate['artifacts'])).encode())
tid = digest(canonical('contract', contracts).encode())
eq(cid, 'ab18cc9c0473730a6aabec5d12e3172f22bea23a0a0f9529052a2bc186cbfc1b', 'canonical candidate identity')
eq(tid, '3de508f79fcbef7258feee8abc013d6f02b000840cac1cb263cb0d6f927b8f2b', 'canonical contract identity')
eq(sha(stage / 'build-inputs.json'), '64cb458acef6c0e98aa5b0dbf8023d85fe569fa2269eb6c3c343959779325e02', 'frozen r4 build identity')
eq(read(stage / 'build-inputs.json'), read(REPO / 'target/foundation-0.1.0/build-inputs.json'), 'retained and active staged build equality')
eq(candidate, obj(TEXT / 'candidate-probe.json')['candidate'], 'actual candidate observation')
eq(candidate, obj(TEXT / 'observed-index.json')['candidate'], 'published observation candidate')
eq({'inputs': candidate['inputs'], 'contract-inputs': contracts}, obj(D / 'final-validation-r4/source-and-contract-inputs.json'), 'same complete host/matrix source and contract inputs')
prior = obj(D / 'final-candidate-r3/build-inputs.json')
eq(contracts, prior['contract-inputs'], 'unchanged r3 contract')
old = {row['path']: row['sha256'] for row in prior['candidate']['inputs']}
new = {row['path']: row['sha256'] for row in candidate['inputs']}
eq(set(old), set(new), 'unchanged source path universe')
delta = [{'path': path, 'r3-sha256': old[path], 'current-sha256': new[path], 'bytes': files[str(REPO / path)]['bytes']} for path in sorted(new) if old[path] != new[path]]
closure = obj(D / 'inventory-read-bound/independent-review-closure.json')
eq(delta, closure['source-delta'], 'only the five independently closed reader changes since r3')
eq(closure['spec-closed'] and closure['standards-closed'], True, 'both source review axes closed')
for axis in ['spec', 'standards']:
    eq(sha(D / 'inventory-read-bound' / (axis + '-review-report.md')), closure[axis + '-report-sha256'], axis + ' original source report')
stage_result = obj(stage / 't75-final-stage-r4-result.json')
eq(stage_result['returncode'], 0, 'actual stage exit')
archive_identity = obj(stage / 'original-archive-identities.json')['staged-build']
eq(sha(stage / archive_identity['archive']), archive_identity['sha256'], 'stage archive identity')
members = []
with tarfile.open(stage / archive_identity['archive'], 'r:xz') as stream:
    for member in stream:
        if member.isdir(): continue
        eq(member.isfile(), True, 'regular stage member')
        data = stream.extractfile(member).read()
        members.append({'path': member.name, 'size': len(data), 'sha256': digest(data)})
eq(members, archive_identity['members'], 'complete original stage archive member identities')
for row in members: eq(sha(Path(archive_identity['original']) / row['path']), row['sha256'], 'unchanged stage original ' + row['path'])
validation = []
for kind, name in [('host','host-full-verify-receipt.json'), ('matrix','jdk-matrix-receipt.json')]:
    receipt = obj(D / 'final-validation-r4' / name)
    eq(receipt['actual-result']['returncode'], 0, kind + ' actual exit')
    eq(receipt['result'], 'pass', kind + ' receipt result')
    eq(sha(Path(receipt['original-log'])), receipt['log-sha256'], kind + ' original log')
    eq(len(receipt['runs']), 1 if kind == 'host' else 4, kind + ' complete run count')
    for run in receipt['runs']: eq(run['totals'], {'tests':1507,'failures':0,'errors':0,'skipped':4}, kind + ' complete counts')
    validation.append({'kind': kind, 'receipt-sha256': sha(D / 'final-validation-r4' / name), 'actual-result': receipt['actual-result'], 'runs': receipt['runs'], 'original-report-boundary': receipt['report-boundary']})
finish('input-stage-inspection', {'created-utc': now(), 'candidate': cid, 'contract': tid, 'input-counts': {kind: len(rows) for kind, rows in groups.items()}, 'source-delta-from-r3': delta, 'stage-archive-members': members, 'original-validation-linkage': validation, 'boundary': 'Current staged/source/artifact/harness bytes rehashed. Original host/matrix results linked, not rerun. Other-obligation raw evidence not read.'})
