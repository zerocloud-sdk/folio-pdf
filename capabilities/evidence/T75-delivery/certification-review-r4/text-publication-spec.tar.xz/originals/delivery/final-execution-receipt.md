# T75 execution receipt

Ticket: [#75](https://github.com/zerocloud-sdk/folio-pdf/issues/75).
Fixed implementation and independent review baseline:
`5b1603c435f11c40368f75b7b9a2777c9c5e9761`.

This receipt is in preparation. The r3 certification described below is historical.
All six actual certifiers exited 0 and published 48 tuples. Text, transactions,
values, pages, metadata and annotations have completed independent publication
review. Final inventory generation,
validation and check exited 0, but the generated view still blocks text because
its complete standards records exceed the inventory reader's 3,000,000-code-point
limit. The [five-file reader correction](inventory-read-bound/README.md) has
passed 17 inventory tests and independent Standards/Spec review. It changes
source identity, so r3 evidence cannot certify that later candidate. Fresh
complete validation and staging have now succeeded. The new
[r4 host verification and four-JDK matrix](final-validation-r4/README.md)
both exited 0, each complete run reporting 1,507 tests, zero failures/errors
and the same four default skips. The independent host-evidence Standards review
has closed with zero documented-standard violations or open judgement findings;
all 105 original review files are retained alongside the host results. Matrix
review has also closed with zero hard violations or open judgement findings;
all 96 original review files are retained. The [r4 stage](final-candidate-r4/README.md) matches the
same frozen 1,933 source and 30 contract inputs. Its actual identity observation
is `ab18cc9c0473730a6aabec5d12e3172f22bea23a0a0f9529052a2bc186cbfc1b`;
the contract remains unchanged. [Fresh text certification](final-certification-r4/README.md)
has now exited 0 and published eight tuples with 32 PASS records. All eight raw
tuples have independent Spec closure; their actual publication review is in
progress. The other five obligations require 40 fresh tuples; transactions has
started. Their independent reviews, final inventory checks and delivery remain
required.
No completion criterion is marked complete by this draft. The user's execution
session explicitly authorizes a real-name DCO commit, GitHub push and subsequent
closure of #75 after all technical gates pass.

The historical r3 candidate is
`e2dd9ebbeae5668ccc8e2985ccd8af17c8921d1ec5e12e0c913cbd1fa00dfbd6`;
the contract is
`3de508f79fcbef7258feee8abc013d6f02b000840cac1cb263cb0d6f927b8f2b`.
The [original stage receipt](final-candidate-r3/README.md) binds 1,933 source
inputs, 30 contract inputs, 23 artifacts and 24 harness inputs. Those identities
were unchanged through all six r3 certification commands. The later inventory
reader fix is outside that certified source. The original frozen build-input
and build-command SHA-256 values are respectively
`edc129bd06eb5ee6ac00c4653173a524f72367f73ac1c14f040f8f5c9eb8aa70` and
`76b3d096020e5fd925bb8e47354e246210f9e68d33be9bfca66929d443d9ca19`.

The implementation completes the approved extraction profile and six matching
Facade members, including successful bounded Form, MCR, OBJR, namespace and
font/CMap cases. It preserves mapping uncertainty, deterministic execution
order, explicit resource ownership and safe complete-query failure. The
[public contract](../../../docs/t13-certification.md) records supported cases,
limits and unsupported boundaries. The whole Stable and Preview surfaces each
contain 21 types and 157 members; #75 adds one Facade type and six members.
The [independently reviewed count addendum](final-delivery-review-r3/historical-facade-counts.md)
distinguishes historical family counts and the 20 individually executed
coexistence probes from the new type's source-reviewed initialization delegation.

## Validation and evidence

The [complete host verification and four-JDK matrix](final-validation-r3/README.md)
both finished with actual outer exit 0 on this source. The host and each of the
four JDK runs report 1,504 tests, zero failures, zero errors and four unchanged
default skips, with all ten reactor modules successful. The four skips are
three unselected opt-in Worker scale profiles and one offline raster profile.
They do not skip the formal text certification. Earlier failed runs and their
independent closures remain preserved in the linked development history.

The [actual certification command records](final-certification-r3/README.md)
retain exact commands, stdout, actual process results, observed indexes and
dated authority snapshots. Each completed obligation has eight actual
Ubuntu 24.04/Linux x86-64 tuples: JDK 8/11/17/21, each with Native IN_PROCESS
and HARDENED_WORKER. Facade execution is observed in its actual IN_PROCESS
mode in every tuple.

| Obligation | Formal tests per tuple | Actual command and publication |
| --- | ---: | --- |
| text | 126: 115 Native, nine public Stable Facade, two artifact contracts | Exit 0; eight tuples and 32 chains; independent review closed |
| transactions | 34 | Exit 0; eight tuples and 32 chains; independent review closed |
| values | 83 | Exit 0; eight tuples and 32 chains; independent review closed |
| pages | 65: 53 Native, ten public Stable Facade, two artifact contracts | Exit 0; eight tuples and 32 chains; independent review closed |
| metadata | 73: 62 Native, nine public Stable Facade, two artifact contracts | Exit 0; eight tuples and 32 chains; independent review closed |
| annotations | 47: 36 Native, nine public Stable Facade, two artifact contracts | Exit 0; eight observed tuples and 32 chains; independent raw and publication reviews closed |

Text's four separate qualified chains bind independent syntax, standards,
semantic and visual observations to each tuple's actual products and immutable
environment/tool identities. Each tuple retains 19,700 original files, 85
producer manifests including the root, 334 declaration rules, 42 program rules,
3,340 declaration controls, 1,650 program controls and 1,730 program producer
receipts. The [independent certification reviews](certification-review-r3/README.md)
retain complete original-file checks and separately close actual publication;
an observed-index file alone is never treated as a successful certifier exit.

The historical baseline failed the generated-readiness check in all four CI
jobs despite passing the focused extraction suites. Its original failure is
preserved. The r3 final generate, validate and check commands exited 0, but
text remains blocked by the complete chain record's YAML read limit. Their
successful exits do not satisfy the required text readiness criterion.
Overall Foundation readiness may remain NOT READY for unrelated obligations.

## Coverage of the 28 completion criteria

This table maps the original contract to retained observations. Final approval
and delivery statuses remain distinct from development or partial evidence.
The original [development coverage map](delivery-readiness-review/development-coverage-map.md)
is retained unchanged at its earlier observation point.

| # | Criterion | Current evidence and remaining gate |
| ---: | --- | --- |
| 1 | Deterministic page/content execution order, nested Forms and split Contents | Public Native extraction suite, independent corpus and all eight text tuples |
| 2 | Independently specified glyph geometry | Independent semantic and visual expectations, complete retained raster controls and all eight text tuples |
| 3 | Exact source bytes and explicit mapping uncertainty | Public mapping observers and qualified font/CMap products in all eight text tuples |
| 4 | Marked Content and approved read-only Logical Structure | Public ordering, MCID, role, language, replacement and alternate-text observers; final appearance closures |
| 5 | Required structure blocker resolved through successful behavior | Required successful MCR/OBJR, namespace and appearance cases plus documented unsupported boundaries; complete source review and text certification |
| 6 | Required font/CMap/content blocker resolved through successful behavior | Type 3, predefined Encoding programs, UCS2 parents, embedded inheritance and content execution observers; complete source review and text certification |
| 7 | Matching extraction Facade set recorded and implemented | Six mappings in the text obligation and Facade Surface Manifest; fixed-baseline source review |
| 8 | Compiled Stable/Preview surfaces and compatible new Stable behavior | Complete artifact contracts and nine public Stable Facade cases per actual text tuple; independently reviewed scope addendum |
| 9 | Independent project-owned fixtures and invalid controls | Five authored corpus Sources, ten Native/Facade products, independent expected outcomes and malformed controls; qualification and eight actual text tuples |
| 10 | Detached results after Session close | Public Native/Facade Session-close observers in all eight text tuples |
| 11 | Queries observe preceding Commands | Public Session Command, Query, publication and reopen observers in all eight text tuples |
| 12 | Exact-boundary and first-excess limits | Public traversal, decompression and font-mapping controls across all fifteen dimensions; product limits unchanged |
| 13 | Complete safe failure in both Native profiles | All eight actual Native suites and negative-control chains; original Worker batch timeout and unchanged-guard scenario split independently closed |
| 14 | Resource ownership and Source preservation | Public ownership, close and original-source observers; complete actual text tuple evidence |
| 15 | Public Native/Facade parity | Detached values, reopened files, Publication Receipts and stable safe failures; Facade retains its actual IN_PROCESS mode |
| 16 | Four independent qualified chains and negative controls | Eight actual text tuples, 32 PASS records, complete rule/control and producer-manifest observations; independent review closed |
| 17 | Eight actual pinned JDK/profile environments and identity binding | Actual text command exit 0; all eight tuples independently reviewed against candidate, artifact, configuration, observed JDK/image and tool identities |
| 18 | Evidence validation rejects missing tools/rules, failed controls and identity mismatches | Retained recorder RED/GREEN qualification, public collector controls and independent review; final actual evidence validation remains required |
| 19 | Authorities, public English/Chinese contracts and provenance agree | Source/contract reviews and historical-count addendum closed; final generated views and final review pending |
| 20 | Text satisfied and prior five obligations valid on final candidate | All six r3 obligations published; text readiness blocked by the YAML read limit, requiring a source fix and fresh final-candidate certification |
| 21 | Focused behavior, Facade, recorder and actual-tool qualification pass | Retained focused RED/GREEN and actual-tool qualification lineage, subsequent closed fixes, complete host/matrix and formal text suites; historical failed aggregate not relabeled PASS |
| 22 | Inventory validate/check and stale readiness resolution | All three r3 inventory commands exited 0; text readiness remains blocked, so the final-candidate gate is still open |
| 23 | Complete Maven verify | Current r4 actual exit 0; 1,507 tests, zero failures/errors, four documented default skips; independently reviewed original log and reports |
| 24 | Complete JDK 8/11/17/21 matrix | Current r4 actual outer exit 0; each JDK reports 1,507/0/0/4; complete original log and final-JDK21 reports retained, independent matrix review closed |
| 25 | Independent Standards and Spec review from fixed baseline | Original full source review plus every identity-affecting closure retained; current certification and final delivery review closure still pending |
| 26 | Authorized real-name DCO commit after all gates | User authorization recorded; commit and push pending technical gates, followed by issue closure |
| 27 | Final whitespace and intentional-workspace check | Original raw-byte Git attributes independently reviewed; final ignored-log staging, index-byte verification and diff checks pending |
| 28 | Execution receipt with validation, evidence, review, commit and limitations | This current receipt links retained originals; final technical review and actual delivery result pending |

## Review and delivery boundary

The [final delivery review records](final-delivery-review-r3/README.md) link the
original fixed-baseline Standards and Spec review to all subsequent source
closures. Original failed observations, reviewer diagnostics and separately
corrected interpretations remain byte-preserved. The current preflight is
explicitly bounded; it does not approve unfinished certification, final
inventory generation or the eventual Git index.

The annotations reviewer records an explicit retention exception: two derived
graph summaries were overwritten by a reader naming error, and their old bytes
and SHA values are unavailable. The
[original incident record](certification-review-r3/annotations-reader-output-incident-and-closure.json)
identifies those paths and their known sizes. Original certification files,
commands and stdout remain unchanged; a fresh independent inspection closes
the affected graph scope. No recovery of the lost summaries is claimed.
The final independent delivery review must assess this precise boundary.

Commit, push and issue closure have not occurred at this draft's observation
point. Delivery must use `git commit -s`, verify the pushed remote commit, and
only then close #75. The final user-facing delivery result supplies the actual
commit identity and confirmed issue state; this pre-commit artifact cannot
contain its own resulting commit hash.

Windows x86-64 and macOS x86-64/arm64 remain uncertified under ADR-0040. This
ticket does not certify downstream Forms, Trust, Conformance, SVG/XML, OCR,
Sanitization or Office capabilities, and does not claim global Foundation
readiness. Acceptance tools and fixtures remain outside product runtime.
