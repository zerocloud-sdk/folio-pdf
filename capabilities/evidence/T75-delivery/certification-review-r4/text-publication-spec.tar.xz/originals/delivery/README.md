# T75 refreshed certification

Candidate:
`ab18cc9c0473730a6aabec5d12e3172f22bea23a0a0f9529052a2bc186cbfc1b`.
Contract:
`3de508f79fcbef7258feee8abc013d6f02b000840cac1cb263cb0d6f927b8f2b`.
The [r4 stage](../final-candidate-r4/README.md) binds the same 1,933 source and
30 contract inputs as the successful complete
[host verification and four-JDK matrix](../final-validation-r4/README.md),
with 23 artifacts and 24 harness inputs. Historical r3 evidence remains
retained separately and does not certify the later inventory reader correction.

The actual text command exited 0. It ran from 2026-09-13 17:01:21.422612 UTC
to 19:42:21.433418 UTC. All eight Ubuntu 24.04/Linux x86-64 JDK 8/11/17/21
by Native IN_PROCESS/HARDENED_WORKER tuples passed 126 formal cases and four
independent chains. Each formal suite contains 115 Native, nine public Stable
Facade and two artifact-contract tests. Facade execution remains its actual
IN_PROCESS mode in every tuple.

The command published exactly eight text certifications and 32 PASS chain
records. The retained authority snapshot equals text's own observed index;
certifications for the previous candidate were invalidated, not reused.
`text-command.tar.xz` retains ten original command, output, actual-result,
index, identity, queue-helper and receipt files. Every member was compared
byte-for-byte with its original. The adjacent command, result, log, receipt
and archive-identity files preserve the same bytes and their exact scope.
Complete current raw evidence remains at its
[original paths](../../T75-foundation-20260914-r4/text/).

The [independent raw reviews](../certification-review-r4/README.md) close all
eight text tuples and their 32-record observed index with zero unresolved Spec
findings. Actual outer-result and authority-publication review is a separate
gate and is still in progress at this observation point.

Transactions has started in the serial queue. Transactions, values, pages,
metadata and annotations each require eight fresh tuples on this candidate;
none is counted complete here. Final inventory generation, validation, check,
all-six satisfied assertions and independent delivery review remain required.
No overall Foundation readiness or Git delivery is asserted by this record.
