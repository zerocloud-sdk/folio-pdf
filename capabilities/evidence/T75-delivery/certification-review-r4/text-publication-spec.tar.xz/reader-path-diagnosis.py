from reviewlib import *
scope = TEXT / 'jdk8-in_process'
names = sorted(path.name for path in scope.iterdir())
source = Path('/tmp/t75-final-spec-r4-text-last-three-9alkqepg/exact-command-audit-v3.py')
source_lines = read(source).decode().splitlines()
matches = [{'line': i + 1, 'text': text} for i, text in enumerate(source_lines) if 'command.json' in text or 'recorder' in text]
definition = REPO / 'scripts/t03-foundation.py'
definition_lines = read(definition).decode().splitlines()
original_matches = [{'line': i + 1, 'text': text} for i, text in enumerate(definition_lines) if 'command.json' in text]
failure = obj(BASE / 'publication-audit-result.json')
eq(failure['returncode'], 1, 'preserved first reader exit')
finish('recorded-command-path-diagnosis', {'created-utc': now(), 'explicit-tuple': str(scope.relative_to(REPO)), 'actual-direct-entry-names': names, 'prior-correct-exact-reader-source': {'path': str(source), 'sha256': sha(source), 'matching-lines': matches}, 'actual-certifier-source': {'path': str(definition.relative_to(REPO)), 'sha256': sha(definition), 'matching-lines': original_matches}, 'first-diagnostic': {'result-sha256': sha(BASE / 'publication-audit-result.json'), 'stderr-sha256': sha(BASE / 'publication-audit-stderr.txt')}, 'scope': 'Filename/protocol diagnosis only; no raw replay or production execution. Original reader output is preserved, and any corrected execution must have distinct filenames.'})
