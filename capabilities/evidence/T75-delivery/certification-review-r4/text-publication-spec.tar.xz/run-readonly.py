from pathlib import Path
import datetime, hashlib, json, subprocess, sys
base = Path(__file__).parent
name = sys.argv[1]
allowed = {'inspect-schema.py', 'publication-audit.py', 'raw-review-linkage-audit.py', 'input-stage-audit.py', 'finalize-publication.py'}
if name not in allowed: raise ValueError('Unauthorized independent reader')
prefix = name.removesuffix('.py')
paths = {key: base / (prefix + '-' + suffix) for key, suffix in [('command','command.json'),('stdout','stdout.txt'),('stderr','stderr.txt'),('result','result.json')]}
if any(path.exists() for path in paths.values()): raise FileExistsError('Original output exists; choose a new reader filename, never overwrite')
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
command = {'command': [sys.executable, '-B', str(base / name)], 'cwd': str(base), 'started-utc': now(), 'script-sha256': sha(base / name), 'reviewlib-sha256': sha(base / 'reviewlib.py'), 'boundary': 'Independent read-only inspection. No project tests, CLI, certifier, environment observer, inventory or Git mutation; outputs exclusively in this unique /tmp packet.'}
with paths['command'].open('x') as handle: json.dump(command, handle, indent=2); handle.write('\n')
with paths['stdout'].open('xb') as stdout, paths['stderr'].open('xb') as stderr:
    result = subprocess.run(command['command'], cwd=base, stdout=stdout, stderr=stderr)
command.update({'returncode': result.returncode, 'completed-utc': now(), 'stdout': {'path': paths['stdout'].name, 'bytes': paths['stdout'].stat().st_size, 'sha256': sha(paths['stdout'])}, 'stderr': {'path': paths['stderr'].name, 'bytes': paths['stderr'].stat().st_size, 'sha256': sha(paths['stderr'])}})
with paths['result'].open('x') as handle: json.dump(command, handle, indent=2); handle.write('\n')
print(paths['stdout'].read_text()); print(paths['stderr'].read_text()); print(json.dumps(command))
sys.exit(result.returncode)
