from reviewlib import *
delivery = REPO / 'capabilities/evidence/T75-delivery/final-certification-r4'
copies = []
summaries = {}
for name in ['command.json', 'command.log', 'identities.json', 'prior-index.sha256', 'receipt.json', 'result.json', 't75-certification-refresh-queue-r4b.py', 't75-run-retained.py', 'authority-at-retention.yaml', 'observed-index.json']:
    path = ORIGINAL / name
    copies.append(copy_original(path, 'retained-command/' + name))
    if name in ['command.json','identities.json','receipt.json','result.json']:
        summaries[name] = obj(path)
    elif name == 'command.log':
        summaries[name] = read(path).decode()
for name in ['text-command-archive-identity.json', 'text-receipt.json', 'text-command.json', 'text-result.json', 'README.md']:
    path = delivery / name
    copies.append(copy_original(path, 'delivery/' + name))
    if name.endswith('.json'):
        summaries['delivery/' + name] = obj(path)
path = REPO / 'capabilities/evidence/T75-delivery/final-execution-receipt.md'
copies.append(copy_original(path, 'delivery/final-execution-receipt.md'))
for name in ['command.json','result.json']:
    copies.append(copy_original(Path('/tmp/t75-final-text-certify-r4-' + name), 'actual-command/' + name))
copies.append(copy_original(Path('/tmp/t75-final-text-certify-r4.log'), 'actual-command/stdout.log'))
authority = obj(REPO / 'capabilities/foundation-evidence.yaml')
copies.append(copy_original(REPO / 'capabilities/foundation-evidence.yaml', 'authority-at-first-inspection.json'))
summaries['current-authority'] = {'top-keys': list(authority), 'certifications': len(authority['certifications']), 'obligations': sorted({row['obligation'] for row in authority['certifications']}), 'environment-count': len(authority['environments'])}
summaries['observation-index-keys'] = list(obj(TEXT / 'observed-index.json'))
save('schema-details.json', summaries)
finish('schema-inspection', {'created-utc': now(), 'copies': copies, 'authority-boundary': summaries['current-authority'], 'detail-file': 'schema-details.json', 'boundary': 'Actual original publication files and explicit paths only; no other obligation raw contents read.'})
