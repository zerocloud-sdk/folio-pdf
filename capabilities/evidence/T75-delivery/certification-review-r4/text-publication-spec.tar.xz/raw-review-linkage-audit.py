from reviewlib import *
import tarfile
specs = obj(BASE / 'raw-packets-plan.json')
D = REPO / 'capabilities/evidence/T75-delivery/certification-review-r4'
results = []
copies = []
for spec in specs:
    original = Path(spec['directory'])
    manifest_path = original / 'archive-manifest.json'
    eq(sha(manifest_path), spec['manifest-sha256'], 'original raw-review manifest')
    manifest = obj(manifest_path)
    eq(manifest['excluded-paths'], ['archive-manifest.json'], 'original manifest excludes only itself')
    wanted = {row['path']: {'size': row['bytes'], 'sha256': row['sha256']} for row in manifest['members']}
    wanted['archive-manifest.json'] = {'size': manifest_path.stat().st_size, 'sha256': sha(manifest_path)}
    eq(len(wanted), spec['members'], 'complete original packet member count')
    eq({str(p.relative_to(original)) for p in original.rglob('*') if p.is_file()}, set(wanted), 'exact original packet file set')
    for name, row in wanted.items():
        data = read(original / name)
        eq({'size': len(data), 'sha256': digest(data)}, row, 'unchanged original review file ' + name)
    archive = D / (spec['stem'] + '.tar.xz')
    eq(sha(archive), spec['archive-sha256'], 'known retained raw-review archive')
    aid = obj(D / (spec['stem'] + '-archive-identity.json'))
    actual = {}
    with tarfile.open(archive, 'r:xz') as stream:
        for member in stream:
            if member.isdir(): continue
            eq(member.isfile(), True, 'regular raw-review archive member')
            eq(member.name in actual, False, 'unique archive member')
            data = stream.extractfile(member).read()
            actual[member.name] = {'size': len(data), 'sha256': digest(data)}
    eq(actual, wanted, 'complete raw-review archive equals original packet')
    for name in ['report.md','receipt.json']:
        eq(sha(original / name), spec[name + '-sha256'], 'original raw-review ' + name)
        published = D / (spec['stem'] + ('-report.md' if name == 'report.md' else '-receipt.json'))
        eq(read(published), read(original / name), 'byte-exact retained review ' + name)
        copies.append(copy_original(original / name, 'raw-review-linkage/' + spec['stem'] + '-' + name))
    receipt = obj(original / 'receipt.json')
    catalog_ref = receipt[spec['catalog-field']]
    eq(sha(original / catalog_ref['path']), catalog_ref['sha256'], 'unchanged complete original raw input identity catalog')
    eq(catalog_ref['sha256'], spec['catalog-sha256'], 'known reviewed catalog identity')
    results.append({'original': str(original), 'original-packet-members': len(wanted), 'archive': str(archive.relative_to(REPO)), 'archive-sha256': spec['archive-sha256'], 'report-sha256': spec['report.md-sha256'], 'receipt-sha256': spec['receipt.json-sha256'], 'manifest-sha256': spec['manifest-sha256'], 'complete-input-catalog': catalog_ref, 'prior-approval-boundary': receipt[spec['approval-field']]})
finish('raw-review-linkage-inspection', {'created-utc': now(), 'packets': results, 'original-review-files': sum(row['original-packet-members'] for row in results), 'copies': copies, 'boundary': 'All three original independent review packets and archives rechecked byte-for-byte. Their complete original input catalogs remain unchanged; full physical raw trees are not replayed by this publication-only reader. Original diagnoses, deferrals and historical loss disclosures remain untouched.'})
