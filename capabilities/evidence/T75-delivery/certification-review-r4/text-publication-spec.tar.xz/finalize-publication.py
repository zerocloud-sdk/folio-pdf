from reviewlib import *
import subprocess
components = ['schema-inspection', 'input-stage-inspection', 'raw-review-linkage-inspection', 'recorded-command-path-diagnosis', 'publication-corrected-inspection']
observed = {}
for stem in components:
    data = obj(BASE / (stem + '.json'))
    require(data['errors'] == [], 'Unresolved independent component: ' + stem)
    observed[stem] = data
pub = observed['publication-corrected-inspection']
stage = observed['input-stage-inspection']
lineage = observed['raw-review-linkage-inspection']
require(pub['records'] == 32 and pub['configurations'] == 8, 'Publication is not the complete eight/32 set')
require(lineage['original-review-files'] == 4639, 'Original three-packet lineage incomplete')
require(obj(BASE / 'publication-audit-result.json')['returncode'] == 1, 'Missing original reader diagnostic')
require(obj(BASE / 'publication-audit-v2-result.json')['returncode'] == 0, 'Reader correction not executed successfully')
source_catalog = {}
for stem in components:
    for row in obj(BASE / (stem + '-read-identities.json')):
        if Path(row['path']).is_relative_to(BASE): continue
        if row['path'] in source_catalog:
            require(source_catalog[row['path']] == row, 'Conflicting observed source identity: ' + row['path'])
        source_catalog[row['path']] = row
authority_path = REPO / 'capabilities/foundation-evidence.yaml'
for path, identity in source_catalog.items():
    if path == str(authority_path): continue
    data = Path(path).read_bytes()
    require(len(data) == identity['bytes'] and digest(data) == identity['sha256'], 'Observed original changed before seal: ' + path)
authority_bytes = authority_path.read_bytes()
authority = json.loads(authority_bytes)
index_bytes = (TEXT / 'observed-index.json').read_bytes()
index = json.loads(index_bytes)
require(digest(index_bytes) == pub['observed-index-sha256'], 'Reviewed text index changed')
require([row for row in authority['certifications'] if row['obligation']=='text'] == index['certifications'], 'Text subset changed before final publication seal')
require(authority['candidate'] == index['candidate'], 'Published candidate changed')
actual_envs = {row['profile']: row['record'] for row in authority['environments']}
for env in index['environments']:
    require(actual_envs[env['profile']]['sha256'] == env['record']['sha256'], 'Published environment identity changed for text')
with (BASE / 'originals/authority-at-final-seal.json').open('xb') as handle: handle.write(authority_bytes)
final_authority = {'observed-utc':now(),'sha256':digest(authority_bytes),'bytes':len(authority_bytes),'copy':'originals/authority-at-final-seal.json','obligation-counts':{kind:sum(row['obligation']==kind for row in authority['certifications']) for kind in sorted({row['obligation'] for row in authority['certifications']})},'text-subset-exact':True,'environment-identities-match-text':True,'later-additions':'Other obligations may be added after this dated observation; no claim about those raw tuples is made.'}
save('final-authority-inspection.json', final_authority)
save('complete-inspected-input-identities.json', list(source_catalog.values()))
copies = []
for component in [observed['schema-inspection'], lineage, pub]:
    for row in component.get('copies', []):
        data = (BASE / row['copy']).read_bytes()
        require(len(data) == row['bytes'] and digest(data) == row['sha256'], 'Selected original copy changed')
        copies.append(row)
copies.append({'original':str(authority_path),'copy':final_authority['copy'],'bytes':len(authority_bytes),'sha256':digest(authority_bytes),'observation-utc':final_authority['observed-utc']})
save('selected-original-copy-identities.json', copies)

for name, argv in [('head',['git','rev-parse','HEAD']),('commits',['git','log','5b1603c435f11c40368f75b7b9a2777c9c5e9761..HEAD','--oneline']),('index',['git','diff','--cached','--name-status'])]:
    command = {'command':argv,'cwd':str(REPO),'started-utc':now()}
    save('git-' + name + '-command.json', command)
    stdout_path = BASE / ('git-' + name + '-stdout.txt')
    stderr_path = BASE / ('git-' + name + '-stderr.txt')
    with stdout_path.open('xb') as stdout, stderr_path.open('xb') as stderr:
        result = subprocess.run(argv, cwd=REPO, stdout=stdout, stderr=stderr)
    command.update({'returncode':result.returncode,'completed-utc':now(),'stdout-sha256':digest(stdout_path.read_bytes()),'stderr-sha256':digest(stderr_path.read_bytes())})
    save('git-' + name + '-result.json', command)
    require(result.returncode == 0, 'Read-only Git identity inspection failed')
require((BASE / 'git-head-stdout.txt').read_text().strip() == '5b1603c435f11c40368f75b7b9a2777c9c5e9761', 'HEAD changed')
require((BASE / 'git-commits-stdout.txt').read_bytes() == b'' and (BASE / 'git-index-stdout.txt').read_bytes() == b'', 'Unexpected commit/index delta')
correction = {'original-script':'publication-audit.py','original-result':'publication-audit-result.json','original-stderr-sha256':sha(BASE / 'publication-audit-stderr.txt'),'correct-protocol-diagnosis':'recorded-command-path-diagnosis.json','corrected-script':'publication-audit-v2.py','corrected-result':'publication-audit-v2-result.json','corrected-returncode':0,'corrected-errors':pub['errors'],'closure':'Recorder argv is preserved in execution.yaml, and successful output is recorder.txt. The nonexistent recorder-command.json was solely a reader path assumption. Original failure and corrected output are retained separately.','certification-files-modified':False,'review-files-overwritten':False}
save('reader-diagnostic-closure.json', correction)
paragraphs = [
    'CLEAN: the deferred r4 text actual outer-exit and authority-publication gate is closed. The original command ran from 2026-09-13T17:01:21.422612Z to 19:42:21.433418Z and returned 0. The retained merged stdout/stderr ends with exactly eight T13 certifications and zero retained other-obligation certifications.',
    'Baseline/HEAD remains `5b1603c435f11c40368f75b7b9a2777c9c5e9761`. Candidate: `ab18cc9c0473730a6aabec5d12e3172f22bea23a0a0f9529052a2bc186cbfc1b`; contract: `3de508f79fcbef7258feee8abc013d6f02b000840cac1cb263cb0d6f927b8f2b`.',
    'All ten original command-archive members match their originals. The dated published authority equals text’s unchanged observed-index byte-for-byte. Current authority has the exact eight text configurations and 32 PASS records. Their original reports, four pinned environments, BEFORE/AFTER observations, recorder/contract commands and eight actual126-case suites match the closed raw evidence. Facade remains actual IN_PROCESS in both Native profiles.',
    'All three independent raw-review archives and 4,639 original packet files remain unchanged. Their previous publication deferrals and diagnostics are preserved. Current 1,933 source, 30 contract, 23 artifact and 24 harness inputs match the frozen stage, five-file source correction, and complete successful host/four-JDK verification. This reader links those full rule/control/RGB/ownership/parity reviews without replaying their raw checks.',
    'The Goal requires “Refresh invalidated certifications rather than reusing stale hashes” (131–133). The previous r3 candidate’s 48 certifications do not certify r4. Only text’s eight are published here; the other five obligations still require 40 fresh tuples. The inspected delivery introductions accurately preserve this boundary.',
    'One nonexistent recorder-command.json path assumption was corrected to the actual execution.yaml/recorder.txt protocol in a separately retained successful reader. A preliminary overbroad filename listing was truncated; its full discovery stdout was not retained. It read no changing contents and lost no certification original; that limitation is explicitly recorded.',
    'No unresolved Spec finding. This approves only text actual exit/publication. Transactions raw data, remaining obligations, final inventory/index, all48 and Git delivery remain outside scope. No project execution or repository mutation occurred.'
]
report = '\n\n'.join(paragraphs) + '\n'
require(len(report.split()) < 400, 'Report exceeds400 words')
with (BASE / 'report.md').open('x') as handle: handle.write(report)
receipt = {'reviewer':'/root/final_spec','axis':'Spec','sealed-utc':now(),'scope':'Only r4 text actual outer process and exact authority publication','baseline':'5b1603c435f11c40368f75b7b9a2777c9c5e9761','candidate':stage['candidate'],'contract':stage['contract'],'actual-command':pub['actual-command'],'actual-result':pub['actual-result'],'original-log-sha256':pub['actual-log-sha256'],'original-publication-archive':{'sha256':pub['original-command-archive-sha256'],'members':pub['original-command-archive-members']},'unchanged-observed-index-sha256':pub['observed-index-sha256'],'dated-authority-sha256':pub['dated-authority-sha256'],'current-final-authority':final_authority,'exact-text-certifications':pub['exact-text-certifications'],'record-count':pub['records'],'configuration-count':pub['configurations'],'observed-environments':pub['observed-environments'],'public-mode':pub['actual-facade-mode'],'complete-original-raw-review-linkage':lineage['packets'],'raw-detail-replay':False,'current-input-counts':stage['input-counts'],'source-delta-from-r3':stage['source-delta-from-r3'],'original-validation-linkage':stage['original-validation-linkage'],'current-documentation':pub['current-documentation'],'completed-components':[{'path':stem+'.json','sha256':sha(BASE/(stem+'.json'))} for stem in components],'complete-inspected-input-identities':{'path':'complete-inspected-input-identities.json','sha256':sha(BASE/'complete-inspected-input-identities.json'),'paths':len(source_catalog),'boundary':'These are the exact inputs read by this bounded publication review. Full raw-control input identities remain in their preserved original raw-review catalogs.'},'selected-original-copies':{'path':'selected-original-copy-identities.json','sha256':sha(BASE/'selected-original-copy-identities.json'),'count':len(copies),'bytes':sum(row['bytes'] for row in copies)},'reader-diagnostics':{'unresolved':[],'closed-protocol-diagnosis':'reader-diagnostic-closure.json','discovery-output-limitation':'discovery-output-limitation.json','full-pre-packet-discovery-stdout-retained':False,'certification-original-loss':False,'original-reviewed-output-overwrites':False,'prior-historical-loss-disclosures':'Previous r3 annotations disclosure remains preserved; no lost derived summaries are claimed recovered.'},'findings':[],'approvals':{'text-eight-actual-outer-exit':True,'text-eight-authority-publication':True,'other-five-obligations':False,'transactions-raw':False,'final-inventory-index':False,'all48-final-delivery':False,'completion-criteria-marked':False},'repository-mutations':[],'project-executions':[],'report-sha256':sha(BASE/'report.md'),'report-words':len(report.split()),'retention':'Exclusive /tmp writes; manifest excludes itself. Failed initial reader and separately corrected outputs are preserved with real command/stdout/stderr/results. Preliminary filename discovery limitation is explicitly disclosed.'}
save('receipt.json', receipt)
print(json.dumps({'result':'CLEAN','directory':str(BASE),'report-sha256':sha(BASE/'report.md'),'receipt-sha256':sha(BASE/'receipt.json'),'inspected-paths':len(source_catalog),'selected-original-copies':len(copies),'report-words':len(report.split()),'current-authority-counts':final_authority['obligation-counts']}))
