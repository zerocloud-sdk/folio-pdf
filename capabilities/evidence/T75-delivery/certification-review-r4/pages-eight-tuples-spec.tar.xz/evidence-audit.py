from auditlib import *
from collections import Counter
stage = obj(OUT / 'stage-environment-contract-all-eight-inspection.json')
eq(stage['errors'], [], 'current r4 stage inspection clean')
CID = stage['candidate-sha256']
TID = stage['contract-sha256']
P = 'T10-page-manipulation-merge-split'
profile = REPO / 'capabilities/evidence/T10-page-manipulation-merge-split.md'
C = REPO / 'capabilities/profiles/T10-standards'
qpin = props(REPO / 'scripts/qpdf-pin.properties')
ppin = props(REPO / 'scripts/pdfium-pin.properties')
mpin = props(REPO / 'scripts/imagemagick-pin.properties')
corpus = obj(REPO / 'capabilities/profiles/T10-pages/corpus.json')
corpusroot = REPO / 'capabilities/profiles/T10-pages'
source = read(REPO / 'pdf-acceptance/src/main/java/net/zerocloud/pdf/acceptance/T10IndependentEvidence.java').decode()
required = REPO / 'capabilities/profiles/T10-standards/required-rules.txt'
rules = set(read(required).decode().splitlines())
eq(len(rules), 84, 'all84 actual required rules')
eq(sha(required), 'ef9fca293259a1d19aa49c179f4f7932960abe7410b7592093ba53da9bc022dd', 'frozen required catalog')
profiles = {c: props(C / (c + '.properties')) for c in ['pdfcpu', 'arlington']}
pinpaths = {c: REPO / ('scripts/' + ('t10-arlington' if c == 'arlington' else c) + '-pin.properties') for c in profiles}
pins = {c: props(pinpaths[c]) for c in profiles}
eq(set().union(*(set(p['required-rules'].split(',')) for p in profiles.values())), rules, 'all required assignments')
eq(sum((len(p['required-rules'].split(',')) for p in profiles.values())), 84, 'no duplicate rule assignments')
model = (REPO / 'scripts' / pins['arlington']['model']).resolve()
model_files = sorted(model.glob('*.tsv'))
eq(0 < len(model_files) <= 2048, True, 'bounded actual Arlington model')
eq(sha((REPO / 'scripts' / pins['arlington']['patch']).resolve()), pins['arlington']['patch-sha256'], 'actual T10 checker patch')
modelidentity = ''.join((p.name + ' ' + sha(p) + '\n' for p in model_files))
eq(lines_hash(modelidentity), pins['arlington']['model-sha256'], 'current complete Arlington model SHA')
eq(any((p.is_symlink() for p in model_files)), False, 'model no symlinks')
for c, pin in pins.items():
    eq(sha((REPO / 'scripts' / pin['executable']).resolve()), pin['sha256'], 'current checker executable ' + c)
    eq(pin['timeout-ms'], '10000', 'unchanged checker timeout')
    eq(pin['max-output-bytes'], '1048576', 'unchanged checker output bound')
allrefs = []
physicalrows = []
tuples = []
products = []
negatives = []
visual = []

def ref(p):
    return {'path': str(p.relative_to(REPO)), 'sha256': sha(p)}

def refs(value, owner):
    if isinstance(value, dict):
        if isinstance(value.get('path'), str) and isinstance(value.get('sha256'), str):
            name = value['path']
            q = PurePosixPath(name)
            p = REPO / name
            eq(not q.is_absolute() and '..' not in q.parts and (q.as_posix() == name), True, str(owner) + ' canonical reference')
            eq(p.resolve(), p, str(owner) + ' no linked reference')
            eq(sha(p), value['sha256'], str(owner) + ' exact referenced original')
            yield {'owner': str(owner.relative_to(REPO)), 'path': name, 'sha256': value['sha256']}
        for v in value.values():
            yield from refs(v, owner)
    elif isinstance(value, list):
        for v in value:
            yield from refs(v, owner)

def md(s, key):
    return re.findall('^' + re.escape(key) + ': `([^`\\r\\n]*)`$', s, re.M)

def fields(s, expected, where):
    for k, v in expected.items():
        eq(md(s, k), [str(v)], str(where) + ' ' + k)

def visual_check(d, product, page, h, negative=False):
    info = corpus['pages'][corpus['products'][product]['pages'][page - 1]]
    vprofile = props(corpusroot / 'visual' / (product + '-page-' + str(page) + '.properties'))
    prefix = 'page-' + str(page)
    txt = read(d / (prefix + '-visual.txt')).decode()
    wanted = 'fail' if negative else 'pass'
    hashes = {label + ' raster SHA-256': sha(d / (prefix + '-' + suffix + '.png')) for label, suffix in [('Expected', 'expected'), ('PDFium', 'pdfium'), ('Implementation', 'implementation'), ('Difference', 'difference'), ('Renderer difference', 'renderer-difference')]}
    eq(hashes['Expected raster SHA-256'], sha(d / 'one-pixel-control.png') if negative else info['raster-sha256'], str(d) + ' expected canonical raster identity')
    fields(txt, dict(hashes, **{'Input exact SHA-256': h, 'Input hash policy': 'SHA-256 of the exact unmodified PDF bytes', 'Profile': vprofile['PROFILE_ID'], 'DPI': 144, 'Raster dimensions': str(info['raster-width']) + 'x' + str(info['raster-height']), 'Comparison metric': 'AE', 'Comparison fuzz percent': 0, 'Comparison threshold': 0, 'Renderer agreement threshold': 0, 'Expected comparison AE': 1 if negative else 0, 'Renderer agreement AE': 0, 'Review required': 'false', 'PDFium CLI version': ppin['PDFIUM_CLI_VERSION'], 'PDFium engine version': ppin['PDFIUM_ENGINE_VERSION'], 'ImageMagick version': mpin['IMAGEMAGICK_VERSION'], 'Implementation renderer version': '3.0.8', 'Final determination': wanted}), str(d) + ' original per-page raw visual')
    for k, field in [('PAGE_BOX', 'Page box'), ('COLOR_POLICY', 'Color policy'), ('FONT_POLICY', 'Font policy'), ('ANTIALIASING_POLICY', 'Antialiasing policy')]:
        fields(txt, {field: vprofile[k]}, d / 'frozen visual settings')
    render = 'pdfium render pages.pdf ' + prefix + '-pdfium.png --dpi 144 --file-type png --pages ' + ('first' if page == 1 else str(page))
    comparison = 'magick compare -metric AE -fuzz 0% -highlight-color #ff0000 -lowlight-color #ffffff -define png:exclude-chunk=time,date '
    eq(md(txt, 'Invocation'), ['pdfium --version', render, 'magick --version', comparison + prefix + '-expected.png ' + prefix + '-pdfium.png ' + prefix + '-difference.png', comparison + prefix + '-pdfium.png ' + prefix + '-implementation.png ' + prefix + '-renderer-difference.png'], str(d) + ' complete original page invocations')
    codes = md(txt, 'Exit code')
    eq(len(codes), 5, str(d) + ' all5 original process records')
    eq(codes[:3], ['0', '0', '0'], str(d) + ' successful identity/render processes')
    eq(codes[4], '0', str(d) + ' secondary comparison')
    eq(codes[3] in (['0', '1'] if negative else ['0']), True, str(d) + ' comparator exit plus AE verdict')
    stdout = re.findall('### Standard output\\n\\n```text\\n(.*?)\\n```', txt, re.S)
    stderr = re.findall('### Standard error\\n\\n```text\\n(.*?)\\n```', txt, re.S)
    eq(len(stdout), 5, str(d) + ' full original stdout')
    eq(len(stderr), 5, str(d) + ' full original stderr')
    eq(stdout[0].strip(), 'pdfium version ' + ppin['PDFIUM_CLI_VERSION'], str(d) + ' actual PDFium version')
    eq(stdout[1].strip(), 'Rendered page ' + str(page) + ' into ' + prefix + '-pdfium.png', str(d) + ' actual requested page')
    eq(stdout[2].startswith('Version: ImageMagick ' + mpin['IMAGEMAGICK_VERSION'] + ' '), True, str(d) + ' actual comparator')
    eq(stdout[3:], ['', ''], str(d) + ' comparator stdout')
    eq(stderr[:3], ['', '', ''], str(d) + ' identity/render stderr')
    eq(stderr[4], '0 (0)', str(d) + ' actual secondary AE0')
    eq(bool(re.fullmatch('1 \\([0-9.eE+-]+\\)', stderr[3])) if negative else stderr[3] == '0 (0)', True, str(d) + ' primary exact AE')
    summary = read(d / (prefix + '-visual.md')).decode()
    fields(summary, {'Result': wanted, 'Input exact SHA-256': h, 'Expected raster SHA-256': hashes['Expected raster SHA-256'], 'PDFium raster SHA-256': hashes['PDFium raster SHA-256'], 'Implementation raster SHA-256': hashes['Implementation raster SHA-256'], 'PDFium executable SHA-256': ppin['PDFIUM_EXECUTABLE_SHA256'], 'ImageMagick executable SHA-256': mpin['IMAGEMAGICK_EXECUTABLE_SHA256']}, str(d) + ' actual existing T10 summary fields')
    visual.append({'directory': str(d.relative_to(ROOT)), 'product': product, 'page': page, 'page-name': corpus['products'][product]['pages'][page - 1], 'result': wanted, 'actual-AE': 1 if negative else 0, 'actual-secondary-AE': 0, 'raster-hashes': hashes, 'original-raw-sha256': sha(d / (prefix + '-visual.txt'))})

def syntax_check(d, filename, wanted):
    txt = read(d / 'syntax.txt').decode()
    h = sha(d / filename)
    fields(txt, {'Input exact SHA-256': h, 'Input hash policy': 'SHA-256 of the exact unmodified PDF bytes', 'Tool': 'qpdf', 'Tool version': qpin['QPDF_VERSION'], 'Distribution SHA-256': qpin['QPDF_ARCHIVE_SHA256'], 'Invocation': 'qpdf --check ' + filename, '`' + filename + '` exit code': 0 if wanted == 'pass' else 2, 'Final determination': wanted}, str(d) + ' actual syntax process')
    fields(read(d / 'syntax.md').decode(), {'Result': wanted, 'Input exact SHA-256': h}, str(d) + ' exact syntax summary')
    if wanted == 'pass':
        eq('No syntax or stream encoding errors found; the file may still contain\nerrors that qpdf cannot detect' in txt, True, str(d) + ' actual qpdf success')
        eq(re.findall('### Standard error\\n\\n```text\\n(.*?)\\n```', txt, re.S), [''], str(d) + ' clean qpdf stderr')
    else:
        eq('unable to find trailer dictionary while recovering damaged file' in txt, True, str(d) + ' actual nonPDF detection')
chains = ['syntax', 'standards', 'semantic', 'visual']
names = ['edited', 'merged', 'left', 'right']
editions = [a + '-' + n for a in ['native', 'facade'] for n in names]
for major, mode in TUPLES:
    name = 'jdk' + str(major) + '-' + mode.lower()
    scope = ROOT / name
    obs = scope / 'observations'
    physical = sorted((p for p in scope.rglob('*') if p.is_file()))
    eq(any((p.is_symlink() for p in scope.rglob('*'))), False, name + ' no linked originals')
    physicalrows.extend(({'tuple': name, **ref(p)} for p in physical))
    overall = dict({c: 'pass' for c in chains}, **{'profile': P, 'native-execution-profile': mode, 'facade-execution-profile': 'IN_PROCESS'})
    overall.update({a + '.' + n + '.' + c: 'pass' for a in ['native', 'facade'] for n in names for c in chains})
    eq(props(obs / 'result.properties'), overall, name + ' actual aggregate record')
    eq(props(obs / 'products.properties'), {'phase': 'certification', 'profile': P, 'native-execution-profile': mode, 'facade-execution-profile': 'IN_PROCESS'}, name + ' actual product phase')
    log = read(scope / 'contract-tests.txt').decode()
    eq(log.startswith('JUnit version 4.13.2\n') and re.search('\\nTime: [0-9.]+\\n\\nOK \\(65 tests\\)\\n\\n\\Z', log) is not None and ('FAILURES!!!' not in log), True, name + ' actual complete65 contract transcript')
    read(scope / 'recorder.txt')
    for api in ['native', 'facade']:
        actualmode = mode if api == 'native' else 'IN_PROCESS'
        for group, targets in [('edited', ['edited']), ('split', ['merged', 'left', 'right'])]:
            expected = {'execution-profile': actualmode, 'execution-profile-source': 'workflow-outcome' if api == 'native' else 'fixed-facade-contract', 'receipt-count': str(len(targets))}
            if group == 'split':
                expected['terminal-command-code'] = 'COMMAND_REJECTED'
            for i, target in enumerate(targets):
                pdf = obs / (api + '-' + target) / 'pages.pdf'
                prefix = 'receipt.' + str(i) + '.'
                expected.update({prefix + 'target': target, prefix + 'status': 'COMMITTED', prefix + 'path': '/workspace/' + str(pdf.relative_to(REPO)), prefix + 'partial-output-possible': 'false', prefix + 'pdf-sha256': sha(pdf)})
            eq(props(obs / (api + '-' + group + '-publication.properties')), expected, name + ' actual public declared target order and receipts ' + api + '/' + group)
    for edition in editions:
        api, product = edition.split('-', 1)
        actualmode = mode if api == 'native' else 'IN_PROCESS'
        d = obs / edition
        pdf = d / 'pages.pdf'
        h = sha(pdf)
        pagecount = len(corpus['products'][product]['pages'])
        expected = dict({c: 'pass' for c in chains}, **{'profile': P, 'input-sha256': h, 'execution-profile': actualmode, 'semantic-scope': 'frozen-corpus', 'standards-rule-count': '84', 'page-count': str(pagecount)})
        expected.update({'page.' + str(i) + '.visual': 'pass' for i in range(1, pagecount + 1)})
        eq(props(d / 'result.properties'), expected, str(d) + ' actual complete product results')
        syntax_check(d, 'pages.pdf', 'pass')
        eq(read(d / 'semantic.txt').decode(), 'Input exact SHA-256: ' + h + '\nAll frozen page, resource, annotation and destination expectations matched.\n', str(d) + ' public semantic success')
        eq(read(d / 'visual.txt').decode(), 'Input exact SHA-256: ' + h + '\n' + ''.join(('page ' + str(i) + '=pass\n' for i in range(1, pagecount + 1))) + 'result=pass\n', str(d) + ' complete per-page aggregation')
        combined = ''
        for checker in ['pdfcpu', 'arlington']:
            q = profiles[checker]
            pin = pins[checker]
            folder = d / checker
            expected = {'result': 'pass', 'profile': P, 'covered-rules': q['required-rules'], 'executable-sha256': pin['sha256'], 'model-sha256': pin.get('model-sha256', 'none'), 'patch-sha256': pin.get('patch-sha256', 'none'), 'input-sha256': h, 'pin-sha256': sha(pinpaths[checker]), 'profile-sha256': sha(C / (checker + '.properties'))}
            eq(props(folder / 'standards.properties'), expected, str(folder) + ' qualified producer/patch/pin binding')
            raw = read(folder / 'findings.txt').decode()
            version, sep, validation = raw.partition('\nValidation exit: ')
            eq(version.startswith('Version exit: 0\n') and pin['version'] in version, True, str(folder) + ' observed version')
            eq(bool(sep) and validation.startswith('0\n'), True, str(folder) + ' original valid product process')
            positive = validation[2:].partition('\nNegative control ')[0].strip()
            eq('validation ok' in positive and 'validating(mode=strict)' in positive if checker == 'pdfcpu' else ' BEGIN - TestGrammar ' in positive and '\nEND\n' in positive and positive.endswith('DONE - 1 files processed') and ('Error:' not in positive) and ('Warning:' not in positive) and ('Info: Processing as PDF 1.7' in positive), True, str(folder) + ' original valid findings')
            for rule in q['required-rules'].split(','):
                control = folder / ('control-' + rule + '.pdf')
                diagfile = folder / ('negative-' + rule + '.txt')
                hcontrol = q['negative.' + rule + '.sha256']
                eq(sha(control), hcontrol, str(control) + ' retained original bytes')
                eq(sha(C / q['negative.' + rule + '.path']), hcontrol, str(control) + ' frozen fixture authority')
                diag = read(diagfile).decode()
                eq(q['negative.' + rule + '.finding'] in diag, True, str(diagfile) + ' required exact rule diagnostic')
                eq(diag.startswith('exit=1\n') if checker == 'pdfcpu' else diag.startswith('exit=0\n') and '\nError: ' in diag, True, str(diagfile) + ' actual checker result')
                eq('Negative control ' + rule + ' sha256=' + hcontrol + ' detected=true' in raw.splitlines(), True, str(diagfile) + ' current qualified control')
                negatives.append({'tuple': name, 'product': edition, 'checker': checker, 'rule': rule, 'control-sha256': hcontrol, 'diagnostic-sha256': sha(diagfile)})
            combined += checker + '\n' + read(folder / 'standards.properties').decode() + raw
        eq(read(d / 'standards.txt').decode(), 'Input exact SHA-256: ' + h + '\n' + combined, str(d) + ' all separate producer raw findings')
        products.append({'tuple': name, 'edition': edition, 'actual-mode': actualmode, 'save-mode': 'REWRITE', 'pdf-sha256': h, 'pages': corpus['products'][product]['pages'], 'destinations': corpus['products'][product]['destinations']})
        for page in range(1, pagecount + 1):
            visual_check(d, product, page, h)
    negative = obs / 'negative'
    eq(props(negative / 'result.properties'), {c: 'fail' for c in chains}, name + ' all negatives detected')
    eq(read(negative / 'invalid.pdf'), b'Intentionally not a PDF.\n', name + ' original nonPDF control')
    syntax_check(negative, 'invalid.pdf', 'fail')
    eq(sha(negative / 'wrong-order.pdf'), sha(obs / 'native-left/pages.pdf'), name + ' actual same-length wrong-order control')
    eq(read(negative / 'semantic.txt').decode(), 'Known left product evaluated as the same-length right product.\nInput exact SHA-256: ' + sha(negative / 'wrong-order.pdf') + '\nFrozen expectation mismatch: page 1 C order/marker\n', name + ' actual public wrong-order failure')
    eq(read(negative / 'standards.txt').decode(), "All 84 original rule-specific illegal PDFs and matching real checker diagnostics are retained under each product's pdfcpu and arlington directories.\nControl result=fail\n", name + ' all rule controls summary')
    v = negative / 'visual'
    eq(sha(v / 'pages.pdf'), sha(obs / 'native-edited/pages.pdf'), name + ' visual product unchanged')
    vp = props(corpusroot / 'visual/edited-page-1.properties')
    eq(props(v / 'one-pixel-control.properties'), dict(vp, EXPECTED_RASTER='one-pixel-control.png', EXPECTED_RASTER_SHA256=sha(v / 'one-pixel-control.png')), name + ' negative only changes expected raster')
    visual_check(v, 'edited', 1, sha(v / 'pages.pdf'), True)
    eq(read(negative / 'visual.txt').decode(), 'A one-pixel change to the original expected raster produced result=fail.\n', name + ' exact onepixel failure summary')
    env = ROOT / ('jdk' + str(major) + '-environment')
    scope_refs = []
    reports = []
    for chain, producer in [('syntax', 'qpdf'), ('standards', 'arlington-t10-r1'), ('semantic', 'folio-pdf-t10'), ('visual', 'pdfium-cli')]:
        rp = scope / (chain + '.yaml')
        jp = scope / (chain + '-report.json')
        record = obj(rp)
        report = obj(jp)
        subset(record, {'schema-version': 1, 'obligation': 'pages', 'acceptance-profile': P, 'release': '0.1.0', 'candidate-sha256': CID, 'contract-sha256': TID, 'environment-sha256': sha(env / 'environment.yaml'), 'execution-configuration-sha256': sha(scope / 'execution.yaml'), 'execution-profile': mode, 'chain': chain, 'result': 'pass', 'producer': producer}, rp)
        eq(record['configuration'], ref(profile), str(rp) + ' current profile')
        eq(record['report'], ref(jp), str(rp) + ' original report')
        eq(record['negative-controls'], report['negative-controls'], str(rp) + ' original controls')
        wanted = {'chain': chain, 'result': 'pass', 'products': [], 'findings': [], 'negative-controls': [ref(negative / (chain + '.txt'))]}
        for edition in editions:
            d = obs / edition
            product = edition.split('-', 1)[1]
            wanted['products'].append(ref(d / 'pages.pdf'))
            wanted['findings'] += [ref(d / (chain + '.txt')), ref(d / 'result.properties')]
            if (d / (chain + '.md')).is_file():
                wanted['findings'].append(ref(d / (chain + '.md')))
            if chain == 'visual':
                for page in range(1, len(corpus['products'][product]['pages']) + 1):
                    for suffix in ['visual.md', 'visual.txt', 'expected.png', 'pdfium.png', 'implementation.png', 'difference.png', 'renderer-difference.png']:
                        wanted['findings'].append(ref(d / ('page-' + str(page) + '-' + suffix)))
            if chain == 'standards':
                for checker in ['pdfcpu', 'arlington']:
                    f = d / checker
                    wanted['findings'] += [ref(f / 'standards.properties'), ref(f / 'findings.txt')]
                    for rule in profiles[checker]['required-rules'].split(','):
                        wanted['negative-controls'] += [ref(f / ('negative-' + rule + '.txt')), ref(f / ('control-' + rule + '.pdf'))]
        if chain == 'syntax':
            wanted['negative-controls'].append(ref(negative / 'invalid.pdf'))
        if chain == 'semantic':
            wanted['negative-controls'].append(ref(negative / 'wrong-order.pdf'))
            wanted['findings'] += [ref(scope / 'contract-tests.txt'), ref(scope / 'contract-tests-command.json')]
        if chain == 'visual':
            wanted['negative-controls'] += [ref(p) for p in sorted((negative / 'visual').rglob('*')) if p.is_file()]
        wanted['environment-observations'] = [ref(p) for p in sorted(env.iterdir()) if p.is_file()]
        eq(report, wanted, str(jp) + ' exact complete ordered report arrays')
        current = list(refs(report, jp))
        scope_refs += current + list(refs(record, rp))
        reports.append({'chain': chain, 'record-sha256': sha(rp), 'report-sha256': sha(jp), 'report-references': len(current), 'counts': {k: len(v) for k, v in report.items() if isinstance(v, list)}})
    allrefs += scope_refs
    tuples.append({'tuple': name, 'physical-files': len(physical), 'observation-files': len([p for p in physical if p.is_relative_to(obs)]), 'original-manifests': len(list(scope.rglob('retained-files.sha256'))), 'reports': reports, 'report-reference-count': sum((r['report-references'] for r in reports)), 'record-report-reference-occurrences': len(scope_refs)})
finish('pages-all-eight-evidence-inspection.json', {'scope': 'All eight actual r4 T10 tuples, completed before inspection; outer/publication excluded', 'tuples': tuples, 'physical-original-file-count': len(physicalrows), 'required-standards-rules': len(rules), 'current-Arlington-model-files': len(model_files), 'qualified-negative-controls': len(negatives), 'positive-public-products': products, 'separate-page-visual-observations': visual, 'T10-producer-manifests-required': False})
dump('original-tuple-file-identities.json', physicalrows)
dump('original-report-reference-identities.json', allrefs)
dump('standards-control-identities.json', negatives)
