from auditlib import *
import subprocess
copies=[]
for name in ['docs/t10-certification.md','docs/page-manipulation.md','capabilities/evidence/T10-page-manipulation-merge-split.md','capabilities/profiles/T10-pages/corpus.json','capabilities/profiles/T10-pages/corpus.properties','capabilities/profiles/T10-standards/pdfcpu.properties','capabilities/profiles/T10-standards/arlington.properties','capabilities/profiles/T10-standards/required-rules.txt','pdf-document/src/test/java/net/zerocloud/pdf/consumer/PageManipulationWorkflowTest.java','pdf-migration-itext7/src/test/java/net/zerocloud/pdf/itext7/consumer/PageManipulationFacadeTest.java']:
 copies.append(copy(REPO/name,'current-schema-source/'+name))
request=read(REPO/'pdf-document/src/test/java/net/zerocloud/pdf/consumer/PageManipulationWorkflowTest.java').decode()
eq('System.getProperty("folio.t10.executionProfile", "IN_PROCESS")' in request,True,'actual existing two-argument default selector')
scope=ROOT/'jdk8-in_process';reports={}
for chain in ['syntax','standards','semantic','visual']:
 record=obj(scope/(chain+'.yaml'));report=obj(scope/(chain+'-report.json'))
 reports[chain]={'record-keys':list(record),'report-keys':list(report),'array-counts':{k:len(v) for k,v in report.items() if isinstance(v,list)},'record-result':record['result'],'candidate':record['candidate-sha256'],'contract':record['contract-sha256']}
 for p in [scope/(chain+'.yaml'),scope/(chain+'-report.json')]:copies.append(copy(p,'initial-complete-tuple/'+p.name))
log=read(scope/'contract-tests.txt').decode();config=obj(scope/'execution.yaml')
original=Path('/tmp/t75-final-spec-pages-eight-btlle2s_');old=obj(original/'receipt.json')
closed=obj(original/'reader-diagnostic-closures.json');copy(original/'reader-diagnostic-closures.json','prior-reader-diagnostic-closures.json')
command=['rg','--files','capabilities/evidence/T75-delivery/certification-review-r4','-g','values*']
r=subprocess.run(command,cwd=REPO,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
with (OUT/'prior-values-filename-discovery-stdout.txt').open('xb') as h:h.write(r.stdout)
with (OUT/'prior-values-filename-discovery-stderr.txt').open('xb') as h:h.write(r.stderr)
dump('prior-values-filename-discovery-command.json',{'command':command,'cwd':str(REPO)})
dump('prior-values-filename-discovery-result.json',{'returncode':r.returncode,'stdout-sha256':hashlib.sha256(r.stdout).hexdigest(),'stderr-sha256':hashlib.sha256(r.stderr).hexdigest()})
eq(r.returncode,0,'read-only prior values archive filename discovery')
finish('initial-schema-inspection.json',{'scope':'Read only completed JDK8 IN_PROCESS raw header and current frozen T10 source/contract; JDK21 Worker/AFTER/root index excluded pending notice','reports':reports,'formal-original-log':log,'configuration-keys':list(config),'configuration-input-count':len(config['inputs']),'selected-copies':copies,'actual-existing-selector':'System.getProperty("folio.t10.executionProfile", "IN_PROCESS")','historical-reader-closures-retained':True,'prior-receipt-keys':list(old),'prior-values-retention-filenames':r.stdout.decode().splitlines(),'optional-T13-or-README-fields-required':False,'auxiliary-display-note':'The model-facing print of the already byte-retained prior stage-all-eight-audit.py hit a 2200-token return cap. The complete source copy remains retained; no certification/derived review original was lost. No extra replay required.'})
print(json.dumps({'current-first-tuple-report-schemas':reports,'prior-values-filenames':r.stdout.decode().splitlines()},ensure_ascii=False))
