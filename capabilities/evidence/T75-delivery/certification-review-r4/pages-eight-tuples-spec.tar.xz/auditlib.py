from pathlib import Path,PurePosixPath
import hashlib,json,re,datetime
REPO=Path('/home/ubuntu/IdeaProjects/open-pdf');OUT=Path(__file__).parent
ROOT=REPO/'capabilities/evidence/T75-foundation-20260914-r4/pages'
TUPLES=[(j,m) for j in [8,11,17,21] for m in ['IN_PROCESS','HARDENED_WORKER']]
files={};errors=[]
def error(where,detail):errors.append({'where':str(where),'detail':detail})
def read(p):
 p=Path(p)
 if p.is_relative_to(ROOT.parent) and not p.is_relative_to(ROOT) and not (p.name=='observed-index.json' and p.parent.name in ['text','transactions','values']):raise ValueError('Excluded other-obligation raw '+str(p))
 if p.is_relative_to(ROOT):
  relative=p.relative_to(ROOT)
  if relative.parts and (relative.parts[0] in ['jdk21-hardened_worker','jdk21-environment-after'] or relative.as_posix() in ['observed-index.json','identities.json','prior-index.sha256']):
   notice=OUT/'all-eight-reading-authorized.json'
   if not notice.is_file() or not json.loads(notice.read_bytes())['parent-confirmed-complete']:raise ValueError('Last tuple / final root not yet authorized '+str(p))
 data=p.read_bytes();row={'path':str(p),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
 if str(p) in files and files[str(p)]!=row:error(p,'bytes changed during reader')
 files[str(p)]=row;return data
def sha(p):return hashlib.sha256(read(p)).hexdigest()
def obj(p):return json.loads(read(p))
def props(p):
 result={}
 for line in read(p).decode('utf-8').splitlines():
  if not line or line[0] in '#!':continue
  key,sep,val=line.partition('=')
  if not sep or key in result:error(p,'duplicate or malformed property '+key);continue
  result[key]=re.sub(r'\\(u[0-9a-fA-F]{4}|.)',lambda m:chr(int(m[1][1:],16)) if m[1].startswith('u') and len(m[1])==5 else {'t':'\t','n':'\n','r':'\r','f':'\f'}.get(m[1],m[1]),val)
 return result
def eq(a,b,w):
 if a!=b:error(w,{'actual':a,'expected':b})
def subset(actual,expected,where):
 for k,v in expected.items():eq(actual.get(k),v,str(where)+':'+k)
def lines_hash(t):return hashlib.sha256(t.encode()).hexdigest()
def dump(name,data):
 with (OUT/name).open('x') as h:json.dump(data,h,ensure_ascii=False,indent=2);h.write('\n')
def finish(name,data):
 data['errors']=errors;dump(name,data);dump(name.removesuffix('.json')+'-read-identities.json',list(files.values()))
 print(json.dumps({'file':name,'read-files':len(files),'error-count':len(errors),'first-errors':errors[:3]},ensure_ascii=False))
 if errors:raise SystemExit(1)
def copy(p,name):
 data=read(p);q=OUT/'originals'/name;q.parent.mkdir(parents=True,exist_ok=True)
 with q.open('xb') as h:h.write(data)
 return {'original':str(p),'copy':str(q.relative_to(OUT)),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
