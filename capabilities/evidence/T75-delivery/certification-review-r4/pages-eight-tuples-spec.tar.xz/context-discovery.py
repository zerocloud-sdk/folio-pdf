from auditlib import *
D=REPO/'capabilities/evidence/T75-delivery/certification-review-r4'
receipts={};copies=[]
for obligation in ['text','transactions','values']:
 prefix=obligation+'-publication-spec'
 for suffix in ['report.md','receipt.json','archive-identity.json']:
  p=D/(prefix+'-'+suffix)
  copies.append(copy(p,Path('prior-publication-linkage')/p.name))
  if suffix=='receipt.json':receipts[obligation]=obj(p)
 indexes=ROOT.parent/obligation/'observed-index.json'
 copies.append(copy(indexes,Path('prior-publication-linkage')/(obligation+'-observed-index.json')))
priorindex=read(ROOT/'prior-index.sha256').decode().strip()
def describe(value):
 if isinstance(value,dict):return {'type':'object','keys':list(value),'scalars':{k:v for k,v in value.items() if v is None or isinstance(v,(str,int,float,bool))},'arrays':{k:len(v) for k,v in value.items() if isinstance(v,list)}}
 return {'type':type(value).__name__,'length':len(value) if isinstance(value,(str,list)) else None}
views={k:{'top':describe(v),'objects':{n:describe(x) for n,x in v.items() if isinstance(x,dict)}} for k,v in receipts.items()}
audits={}
for name in ['pages-all-eight-evidence-inspection.json','stage-environment-contract-all-eight-inspection.json','complete-config-and-index-inspection.json','complete-rgb-raster-inspection.json']:
 v=obj(OUT/name);audits[name]={'top':describe(v),'sample-arrays':{k:v[:1] for k,v in v.items() if isinstance(v,list) and k!='errors'}}
finish('context-discovery-inspection.json',{'prior-pages-index-sha256':priorindex,'prior-publication-receipt-actual-fields':views,'current-audit-fields':audits,'selected-originals':copies,'boundary':'Schema inspection and stable prior linkage originals; no old raw replay and no pages actual outer/publication inspection.'})
