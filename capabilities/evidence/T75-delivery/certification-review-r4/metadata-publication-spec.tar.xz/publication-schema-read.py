from auditlib import *
for name in ['metadata-eight-tuples-spec-archive-identity.json','pages-publication-spec-archive-identity.json']:
 q=REPO/'capabilities/evidence/T75-delivery/certification-review-r4'/name;o=obj(q);print(name,'keys',list(o),'firstmember',o['members'][0],'scalars',{k:v for k,v in o.items() if not isinstance(v,(dict,list))})
p=Path('/tmp/t75-final-spec-r4-pages-publication-blveufbw/archive-manifest.json');o=obj(p);print('PAGE_MANIFEST_MEMBER',o['members'][0],'excludes',o['excludes'])
for n in ['authority-at-retention.yaml','observed-index.json']:
 o=obj(Path('/tmp/t75-final-metadata-certified-r4-1jfzac5p')/n);print(n,'keys',list(o),'certifications',len(o['certifications']),'first-environment',o['environments'][0]);print('firstcertkeys',list(o['certifications'][0]))
p=Path('/tmp/t75-r4-values-publication-spec-fbsksqo5/publication-audit.py');s=read(p).decode();print(s[11000:])
p=Path('/tmp/t75-final-metadata-certified-r4-1jfzac5p/t75-run-retained.py');print('ORIGINAL_WRAPPER',read(p).decode())
p=REPO/'scripts/t03-foundation.py';s=read(p).decode();lines=s.splitlines()
for i,l in enumerate(lines):
 if 'Recorded exactly eight' in l or ' environment JDK ' in l or ' certification JDK ' in l:print('RUNNER_PROTOCOL',i+1,'\n'.join(lines[max(0,i-3):i+5]))
