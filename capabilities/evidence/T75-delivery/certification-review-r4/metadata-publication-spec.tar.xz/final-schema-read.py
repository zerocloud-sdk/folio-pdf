from auditlib import *
q=Path('/tmp/t75-final-metadata-certified-r4-1jfzac5p/receipt.json');o=obj(q);print('TUPLE_RECEIPT',o['tuples'][0])
q=Path('/tmp/t75-r4-values-publication-spec-fbsksqo5/publication-audit.py');s=read(q).decode();print(s[6300:11100])
q=Path('/tmp/t75-r4-metadata-spec-qm8qa5w2/final-input-catalog.json');o=obj(q);print('RAW_INPUT_CATALOG_TYPE',type(o).__name__,'COUNT',len(o),'FIRST_SCHEMA',list(o[0]));q=Path('/tmp/t75-r4-metadata-spec-qm8qa5w2/final-complete-scope-inspection.json');o=obj(q);print('RAW_SCOPE_SCALARS',{k:v for k,v in o.items() if isinstance(v,(bool,int,str))})
