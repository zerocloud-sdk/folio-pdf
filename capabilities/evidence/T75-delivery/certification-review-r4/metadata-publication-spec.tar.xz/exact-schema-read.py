from auditlib import *
import tarfile
base=Path('/tmp/t75-final-metadata-certified-r4-1jfzac5p')
for name in ['command.json','result.json','receipt.json']:
 o=obj(base/name)
 if name=='receipt.json':o={k:o[k] for k in ['actual-result','authority-counts','original-copies']}
 print('ACTUAL',name,json.dumps(o,indent=2))
print('ACTUAL FULL LOG',read(base/'command.log').decode())
a=REPO/'capabilities/evidence/T75-delivery/final-certification-r4/metadata-command-archive-identity.json';o=obj(a);print('ARCHIVE_IDENTITY',json.dumps(o,indent=2))
q=Path('/tmp/t75-final-spec-r4-pages-publication-blveufbw/receipt.json');o=obj(q)
for k in ['dated-authority','current-final-authority-observation','approvals','closed-prior-publications']:print('PRIOR_PAGES',k,json.dumps(o[k],indent=2))
q=Path('/tmp/t75-final-spec-r4-pages-publication-blveufbw/archive-manifest.json');o=obj(q);print('PAGES_MANIFEST_SCHEMA',list(o),{k:v for k,v in o.items() if not isinstance(v,(dict,list))});print('PAGES_FIRST_ROW',o.get('files',[None])[0])
for name in ['metadata-command.tar.xz']:
 q=REPO/'capabilities/evidence/T75-delivery/final-certification-r4'/name;read(q)
 with tarfile.open(q,'r:xz') as tar:print('COMMAND_ARCHIVE_MEMBERS',[(m.name,m.size,m.isfile()) for m in tar.getmembers()])
for name in ['metadata-eight-tuples-spec.tar.xz','pages-publication-spec.tar.xz']:
 q=REPO/'capabilities/evidence/T75-delivery/certification-review-r4'/name;print('REVIEW_ARCHIVE',name,q.is_file())
q=Path('/tmp/t75-r4-values-publication-spec-fbsksqo5/publication-audit.py');s=read(q).decode();print('PRIOR_READER_BYTES',len(s));print(s[:11000])
