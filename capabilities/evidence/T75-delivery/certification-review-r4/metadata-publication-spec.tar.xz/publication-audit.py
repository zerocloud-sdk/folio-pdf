from auditlib import *
from pathlib import PurePosixPath
from collections import Counter
import tarfile,io,re,datetime
AUTH=obj(OUT/'authorization.json');CID=AUTH['candidate'];TID=AUTH['contract'];RAW=Path(AUTH['raw-packet']);PAGES=Path(AUTH['prior-pages-packet']);retain=Path(AUTH['actual-outer-originals']);delivery=REPO/'capabilities/evidence/T75-delivery';cert=delivery/'final-certification-r4';reviews=delivery/'certification-review-r4'
def require(condition,label):assert condition,label
def ref(path):return {'path':str(path.relative_to(REPO)),'sha256':sha(path)}
rawpins={'report.md':'3ab3146ed407f2ffa8b2a894167d153e4f3d9278acdd5406b6f728d2a0974e14','receipt.json':'edd0394ffe3fe5a22b5b20678ad3f3470b6e06c5705d9e1fb14fed79d3455290','final-input-catalog.json':'da36e83bff31ba0146c79123384b50d702e4312777e2ddc8af68275fb4109e1f','artifact-manifest.json':'ae7277bb24484099f6df82e9a5e297e8d3a07b157c133186d9cd9d2dcafc13f2'}
for name,h in rawpins.items():require(sha(RAW/name)==h,'sealed raw packet pin '+name)
rawreceipt=obj(RAW/'receipt.json');require(rawreceipt['findings']==[] and rawreceipt['approvals']['metadata-eight-raw-and-own-index'] is True,'raw8 own-index independently closed');require(rawreceipt['candidate-sha256']==CID and rawreceipt['contract-sha256']==TID,'same closed raw identities');rawcatalog={r['path']:r for r in obj(RAW/'final-input-catalog.json')}
def unchanged(path,label):require(sha(path)==rawcatalog[str(path)]['sha256'],'same sealed raw input '+label)
archives=[]
def archive_check(archive,idpath,pin,original,count):
 ident=obj(idpath);require(ident['original']==str(original) and ident['archive']==archive.name and ident['sha256']==pin,'archive declaration '+archive.name);data=read(archive);require(hashlib.sha256(data).hexdigest()==pin,'archive exact hash '+archive.name);rows=[]
 with tarfile.open(fileobj=io.BytesIO(data),mode='r:xz') as tar:
  for member in tar.getmembers():
   name=member.name;q=PurePosixPath(name);require(member.isfile() and not q.is_absolute() and '..' not in q.parts and q.as_posix()==name,'regular canonical archived original '+name);payload=tar.extractfile(member).read();require(read(original/name)==payload,'complete archived/original bytes '+str(original/name));rows.append({'path':name,'size':len(payload),'sha256':hashlib.sha256(payload).hexdigest()})
 require(len(rows)==count and len({r['path'] for r in rows})==count,'archive complete unique members '+archive.name);require(rows==ident['members'] and ident['symbolic_links']==[],'archive exact member catalog '+archive.name);require({str(q.relative_to(original)) for q in original.rglob('*') if q.is_file()}=={r['path'] for r in rows},'no missing original archive member '+archive.name);archives.append({'archive':ref(archive),'identity':ref(idpath),'original':str(original),'member-count':count,'members':rows});return {r['path']:r for r in rows}
rawmembers=archive_check(reviews/'metadata-eight-tuples-spec.tar.xz',reviews/'metadata-eight-tuples-spec-archive-identity.json',AUTH['raw-archive-sha256'],RAW,537)
pagemembers=archive_check(reviews/'pages-publication-spec.tar.xz',reviews/'pages-publication-spec-archive-identity.json',AUTH['prior-pages-archive-sha256'],PAGES,504)
commandmembers=archive_check(cert/'metadata-command.tar.xz',cert/'metadata-command-archive-identity.json',AUTH['command-archive-sha256'],retain,10)
for base,name,key,members,count in [(RAW,'artifact-manifest.json','files',rawmembers,536),(PAGES,'archive-manifest.json','members',pagemembers,503)]:
 manifest=obj(base/name);require(manifest['excludes']==[name],'exact manifest self exclusion '+str(base));rows=manifest[key];require(len(rows)==count and {r['path'] for r in rows}==set(members)-{name},'manifest binds every retained artifact '+str(base))
 for row in rows:require(row['sha256']==members[row['path']]['sha256'] and row['bytes']==members[row['path']]['size'],'manifest exact bytes '+row['path'])
for label,base in [('metadata-eight-tuples-spec',RAW),('pages-publication-spec',PAGES)]:
 for name in ['report.md','receipt.json']:require(read(base/name)==read(reviews/(label+'-'+name)),'unchanged adjacent review original '+label+'/'+name)
pages=obj(PAGES/'receipt.json');require(pages['findings']==[] and pages['candidate']==CID and pages['contract']==TID,'closed prior pages same identity no findings')
for key in ['pages-actual-outer-exit','pages-eight-exact-publication','existing-text8-transactions8-values8-preservation']:require(pages['approvals'][key] is True,'closed prior publication '+key)
command=obj(retain/'command.json');result=obj(retain/'result.json');log=read(retain/'command.log').decode();receipt=obj(retain/'receipt.json');expectedcommand=['/usr/bin/python3','scripts/t03-foundation.py','certify','capabilities/evidence/T75-foundation-20260914-r4/metadata','--obligation','metadata'];require(command['command']==expectedcommand and command['cwd']==str(REPO),'actual command exact authorized metadata execution');require(command['started-utc']=='2026-09-13T21:32:39.670650+00:00','actual start time');require(result==dict(command,**{'command-pid':545120,'returncode':0,'completed-utc':'2026-09-13T22:22:04.297720+00:00'}),'actual completed outer result');require(receipt['actual-result']==result and receipt['actual-exit']==0,'retention actual result');require(receipt['candidate']==CID and receipt['contract']==TID,'retention same candidate and contract');require(receipt['observed-tuples']==8 and receipt['matching-pass-records']==32 and receipt['published-subsets-exactly-match-own-observed-indexes'] is True,'retention complete8/32 observations');require(receipt['authority-counts']=={k:8 for k in ['text','transactions','values','pages','metadata']},'actual dated40 count receipt')
expectedlines=[]
for major in [8,11,17,21]:
 expectedlines.append(f'T11 environment JDK {major}')
 for mode in ['IN_PROCESS','HARDENED_WORKER']:expectedlines.append(f'T11 certification JDK {major} / {mode}')
expectedlines.append('Recorded exactly eight T11 certifications; retained 32 current certifications for other obligations.');require(log=='\n'.join(expectedlines)+'\n','complete original13line outer protocol')
for a,b in [('command.json','metadata-command.json'),('result.json','metadata-result.json'),('command.log','metadata-command.log'),('receipt.json','metadata-receipt.json')]:require(read(retain/a)==read(cert/b),'exact adjacent command retention '+b)
for row in receipt['original-copies']:
 data=read(retain/row['copy']);require(len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'],'exact original copy identity '+row['copy'])
 if row['copy']!='authority-at-retention.yaml':require(read(Path(row['original']))==data,'original retained bytes remain unchanged '+row['original'])
source=read(REPO/'scripts/t03-foundation.py').decode();unchanged(REPO/'scripts/t03-foundation.py','runner source');wrapper=read(retain/'t75-run-retained.py').decode()
for token in ["run_logged(test_command, scope / 'contract-tests.txt'",'merged = publish_index(root, output)','os.replace(prepared, authority)','if authority.read_bytes() != previous_bytes:','os.fsync(descriptor)',"verified['certifications'] != fresh['certifications']"]:require(token in source,'existing actual publication/retention protocol '+token)
require('stderr=subprocess.STDOUT' in wrapper and "result['returncode'] = process.wait()" in wrapper,'outer actual merged output and child wait returncode')
stage=delivery/'final-candidate-r4/build-inputs.json';unchanged(stage,'frozen stage declaration');build=obj(stage);counts={}
for label,rows in {'sources':build['candidate']['inputs'],'contracts':build['contract-inputs'],'artifacts':build['candidate']['artifacts'],'harness':build['harness']}.items():
 counts[label]=len(rows)
 for row in rows:require(sha(REPO/row['path'])==row['sha256']==rawcatalog[str(REPO/row['path'])]['sha256'],'complete current staged identity '+row['path'])
require(counts=={'sources':1933,'contracts':30,'artifacts':23,'harness':24},'exact staged1933/30/23/24 input counts')
own=obj(ROOT/'observed-index.json');unchanged(ROOT/'observed-index.json','metadata own index');require(own['candidate']==build['candidate'],'actual own index exact current stage candidate');require(read(ROOT/'observed-index.json')==read(retain/'observed-index.json'),'retained exact own metadata index');require(obj(ROOT/'identities.json')=={'Candidate':CID,'Contract':TID},'actual observed identities')
for name in ['candidate-probe.json','candidate-identity.txt','identities.json','prior-index.sha256']:unchanged(ROOT/name,'actual root schema '+name)
priorpath=Path(pages['dated-authority']['path']);prior=obj(priorpath);require(sha(priorpath)==pages['dated-authority']['sha256'],'exact closed prior32 authority');require(read(ROOT/'prior-index.sha256').decode().strip()==sha(priorpath),'metadata actual prior publication guard');require(prior['candidate']==own['candidate'],'same prior staged candidate')
indexes={'metadata':own};priorlinks=[]
for previous in pages['closed-prior-publications']:
 label=previous['obligation'];p=ROOT.parent/label/'observed-index.json';require(sha(p)==previous['own-index-sha256'],'unchanged closed prior own index '+label);indexes[label]=obj(p);base=Path(previous['original-directory'])
 for name,key in [('report.md','report-sha256'),('receipt.json','receipt-sha256')]:require(sha(base/name)==previous[key],'closed previous report/receipt link '+label+'/'+name)
 priorlinks.append(previous)
p=ROOT.parent/'pages/observed-index.json';require(sha(p)==pages['own-pages-index-sha256'],'unchanged closed pages own index');indexes['pages']=obj(p)
for label in ['text','transactions','values','pages']:require([c for c in prior['certifications'] if c['obligation']==label]==indexes[label]['certifications'],'prior exact independently closed subset '+label)
dated=obj(retain/'authority-at-retention.yaml');require(dated==dict(own,certifications=prior['certifications']+own['certifications']),'exact dated publication: prior32 plus metadata8 and current own environment records');require(Counter(c['obligation'] for c in dated['certifications'])==Counter({k:8 for k in indexes}),'exact five dated subsets')
started=datetime.datetime.now(datetime.timezone.utc).isoformat();authoritypath=REPO/'capabilities/foundation-evidence.yaml';authoritybytes=read(authoritypath);snapshot=OUT/'authority-current-observation.yaml'
with snapshot.open('xb') as f:f.write(authoritybytes)
completed=datetime.datetime.now(datetime.timezone.utc).isoformat();current=obj(snapshot);require(current['candidate']==own['candidate'],'current observed same candidate')
for label,index in indexes.items():require([c for c in current['certifications'] if c['obligation']==label]==index['certifications'],'current preserved exact published subset '+label)
require({e['profile']:e['record']['sha256'] for e in current['environments']}=={e['profile']:e['record']['sha256'] for e in own['environments']},'current environment identity matches reviewed four JDKs; later paths are not followed')
priorrecords=[];priorconfigs=[]
for label in ['text','transactions','values','pages']:
 for c in indexes[label]['certifications']:
  require(sha(REPO/c['configuration']['path'])==c['configuration']['sha256'],'existing exact prior configuration '+label);priorconfigs.append(c['configuration'])
  for record in c['records']:
   require(sha(REPO/record['path'])==record['sha256'],'existing exact prior PASS record '+label);priorrecords.append(record)
configs=[];records=[];transcripts=[];envs=[];report_ref_occurrences=0
def bind_reference_catalog(value):
 global report_ref_occurrences
 if isinstance(value,dict):
  if isinstance(value.get('path'),str) and isinstance(value.get('sha256'),str):
   q=PurePosixPath(value['path']);require(not q.is_absolute() and '..' not in q.parts and q.as_posix()==value['path'],'canonical report reference');require(rawcatalog[str(REPO/value['path'])]['sha256']==value['sha256'],'same sealed raw referenced identity '+value['path']);report_ref_occurrences+=1
  for item in value.values():bind_reference_catalog(item)
 elif isinstance(value,list):
  for item in value:bind_reference_catalog(item)
for c in own['certifications']:
 confpath=REPO/c['configuration']['path'];scope=confpath.parent;unchanged(confpath,'complete configuration');require(sha(confpath)==c['configuration']['sha256'],'published exact configuration');conf=obj(confpath);require(conf['candidate-sha256']==CID and conf['execution-profile']==c['execution-profile'],'actual Native execution identity');require(conf['settings']['providers']=='none; Stable Facade execution is IN_PROCESS','actual Facade mode retained');configs.append(c['configuration'])
 for name in ['contract-tests-command.json','contract-tests.txt']:unchanged(scope/name,'complete original formal command/transcript')
 txt=read(scope/'contract-tests.txt').decode();require(txt.startswith('JUnit version 4.13.2\n') and re.search(r'\nTime: ([0-9.]+)\n\nOK \(73 tests\)\n\n\Z',txt) and 'FAILURES!!!' not in txt,'actual complete73 formal transcript');transcripts.append({'scope':str(scope.relative_to(REPO)),'formal-tests':73,'seconds':float(re.search(r'Time: ([0-9.]+)',txt)[1])})
 for r in c['records']:
  path=REPO/r['path'];unchanged(path,'actual published metadata chain');require(sha(path)==r['sha256'],'published exact metadata record');record=obj(path)
  for key,expected in {'result':'pass','obligation':'metadata','candidate-sha256':CID,'contract-sha256':TID,'execution-profile':c['execution-profile'],'execution-configuration-sha256':c['configuration']['sha256']}.items():require(record[key]==expected,'actual metadata record field '+key)
  reportpath=REPO/record['report']['path'];unchanged(reportpath,'actual original metadata report');require(sha(reportpath)==record['report']['sha256'],'actual metadata report exact hash');bind_reference_catalog(record);bind_reference_catalog(obj(reportpath));records.append({'record':r,'report':record['report'],'chain':record['chain'],'execution-profile':record['execution-profile']})
require(transcripts==receipt['tuples'],'original retained tuple counts/times match complete formal logs')
for major in [8,11,17,21]:
 for suffix in ['', '-after']:
  directory=ROOT/f'jdk{major}-environment{suffix}';rows=[]
  for p in sorted(directory.iterdir()):
   if p.is_file():unchanged(p,'complete original BEFORE/AFTER environment');rows.append(ref(p))
  envs.append({'directory':str(directory.relative_to(REPO)),'files':rows})
require(sum(len(e['files']) for e in envs)==84 and len(records)==32 and len(configs)==8,'all metadata8/32/84 identities');require(len(priorrecords)==128 and len(priorconfigs)==32,'prior32 configurations and128 records unchanged')
put('archive-member-catalog.json',archives)
put('publication-inspection.json',{'scope':'Metadata actual outer exit/publication and exact preservation of prior text8/transactions8/values8/pages8 only','candidate':CID,'contract':TID,'actual-command':command,'actual-result':result,'complete-outer-log-sha256':sha(retain/'command.log'),'complete-outer-log-lines':13,'outer-stderr-policy':'Merged into original command.log by retained actual wrapper. Per-tuple73-test details remain in their complete original contract-tests.txt, not repeated in outer progress output.','actual-command-retention':archives[2],'closed-raw-review':{'directory':str(RAW),'pins':rawpins,'archive-sha256':AUTH['raw-archive-sha256'],'original-members':537},'closed-pages-publication':{'directory':str(PAGES),'archive-sha256':AUTH['prior-pages-archive-sha256'],'original-members':504,'report-sha256':sha(PAGES/'report.md'),'receipt-sha256':sha(PAGES/'receipt.json')},'closed-prior-links':priorlinks,'dated-authority':{'path':str(retain/'authority-at-retention.yaml'),'sha256':sha(retain/'authority-at-retention.yaml'),'exact-subsets':{k:8 for k in ['text','transactions','values','pages','metadata']}},'prior-authority':{'path':str(priorpath),'sha256':sha(priorpath)},'current-authority-observation':{'original':str(authoritypath),'started-utc':started,'completed-utc':completed,'snapshot':str(snapshot.relative_to(OUT)),'sha256':sha(snapshot),'reviewed-exact-subsets':{k:8 for k in indexes},'observed-total-certifications':len(current['certifications']),'other-obligations-excluded':sorted({c['obligation'] for c in current['certifications']}-set(indexes)),'mutable-original-not-a-frozen-input':True},'current-stage-input-counts':counts,'metadata-configurations':configs,'metadata-records-and-reports':records,'sealed-raw-reference-occurrences-bound-without-replay':report_ref_occurrences,'formal-transcripts':transcripts,'before-after-environments':envs,'prior-preserved-configurations':priorconfigs,'prior-preserved-records':priorrecords,'raw-rule-or-RGB-replayed':False,'five-file-inventory-source-review-repeated':False,'repository-mutations':False,'project-executions':False,'findings':[],'deferred':['annotations','final48/inventory/index/readiness/delivery','completion criteria marks']})
print(json.dumps({'actual-outer-exit':0,'exact-publication':40,'metadata-records':32,'previous-records-preserved':128,'metadata-environment-files':84,'archive-members':[537,504,10],'findings':0,'inputs':len(FILES)}))
