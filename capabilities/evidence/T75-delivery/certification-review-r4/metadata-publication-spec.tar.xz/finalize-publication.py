from auditlib import *
import datetime
inspection=obj(OUT/'publication-inspection.json');assert inspection['findings']==[];assert obj(OUT/'publication-check.result.json')['actual_exit']==0
assert read(OUT/'fixed-head-check.stdout.txt').decode().strip()=='5b1603c435f11c40368f75b7b9a2777c9c5e9761'
assert read(OUT/'canonical-baseline-diff-check.stdout.txt')==b''
observed={};phasecatalogs=[]
for p in sorted(OUT.glob('*-input-catalog.json')):
 phasecatalogs.append(identity(p))
 for row in obj(p):
  if row['path'] in observed:assert observed[row['path']]['sha256']==row['sha256'],'changed original across phases '+row['path']
  observed[row['path']]=row
mutable=inspection['current-authority-observation']['original'];checked=0
for row in list(observed.values()):
 if row['path']==mutable:continue
 assert sha(Path(row['path']))==row['sha256'],'immutable reviewed input changed '+row['path'];checked+=1
commands=[]
for path in sorted(OUT.glob('*.command.json')):
 label=path.name[:-len('.command.json')]
 if label=='publication-finalize':continue
 result=obj(OUT/(label+'.result.json'));assert result['actual_exit']==0
 commands.append({'label':label,'command':identity(path),'stdout':identity(OUT/(label+'.stdout.txt')),'stderr':identity(OUT/(label+'.stderr.txt')),'actual-result':identity(OUT/(label+'.result.json')),'actual-exit':0})
selected=[]
def copy_original(source,relative):
 data=read(source);dest=OUT/'selected-originals'/relative;dest.parent.mkdir(parents=True,exist_ok=True)
 with dest.open('xb') as f:f.write(data)
 selected.append({'source':str(source),'copy':str(dest.relative_to(OUT)),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
retain=Path('/tmp/t75-final-metadata-certified-r4-1jfzac5p')
for path in sorted(retain.iterdir()):
 if path.is_file():copy_original(path,Path('actual-command')/path.name)
for label,base in [('closed-metadata-raw',Path('/tmp/t75-r4-metadata-spec-qm8qa5w2')),('closed-pages-publication',Path('/tmp/t75-final-spec-r4-pages-publication-blveufbw'))]:
 for name in ['report.md','receipt.json']:copy_original(base/name,Path(label)/name)
context=[Path('/home/ubuntu/.codex/attachments/77353239-0dda-4ee1-b4bb-ce7fb3fa0f9b/pasted-text-1.txt')]+[REPO/name for name in ['AGENTS.md','CONTRIBUTING.md','docs/agents/issue-tracker.md','docs/t11-certification.md']]
for path in context:copy_original(path,Path('context')/(path.relative_to(REPO) if path.is_relative_to(REPO) else Path('originating-goal.txt')))
copy_original(REPO/'capabilities/evidence/T75-delivery/final-candidate-r4/build-inputs.json',Path('current-stage/build-inputs.json'))
put('selected-original-catalog.json',selected)
inputs={**observed,**FILES};inputs[mutable]={**inputs[mutable],'mutable-original':True,'observation':inspection['current-authority-observation'],'final-immutable-recheck-excluded':True};rows=[inputs[k] for k in sorted(inputs)];put('input-catalog.json',{'schema-version':1,'file-count':len(rows),'immutable-originals-rechecked':checked,'mutable-authority-observations':1,'files':rows})
put('final-integrity-inspection.json',{'findings':[],'completed-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'phase-input-catalogs':phasecatalogs,'distinct-phase-inputs':len(observed),'immutable-inputs-rechecked':checked,'mutable-authority-observations':1,'complete-input-catalog-count':len(rows),'original-authority-observation':inspection['current-authority-observation'],'selected-original-copies':len(selected),'decisive-reader-results':commands,'scope':'Exact publication and original byte identities only; no raw-rule/RGB or five-file source review replay.'})
report="""No findings. Metadata/T11's actual outer exit and eight-certification publication are independently closed under Goal step 5's refresh requirement and `docs/t11-certification.md` lines 111–120. Annotations, the full set of 48 certifications, inventory/index/readiness, delivery and completion marks remain deferred.

The original command completed with actual exit 0 from `2026-09-13T21:32:39.670650Z` to `2026-09-13T22:22:04.297720Z`. Its entire 13-line progress/completion output matches the existing protocol. The retained wrapper merges stderr into that log and records the child process's actual wait result. Detailed 73-test transcripts remain in each tuple's original `contract-tests.txt`; no duplicate outer transcript is required. All ten command-retention originals exactly match their archive and adjacent copies.

The dated authority is exactly the previous text/transactions/values/pages 32 certifications plus metadata's eight, with the current own-index environments. Metadata's prior-index guard matches the independently closed pages authority. A subsequent current-authority snapshot preserves all five exact subsets: 40 certifications. All 32 prior configurations and 128 prior chain records remain byte-identical to their previously reviewed indexes.

Metadata's eight configurations, 32 PASS records/reports, 84 BEFORE/AFTER environment files and eight complete formal transcripts remain bound to the sealed raw review. Every report reference matches its reviewed input catalog. Facade remains actual IN_PROCESS; Native retains both profiles. Current 1,933 source, 30 contract, 23 artifact and 24 harness hashes retain candidate `ab18cc9c0473730a6aabec5d12e3172f22bea23a0a0f9529052a2bc186cbfc1b` and contract `3de508f79fcbef7258feee8abc013d6f02b000840cac1cb263cb0d6f927b8f2b`.

The sealed metadata raw review's 537 originals and preceding pages publication review's 504 originals match their archives completely. No raw-rule/RGB qualification or five-file inventory correction was replayed. No project execution or repository mutation occurred. The previously disclosed historical derived-summary loss remains unchanged; no recovery is claimed.
"""
assert len(report.split())<400;put('report.md',report)
def packetid(name):
 row=identity(OUT/name);return dict(row,path=name)
put('receipt.json',{'sealed-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'review-axis':'Spec','scope':inspection['scope'],'baseline':'5b1603c435f11c40368f75b7b9a2777c9c5e9761','observed-head':'5b1603c435f11c40368f75b7b9a2777c9c5e9761','canonical-committed-diff-empty':True,'explicit-uncommitted-publication-scope':True,'candidate':inspection['candidate'],'contract':inspection['contract'],'findings':[],'report':packetid('report.md'),'report-word-count':len(report.split()),'actual-command':inspection['actual-command'],'actual-result':inspection['actual-result'],'complete-original-outer-log-sha256':inspection['complete-outer-log-sha256'],'complete-original-outer-log-lines':13,'outer-stderr-policy':inspection['outer-stderr-policy'],'actual-command-retention':inspection['actual-command-retention'],'closed-raw-review':inspection['closed-raw-review'],'closed-pages-publication':inspection['closed-pages-publication'],'closed-prior-links':inspection['closed-prior-links'],'dated-authority':inspection['dated-authority'],'prior-authority':inspection['prior-authority'],'current-authority-observation':inspection['current-authority-observation'],'current-stage-input-counts':inspection['current-stage-input-counts'],'metadata-configuration-count':8,'metadata-record-report-count':32,'metadata-environment-files':84,'prior-preserved-configuration-count':32,'prior-preserved-record-count':128,'formal-transcripts':inspection['formal-transcripts'],'sealed-raw-reference-occurrences-bound':inspection['sealed-raw-reference-occurrences-bound-without-replay'],'publication-inspection':packetid('publication-inspection.json'),'archive-member-catalog':packetid('archive-member-catalog.json'),'input-catalog':packetid('input-catalog.json'),'input-file-count':len(rows),'immutable-inputs-rechecked':checked,'final-integrity-inspection':packetid('final-integrity-inspection.json'),'selected-original-copies':packetid('selected-original-catalog.json'),'selected-original-copy-count':len(selected),'actual-reader-commands':commands,'reader-diagnostics':[],'approvals':{'metadata-actual-outer-exit':True,'metadata-eight-exact-publication':True,'existing-text8-transactions8-values8-pages8-preserved':True,'annotations':False,'final48-inventory-index-readiness-delivery':False,'completion-criteria-marked':False},'repository-mutations':False,'project-executions':False,'raw-rule-or-RGB-replayed':False,'five-file-source-review-repeated':False,'historical-boundary':'The previously disclosed r3 loss of two derived annotations summaries remains unchanged; no recovery is claimed. Historical raw is neither replayed nor required at deleted live paths.','retention':{'manifest':'artifact-manifest.json','manifest-excludes':['artifact-manifest.json'],'current-finalizer-envelope':'Retained by run.py after this finalizer exits; complete command/stdout/stderr/actual-result included in the final artifact manifest.','temporal-progress-docs':'Dated snapshots represent their actual observation times; later canonical README progress is not required to equal older snapshots.','active-annotations-raw-read':False}})
print(json.dumps({'findings':0,'input-files':len(rows),'immutable-inputs-rechecked':checked,'selected-original-copies':len(selected),'report-words':len(report.split()),'approves':'metadata actual publication and prior32 preservation only'}))
