from auditlib import *
import tarfile
for base in [REPO/'capabilities/evidence/T75-delivery/final-certification-r4',Path('/tmp/t75-final-metadata-certified-r4-1jfzac5p')]:
 print('FILES',str(base),[str(q.relative_to(base)) for q in sorted(base.rglob('*')) if q.is_file() and (base.name.startswith('t75-final-metadata-') or q.name.startswith('metadata'))])
for base in [Path('/tmp/t75-final-metadata-certified-r4-1jfzac5p'),Path('/tmp/t75-final-spec-r4-pages-publication-blveufbw')]:
 for name in ['receipt.json','artifact-manifest.json']:
  q=base/name
  if q.exists():
   o=obj(q);print('SCHEMA',str(q),'keys',list(o),'scalarfields',{k:v for k,v in o.items() if not isinstance(v,(dict,list))})
 print('ROOTFILES',str(base),[q.name for q in sorted(base.iterdir()) if q.is_file()])
for name in ['metadata-command.cmd.json','metadata-command.result.json','metadata-command.receipt.json','metadata-command.archive-identity.json']:
 q=REPO/'capabilities/evidence/T75-delivery/final-certification-r4'/name
 if q.exists():
  o=obj(q);print('ADJACENT',name,'keys',list(o),'scalarfields',{k:v for k,v in o.items() if not isinstance(v,(dict,list))})
for q in [Path('/home/ubuntu/.codex/attachments/77353239-0dda-4ee1-b4bb-ce7fb3fa0f9b/pasted-text-1.txt'),REPO/'AGENTS.md',REPO/'CONTRIBUTING.md',REPO/'docs/agents/issue-tracker.md',REPO/'docs/t11-certification.md']:print('CONTEXT',q,sha(q))
print('REFERENCE PUBLICATION READER')
q=Path('/tmp/t75-r4-values-publication-spec-fbsksqo5/publication-audit.py')
print('READERS',[q.name for q in sorted(q.parent.glob('*.py'))])
