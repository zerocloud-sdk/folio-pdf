from pathlib import Path
import hashlib,json
out=Path(__file__).parent
assert json.loads((out/'publication-finalize.result.json').read_bytes())['actual_exit']==0
assert json.loads((out/'receipt.json').read_bytes())['findings']==[]
rows=[]
for p in sorted(out.rglob('*')):
 if not p.is_file():continue
 assert not p.is_symlink();assert p.name!='artifact-manifest.json','refusing reseal'
 data=p.read_bytes();rows.append({'path':str(p.relative_to(out)),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
with (out/'artifact-manifest.json').open('x') as f:json.dump({'schema-version':1,'scope':'Independent r4 metadata actual-publication Spec packet','excludes':['artifact-manifest.json'],'file-count-excluding-manifest':len(rows),'files':rows},f,indent=2);f.write('\n')
assert len([p for p in out.rglob('*') if p.is_file()])==len(rows)+1
for name in ['report.md','receipt.json','input-catalog.json','artifact-manifest.json']:print(name,hashlib.sha256((out/name).read_bytes()).hexdigest())
print('files',len(rows)+1,'manifest-members',len(rows),'inputs',json.loads((out/'receipt.json').read_bytes())['input-file-count'])
