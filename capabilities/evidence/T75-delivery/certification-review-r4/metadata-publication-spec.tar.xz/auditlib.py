from pathlib import Path
import json,hashlib,atexit,sys
REPO=Path('/home/ubuntu/IdeaProjects/open-pdf');OUT=Path(__file__).parent;ROOT=REPO/'capabilities/evidence/T75-foundation-20260914-r4/metadata';FILES={};ERRORS=[]
def read(path):
 path=Path(path)
 if '/T75-foundation-20260914-r4/annotations/' in str(path):raise PermissionError('Active annotations raw is outside this publication review')
 data=path.read_bytes();row={'path':str(path),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
 if str(path) in FILES and FILES[str(path)]['sha256']!=row['sha256']:raise AssertionError('Input changed between reads: '+str(path))
 FILES[str(path)]=row;return data
def sha(path):return hashlib.sha256(read(path)).hexdigest()
def obj(path):return json.loads(read(path))
def put(name,value):
 with (OUT/name).open('x') as f:f.write(value if isinstance(value,str) else json.dumps(value,indent=2)+'\n')
def identity(path):read(path);return FILES[str(path)]
@atexit.register
def retain_inputs():put(Path(sys.argv[0]).stem+'-input-catalog.json',list(FILES.values()))
