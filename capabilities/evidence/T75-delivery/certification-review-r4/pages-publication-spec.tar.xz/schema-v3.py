from auditlib import *
import subprocess
copies=[];schemas={}
def retained(p,n):
 q=OUT/'originals'/n;eq(read(p),read(q),'initial discovery copy remains unchanged '+str(p))
 return {'original':str(p),'copy':str(q.relative_to(OUT)),'bytes':len(read(q)),'sha256':sha(q),'origin':'Original schema.py copied this before the diagnostic; verified by a fresh read, never overwritten.'}
for p in sorted(COMMAND.iterdir()):
 if p.is_file():copies.append(retained(p,Path('actual-command')/p.name))
for rel in ['final-certification-r4/pages-command-archive-identity.json','certification-review-r4/pages-eight-tuples-spec-archive-identity.json','certification-review-r4/pages-eight-tuples-spec-report.md','certification-review-r4/pages-eight-tuples-spec-receipt.json']:
 copies.append(retained(DELIVERY/rel,Path('retention-linkage')/Path(rel).name))
paths=[COMMAND/'command.json',COMMAND/'result.json',COMMAND/'receipt.json',COMMAND/'identities.json',DELIVERY/'final-candidate-r4/build-inputs.json',ROOT/'jdk8-environment/environment.yaml']
raw_catalog=obj(RAW/'complete-current-raw-file-identities.json')
tuple_root=ROOT/'jdk8-in_process'
for row in raw_catalog:
 p=REPO/row['path']
 if p.parent==tuple_root and p.suffix in ['.json','.yaml']:paths.append(p)
for p in paths:
 d=obj(p)
 if isinstance(d,dict):schemas[str(p)]={'type':'object','keys':list(d),'scalars':{k:v for k,v in d.items() if isinstance(v,(str,int,float,bool)) or v is None},'arrays':{k:len(v) for k,v in d.items() if isinstance(v,list)},'object-fields':{k:list(v) for k,v in d.items() if isinstance(v,dict)}}
 elif isinstance(d,list):schemas[str(p)]={'type':'array','length':len(d),'members':d}
 else:error(p,'unexpected schema type '+type(d).__name__)
command=['rg','--files','docs/adr','-g','*0035*'];start=datetime.datetime.now(datetime.timezone.utc).isoformat();r=subprocess.run(command,cwd=REPO,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
for suffix,data in [('stdout.txt',r.stdout),('stderr.txt',r.stderr)]:
 with (OUT/('adr-discovery-'+suffix)).open('xb') as f:f.write(data)
dump('adr-discovery-command.json',{'command':command,'cwd':str(REPO),'started-utc':start})
dump('adr-discovery-result.json',{'returncode':r.returncode,'completed-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stdout-sha256':sha(OUT/'adr-discovery-stdout.txt'),'stderr-sha256':sha(OUT/'adr-discovery-stderr.txt')});eq(r.returncode,0,'read-only ADR filename discovery')
for name in r.stdout.decode().splitlines():copies.append(copy(REPO/name,Path('requirements')/Path(name).name))
for p in [Path('/home/ubuntu/.codex/attachments/77353239-0dda-4ee1-b4bb-ce7fb3fa0f9b/pasted-text-1.txt'),Path('/tmp/t75-issue-75-pre-freeze.json'),Path('/tmp/t75-issue-1.json'),REPO/'docs/t10-certification.md',REPO/'CONTRIBUTING.md',REPO/'scripts/t03-foundation.py']:
 copies.append(copy(p,Path('requirements')/p.name))
dump('schema-v3-original-copy-identities.json',copies)
dump('schema-diagnostic-closure.json',{'originals':[{'script':'schema.py','result':'schema-result.json','actual-exit':obj(OUT/'schema-result.json')['returncode'],'stderr-sha256':sha(OUT/'schema-stderr.txt'),'diagnostic':'Object .items() summary was incorrectly applied to actual top-level command arrays.'},{'script':'schema-v2.py','result':'schema-v2-result.json','actual-exit':obj(OUT/'schema-v2-result.json')['returncode'],'stderr-sha256':sha(OUT/'schema-v2-stderr.txt'),'diagnostic':'Guessed optional recorder-command.json pathname does not exist. Actual recorder invocation is in execution.yaml, already validated in the closed complete configuration raw review.'}],'corrected-reader':'schema-v3.py','correction':'Use explicitly typed object/array summaries and exact tuple header paths from the sealed complete raw file catalog.','classification':'Two discovery reader assumptions; neither is a certification failure, missing required record, or original-data loss.','fresh-read':True,'original-script-outputs-or-copies-overwritten':False,'certification-restarted-or-modified':False,'unresolved':False})
finish('actual-publication-schema-v3-inspection.json',{'scope':'Actual r4 pages publication schemas, fresh correctly typed discovery with original failures preserved','retained-command-original-members':[p.name for p in sorted(COMMAND.iterdir()) if p.is_file()],'actual-fields':schemas,'selected-original-copies':copies})
