from pathlib import Path
import sys,json,hashlib,datetime,subprocess
root=Path(__file__).parent;assert root.is_relative_to('/tmp')
names=['archive-check-command.json','archive-check-stdout.txt','archive-check-stderr.txt','archive-check-result.json','archive-sealing-inspection.json','archive-manifest.json']
if any((root/n).exists() for n in names):raise FileExistsError('Exclusive archive outputs already exist')
code='''from pathlib import Path
import json,hashlib,sys
r=Path(sys.argv[1]);h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
receipt=json.loads((r/'receipt.json').read_bytes())
assert h(r/'report.md')==receipt['report']['sha256']
assert json.loads((r/'finalize-result.json').read_bytes())['returncode']==0
assert json.loads((r/'final-integrity-inspection.json').read_bytes())['errors']==[]
assert receipt['approvals']['pages-actual-outer-exit'] is True
assert receipt['approvals']['pages-eight-exact-publication'] is True
assert receipt['approvals']['metadata-or-annotations'] is False
assert receipt['approvals']['all48-inventory-index-delivery'] is False
for name in ['schema-v3-original-copy-identities.json','publication-original-copy-identities.json','preserved-publication-v2-partial-copy-identities.json']:
 for row in json.loads((r/name).read_bytes()):assert h(r/row['copy'])==row['sha256']
assert not any(p.is_symlink() for p in r.rglob('*'))
codes={'schema':1,'schema-v2':1,'schema-v3':0,'prepare-publication-reader':0,'publication-v2':1,'prepare-publication-v3':0,'publication-v3':0,'current-authority':0,'finalize':0}
for stem,code in codes.items():
 result=json.loads((r/(stem+'-result.json')).read_bytes());assert result['returncode']==code
 for key in ['stdout','stderr']:assert h(r/result[key]['path'])==result[key]['sha256']
assert receipt['reader-diagnostics']['closed']==3
print(json.dumps({'archive-check':'PASS','pages-publication-only':True,'actual-finalizer-exit':0,'original-failed-and-corrected-reader-envelopes-preserved':True}))
'''
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def put(name,data):
 with (root/name).open('x') as f:json.dump(data,f,indent=2);f.write('\n')
command={'command':[sys.executable,'-B','-c',code,str(root)],'cwd':str(root),'started-utc':now(),'scope':'Verify only completed review artifacts and exact original copies before creating their archive manifest; no repository/project execution.'}
put('archive-check-command.json',command)
with (root/'archive-check-stdout.txt').open('xb') as out,(root/'archive-check-stderr.txt').open('xb') as err:result=subprocess.run(command['command'],cwd=root,stdout=out,stderr=err)
put('archive-check-result.json',{**command,'returncode':result.returncode,'completed-utc':now(),'stdout-sha256':sha(root/'archive-check-stdout.txt'),'stderr-sha256':sha(root/'archive-check-stderr.txt')})
if result.returncode:raise SystemExit(result.returncode)
put('archive-sealing-inspection.json',{'controller':[sys.executable,'-B',str(root/'seal-packet.py')],'verified-utc':now(),'actual-archive-check-exit':0,'actual-check-result-sha256':sha(root/'archive-check-result.json'),'report-sha256':sha(root/'report.md'),'receipt-sha256':sha(root/'receipt.json'),'manifest-policy':'Every current regular file except archive-manifest.json itself. Manifest creation is the final archive-only operation.'})
entries=[]
for p in sorted(root.rglob('*')):
 if p.is_file():entries.append({'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':sha(p)})
put('archive-manifest.json',{'schema-version':1,'original-directory':str(root),'created-utc':now(),'excludes':['archive-manifest.json'],'exclusion-reason':'Only the manifest itself is excluded to avoid self-reference. All actual reader/check command, stdout, stderr, result and original diagnostic files are included.','member-count':len(entries),'total-member-bytes':sum(x['bytes'] for x in entries),'members':entries})
print(json.dumps({'directory':str(root),'report-sha256':sha(root/'report.md'),'receipt-sha256':sha(root/'receipt.json'),'archive-manifest-sha256':sha(root/'archive-manifest.json'),'manifest-members-excluding-self':len(entries),'archive-members-including-manifest':len(entries)+1,'complete-input-catalog-sha256':sha(root/'complete-inspected-input-identities.json'),'pages-publication-only-approved':True,'metadata-annotations-final-delivery-approved':False}))
