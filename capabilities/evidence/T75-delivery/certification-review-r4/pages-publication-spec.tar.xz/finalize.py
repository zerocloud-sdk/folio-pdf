from auditlib import *
import yaml
from collections import Counter
components=['actual-publication-schema-v3-inspection.json','pre-execution-reader-preparation.json','publication-root-schema-preparation.json','actual-publication-inspection.json','current-authority-inspection.json'];component_rows=[]
for name in components:
 d=obj(OUT/name);eq(d['errors'],[],'closed bounded component '+name);component_rows.append({'path':name,'sha256':sha(OUT/name)})
expected_results={'schema':1,'schema-v2':1,'schema-v3':0,'prepare-publication-reader':0,'publication-v2':1,'prepare-publication-v3':0,'publication-v3':0,'current-authority':0};reader_results=[]
for stem,code in expected_results.items():
 r=obj(OUT/(stem+'-result.json'));eq(r['returncode'],code,'preserved actual original reader result '+stem);eq(sha(OUT/(stem+'.py')),r['script-sha256'],'preserved executed source '+stem)
 for stream in ['stdout','stderr']:eq(sha(OUT/r[stream]['path']),r[stream]['sha256'],'preserved original '+stream+' '+stem)
 reader_results.append({'name':stem,'actual-exit':r['returncode'],'script-sha256':r['script-sha256'],'command-sha256':sha(OUT/(stem+'-command.json')),'result-sha256':sha(OUT/(stem+'-result.json')),'stdout-sha256':r['stdout']['sha256'],'stderr-sha256':r['stderr']['sha256']})
eq(obj(OUT/'schema-diagnostic-closure.json')['unresolved'],False,'first two reader schema diagnostics closed');eq(obj(OUT/'publication-root-schema-diagnostic-closure.json')['unresolved'],False,'root path reader diagnostic closed')
catalog={};observations=[]
for p in sorted(OUT.glob('*-read-identities.json')):
 for row in obj(p):
  previous=catalog.get(row['path'])
  if previous and not row.get('mutable-original'):eq(previous,row,'unchanged input identity across completed reader observations')
  catalog[row['path']]=row;observations.append({'reader-catalog':p.name,**row})
for path,row in sorted(catalog.items()):
 if row.get('mutable-original'):continue
 eq(sha(path),row['sha256'],'final immutable input identity '+path);eq(len(read(path)),row['bytes'],'final immutable input size '+path)
pub=obj(OUT/'actual-publication-inspection.json');prior_current=obj(OUT/'current-authority-inspection.json')
eq(pub['actual-result']['returncode'],0,'actual pages outer completed0');eq(len(pub['actual-records-and-report-bindings']),32,'all pages records');eq(len(pub['actual-configurations']),8,'all actual configs');eq(len(pub['observed-environment-files']),84,'all environment originals')
eq(pub['current-stage-counts'],{'sources':1933,'contracts':30,'artifacts':23,'harness':24},'same current r4 stage identity counts');eq(pub['actual-Facade-mode'],'IN_PROCESS','actual Facade mode')
eq(sha(OUT/'originals/requirements/pasted-text-1.txt'),'794423d41161169ea6a4fee993553f777d6249cb05c5fe4d34f59657ab18f83f','original complete Goal identity')
for catalog_name in ['schema-v3-original-copy-identities.json','publication-original-copy-identities.json','preserved-publication-v2-partial-copy-identities.json']:
 for row in obj(OUT/catalog_name):eq(sha(OUT/row['copy']),row['sha256'],'all selected old/new original copies exact '+row['copy'])
started=datetime.datetime.now(datetime.timezone.utc).isoformat();data=read(AUTHORITY);completed=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (OUT/'originals/authority-at-final-seal.yaml').open('xb') as f:f.write(data)
current=yaml.safe_load(data);indexes={o:obj(ROOT.parent/o/'observed-index.json') for o in ['text','transactions','values','pages']};eq(current['candidate'],indexes['pages']['candidate'],'final current authority candidate graph')
known={}
for obligation,index in indexes.items():
 actual=[x for x in current['certifications'] if x['obligation']==obligation];eq(actual,index['certifications'],'final exact known published subset '+obligation);eq(len(actual),8,'final exact eight '+obligation);known[obligation]=8
current_env={x['profile']:x['record']['sha256'] for x in current['environments']}
for env in indexes['pages']['environments']:eq(current_env[env['profile']],env['record']['sha256'],'final same environment identity; do not read later-obligation paths')
current_observation={'original':str(AUTHORITY),'started-utc':started,'completed-utc':completed,'copy':'originals/authority-at-final-seal.yaml','sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'exact-known-subsets':known,'observed-total-certifications':len(current['certifications']),'other-obligations-excluded':sorted(set(x['obligation'] for x in current['certifications'])-set(indexes)),'later-obligation-raw-references-followed':False,'mutable-original-not-a-frozen-input':True}
dump('authority-at-final-seal-inspection.json',{**current_observation,'errors':list(errors)})
if errors:finish('final-integrity-inspection.json',{'status':'FAILED','current-authority':current_observation})
inputrows=sorted(catalog.values(),key=lambda x:x['path']);dump('complete-inspected-input-identities.json',inputrows);dump('complete-reader-input-observations.json',observations)
report='''CLEAN — zero unresolved Spec findings. This review closes only r4 pages/T10 actual outer exit and publication, preserving the prior text8, transactions8 and values8.

The actual original command exited 0, from 2026-09-13T20:40:58.053611Z to 21:32:39.398376Z. Its complete thirteen-line progress/publication log and all ten retained command artifacts match the originals and archive. Detailed JUnit results remain in the eight tuple logs; no duplicate outer-log requirement is imposed.

The Goal requires “Refresh invalidated certifications rather than reusing stale hashes” (Goal:131–133). Per docs/t10-certification.md:6–9 and 134–138, the dated 32-certification authority and current observed authority contain exactly the eight pages records from the unchanged own-index; each prior eight-record subset remains exact. Later obligations may be added without changing these reviewed subsets.

All eight configurations, 32 PASS chain records and original report hashes, eight actual 65-test transcripts, and 84 BEFORE/AFTER environment files remain byte-identical to the closed raw review. Native profiles remain actual IN_PROCESS/HARDENED_WORKER; Facade remains actual IN_PROCESS. Current 1,933 source, 30 contract, 23 artifact and 24 harness inputs match r4 candidate `ab18cc9c0473730a6aabec5d12e3172f22bea23a0a0f9529052a2bc186cbfc1b` and contract `3de508f79fcbef7258feee8abc013d6f02b000840cac1cb263cb0d6f927b8f2b`, against fixed baseline `5b1603c435f11c40368f75b7b9a2777c9c5e9761`.

The original 1,149-member pages raw packet and prior publication packets remain byte-exact. No rules/RGB qualification or five-file source review was replayed. Three discovery-reader diagnostics are preserved and separately closed by a fresh complete inspection using actual schemas and catalogued filenames. Prior scripts, failed outputs and partial copies were retained unchanged.

The historical loss of two r3 annotations derived summaries remains disclosed; no recovery is claimed. Metadata, annotations, final 48-tuple readiness/inventory/index/delivery and completion marks are not approved.
'''
eq(len(report.split())<400,True,'bounded English report under400words')
if errors:finish('final-integrity-inspection.json',{'status':'FAILED'})
with (OUT/'report.md').open('x') as f:f.write(report)
selected_files=[p for p in (OUT/'originals').rglob('*') if p.is_file()]
receipt={'reviewer':'/root/final_spec','axis':'Spec','sealed-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'r4 pages actual outer exit/publication only, and exact preservation of prior text8+transactions8+values8','baseline':'5b1603c435f11c40368f75b7b9a2777c9c5e9761','candidate':CID,'contract':CT,'findings':[],'report':{'path':'report.md','sha256':sha(OUT/'report.md'),'words':len(report.split())},'actual-command':pub['actual-command'],'actual-result':pub['actual-result'],'complete-original-outer-log-sha256':pub['actual-original-log-sha256'],'actual-outer-log-lines':pub['actual-outer-log-lines'],'actual-original-command-retention':pub['original-command-retention'],'dated-authority':pub['dated-authority'],'prior-authority':pub['prior-authority'],'earlier-current-authority-observation':prior_current,'current-final-authority-observation':current_observation,'own-pages-index-sha256':pub['own-index-sha256'],'actual-staged-input-counts':pub['current-stage-counts'],'actual-configurations':pub['actual-configurations'],'actual-records-and-report-bindings':pub['actual-records-and-report-bindings'],'actual-formal-suites':pub['actual-formal-transcripts'],'all84-observed-environment-identities':pub['observed-environment-files'],'all-four-BEFORE-AFTER-equal-and-byte-unchanged':True,'actual-Facade-mode':'IN_PROCESS','closed-raw-review':pub['closed-raw-review'],'closed-prior-publications':pub['closed-prior-publications'],'archive-retention-inspection':{'path':'retained-archive-verification-identities.json','sha256':sha(OUT/'retained-archive-verification-identities.json')},'completed-components':component_rows,'actual-original-reader-results':reader_results,'current-finalizer-envelope':'The wrapper retains this finalizer complete command/stdout/stderr/actual result after it exits; the final manifest is created afterward.','reader-diagnostics':{'original-failed-readers':3,'closed':3,'unresolved':[],'closures':['schema-diagnostic-closure.json','publication-root-schema-diagnostic-closure.json'],'pre-execution-draft-adjustment':'pre-execution-reader-preparation.json','fresh-inspection-not-recovered-original-output':True,'original-scripts-results-stdout-stderr-or-partial-copies-overwritten':False,'certification-original-loss':False,'historical-r3-annotations-derived-summary-loss':'Original historical disclosure remains; no lost bytes are claimed recovered.'},'complete-inspected-input-catalog':{'path':'complete-inspected-input-identities.json','sha256':sha(OUT/'complete-inspected-input-identities.json'),'unique-input-observations':len(inputrows),'immutable-inputs-rechecked':sum(not x.get('mutable-original',False) for x in inputrows),'mutable-authority-observations-are-dated-snapshots':True},'selected-original-copies':{'files':len(selected_files),'bytes':sum(p.stat().st_size for p in selected_files),'whole-live-raw-tree-duplicated':False,'original-failed-reader-partial-copies-preserved':True},'approvals':{'pages-actual-outer-exit':True,'pages-eight-exact-publication':True,'existing-text8-transactions8-values8-preservation':True,'metadata-or-annotations':False,'all48-inventory-index-delivery':False,'completion-criteria-marked':False},'raw-rule-or-RGB-replayed':False,'five-file-inventory-source-review-repeated':False,'repository-mutations':False,'project-executions':False,'retention':'Every output uses exclusive /tmp creation. Archive manifest excludes only itself and includes the completed finalizer command/output/result. Previously sealed raw packets remain unchanged.'}
dump('receipt.json',receipt)
finish('final-integrity-inspection.json',{'status':'CLEAN','report-sha256':sha(OUT/'report.md'),'receipt-sha256':sha(OUT/'receipt.json'),'report-word-count':len(report.split()),'immutable-input-observations-rechecked':sum(not x.get('mutable-original',False) for x in inputrows),'selected-original-copy-files':len(selected_files),'closed-reader-diagnostics':3,'pages-publication-only':True,'other-obligations-or-final-delivery-approved':False})
