from pathlib import Path
import json,sys,datetime,hashlib,subprocess
b=Path(__file__).parent
assert len(sys.argv)==2 and sys.argv[1] in ['schema-v2.py']
p=b/sys.argv[1];names={k:b/(p.stem+'-'+v) for k,v in [('command','command.json'),('stdout','stdout.txt'),('stderr','stderr.txt'),('result','result.json')]}
if any(q.exists() for q in names.values()):raise FileExistsError('Original review output exists; no overwrite')
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m={'command':[sys.executable,'-B',str(p)],'cwd':str(b),'started-utc':now(),'script-sha256':sha(p),'library-sha256':sha(b/'auditlib.py'),'boundary':'Separate corrected read-only r4 pages publication schema inspection; original failed discovery preserved. Exclusive /tmp outputs. No project execution or repository mutation.'}
with names['command'].open('x') as f:json.dump(m,f,indent=2);f.write('\n')
with names['stdout'].open('xb') as out,names['stderr'].open('xb') as err:r=subprocess.run(m['command'],cwd=b,stdout=out,stderr=err)
m.update({'returncode':r.returncode,'completed-utc':now(),'stdout':{'path':names['stdout'].name,'sha256':sha(names['stdout'])},'stderr':{'path':names['stderr'].name,'sha256':sha(names['stderr'])}})
with names['result'].open('x') as f:json.dump(m,f,indent=2);f.write('\n')
print(names['stdout'].read_text());print(names['stderr'].read_text());print(json.dumps(m));sys.exit(r.returncode)
