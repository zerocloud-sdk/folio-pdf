from auditlib import *
import subprocess
copies=[];schemas={}
for p in sorted(COMMAND.iterdir()):
 if p.is_file():copies.append(copy(p,Path('actual-command')/p.name))
for rel in ['final-certification-r4/pages-command-archive-identity.json','certification-review-r4/pages-eight-tuples-spec-archive-identity.json','certification-review-r4/pages-eight-tuples-spec-report.md','certification-review-r4/pages-eight-tuples-spec-receipt.json']:
 copies.append(copy(DELIVERY/rel,Path('retention-linkage')/Path(rel).name))
for p in [COMMAND/'command.json',COMMAND/'result.json',COMMAND/'receipt.json',COMMAND/'identities.json',DELIVERY/'final-candidate-r4/build-inputs.json',ROOT/'jdk8-in_process/execution.yaml',ROOT/'jdk8-in_process/contract-tests-command.json',ROOT/'jdk8-in_process/recorder-command.json',ROOT/'jdk8-in_process/syntax.yaml',ROOT/'jdk8-environment/environment.yaml']:
 d=obj(p);schemas[str(p)]={'keys':list(d),'scalars':{k:v for k,v in d.items() if isinstance(v,(str,int,float,bool)) or v is None},'arrays':{k:len(v) for k,v in d.items() if isinstance(v,list)},'object-fields':{k:list(v) for k,v in d.items() if isinstance(v,dict)}}
command=['rg','--files','docs/adr','-g','*0035*'];start=datetime.datetime.now(datetime.timezone.utc).isoformat();r=subprocess.run(command,cwd=REPO,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
for suffix,data in [('stdout.txt',r.stdout),('stderr.txt',r.stderr)]:
 with (OUT/('adr-discovery-'+suffix)).open('xb') as f:f.write(data)
dump('adr-discovery-command.json',{'command':command,'cwd':str(REPO),'started-utc':start})
dump('adr-discovery-result.json',{'returncode':r.returncode,'completed-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stdout-sha256':sha(OUT/'adr-discovery-stdout.txt'),'stderr-sha256':sha(OUT/'adr-discovery-stderr.txt')})
eq(r.returncode,0,'read-only ADR filename discovery')
for name in r.stdout.decode().splitlines():copies.append(copy(REPO/name,Path('requirements')/Path(name).name))
for p in [Path('/home/ubuntu/.codex/attachments/77353239-0dda-4ee1-b4bb-ce7fb3fa0f9b/pasted-text-1.txt'),Path('/tmp/t75-issue-75-pre-freeze.json'),Path('/tmp/t75-issue-1.json'),REPO/'docs/t10-certification.md',REPO/'CONTRIBUTING.md',REPO/'scripts/t03-foundation.py']:
 copies.append(copy(p,Path('requirements')/p.name))
dump('initial-original-copy-identities.json',copies)
finish('actual-publication-schema-inspection.json',{'scope':'Actual r4 pages publication originals and schemas only; no assumptions imported from another obligation','retained-command-original-members':[p.name for p in sorted(COMMAND.iterdir()) if p.is_file()],'actual-fields':schemas,'selected-original-copies':copies})
