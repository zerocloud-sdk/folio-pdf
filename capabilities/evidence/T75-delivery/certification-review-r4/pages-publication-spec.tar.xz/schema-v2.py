from auditlib import *
import subprocess
copies=[];schemas={}
def retained(p,n):
 q=OUT/'originals'/n
 eq(read(p),read(q),'initial discovery original copy retained unchanged '+str(p))
 return {'original':str(p),'copy':str(q.relative_to(OUT)),'bytes':len(read(q)),'sha256':sha(q),'copied-by':'original schema.py before type diagnostic; verified unchanged by fresh schema-v2 read'}
for p in sorted(COMMAND.iterdir()):
 if p.is_file():copies.append(retained(p,Path('actual-command')/p.name))
for rel in ['final-certification-r4/pages-command-archive-identity.json','certification-review-r4/pages-eight-tuples-spec-archive-identity.json','certification-review-r4/pages-eight-tuples-spec-report.md','certification-review-r4/pages-eight-tuples-spec-receipt.json']:
 copies.append(retained(DELIVERY/rel,Path('retention-linkage')/Path(rel).name))
for p in [COMMAND/'command.json',COMMAND/'result.json',COMMAND/'receipt.json',COMMAND/'identities.json',DELIVERY/'final-candidate-r4/build-inputs.json',ROOT/'jdk8-in_process/execution.yaml',ROOT/'jdk8-in_process/contract-tests-command.json',ROOT/'jdk8-in_process/recorder-command.json',ROOT/'jdk8-in_process/syntax.yaml',ROOT/'jdk8-environment/environment.yaml']:
 d=obj(p)
 if isinstance(d,dict):schemas[str(p)]={'type':'object','keys':list(d),'scalars':{k:v for k,v in d.items() if isinstance(v,(str,int,float,bool)) or v is None},'arrays':{k:len(v) for k,v in d.items() if isinstance(v,list)},'object-fields':{k:list(v) for k,v in d.items() if isinstance(v,dict)}}
 elif isinstance(d,list):schemas[str(p)]={'type':'array','length':len(d),'members':d}
 else:error(p,'unexpected schema type '+type(d).__name__)
command=['rg','--files','docs/adr','-g','*0035*'];start=datetime.datetime.now(datetime.timezone.utc).isoformat();r=subprocess.run(command,cwd=REPO,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
for suffix,data in [('stdout.txt',r.stdout),('stderr.txt',r.stderr)]:
 with (OUT/('adr-discovery-'+suffix)).open('xb') as f:f.write(data)
dump('adr-discovery-command.json',{'command':command,'cwd':str(REPO),'started-utc':start})
dump('adr-discovery-result.json',{'returncode':r.returncode,'completed-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stdout-sha256':sha(OUT/'adr-discovery-stdout.txt'),'stderr-sha256':sha(OUT/'adr-discovery-stderr.txt')})
eq(r.returncode,0,'read-only ADR filename discovery')
for name in r.stdout.decode().splitlines():copies.append(copy(REPO/name,Path('requirements')/Path(name).name))
for p in [Path('/home/ubuntu/.codex/attachments/77353239-0dda-4ee1-b4bb-ce7fb3fa0f9b/pasted-text-1.txt'),Path('/tmp/t75-issue-75-pre-freeze.json'),Path('/tmp/t75-issue-1.json'),REPO/'docs/t10-certification.md',REPO/'CONTRIBUTING.md',REPO/'scripts/t03-foundation.py']:
 copies.append(copy(p,Path('requirements')/p.name))
dump('schema-v2-original-copy-identities.json',copies)
dump('schema-diagnostic-closure.json',{'original-script':'schema.py','original-result':'schema-result.json','actual-original-reader-exit':obj(OUT/'schema-result.json')['returncode'],'original-stderr-sha256':sha(OUT/'schema-stderr.txt'),'diagnostic':'AttributeError: list object has no attribute items','cause':'Summary-only discovery used object .items() on actual top-level command arrays. Tuple command JSON arrays are the existing correct protocol.','corrected-reader':'schema-v2.py','corrected-array-paths':[p for p,v in schemas.items() if v['type']=='array'],'classification':'Reader schema assumption, not a certification failure or missing output.','fresh-read':True,'original-script-outputs-or-copies-overwritten':False,'certification-restarted-or-modified':False,'unresolved':False})
finish('actual-publication-schema-v2-inspection.json',{'scope':'Actual r4 pages publication schemas; fresh corrected summary retaining original diagnostic unchanged','retained-command-original-members':[p.name for p in sorted(COMMAND.iterdir()) if p.is_file()],'actual-fields':schemas,'selected-original-copies':copies})
