from auditlib import *
import io,tarfile,yaml
from collections import Counter
copies=[];archives=[]
def archive_check(path,metadata,original,pinned):
 meta=obj(metadata);eq(sha(path),pinned,'pinned retained archive '+str(path));eq(meta['sha256'],pinned,'archive metadata identity')
 expected={x['path']:x for x in meta['members']};eq(len(expected),len(meta['members']),'unique archive members')
 actual=[]
 with tarfile.open(fileobj=io.BytesIO(read(path)),mode='r:xz') as t:
  for member in t:
   if member.isdir():continue
   eq(member.isfile(),True,'ordinary retained archive member '+member.name)
   rp=PurePosixPath(member.name);eq(rp.is_absolute() or '..' in rp.parts,False,'safe archive member path')
   b=t.extractfile(member).read();row=expected[member.name]
   eq(len(b),row['size'],'retained member size '+member.name);eq(hashlib.sha256(b).hexdigest(),row['sha256'],'retained member hash '+member.name)
   eq(read(original/member.name),b,'original member unchanged '+str(original/member.name));actual.append(member.name)
 eq(set(actual),set(expected),'complete retained archive member set')
 value={'path':str(path),'sha256':sha(path),'original-directory':str(original),'members':len(actual),'all-original-members-byte-exact':True};archives.append(value);return value
command_archive=archive_check(DELIVERY/'final-certification-r4/pages-command.tar.xz',DELIVERY/'final-certification-r4/pages-command-archive-identity.json',COMMAND,'dd74ead73708c454705748d98d197e42852b25abb8c149fab33afc1b3204f681')
eq(command_archive['members'],10,'actual outer retention10')
raw_archive=archive_check(DELIVERY/'certification-review-r4/pages-eight-tuples-spec.tar.xz',DELIVERY/'certification-review-r4/pages-eight-tuples-spec-archive-identity.json',RAW,'fe70a77740b6d7885f9a84eb532472286f938f42de5ab98c2c4274ab4f4ffe2f')
eq(raw_archive['members'],1149,'independent raw packet1149')
for name,pinned in [('report.md','b5b10b3604ebb0f5ccf58249b61ac1dd121c966dac471dad5c2a32a5e3e452bf'),('receipt.json','83a4e6db500919570eefa5d19388f25cb90b5c70cd1d096a9f5a5bda7d2bc9cf'),('archive-manifest.json','a24ee8db95ee652bb38d49981aba7548d80bd594001440c27d9fbf50338da7ec')]:
 eq(sha(RAW/name),pinned,'sealed original raw '+name);copies.append(copy(RAW/name,Path('closed-raw-review')/name))
raw=obj(RAW/'receipt.json');eq(raw['findings'],[],'closed raw zero findings');eq(raw['approvals']['pages-eight-raw-and-own-index'],True,'closed raw8 gate');eq(raw['approvals']['pages-authority-publication'],False,'prior raw deferred publication remains unchanged')
eq(raw['candidate'],CID,'raw candidate');eq(raw['contract'],CT,'raw contract')
for rel,suffix in [('command.json','-command.json'),('result.json','-result.json'),('command.log','.log')]:
 exact=Path('/tmp/t75-final-pages-certify-r4'+suffix);eq(read(exact),read(COMMAND/rel),'actual original outer '+rel);copies.append(copy(exact,Path('actual-prefix')/exact.name))
command=obj(COMMAND/'command.json');result=obj(COMMAND/'result.json')
eq(command['command'],['/usr/bin/python3','scripts/t03-foundation.py','certify',str(ROOT.relative_to(REPO)),'--obligation','pages'],'actual full outer argv')
eq(command['cwd'],str(REPO),'actual outer cwd');eq({k:v for k,v in result.items() if k not in ['command-pid','returncode','completed-utc']},command,'complete command/result identity')
eq(result['returncode'],0,'actual outer exit0');eq(command['started-utc'],'2026-09-13T20:40:58.053611+00:00','actual outer start');eq(result['completed-utc'],'2026-09-13T21:32:39.398376+00:00','actual outer completed time')
expected=[]
for j in [8,11,17,21]:expected+=['T10 environment JDK '+str(j),'T10 certification JDK '+str(j)+' / IN_PROCESS','T10 certification JDK '+str(j)+' / HARDENED_WORKER']
expected+=['Recorded exactly eight T10 certifications; retained 24 current certifications for other obligations.']
eq(read(COMMAND/'command.log').decode().splitlines(),expected,'complete13-line actual outer progress/publication log; no duplicate JUnit requirement')
eq(obj(COMMAND/'identities.json'),{'Candidate':CID,'Contract':CT},'retained actual identities')
eq(read(COMMAND/'identities.json'),read(ROOT/'identities.json'),'actual/current identities unchanged')
eq(read(COMMAND/'observed-index.json'),read(ROOT/'observed-index.json'),'retained/current own-index unchanged')
eq(sha(ROOT/'observed-index.json'),raw['own-index-sha256'],'same own-index as complete raw audit')
eq(read(COMMAND/'prior-index.sha256'),read(ROOT/'prior-index.sha256'),'retained/current prior identity unchanged')
own=obj(ROOT/'observed-index.json');eq(len(own['certifications']),8,'exact observed eight')
dated=yaml.safe_load(read(COMMAND/'authority-at-retention.yaml'));eq(len(dated['certifications']),32,'dated actual authority32')
eq(dated['candidate'],own['candidate'],'dated candidate graph');eq(dated['environments'],own['environments'],'dated current environment records equal own-index')
indexes={'pages':own};prior_links=[]
for link in raw['prior-closed-review-lineage']['closed-prior-reviews']:
 obligation=link['obligation'];prefix=obligation+'-publication-spec';base=DELIVERY/'certification-review-r4';meta=obj(base/(prefix+'-archive-identity.json'))
 prior_archive=next(x for x in raw['prior-closed-review-lineage']['unchanged-original-packets'] if x['obligation']==obligation)
 archive_check(base/meta['archive'],base/(prefix+'-archive-identity.json'),Path(meta['original']),prior_archive['archive-sha256'])
 for name in ['report','receipt']:eq(sha(base/(prefix+'-'+name+('.md' if name=='report' else '.json'))),link[name+'-sha256'],'unchanged prior closed '+obligation+' '+name)
 receipt=obj(base/(prefix+'-receipt.json'));eq(receipt['candidate'],CID,'prior same r4 candidate');eq(receipt['contract'],CT,'prior same contract');eq(receipt['findings'],[],'prior closed no findings')
 p=ROOT.parent/obligation/'observed-index.json';eq(sha(p),link['own-index-sha256'],'unchanged prior own-index '+obligation);indexes[obligation]=obj(p)
 copies.append(copy(base/(prefix+'-receipt.json'),Path('prior-publication-linkage')/(prefix+'-receipt.json')))
 copies.append(copy(base/(prefix+'-report.md'),Path('prior-publication-linkage')/(prefix+'-report.md')))
 copies.append(copy(p,Path('prior-publication-linkage')/(obligation+'-observed-index.json')))
 prior_links.append(link)
counts=Counter(x['obligation'] for x in dated['certifications']);eq(dict(counts),{'text':8,'transactions':8,'values':8,'pages':8},'dated exact four published subsets')
for obligation,index in indexes.items():
 eq([x for x in dated['certifications'] if x['obligation']==obligation],index['certifications'],'dated exact published own-index '+obligation)
 eq(index['candidate'],own['candidate'],'same candidate input graph '+obligation)
prior_authority=Path(raw['prior-closed-review-lineage']['dated-prior-authority']['path'])
eq(sha(prior_authority),read(ROOT/'prior-index.sha256').decode().strip(),'published preceding authority identity binds original guard')
prior=yaml.safe_load(read(prior_authority));eq(prior['certifications'],[x for x in dated['certifications'] if x['obligation']!='pages'],'all prior24 exactly preserved in dated32')
copies.append(copy(prior_authority,'prior-publication-linkage/preceding-authority24.yaml'))
buildpath=DELIVERY/'final-candidate-r4/build-inputs.json';eq(sha(buildpath),'64cb458acef6c0e98aa5b0dbf8023d85fe569fa2269eb6c3c343959779325e02','frozen r4 stage identity');eq(read(buildpath),read(RAW/'originals/current-stage/build-inputs.json'),'stage exact to closed raw audit')
build=obj(buildpath);eq(build['candidate'],own['candidate'],'stage complete candidate input/artifact graph matches own-index')
groups={'sources':build['candidate']['inputs'],'contracts':build['contract-inputs'],'artifacts':build['candidate']['artifacts'],'harness':build['harness']}
eq({k:len(v) for k,v in groups.items()},{'sources':1933,'contracts':30,'artifacts':23,'harness':24},'current r4 stage counts')
for group,rows in groups.items():
 for row in rows:eq(sha(REPO/row['path']),row['sha256'],'current staged '+group+' input '+row['path'])
copies.append(copy(buildpath,'current-stage/build-inputs.json'))
raw_files={x['path']:x for x in obj(RAW/'complete-current-raw-file-identities.json')};envs={x['profile']:x['record'] for x in own['environments']};records=[];configs=[];transcripts=[];environment_files=[]
def reviewed(p):
 row=raw_files[str(p.relative_to(REPO))];eq(sha(p),row['sha256'],'same bytes as complete independent raw audit '+str(p));eq(len(read(p)),row['bytes'],'same raw audit input size')
def reference(value):
 rel=PurePosixPath(value['path']);eq(rel.is_absolute() or '..' in rel.parts,False,'canonical repository reference')
 p=REPO/value['path'];eq(p.resolve(),p,'no linked reference');eq(sha(p),value['sha256'],'published reference exact SHA');reviewed(p);return p
raw_suites={x['tuple'].split('/')[-1]:x for x in raw['actual-formal-suites']}
for certification in own['certifications']:
 mode=certification['execution-profile'];profile=certification['environment'];configpath=reference(certification['configuration']);scope=configpath.parent;config=obj(configpath)
 eq(config['candidate-sha256'],CID,'actual configuration candidate');eq(config['execution-profile'],mode,'actual Native profile');eq(config['environment-sha256'],envs[profile]['sha256'],'config environment');eq(config['acceptance-profile'],'T10-page-manipulation-merge-split','actual T10 profile')
 eq(len(config['inputs']),190,'complete T10 configuration input count')
 for row in config['inputs']:eq(sha(REPO/row['path']),row['sha256'],'current complete configuration input')
 commandpath=scope/'contract-tests-command.json';reviewed(commandpath);argv=obj(commandpath);eq(isinstance(argv,list),True,'actual contract argv array');eq(isinstance(config['command'],list),True,'recorder argv in actual configuration')
 log=scope/'contract-tests.txt';reviewed(log);body=read(log).decode();match=re.fullmatch(r'JUnit version 4\.13\.2\n.*\nTime: ([0-9.]+)\n\nOK \(65 tests\)\n\n',body,re.S);eq(match is not None,True,'actual complete formal65 transcript');eq('FAILURES!!!' in body,False,'actual formal no failures')
 suite=raw_suites[scope.name];eq(suite['actual-facade-mode'],'IN_PROCESS','closed observed Facade actual IN_PROCESS');eq(suite['actual-native-mode'],mode,'closed actual selected Native profile');eq(sha(log),suite['contract-tests-sha256'],'same formal transcript as raw audit')
 transcripts.append({'tuple':scope.name,'tests':65,'seconds':float(match[1]) if match else None,'sha256':sha(log),'actual-Native-mode':mode,'actual-Facade-mode':'IN_PROCESS'})
 for p in [configpath,commandpath,log,scope/'recorder.txt']:reviewed(p);copies.append(copy(p,Path('current-tuples')/scope.name/p.name))
 for name in ['products.properties','result.properties','native-edited-publication.properties','native-split-publication.properties','facade-edited-publication.properties','facade-split-publication.properties']:reviewed(scope/'observations'/name)
 seen=[]
 for recordref in certification['records']:
  p=reference(recordref);record=obj(p);seen.append(record['chain'])
  for k,v in {'obligation':'pages','candidate-sha256':CID,'contract-sha256':CT,'environment-sha256':envs[profile]['sha256'],'execution-configuration-sha256':certification['configuration']['sha256'],'execution-profile':mode,'result':'pass','acceptance-profile':'T10-page-manipulation-merge-split'}.items():eq(record[k],v,'actual published record '+k)
  reportpath=reference(record['report']);report=obj(reportpath);eq(report['chain'],record['chain'],'report chain');eq(report['result'],'pass','report pass');eq(report['negative-controls'],record['negative-controls'],'same qualified raw control references')
  eq(sha(REPO/record['configuration']['path']),record['configuration']['sha256'],'acceptance contract profile identity')
  for q in [p,reportpath]:copies.append(copy(q,Path('current-tuples')/scope.name/q.name))
  records.append({'tuple':scope.name,'chain':record['chain'],'record':recordref,'report':record['report'],'qualified-raw-details-replayed':False})
 eq(sorted(seen),['semantic','standards','syntax','visual'],'all four chains exact and unique')
 configs.append({'tuple':scope.name,'configuration':certification['configuration'],'contract-argv-sha256':sha(commandpath),'recorder-command-field':'execution.yaml:command','actual-Native-profile':mode,'actual-Facade-mode':'IN_PROCESS','unchanged-complete-command-review':str(RAW/'complete-config-and-index-inspection.json')})
for j in [8,11,17,21]:
 for suffix,n in [('environment',11),('environment-after',10)]:
  d=ROOT/('jdk'+str(j)+'-'+suffix);entries=sorted(p for p in d.iterdir() if p.is_file());eq(len(entries),n,'actual complete raw environment files '+d.name)
  for p in entries:reviewed(p);copies.append(copy(p,Path('current-environments')/d.name/p.name));environment_files.append({'path':str(p.relative_to(REPO)),'bytes':len(read(p)),'sha256':sha(p)})
  if suffix=='environment':
   ep=d/'environment.yaml';record=envs['ubuntu-24.04-linux-x86-64-jdk'+str(j)];eq(str(ep.relative_to(REPO)),record['path'],'own environment original path');eq(sha(ep),record['sha256'],'own environment exact reference')
eq(len(records),32,'all32 actual published records');eq(len(configs),8,'all8 actual configurations');eq(len(environment_files),84,'all84 before/after raw environment files')
for name in ['candidate-identity.txt','candidate-probe.properties','identities.json','observed-index.json','prior-index.sha256']:reviewed(ROOT/name)
eq(raw['current-stage-environment']['all-four-BEFORE-AFTER-equal'],True,'closed reconstructed environment equality with unchanged84 originals')
source=read(REPO/'scripts/t03-foundation.py').decode();eq("stdout=log, stderr=subprocess.STDOUT" in source,True,'original runner merged subprocess capture protocol')
dump('publication-original-copy-identities.json',copies);dump('retained-archive-verification-identities.json',archives)
finish('actual-publication-inspection.json',{'scope':'Only r4 pages actual outer exit/publication and exact preservation of prior24','candidate':CID,'contract':CT,'actual-command':command,'actual-result':result,'actual-original-log-sha256':sha(COMMAND/'command.log'),'actual-outer-log-lines':len(expected),'original-command-retention':command_archive,'closed-raw-review':{'original':str(RAW),'report-sha256':sha(RAW/'report.md'),'receipt-sha256':sha(RAW/'receipt.json'),'manifest-sha256':sha(RAW/'archive-manifest.json'),'archive':raw_archive,'raw-rule-or-RGB-replayed':False,'raw-deferred-report-unchanged':True},'own-index-sha256':sha(ROOT/'observed-index.json'),'dated-authority':{'path':str(COMMAND/'authority-at-retention.yaml'),'sha256':sha(COMMAND/'authority-at-retention.yaml'),'exact-subsets':dict(counts)},'prior-authority':{'path':str(prior_authority),'sha256':sha(prior_authority),'all-prior24-exactly-preserved':True},'current-stage-counts':{k:len(v) for k,v in groups.items()},'actual-records-and-report-bindings':records,'actual-configurations':configs,'actual-formal-transcripts':transcripts,'observed-environment-files':environment_files,'all-four-BEFORE-AFTER-equal-and-unchanged':True,'actual-Facade-mode':'IN_PROCESS','closed-prior-publications':prior_links,'current-authority-gate':'Separate dated observation in current-authority.py; additions allowed, only known four subsets approved','five-file-inventory-source-review-repeated':False,'other-obligations-or-final48-approved':False})
