from auditlib import *
original=OUT/'publication.py';source=read(original).decode()
old='stdout=subprocess.PIPE, stderr=subprocess.STDOUT';new='stdout=log, stderr=subprocess.STDOUT'
eq(source.count(old),1,'single unexecuted draft protocol literal')
real=read(REPO/'scripts/t03-foundation.py').decode();eq(new in real,True,'actual run_logged writes child stdout directly into retained tuple log')
if errors:finish('pre-execution-reader-preparation.json',{'prepared':False})
with (OUT/'publication-v2.py').open('x') as f:f.write(source.replace(old,new,1))
finish('pre-execution-reader-preparation.json',{'original-unexecuted-draft':str(original),'original-sha256':sha(original),'executed-draft':False,'new-reader':'publication-v2.py','new-sha256':sha(OUT/'publication-v2.py'),'only-change':'Before running the publication reader, align the final source-binding literal with actual run_logged stdout=log and merged stderr. No assertion or guard relaxation: detailed JUnit output remains in each original tuple log, not duplicated in outer progress stdout.','original-draft-overwritten':False,'new-certification-run':False})
