from auditlib import *
import yaml
from collections import Counter
indexes={obligation:obj(ROOT.parent/obligation/'observed-index.json') for obligation in ['text','transactions','values','pages']}
started=datetime.datetime.now(datetime.timezone.utc).isoformat();data=read(AUTHORITY);completed=datetime.datetime.now(datetime.timezone.utc).isoformat()
dest=OUT/'originals/authority-current-observation.yaml';dest.parent.mkdir(parents=True,exist_ok=True)
with dest.open('xb') as f:f.write(data)
current=yaml.safe_load(data);own=indexes['pages'];eq(current['candidate'],own['candidate'],'current authority same r4 candidate graph')
counts=Counter(x['obligation'] for x in current['certifications']);known={}
for obligation,index in indexes.items():
 expected=index['certifications'];actual=[x for x in current['certifications'] if x['obligation']==obligation]
 eq(len(actual),8,'current exact published8 '+obligation);eq(actual,expected,'current exact published subset equals unchanged own-index '+obligation)
 known[obligation]={'certifications':len(actual),'own-index-sha256':sha(ROOT.parent/obligation/'observed-index.json'),'exact':True}
envs={x['profile']:x['record'] for x in current['environments']};bindings=[]
for row in own['environments']:
 profile=row['profile'];eq(envs[profile]['sha256'],row['record']['sha256'],'current environment identity remains exact even if later obligation changes reference path')
 bindings.append({'profile':profile,'pages-record':row['record'],'current-authority-reference':envs[profile],'identity-equal':True,'later-obligation-raw-reference-followed':False})
finish('current-authority-inspection.json',{'scope':'Dated current authority observation; approve pages8 publication and preserve prior24, exclude any later additions','original':str(AUTHORITY),'mutable-original-is-not-a-frozen-input':True,'started-utc':started,'completed-utc':completed,'copy':str(dest.relative_to(OUT)),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'exact-reviewed-subsets':known,'observed-authority-counts':dict(counts),'environment-identity-bindings':bindings,'other-obligation-names-observed-but-excluded':sorted(set(counts)-set(indexes)),'other-obligation-raw-or-report-reference-read':False,'candidate':CID,'contract':CT,'metadata-annotations-or-final48-approved':False})
