from auditlib import *
base=REPO/'capabilities/evidence/T75-delivery';bound=base/'inventory-read-bound';closure=obj(bound/'independent-review-closure.json');delta=obj(bound/'five-file-source-delta.json')
eq(closure['standards-closed'],True,'existing independent Standards closure');eq(closure['spec-closed'],True,'existing independent Spec closure');eq(closure['source-delta'],delta,'exact five-source delta named in independent closures');eq(len(delta),5,'only approved five-source r3/r4 delta')
archives=[]
for axis in ['standards','spec']:
 report=bound/(axis+'-review-report.md');eq(sha(report),closure[axis+'-report-sha256'],'closed independent report identity '+axis)
 meta=obj(bound/(axis+'-review-archive-identity.json'));archive=bound/(axis+'-review.tar.xz');eq(sha(archive),meta['sha256'],'unchanged closed review archive '+axis)
 eq(any(row['sha256']==closure[axis+'-report-sha256'] for row in meta['members']),True,'closed report hash is in preserved original archive '+axis)
 archives.append({'axis':axis,'report-sha256':sha(report),'archive':str(archive.relative_to(REPO)),'archive-sha256':sha(archive),'report-bound-to-archive':True})
for row in delta:eq(sha(REPO/row['path']),row['current-sha256'],'approved current source identity '+row['path']);eq(len(read(REPO/row['path'])),row['bytes'],'approved current source size')
build=obj(base/'final-candidate-r4/build-inputs.json');validated=obj(base/'final-validation-r4/source-and-contract-inputs.json')
eq(build['candidate']['inputs'],validated['inputs'],'current stage has exact host/four-JDK source input identities');eq(build['contract-inputs'],validated['contract-inputs'],'current stage has exact host/four-JDK contract identities')
copies=[copy(REPO/row['path'],Path('approved-inventory-source-identities')/row['path']) for row in delta]
finish('closed-source-lineage-inspection.json',{'scope':'Identity linkage to already closed five-source inventory correction and r4 complete validation. No behavior/source re-review or new execution.','candidate':CID,'contract':CT,'approved-five-source-delta':delta,'independent-closure-archives':archives,'current1933-sources-and30-contracts-exact-to-validated-inputs':True,'r4-stage-build-inputs-sha256':sha(base/'final-candidate-r4/build-inputs.json'),'validation-inputs-sha256':sha(base/'final-validation-r4/source-and-contract-inputs.json'),'selected-current-source-identity-copies':copies,'current-annotations-raw-read':False,'new-certification-or-final-delivery-approved':False})
