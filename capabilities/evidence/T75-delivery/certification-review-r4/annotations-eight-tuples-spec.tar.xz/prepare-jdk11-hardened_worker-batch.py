from batch_factory import *
prepare(11,'HARDENED_WORKER','004-jdk11-hardened_worker-after-complete.json',True)
