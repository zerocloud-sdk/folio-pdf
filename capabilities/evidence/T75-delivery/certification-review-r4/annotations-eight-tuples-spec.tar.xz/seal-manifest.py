from pathlib import Path
import json,hashlib,datetime,sys
p=Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest()
assert json.loads((p/'write-final-report-receipt-result.json').read_bytes())['returncode']==0
assert json.loads((p/'retention-copy-schema-closure-result.json').read_bytes())['returncode']==0
assert not (p/'manifest.json').exists()
creation={'command':[sys.executable,'-B',str(p/'seal-manifest.py')],'script-sha256':sha((p/'seal-manifest.py').read_bytes()),'operation':'Terminal packaging catalog creation after every actual review command/result has been retained. No project or evidence execution.'}
with (p/'manifest-creation-command.json').open('x') as f:json.dump(creation,f,indent=2);f.write('\n')
members=[]
for f in sorted(p.rglob('*')):
 if not f.is_file():continue
 assert not f.is_symlink()
 b=f.read_bytes();members.append({'path':str(f.relative_to(p)),'bytes':len(b),'sha256':sha(b)})
manifest={'schema-version':1,'original-directory':str(p),'created-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'explicit-self-exclusion':{'path':'manifest.json','reason':'A SHA manifest cannot hash its own final bytes.'},'member-count-excluding-self':len(members),'archive-member-count-including-manifest':len(members)+1,'total-bytes-excluding-self':sum(x['bytes'] for x in members),'creation':creation,'members':members}
with (p/'manifest.json').open('x') as f:json.dump(manifest,f,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps({'original-directory':str(p),'report-sha256':sha((p/'report.md').read_bytes()),'receipt-sha256':sha((p/'receipt.json').read_bytes()),'manifest-sha256':sha((p/'manifest.json').read_bytes()),'manifest-members-excluding-self':len(members),'archive-members-including-manifest':len(members)+1,'bytes-excluding-manifest':manifest['total-bytes-excluding-self'],'scope':'CLEAN annotations raw8/own-index only; actual publication deferred'},indent=2))
