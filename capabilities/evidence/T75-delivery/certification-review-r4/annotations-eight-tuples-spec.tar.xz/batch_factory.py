from auditlib import *
import tempfile
TEMPLATE=PACKET/'batches/jdk8-hardened_worker-7cl2xyfq'
def prepare(major,mode,grantname,after):
 label='jdk'+str(major)+'-'+mode.lower();grant=PACKET/'authorizations'/grantname;notice=obj(grant)
 eq(notice['parent-confirmed-complete'],True,'explicit complete grant')
 eq(label in notice['allowed-root-members'],True,'explicit tuple in grant')
 env='jdk'+str(major)+'-environment';allowed=[env]+([env+'-after'] if after else [])
 eq(set([label]+allowed)<=allowed_roots(),True,'all raw members explicitly authorized complete')
 batch=Path(tempfile.mkdtemp(prefix=label+'-',dir=PACKET/'batches'))
 def write(name,data):
  with (batch/name).open('xb') as f:f.write(data)
 def js(name,data):write(name,(json.dumps(data,ensure_ascii=False,indent=2)+'\n').encode())
 context={'tuple':[major,mode],'tuple-directory':label,'allowed-environment-directories':allowed,'deferred-environment-directories':[] if after else [env+'-after'],'observed-index-excluded':True,'candidate':CID,'contract':CT,'authorization-file':str(grant)}
 js('batch-context.json',context);js('scope.json',{'batch':label,'tuples':[context['tuple']],'stage-inspection':'stage-environment-contract-'+label+'-inspection.json'})
 copies=[]
 for name in ['auditlib.py','run-readonly.py','stage-audit.py','evidence-audit.py','graph-audit.py','raster-audit.py','complete-command-audit.py','batch-schema.py','batch-receipt.py']:
  original=(PACKET/'batch-receipt-template.py') if name=='batch-receipt.py' else (PACKET if name in ['auditlib.py','run-readonly.py'] else TEMPLATE)/name
  data=read(original);write(name,data);copies.append({'original':str(original),'copy':str(batch/name),'sha256':sha(original),'byte-exact':True})
 finish(label+'-batch-preparation-inspection.json',{'batch':str(batch),'authorization':notice,'context':context,'byte-exact-generic-reader-copies':copies,'raw-content-read':False,'exclusive-outputs':True})
