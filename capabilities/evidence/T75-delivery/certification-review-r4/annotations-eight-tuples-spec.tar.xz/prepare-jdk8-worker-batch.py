from auditlib import *
import ast,tempfile
grant=PACKET/'authorizations/002-jdk8-hardened_worker-after-complete.json'
notice=obj(grant);eq(notice['parent-confirmed-complete'],True,'parent confirmed immutable Worker and AFTER')
origin=PACKET/'batches/jdk8-in_process-9i7rufn6'
batch=Path(tempfile.mkdtemp(prefix='jdk8-hardened_worker-',dir=PACKET/'batches'))
def write(name,data):
 with (batch/name).open('xb') as f:f.write(data)
def jsonwrite(name,data):write(name,(json.dumps(data,ensure_ascii=False,indent=2)+'\n').encode())
context={'tuple':[8,'HARDENED_WORKER'],'tuple-directory':'jdk8-hardened_worker','allowed-environment-directories':['jdk8-environment','jdk8-environment-after'],'deferred-environment-directories':[],'observed-index-excluded':True,'candidate':CID,'contract':CT,'authorization-file':str(grant)}
jsonwrite('batch-context.json',context)
jsonwrite('scope.json',{'batch':context['tuple-directory'],'tuples':[context['tuple']],'stage-inspection':'stage-environment-contract-'+context['tuple-directory']+'-inspection.json'})
copies=[]
for name in ['auditlib.py','run-readonly.py','stage-audit.py','evidence-audit.py','graph-audit.py','raster-audit.py','complete-command-audit.py']:
 p=(PACKET if name in ['auditlib.py','run-readonly.py'] else origin)/name
 data=read(p);write(name,data);copies.append({'original':str(p),'copy':str(batch/name),'sha256':sha(p),'byte-exact':True})
source=read(origin/'batch-schema.py').decode();tree=ast.parse(source)
assertion=next(n for n in tree.body if isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Name) and n.value.func.id=='eq')
eq(ast.literal_eval(assertion.value.args[1]),'IN_PROCESS','qualified first schema literal before explicit scope correction')
assertion.value.args[1]=ast.Subscript(value=ast.Subscript(value=ast.Name(id='context',ctx=ast.Load()),slice=ast.Constant(value='tuple'),ctx=ast.Load()),slice=ast.Constant(value=1),ctx=ast.Load())
assertion.value.args[2]=ast.Constant(value='explicit authorized tuple Native mode')
matches=0
for n in ast.walk(tree):
 if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='Path' and len(n.args)==1 and isinstance(n.args[0],ast.Constant) and n.args[0].value=='environment-before':
  n.args=[ast.Constant(value='environments')];matches+=1
  # The selected destination must include each actual environment directory.
  for parent in ast.walk(tree):
   if isinstance(parent,ast.BinOp) and parent.left is n:
    parent.left=ast.BinOp(left=n,op=ast.Div(),right=ast.Name(id='name',ctx=ast.Load()))
    break
eq(matches,1,'one explicit environment copy destination correction')
ast.fix_missing_locations(tree);write('batch-schema.py',(ast.unparse(tree)+'\n').encode())
finish('jdk8-worker-batch-preparation-inspection.json',{'batch':str(batch),'authorization':notice,'context':context,'unchanged-reader-copies':copies,'schema-template':{'path':str(origin/'batch-schema.py'),'sha256':sha(origin/'batch-schema.py')},'schema-changes':['Bind the assertion to the explicit batch Native profile.','Name selected environment copies by their actual BEFORE/AFTER directories.'],'reads-active-raw':False,'outputs-created-exclusively':True})
