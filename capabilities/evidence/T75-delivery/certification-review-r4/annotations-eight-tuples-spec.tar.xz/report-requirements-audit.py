from auditlib import *
goal=Path('/home/ubuntu/.codex/attachments/77353239-0dda-4ee1-b4bb-ce7fb3fa0f9b/pasted-text-1.txt')
contract=REPO/'docs/t12-certification.md'
entries=[
 ('fresh existing-obligation observations',goal,131,133,'All eight fresh current-candidate raw tuples; no added T12 functionality.'),
 ('actual public Facade mode',goal,121,125,'Per-tuple complete argv/settings/public outcomes and fixed T12 source binding.'),
 ('separate qualified chains and identities',goal,86,93,'Per-tuple four chain/report arrays, every original reference and complete raw catalogs.'),
 ('required public T12 family products',contract,86,107,'Direct qpdf graph inspection and exact public Publication Receipts, success products and intended semantic mutations.'),
 ('actual selected Worker safety',contract,109,119,'Each selected Native profile and public Facade IN_PROCESS; five independently qualified canary classes and declared descendant scope.'),
 ('exact qualified T12 rule union',contract,199,209,'Original 174-rule union, per-product assignments, original illegal bytes/expected diagnostics and legal boundaries.'),
 ('full authored appearance/RGB observations',contract,165,178,'Original Widget projection bindings and direct original-PDF secondary renderer; every authored RGB scanline.'),
 ('negative pixel and Action control boundary',contract,218,236,'Actual PDF appearance/placement/retained-paint mutations, one-pixel comparator control, preserved/replaced Actions and synthetic signed Source.'),
 ('actual 47-test profile contract',contract,280,286,'Per-tuple actual 36 Native + 9 public Stable Facade + 2 artifact contracts; formal and recorder guards unchanged.')]
rows=[]
for name,p,start,end,proof in entries:
 lines=read(p).decode().splitlines();eq(end<=len(lines),True,'source quote range '+name)
 rows.append({'requirement':name,'source':str(p),'source-sha256':sha(p),'start-line':start,'end-line':end,'verbatim-original-lines':[{'line':i,'text':lines[i-1]} for i in range(start,end+1)],'assigned-independent-inspection':proof})
finish('fixed-requirements-and-review-coverage-map.json',{'boundary':'Requirement citations only. Coverage closes only when all eight authorized raw inspections and own-index binding are complete; no outer/publication or final delivery approval here.','requirements':rows,'closed-source-correction-reopened':False})
