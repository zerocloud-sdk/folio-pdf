from auditlib import *
import ast,subprocess
copies=[]
old_paths=[p for p in sorted(OLD.glob('*.py'))]+[OLD/n for n in ['report.md','receipt.json','reader-output-incident-and-closure.json','reader-schema-diagnostic.json','reader-boolean-schema-diagnostic.json']]
for folder in ['batch-source-contract-vnok5ax0','batch-all-eight-closure-22ypv95e','batch-jdk21-p77mn8_t']:
 old_paths.extend(sorted((OLD/folder).glob('*.py')))
for p in old_paths:copies.append(copy(p,Path('prior-reader-originals')/p.relative_to(OLD)))
priorpath=OLD/'batch-source-contract-vnok5ax0/source-contract-inspection.json';prior=obj(priorpath);eq(prior['errors'],[],'closed original T12 fixed-baseline source inspection');copies.append(copy(priorpath,'prior-reader-originals/source-contract-inspection.json'))
baseline=[]
for row in prior['baseline-current-identities']:
 p=REPO/row['path'];eq(sha(p),row['baseline-sha256'],'dedicated T12 source/fixture unchanged since fixed baseline '+row['path']);eq(len(read(p)),row['bytes'],'same source/fixture size');baseline.append({'path':row['path'],'bytes':len(read(p)),'baseline-sha256':row['baseline-sha256'],'current-sha256':sha(p)})
 if p.suffix in ['.java','.py','.md','.properties','.json','.txt']:copies.append(copy(p,Path('current-fixed-T12')/row['path']))
commands=[['rg','--files','capabilities/profiles/T12-annotations','capabilities/profiles/T12-standards'],['rg','--files','pdf-acceptance/src/main/java/net/zerocloud/pdf/acceptance','-g','T12*.java'],['rg','--files','capabilities/evidence/T75-delivery/inventory-read-bound']]
discoveries=[]
for i,command in enumerate(commands,1):
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();r=subprocess.run(command,cwd=REPO,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 stem='preflight-discovery-'+str(i)
 for suffix,data in [('stdout.txt',r.stdout),('stderr.txt',r.stderr)]:
  with (OUT/(stem+'-'+suffix)).open('xb') as f:f.write(data)
 dump(stem+'-command.json',{'command':command,'cwd':str(REPO),'started-utc':start});dump(stem+'-result.json',{'returncode':r.returncode,'completed-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stdout-sha256':sha(OUT/(stem+'-stdout.txt')),'stderr-sha256':sha(OUT/(stem+'-stderr.txt'))});eq(r.returncode,0,'actual read-only fixed-source discovery '+str(i));discoveries.append(r.stdout.decode().splitlines())
dedicated_prefixes=['capabilities/profiles/T12-annotations/','capabilities/profiles/T12-standards/','pdf-acceptance/src/main/java/net/zerocloud/pdf/acceptance/T12']
eq(set(discoveries[0]+discoveries[1]),{x['path'] for x in baseline if any(x['path'].startswith(prefix) for prefix in dedicated_prefixes)},'exact dedicated T12 profile and acceptance source inventory')
buildpath=REPO/'capabilities/evidence/T75-delivery/final-candidate-r4/build-inputs.json';eq(sha(buildpath),'64cb458acef6c0e98aa5b0dbf8023d85fe569fa2269eb6c3c343959779325e02','fixed current r4 stage identity');build=obj(buildpath)
groups={'sources':build['candidate']['inputs'],'contracts':build['contract-inputs'],'artifacts':build['candidate']['artifacts'],'harness':build['harness']};eq({k:len(v) for k,v in groups.items()},{'sources':1933,'contracts':30,'artifacts':23,'harness':24},'actual current stage cardinality')
for group,rows in groups.items():
 for row in rows:eq(sha(REPO/row['path']),row['sha256'],'current staged '+group+' '+row['path'])
copies.append(copy(buildpath,'current-stage/build-inputs.json'))
sourcepath=REPO/'scripts/t03-foundation.py';tree=ast.parse(read(sourcepath).decode());cases=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='CERTIFICATION_CASES' for t in n.targets));case=ast.literal_eval(next(v for k,v in zip(cases.value.keys,cases.value.values) if ast.literal_eval(k)=='annotations'))
eq(case,prior['unchanged-complete-T12-case'],'complete T12 execution protocol unchanged from fixed baseline qualified inspection');eq(case['test-count'],47,'fixed36Native+9Facade+2artifact');eq(case['contract-timeout'],600,'original aggregate contract guard');eq(case['recorder-timeout'],1800,'original recorder guard');eq(case['facade-execution-profile'],'IN_PROCESS','actual fixed Facade mode')
copies.append(copy(sourcepath,'current-stage/t03-foundation.py'))
goal=Path('/home/ubuntu/.codex/attachments/77353239-0dda-4ee1-b4bb-ce7fb3fa0f9b/pasted-text-1.txt');eq(sha(goal),'794423d41161169ea6a4fee993553f777d6249cb05c5fe4d34f59657ab18f83f','complete original Goal identity')
for p in [goal,Path('/tmp/t75-issue-75-pre-freeze.json'),Path('/tmp/t75-issue-1.json'),REPO/'AGENTS.md',REPO/'CONTEXT.md',REPO/'CONTRIBUTING.md',REPO/'docs/agents/domain.md',REPO/'docs/agents/issue-tracker.md']:
 copies.append(copy(p,Path('requirements')/p.name))
incident=obj(OLD/'reader-output-incident-and-closure.json');eq(len(incident['lost-derived-summary-paths']),2,'preserved exact historical lost-summary boundary')
dump('fixed-protocol-selected-copy-identities.json',copies)
finish('fixed-protocol-source-preflight-inspection.json',{'scope':'Only fixed T12 protocol/source identity preflight. Every current annotations raw tuple/environment/root file remains excluded; no new actual certification conclusion.','baseline':prior['baseline'],'candidate':CID,'contract':CT,'stage-identity-sha256':sha(buildpath),'current-stage-input-counts':{k:len(v) for k,v in groups.items()},'dedicated-T12-files-unchanged-from-fixed-baseline':len(baseline),'baseline-current-source-identities':baseline,'complete-frozen-T12-execution-case':case,'previous-public-contract-method-counts':{k:len(v) for k,v in prior['public-test-methods'].items()},'previous-rule-group-counts-navigation-only':prior['rule-counts'],'r4-rule-controls-products-RGB-counts':'Deferred until actual new complete tuples are explicitly authorized and independently observed.','inventory-correction-closure-file-discovery':discoveries[2],'five-file-source-correction-re-reviewed':False,'historical-lost-derived-summary-incident':incident,'lost-bytes-recovered':False,'new-reader-output-collisions-or-overwrites':False,'current-annotations-raw-files-read':0,'actual-outer-publication-or-final48-approved':False})
