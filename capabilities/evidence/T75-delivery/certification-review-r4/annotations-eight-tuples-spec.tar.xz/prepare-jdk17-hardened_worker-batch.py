from batch_factory import *
prepare(17,'HARDENED_WORKER','006-jdk17-hardened_worker-after-complete.json',True)
