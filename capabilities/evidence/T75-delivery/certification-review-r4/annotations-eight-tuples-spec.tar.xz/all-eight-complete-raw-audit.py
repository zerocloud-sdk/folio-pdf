from auditlib import *
import datetime
TUPLES=[(j,m) for j in [8,11,17,21] for m in ['IN_PROCESS','HARDENED_WORKER']]
labels=['jdk'+str(j)+'-'+m.lower() for j,m in TUPLES]
rootnames=['candidate-identity.txt','candidate-probe.json','identities.json','observed-index.json','prior-index.sha256']
required=set(labels+rootnames+['jdk'+str(j)+'-environment'+suffix for j in [8,11,17,21] for suffix in ['', '-after']])
if not required<=allowed_roots():raise ValueError('Final all-eight/index read is not explicitly authorized complete')
batches={}
for p in sorted((PACKET/'batches').glob('*/completed-tuple-bounded-receipt.json')):
 r=obj(p);eq(r['errors'],[],'clean scoped receipt '+str(p));label=r['tuple']
 eq(label not in batches,True,'one original complete batch per exact JDK/profile '+label);batches[label]=p.parent
eq(set(batches),set(labels),'all and only eight completed immutable batches')
if errors:finish('all-eight-complete-raw-inspection.json',{'boundary':'early scope diagnostic'})
seen={};physical=[];references=[];controls=[];products=[];visuals=[];graphs=[];rgb={};environments={};certs=[];envrefs={};linked=[];tests=[];tools=None;parity=None;pixelparity=None;configinputs=None
def merge(rows):
 for r in rows:
  if r['path'] in seen:eq(seen[r['path']],r,'same input identity across original batches '+r['path'])
  seen[r['path']]=r
for label in labels:
 b=batches[label];receipt=obj(b/'completed-tuple-bounded-receipt.json');eq(receipt['candidate'],CID,'same r4 candidate');eq(receipt['contract'],CT,'same frozen contract')
 result=obj(b/'batch-receipt-result.json');eq(result['returncode'],0,'actual scoped receipt reader exit0')
 for stream in ['stdout','stderr']:eq(sha(b/result[stream]['path']),result[stream]['sha256'],'scoped receipt retained '+stream)
 merge(obj(b/'complete-batch-input-identities.json'));merge(obj(b/'completed-tuple-bounded-receipt-read-identities.json'))
 inspect={key:obj(b/row['path']) for key,row in receipt['inspections'].items()}
 for key,row in receipt['inspections'].items():eq(sha(b/row['path']),row['sha256'],'original completed inspection unchanged '+key+' '+label)
 e=inspect['evidence'];s=inspect['stage'];g=inspect['graph'];r=inspect['raster'];c=inspect['configuration']
 physical.extend(obj(b/(label+'-original-tuple-file-identities.json')));references.extend(obj(b/(label+'-record-report-reference-identities.json')));controls.extend(obj(b/(label+'-rule-control-identities.json')))
 products.extend(e['public-products']);visuals.extend(e['separate-page-visual-observations']);graphs.extend(g['graph-observations'])
 tests.append({'tuple':label,'formal-tests':c['formal-tests'],'formal-time-seconds':receipt['formal-time-seconds'],'Native-mode':c['Native-mode'],'actual-Facade-mode':c['actual-Facade-mode'],'formal-command-sha256':c['exact-formal-command-sha256'],'execution-configuration-sha256':c['exact-configuration-sha256']})
 certs.append(c['observed-certification-for-final-own-index-binding']);er=c['current-environment-reference']
 if er['profile'] in envrefs:eq(envrefs[er['profile']],er,'same BEFORE reference across Native modes')
 envrefs[er['profile']]=er
 if tools is None:tools=s['tools']
 else:eq(s['tools'],tools,'same exact fifteen pinned tool observations '+label)
 for env in s['environment-observations']:
  if env['directory'] in environments:eq(environments[env['directory']],env,'same BEFORE bytes/reconstruction '+label)
  environments[env['directory']]=env
 values=[{k:v for k,v in p.items() if k not in ['tuple','pdf-sha256','actual-mode']} for p in e['public-products']]
 if parity is None:parity=values
 else:eq(values,parity,'actual public products have same prescribed contents/order across JDK/profiles '+label)
 localpixels={}
 for row in r['observations']:
  if row['path'] in rgb:eq(rgb[row['path']],row,'shared canonical full RGB input unchanged')
  rgb[row['path']]=row
  p=REPO/row['path']
  if p.is_relative_to(ROOT/label):
   key=str(p.relative_to(ROOT/label));localpixels[key]={k:row[k] for k in ['product','page','prescribed-control','prescribed-decoded-rgb-sha256','pixel-count','width','height']}
 if pixelparity is None:pixelparity=localpixels
 else:eq(localpixels,pixelparity,'every independently checked RGB input has the prescribed same pixels across JDK/profiles '+label)
 config=obj(ROOT/label/'execution.yaml')['inputs']
 if configinputs is None:configinputs=config
 else:eq(config,configinputs,'same complete configuration inputs across eight tuples')
 linked.append({'tuple':label,'original-batch':str(b),'receipt':str(b/'completed-tuple-bounded-receipt.json'),'receipt-sha256':sha(b/'completed-tuple-bounded-receipt.json'),'receipt-actual-result-sha256':sha(b/'batch-receipt-result.json')})
for n in ['fixed-protocol-source-preflight-inspection','closed-source-lineage-inspection','fixed-requirements-and-review-coverage-map','root-schema-inspection']:
 d=obj(PACKET/(n+'.json'));eq(d['errors'],[],'closed fixed protocol/source/requirements '+n);merge(obj(PACKET/(n+'-read-identities.json')))
# The completed original inputs are immutable. No appendable certifier output or
# live authority was included in this raw-only review's input catalogs.
for path,row in sorted(seen.items()):eq(sha(Path(path)),row['sha256'],'all inspected immutable bytes remain exact '+path)
for row in references:
 p=str(REPO/row['path']);eq(seen[p]['sha256'],row['sha256'],'every retained report/record reference remains exact '+row['path'])
eq(len({r['path'] for r in physical}),len(physical),'unique original tuple files')
actualtuples={str(p.relative_to(REPO)) for label in labels for p in (ROOT/label).rglob('*') if p.is_file()}
eq({r['path'] for r in physical},actualtuples,'complete eight physical tuple trees equal original catalogs')
for row in physical:eq(seen[str(REPO/row['path'])]['sha256'],row['sha256'],'full original tuple byte catalog '+row['path'])
build=obj(REPO/'capabilities/evidence/T75-delivery/final-candidate-r4/build-inputs.json')
expectedenv=[envrefs['ubuntu-24.04-linux-x86-64-jdk'+str(j)] for j in [8,11,17,21]]
index=obj(ROOT/'observed-index.json');eq(index,{'schema-version':1,'candidate':build['candidate'],'environments':expectedenv,'certifications':certs},'exact actual own-index binds all eight independently reviewed scopes')
eq(obj(ROOT/'identities.json'),{'Candidate':CID,'Contract':CT},'actual certification identities')
eq(obj(ROOT/'candidate-probe.json'),{'schema-version':1,'candidate':build['candidate'],'environments':[],'certifications':[]},'exact original provisional identity input')
identitytext=read(ROOT/'candidate-identity.txt').decode()
for key,want in [('Candidate',CID),('Contract',CT)]:
 matches=re.findall('^'+key+' identity: ([a-f0-9]{64})$',identitytext,re.M);eq(matches,[want],'actual original inventory identity output '+key)
eq(re.fullmatch(r'[a-f0-9]{64}\n',read(ROOT/'prior-index.sha256').decode()) is not None,True,'retained prior-index identity syntax; actual publication is separate')
eq({p.name for p in ROOT.iterdir() if p.is_file()},set(rootnames),'actual complete fixed protocol root members')
raw=[]
for p in sorted(ROOT.rglob('*')):
 if p.is_file():
  read(p);row=files[str(p)];raw.append({'path':str(p.relative_to(REPO)),'bytes':row['bytes'],'sha256':row['sha256']})
rawpaths={r['path'] for r in raw};expectedpaths=actualtuples|{str((ROOT/name).relative_to(REPO)) for name in rootnames}
for env in environments.values():expectedpaths.update(env['directory']+'/'+row['name'] for row in env['raw-files'])
eq(rawpaths,expectedpaths,'entire authorized raw root accounted by tuples, environments and five root records')
eq(len(environments),8,'eight unique BEFORE/AFTER directories')
for j in [8,11,17,21]:
 base=str((ROOT/('jdk'+str(j)+'-environment')).relative_to(REPO));eq(environments[base]['reconstructed'],environments[base+'-after']['reconstructed'],'complete BEFORE/AFTER equality JDK'+str(j))
rulekeys={(r['checker'],r['rule']) for r in controls};expectedrules=set()
for checker in ['pdfcpu','arlington-core','arlington-annotations']:
 p=props(REPO/'capabilities/profiles/T12-standards'/(checker+'.properties'));expectedrules.update((checker,rule) for rule in p['required-rules'].split(','))
eq(rulekeys,expectedrules,'complete actual qualified T12 assigned union')
for label in labels:
 for product in [p['product'] for p in products if p['tuple']==label]:eq({(r['checker'],r['rule']) for r in controls if r['tuple']==label and r['product']==product},expectedrules,'complete per-product illegal controls '+label+'/'+product)
eq(len(controls),len(products)*len(expectedrules),'each required product/rule control exactly once')
copies=[]
for name in rootnames:copies.append(copy(ROOT/name,Path('final-root-originals')/name))
for label in labels:
 for product in [p['product'] for p in products if p['tuple']==label]:
  d=ROOT/label/'observations'/product
  for name in ['annotations.pdf','result.properties']:copies.append(copy(d/name,Path('selected-public-products')/label/product/name))
completeinputs=dict(seen);completeinputs.update(files)
dump('complete-original-raw-root-identities.json',raw)
dump('complete-record-report-reference-identities.json',references)
dump('complete-qualified-rule-control-identities.json',controls)
dump('complete-inspected-input-identities.json',sorted(completeinputs.values(),key=lambda x:x['path']))
count={'tuples':len(labels),'formal-tests-per-tuple':[x['formal-tests'] for x in tests],'chain-records':sum(len(x['records']) for x in certs),'physical-tuple-files':len(physical),'observation-files':sum(sum(r['path'].startswith(str((ROOT/label/'observations').relative_to(REPO))+'/') for r in physical) for label in labels),'total-original-raw-root-files':len(raw),'root-files':len(rootnames),'unique-environment-files':sum(len(e['raw-files']) for e in environments.values()),'unique-before-after-directories':len(environments),'report-record-reference-occurrences':len(references),'qualified-rules':len(expectedrules),'rules-per-checker':{c:sum(k[0]==c for k in expectedrules) for c in ['pdfcpu','arlington-core','arlington-annotations']},'illegal-rule-control-executions':len(controls),'public-products':len(products),'positive-semantic-graphs':sum(x['control'] is None for x in graphs),'actual-semantic-mutation-graphs':sum(x['control'] is not None for x in graphs),'positive-page-visual-observations':sum('/negative/' not in x['directory'] and x['result']=='pass' for x in visuals),'actual-PDF-visual-defect-controls':len({x['directory'] for x in visuals if '/negative/' in x['directory']}),'one-pixel-controls':sum(r['path'].endswith('/observations/negative/visual/one-pixel/result.properties') for r in physical),'full-RGB-input-observations-unique-paths':len(rgb),'configuration-inputs-per-tuple':len(configinputs),'pinned-tools':len(tools),'current-stage-inputs':{'sources':len(build['candidate']['inputs']),'contracts':len(build['contract-inputs']),'artifacts':len(build['candidate']['artifacts']),'harness':len(build['harness'])}}
finish('all-eight-complete-raw-inspection.json',{'created-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'result':'CLEAN' if not errors else 'DIAGNOSTIC','scope':'Only fresh current-candidate annotations/T12 eight raw tuples and exact own-index. Actual outer/publication and final48/inventory/index/delivery remain separate.','candidate-sha256':CID,'contract-sha256':CT,'fixed-baseline':'5b1603c435f11c40368f75b7b9a2777c9c5e9761','counts':count,'tuple-observations':tests,'all-eight-own-index-sha256':sha(ROOT/'observed-index.json'),'original-batch-linkage':linked,'cross-profile-and-cross-JDK-public-outcome-parity':True,'cross-JDK-PNG-compressed-byte-equality-required':False,'all-inspected-inputs-unchanged':True,'eight-environment-reconstructions':list(environments.values()),'complete-raw-catalog-sha256':sha(PACKET/'complete-original-raw-root-identities.json'),'complete-input-catalog-sha256':sha(PACKET/'complete-inspected-input-identities.json'),'selected-additional-originals':copies,'actual-outer-or-authority-read':False,'annotations-publication-gate-closed':False,'no-project-execution-or-repository-mutation':True})
