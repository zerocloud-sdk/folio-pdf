from batch_factory import *
prepare(21,'HARDENED_WORKER','008-jdk21-hardened_worker-after-and-index-complete.json',True)
