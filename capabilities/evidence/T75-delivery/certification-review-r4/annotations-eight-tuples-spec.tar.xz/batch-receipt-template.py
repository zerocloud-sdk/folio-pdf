from auditlib import *
context=obj(OUT/'batch-context.json');scope=obj(OUT/'scope.json');label=context['tuple-directory'];records=[];catalog={}
scripts=['batch-schema','stage-audit','evidence-audit','graph-audit','raster-audit','complete-command-audit']
for name in scripts:
 result=obj(OUT/(name+'-result.json'));command=obj(OUT/(name+'-command.json'))
 eq(result['returncode'],0,'completed independent reader '+name)
 eq(result['command'],command['command'],'retained actual reader argv '+name)
 eq(result['script-sha256'],sha(OUT/(name+'.py')),'retained reader source '+name)
 eq(result['library-sha256'],sha(OUT/'auditlib.py'),'retained reader library '+name)
 for stream in ['stdout','stderr']:eq(sha(OUT/result[stream]['path']),result[stream]['sha256'],'retained original '+stream+' '+name)
 records.append({'script':name,'returncode':result['returncode'],'result-sha256':sha(OUT/(name+'-result.json')),'command-sha256':sha(OUT/(name+'-command.json'))})
inspections={}
for key,name in [('schema','actual-tuple-schema-inspection.json'),('stage',scope['stage-inspection']),('evidence','annotations-'+label+'-evidence-inspection.json'),('graph','annotations-'+label+'-direct-graph-inspection.json'),('raster','annotations-'+label+'-complete-rgb-raster-inspection.json'),('configuration','complete-command-configuration-inspection.json')]:
 data=obj(OUT/name);eq(data['errors'],[],'completed inspection '+key);inspections[key]={'path':name,'sha256':sha(OUT/name),'data':data}
 for row in obj(OUT/(name.removesuffix('.json')+'-read-identities.json')):
  if row['path'] in catalog:eq(catalog[row['path']],row,'same input across retained readers '+row['path'])
  catalog[row['path']]=row
raw=obj(OUT/(label+'-original-tuple-file-identities.json'))
for row in raw:
 absolute=str(REPO/row['path']);eq(catalog[absolute]['sha256'],row['sha256'],'complete size/hash catalog '+row['path'])
selected=[]
safety=ROOT/label/'observations/safety'
for p in sorted(safety.rglob('*')):
 if not p.is_file():continue
 if p.suffix in ['.properties','.json','.log','.txt'] or p.parent.name=='canaries' or p.name in ['signed-docmdp-p3.pdf','native-signed-target.pdf','facade-signed-target.pdf']:
  selected.append(copy(p,Path('selected-safety-originals')/p.relative_to(safety)))
e=inspections['evidence']['data'];r=inspections['raster']['data'];g=inspections['graph']['data'];s=inspections['stage']['data'];c=inspections['configuration']['data']
eq(e['tuples'][0]['tuple'],label,'exact scoped raw tuple');eq(c['tuple'],label,'exact scoped command tuple')
eq(c['actual-Facade-mode'],'IN_PROCESS','actual Facade mode retained')
dump('complete-batch-input-identities.json',sorted(catalog.values(),key=lambda x:x['path']))
finish('completed-tuple-bounded-receipt.json',{'tuple':label,'candidate':CID,'contract':CT,'result':'CLEAN','boundary':'Only this immutable raw tuple, assigned environments and fixed source/stage; root own-index and actual outer/publication remain excluded.','reader-results':records,'inspections':{k:{'path':v['path'],'sha256':v['sha256']} for k,v in inspections.items()},'formal-tests':c['formal-tests'],'formal-time-seconds':s['tuples'][0]['time-seconds'],'Native-mode':c['Native-mode'],'actual-Facade-mode':c['actual-Facade-mode'],'physical-raw-files':len(raw),'observation-files':e['tuples'][0]['observation-files'],'raw-input-identity-catalog':'complete-batch-input-identities.json','raw-input-identity-catalog-sha256':sha(OUT/'complete-batch-input-identities.json'),'complete-input-count':len(catalog),'rules':e['qualified-standards-rules'],'illegal-rule-controls':e['qualified-rule-control-executions'],'public-products':len(e['public-products']),'semantic-positive-graphs':g['positive-graphs'],'semantic-mutated-graphs':g['actual-mutation-graphs'],'complete-rgb-input-observations':r['input-raster-observations'],'canonical-rgb-inputs-shared-across-batches':len(r['authored-product-pages']),'checked-environments':[v['directory'] for v in s['environment-observations']],'deferred-AFTER':s['deferred-environment-post-check'],'full-config-inputs':c['configuration-inputs'],'selected-originals':selected,'all-original-reader-outputs-preserved':True,'history-boundary':'Historical r3 two lost derived summaries remain disclosed in the unchanged incident original; these are fresh r4 reads and do not recover historical bytes.'})
