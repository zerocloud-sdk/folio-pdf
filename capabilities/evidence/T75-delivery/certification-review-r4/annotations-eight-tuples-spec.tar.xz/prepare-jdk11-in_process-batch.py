from batch_factory import *
prepare(11,'IN_PROCESS','003-jdk11-in_process-before-complete.json',False)
