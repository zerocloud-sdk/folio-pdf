from auditlib import *
failed=PACKET/'raw-packet-retention-audit-result.json';failedresult=obj(failed)
eq(failedresult['returncode'],1,'preserved actual retention-reader diagnostic')
old=obj(PACKET/'raw-packet-retention-inspection.json')
eq(old['errors'],[{'where':'every retained selected original has an explicit original SHA/copy binding','detail':{'actual':False,'expected':True}}],'only the recorded copy-schema gap')
diag=obj(PACKET/'retention-copy-schema-diagnostic-inspection.json');eq(diag['errors'],[],'narrow copy inventory inspection')
b=PACKET/'batches/jdk8-in_process-9i7rufn6';preparation=obj(b/'qualified-reader-preparation-inspection.json');eq(preparation['errors'],[],'original template preparation clean')
rows=obj(PACKET/'selected-original-copy-identities.json');catalog={r['copy']:r for r in rows};added=[]
for r in preparation['prepared-readers']:
 original=Path(r['original-template']);dest=b/'selected-originals/qualified-reader-templates'/r['reader']
 eq(sha(original),r['original-sha256'],'original qualified template remains exact '+r['reader'])
 eq(sha(dest),r['original-sha256'],'byte-exact retained template '+r['reader'])
 eq(sha(b/r['reader']),r['current-sha256'],'original executed scoped reader remains exact '+r['reader'])
 row={'original':str(original),'copy':str(dest),'sha256':r['original-sha256'],'bytes':len(read(dest))};added.append(row);catalog[str(dest)]=row
eq({r['copy'] for r in added},{r['copy'] for r in diag['missing-copy-binding-records']},'exactly the four previously unrecognized source-schema entries')
selected={str(p) for p in PACKET.rglob('*') if p.is_file() and 'selected-originals' in p.relative_to(PACKET).parts}
eq(selected<=set(catalog),True,'every selected original has its original source/copy SHA binding')
for p in selected:eq(sha(Path(p)),catalog[p]['sha256'],'every current selected copy remains byte-exact '+p)
commands=[]
for p in sorted(PACKET.rglob('*-result.json')):
 if 'selected-originals' in p.relative_to(PACKET).parts:continue
 result=obj(p);code=result.get('returncode',result.get('exit_code'));eq(code,1 if p==failed else 0,'actual retained reader exit with one explicitly closed schema diagnostic')
 cp=p.with_name(p.name.removesuffix('-result.json')+'-command.json');command=obj(cp)
 if result.get('command') is not None:eq(result['command'],command['command'],'retained original command/result argv')
 if 'script-sha256' in result:
  eq(sha(Path(result['command'][-1])),result['script-sha256'],'retained executed reader source')
  eq(sha(p.parent/'auditlib.py'),result['library-sha256'],'retained executed reader library')
  for stream in ['stdout','stderr']:eq(sha(p.parent/result[stream]['path']),result[stream]['sha256'],'retained complete original '+stream)
 else:
  for stream in ['stdout','stderr']:
   if stream+'-sha256' in result:eq(sha(p.with_name(p.name.removesuffix('-result.json')+'-'+stream+'.txt')),result[stream+'-sha256'],'retained initial discovery original '+stream)
 commands.append({'result':str(p),'result-sha256':sha(p),'actual-returncode':code,'explicitly-closed-copy-schema-diagnostic':p==failed,'command':str(cp),'command-sha256':sha(cp)})
display=obj(PACKET/'auxiliary-display-boundary.json');schema=obj(PACKET/'root-schema-inspection.json');source=ROOT/'candidate-identity.txt'
eq(next(x['original-text'] for x in schema['members'] if x['path']==str(source.relative_to(REPO))),read(source).decode(),'auxiliary display limit did not truncate the retained original schema text')
eq(display['data-loss'],False,'auxiliary display boundary retained')
eq(obj(PACKET/'all-eight-complete-raw-inspection.json')['errors'],[],'raw/index review remains complete and clean')
dump('selected-original-copy-identities-schema-closure.json',sorted(catalog.values(),key=lambda x:x['copy']))
dump('completed-independent-command-results-schema-closure.json',commands)
finish('retention-copy-schema-closure-inspection.json',{'scope':'Only four already-retained template copies and their original-template/original-sha256 schema; original failing reader and outputs remain unchanged.','original-retention-result':{'path':str(failed),'sha256':sha(failed),'actual-returncode':1},'cause':'The generic copy walker required original/copy/sha256 keys. Original qualified-reader preparation uses original-template/original-sha256 and names the retained copy by reader.','newly-recognized-copy-bindings':added,'current-selected-original-files':len(selected),'complete-verified-copy-bindings':len(catalog),'all-current-selected-original-copies-byte-exact':True,'selected-copy-catalog':'selected-original-copy-identities-schema-closure.json','selected-copy-catalog-sha256':sha(PACKET/'selected-original-copy-identities-schema-closure.json'),'actual-command-result-catalog':'completed-independent-command-results-schema-closure.json','actual-command-result-catalog-sha256':sha(PACKET/'completed-independent-command-results-schema-closure.json'),'retained-completed-command-results-before-this-closure':len(commands),'current-r4-output-overwrites':0,'current-r4-certification-raw-data-loss':False,'auxiliary-display-boundary-sha256':sha(PACKET/'auxiliary-display-boundary.json'),'historical-r3-incident-original-sha256':old['historical-r3-incident-original']['sha256'],'historical-lost-derived-summaries-recovered':False,'all-historical-derived-review-artifacts-preserved':False,'all-eight-raw-and-own-index-remain-clean':True,'annotations-publication-gate-closed':False,'unresolved-current-scope-findings':[]})
