from auditlib import *
complete=obj(PACKET/'all-eight-complete-raw-inspection.json');eq(complete['errors'],[],'all-eight raw/index inspection clean')
eq(complete['annotations-publication-gate-closed'],False,'bounded raw-only publication deferral')
copies={};origins={};commands=[]
def visit(value,owner):
 if isinstance(value,dict):
  if {'original','copy','sha256'}<=set(value) and isinstance(value['copy'],str) and isinstance(value['original'],str):
   cp=Path(value['copy']);dest=cp if cp.is_absolute() else owner.parent/cp
   if dest.is_relative_to(PACKET) and dest.is_file():
    expected={'original':value['original'],'copy':str(dest),'sha256':value['sha256']}
    if str(dest) in copies:eq(copies[str(dest)],expected,'same selected copy binding')
    copies[str(dest)]=expected
  for child in value.values():visit(child,owner)
 elif isinstance(value,list):
  for child in value:visit(child,owner)
for p in sorted(PACKET.rglob('*.json')):
 if 'selected-originals' in p.relative_to(PACKET).parts:continue
 data=read(p)
 if b'"copy"' in data and b'"original"' in data:visit(json.loads(data),p)
for row in copies.values():
 original=Path(row['original']);eq(sha(original),row['sha256'],'unchanged selected original '+row['original']);eq(sha(Path(row['copy'])),row['sha256'],'byte-exact retained copy '+row['copy']);row['bytes']=len(read(original))
selected={str(p) for p in PACKET.rglob('*') if p.is_file() and 'selected-originals' in p.relative_to(PACKET).parts}
eq(selected<=set(copies),True,'every retained selected original has an explicit original SHA/copy binding')
for p in sorted(PACKET.rglob('*-result.json')):
 if 'selected-originals' in p.relative_to(PACKET).parts:continue
 result=obj(p);code=result.get('returncode',result.get('exit_code'))
 eq(code,0,'actual independent command result '+str(p))
 commandpath=p.with_name(p.name.removesuffix('-result.json')+'-command.json');command=obj(commandpath)
 if result.get('command') is not None:eq(result['command'],command['command'],'actual command/result argv agreement')
 if 'script-sha256' in result:
  source=Path(result['command'][-1]);eq(sha(source),result['script-sha256'],'retained exact executed reviewer source')
  eq(sha(p.parent/'auditlib.py'),result['library-sha256'],'retained exact executed reviewer helper')
  for stream in ['stdout','stderr']:eq(sha(p.parent/result[stream]['path']),result[stream]['sha256'],'retained complete original reader '+stream)
 else:
  for stream in ['stdout','stderr']:
   if stream+'-sha256' in result:eq(sha(p.with_name(p.name.removesuffix('-result.json')+'-'+stream+'.txt')),result[stream+'-sha256'],'retained initial discovery original '+stream)
 commands.append({'path':str(p),'sha256':sha(p),'actual-returncode':code,'script-sha256':result.get('script-sha256'),'command-original':str(commandpath),'command-sha256':sha(commandpath),'command-fields':command})
historical=PACKET/'selected-originals/prior-reader-originals/reader-output-incident-and-closure.json'
history=obj(historical)
dump('selected-original-copy-identities.json',sorted(copies.values(),key=lambda x:x['copy']))
dump('completed-independent-command-result-identities.json',commands)
finish('raw-packet-retention-inspection.json',{'scope':'Retention of actual current r4 review originals and unchanged historical incident disclosure; no reconstruction of lost historical bytes.','all-eight-raw-inspection-sha256':sha(PACKET/'all-eight-complete-raw-inspection.json'),'current-r4-selected-originals':len(selected),'verified-copy-bindings':len(copies),'selected-copy-catalog-sha256':sha(PACKET/'selected-original-copy-identities.json'),'completed-independent-command-results-before-this-retention-reader':len(commands),'original-command-result-catalog-sha256':sha(PACKET/'completed-independent-command-result-identities.json'),'current-r4-output-overwrites-observed':0,'historical-r3-incident-original':{'path':str(historical),'sha256':sha(historical),'original-fields':history},'historical-lost-derived-summary-bytes-recovered':False,'all-historical-derived-review-artifacts-preserved':False,'full-certification-raw-tree-duplicated':False,'annotations-publication-gate-closed':False})
