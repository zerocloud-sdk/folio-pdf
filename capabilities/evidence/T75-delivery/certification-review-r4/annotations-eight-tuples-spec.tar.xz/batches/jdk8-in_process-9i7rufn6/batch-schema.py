from auditlib import *
context=obj(OUT/'batch-context.json');read(Path(context['authorization-file']));scope=ROOT/context['tuple-directory'];copies=[];headers=[];aggregates=[]
major,mode=context['tuple'];eq(mode,'IN_PROCESS','this explicit first completed tuple only')
for p in sorted(scope.iterdir()):
 if not p.is_file():continue
 data=read(p);row={'name':p.name,'bytes':len(data),'sha256':sha(p)}
 if p.suffix in ['.json','.yaml']:
  value=obj(p)
  if isinstance(value,dict):row['schema']={'type':'object','keys':list(value),'scalars':{k:v for k,v in value.items() if not isinstance(v,(dict,list))},'arrays':{k:len(v) for k,v in value.items() if isinstance(v,list)},'objects':{k:list(v) for k,v in value.items() if isinstance(v,dict)}}
  elif isinstance(value,list):row['schema']={'type':'array','length':len(value),'members':value}
  else:error(p,'unexpected header JSON type')
 headers.append(row);copies.append(copy(p,Path('tuple-headers')/p.name))
for chain in ['syntax','standards','semantic','visual']:
 record=obj(scope/(chain+'.yaml'));eq(record['chain'],chain,'actual chain');eq(record['result'],'pass','actual complete chain PASS');eq(record['candidate-sha256'],CID,'actual current candidate');eq(record['contract-sha256'],CT,'actual unchanged contract');eq(record['execution-profile'],mode,'actual selected Native profile')
obs=scope/'observations'
for p in sorted(obs.iterdir()):
 if not p.is_file():continue
 if p.suffix=='.properties':value=props(p)
 elif p.suffix=='.json':value=obj(p)
 else:value=None
 aggregates.append({'name':p.name,'bytes':len(read(p)),'sha256':sha(p),'value':value});copies.append(copy(p,Path('observation-aggregates')/p.name))
envcopies=[]
for name in context['allowed-environment-directories']:
 d=ROOT/name
 for p in sorted(d.iterdir()):
  if p.is_file():envcopies.append(copy(p,Path('environment-before')/p.name))
schema={'scope':context['tuple-directory'],'headers':headers,'observation-top-level-members':[p.name for p in sorted(obs.iterdir())],'aggregate-files':aggregates,'actual-current-candidate':CID,'actual-contract':CT,'Native-mode':mode,'allowed-environment-directories':context['allowed-environment-directories'],'deferred-environment-directories':context['deferred-environment-directories'],'root-identity-and-own-index-read':False,'selected-original-copies':copies+envcopies}
finish('actual-tuple-schema-inspection.json',schema)
