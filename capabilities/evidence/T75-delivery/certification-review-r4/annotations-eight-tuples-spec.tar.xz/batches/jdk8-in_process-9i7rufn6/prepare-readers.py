from auditlib import *
import ast
context=obj(OUT/'batch-context.json');tuple_name=context['tuple-directory'];scope={'batch':tuple_name,'tuples':[context['tuple']],'stage-inspection':'stage-environment-contract-'+tuple_name+'-inspection.json'}
eq(context['tuple'],[8,'IN_PROCESS'],'explicit authorized single tuple');eq(tuple_name,'jdk8-in_process','actual unique tuple label');eq(context['allowed-environment-directories'],['jdk8-environment'],'only authorized BEFORE');eq(context['deferred-environment-directories'],['jdk8-environment-after'],'AFTER remains explicitly deferred')
dump('scope.json',scope)
templates=OLD/'batch-jdk21-p77mn8_t';prepared=[]
for name in ['evidence-audit.py','graph-audit.py','raster-audit.py']:
 original=read(templates/name).decode();copy(templates/name,Path('qualified-reader-templates')/name);tree=ast.parse(original)
 insertion=ast.parse("TUPLES=[tuple(x) for x in obj(OUT/'scope.json')['tuples']]\n").body[0]
 tree.body.insert(1,insertion);new=ast.unparse(ast.fix_missing_locations(tree))+'\n'
 original_functions={n.name:ast.dump(n,include_attributes=False) for n in ast.parse(original).body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))};new_functions={n.name:ast.dump(n,include_attributes=False) for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))};eq(original_functions,new_functions,'all qualified algorithm functions unchanged '+name)
 with (OUT/name).open('x') as f:f.write(new)
 prepared.append({'reader':name,'original-template':str(templates/name),'original-sha256':sha(templates/name),'current-sha256':sha(OUT/name),'algorithm-functions-AST-identical':list(original_functions),'only-adaptation':'Read explicit single-tuple scope from this unique batch; existing parameterized filenames include actual JDK/profile.'})
original=read(templates/'stage-audit.py').decode();copy(templates/'stage-audit.py','qualified-reader-templates/stage-audit.py');tree=ast.parse(original)
start=next(i for i,n in enumerate(tree.body) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='source' for t in n.targets));tail=tree.body[start:]
for node in tail:
 if isinstance(node,ast.For) and isinstance(node.target,ast.Tuple) and [x.id for x in node.target.elts]==['major','suffix']:
  node.body.insert(1,ast.parse("if name not in BATCH_CONTEXT['allowed-environment-directories']:\n continue\n").body[0])
 if isinstance(node,ast.Expr) and isinstance(node.value,ast.Call) and isinstance(node.value.func,ast.Name) and node.value.func.id=='finish':
  node.value.args[0]=ast.parse("SCOPE['stage-inspection']",mode='eval').body
  fields=node.value.args[1]
  for i,key in enumerate(fields.keys):
   if isinstance(key,ast.Constant) and key.value=='matches-worker-batch-host-matrix-inputs':fields.keys[i]=ast.Constant('matches-r4-fixed-source-preflight')
   if isinstance(key,ast.Constant) and key.value=='deferred-environment-post-check':fields.values[i]=ast.parse("BATCH_CONTEXT['deferred-environment-directories']",mode='eval').body
   if isinstance(key,ast.Constant) and key.value=='complete-eight-tuple-index-at-inspection':fields.keys[i]=ast.Constant('root-own-index-read');fields.values[i]=ast.Constant(False)
prelude="""from auditlib import *
import ast,datetime,yaml
BATCH_CONTEXT=obj(OUT/'batch-context.json');SCOPE=obj(OUT/'scope.json');TUPLES=[tuple(x) for x in SCOPE['tuples']]
preflight=obj(PACKET/'fixed-protocol-source-preflight-inspection.json');eq(preflight['errors'],[],'closed current r4 source preflight');lineage=obj(PACKET/'closed-source-lineage-inspection.json');eq(lineage['errors'],[],'closed current r4 source/validation identity linkage')
stage=REPO/'capabilities/evidence/T75-delivery/final-candidate-r4';build=obj(stage/'build-inputs.json');eq(sha(stage/'build-inputs.json'),preflight['stage-identity-sha256'],'same r4 stage as current full input preflight');eq(read(stage/'build-inputs.json'),read(REPO/'target/foundation-0.1.0/build-inputs.json'),'current staged build copy')
candidate=build['candidate'];contract=build['contract-inputs'];groups={'sources':candidate['inputs'],'contracts':contract,'artifacts':candidate['artifacts'],'harness':build['harness']};observed={k:len(v) for k,v in groups.items()};eq(observed,preflight['current-stage-input-counts'],'unchanged1933/30/23/24 stage graph')
for group in ['artifacts','harness']:
 for row in groups[group]:eq(sha(REPO/row['path']),row['sha256'],'actual staged '+group+' identity '+row['path'])
canonical=lambda kind,rows:''.join(kind+' '+r['path']+' '+r['sha256']+'\\n' for r in sorted(rows,key=lambda r:r['path']))
cid=lines_hash('release '+candidate['release']+'\\n'+canonical('input',candidate['inputs'])+canonical('artifact',candidate['artifacts']));tid=lines_hash(canonical('contract',contract));eq(cid,CID,'actual current canonical candidate');eq(tid,CT,'actual canonical contract')
eq(obj(stage/'t75-final-stage-r4-result.json')['returncode'],0,'actual fresh r4 stage exit0')
"""
newtree=ast.parse(prelude);newtree.body.extend(tail)
# Extra envelope checks enforce the precise completed batch without changing existing T12 predicates.
finish_index=next(i for i,n in enumerate(newtree.body) if isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Name) and n.value.func.id=='finish')
checks=ast.parse("eq(len(environments),len(BATCH_CONTEXT['allowed-environment-directories']),'all and only authorized complete environments observed')\neq(len(tuples),len(TUPLES),'all and only explicit complete tuples observed')\n").body
newtree.body[finish_index:finish_index]=checks
with (OUT/'stage-audit.py').open('x') as f:f.write(ast.unparse(ast.fix_missing_locations(newtree))+'\n')
prepared.append({'reader':'stage-audit.py','original-template':str(templates/'stage-audit.py'),'original-sha256':sha(templates/'stage-audit.py'),'current-sha256':sha(OUT/'stage-audit.py'),'changes':['Bind r4 stage and already checked source/validation identities; independently recompute canonical candidate/contract and staged binary hashes.','Remove historical r3/Worker-overlay and current raw root-probe reads; current root/own-index remain excluded.','Observe only explicitly complete batch environments; record pending AFTER without reading it.','Use exact current tuple output name in a new unique batch; keep actual T12 command/configuration/tool/environment/test guards.']})
finish('qualified-reader-preparation-inspection.json',{'scope':scope,'batch-context':context,'prepared-readers':prepared,'current-raw-reads-during-preparation':0,'repository-or-original-reader-mutations':False,'qualified-algorithms-preserved':True,'root-own-index-and-outer-publication-excluded':True})
