from auditlib import *
TUPLES = [tuple(x) for x in obj(OUT / 'scope.json')['tuples']]
from collections import Counter
from decimal import Decimal
import sys
BATCH = obj(OUT / 'scope.json')['batch']
STAGE_FILE = obj(OUT / 'scope.json')['stage-inspection']
stage = obj(OUT / STAGE_FILE)
eq(stage['errors'], [], 'stage clean')
CID = stage['candidate-sha256']
TID = stage['contract-sha256']
P = 'T12-annotations-document-actions'
profile = REPO / 'capabilities/evidence/T12-annotations-document-actions.md'
C = REPO / 'capabilities/profiles/T12-standards'
corpusroot = REPO / 'capabilities/profiles/T12-annotations'
corpus = obj(corpusroot / 'corpus.json')
names = ['created', 'changed', 'flattened', 'copied', 'merged', 'adopted', 'left', 'right']
editions = [a + '-' + n for a in ['native', 'facade'] for n in names]
chains = ['syntax', 'standards', 'semantic', 'visual']
checkers = ['pdfcpu', 'arlington-core', 'arlington-annotations']
changes = ['order', 'identifier', 'rectangle', 'appearance', 'appearance-box', 'payload', 'icon', 'direct-target', 'action-operand', 'named-target', 'copy-target', 'copy-external', 'merge-name', 'split-survival', 'open-adoption', 'flatten-removal', 'flatten-placement', 'retained-paint']
rules = read(C / 'required-rules.txt').decode().splitlines()
eq(len(set(rules)), 174, 'all174 required rules')
eq(sha(C / 'required-rules.txt'), '4be1e31062eafdfff6efd2d29d5217287c5c1a5186aed693a0c608672ba9e98e', 'required catalog frozen')
profiles = {c: props(C / (c + '.properties')) for c in checkers}
pinpaths = {c: REPO / ('scripts/' + ('t12-arlington' if c.startswith('arlington') else c) + '-pin.properties') for c in checkers}
pins = {c: props(pinpaths[c]) for c in checkers}
eq(sorted((r for c in checkers for r in profiles[c]['required-rules'].split(','))), sorted(rules), 'exact full no-duplicate rule assignment')
eq([len(profiles[c]['required-rules'].split(',')) for c in checkers], [69, 68, 37], 'exact checker groups')
for c, pin in pins.items():
    eq(sha((REPO / 'scripts' / pin['executable']).resolve()), pin['sha256'], 'actual checker binary ' + c)
    eq(pin['timeout-ms'], '10000', 'finite checker timeout')
    eq(pin['max-output-bytes'], '1048576', 'finite checker output')
    eq(profiles[c]['covered-rules'], profiles[c]['required-rules'], 'all assigned rules ' + c)
model = (REPO / 'scripts' / pins['arlington-core']['model']).resolve()
models = sorted(model.glob('*.tsv'))
eq(len(models), 613, 'full pinned model file count')
eq(lines_hash(''.join((p.name + ' ' + sha(p) + '\n' for p in models))), pins['arlington-core']['model-sha256'], 'full model identity')
eq(any((p.is_symlink() for p in models)), False, 'no linked model inputs')
eq(sha((REPO / 'scripts' / pins['arlington-core']['patch']).resolve()), pins['arlington-core']['patch-sha256'], 'actual checker patch')
eq(sha(Path('/usr/lib/x86_64-linux-gnu/libexpat.a')), pins['arlington-core']['expat-static-archive-sha256'], 'acceptance-only static Expat identity')
qpin = props(REPO / 'scripts/qpdf-pin.properties')
ppin = props(REPO / 'scripts/pdfium-pin.properties')
mpin = props(REPO / 'scripts/imagemagick-pin.properties')
pythonsha = sha(Path('/usr/bin/python3.12'))
semsha = sha(REPO / 'scripts/t12-semantics.py')
safetysha = sha(REPO / 'scripts/t12-safety-observer.py')
qwrapper = sha(REPO / 'scripts/container-bin/qpdf')
corpussha = sha(corpusroot / 'corpus.json')
stdsource = read(REPO / 'pdf-acceptance/src/main/java/net/zerocloud/pdf/acceptance/StandardsEvidenceCommand.java').decode()
constant = stdsource.split('private static final String PDFCPU_20_NOTICE =', 1)[1].split(';', 1)[0]
notice = ''.join((json.loads(x) for x in re.findall('"(?:\\\\.|[^"\\\\])*"', constant)))
allrefs = []
physicalrows = []
tuples = []
products = []
controls = []
visuals = []
semantics = []
safety = []

def ref(p):
    return {'path': str(p.relative_to(REPO)), 'sha256': sha(p)}

def refs(value, owner):
    if isinstance(value, dict):
        if isinstance(value.get('path'), str) and isinstance(value.get('sha256'), str):
            q = PurePosixPath(value['path'])
            p = REPO / value['path']
            eq(not q.is_absolute() and '..' not in q.parts and (q.as_posix() == value['path']), True, 'canonical reference ' + str(owner))
            eq(p.resolve(), p, 'no linked original reference ' + str(owner))
            eq(sha(p), value['sha256'], 'bound original reference ' + str(owner))
            yield {'owner': str(owner.relative_to(REPO)), **value}
        for v in value.values():
            yield from refs(v, owner)
    elif isinstance(value, list):
        for v in value:
            yield from refs(v, owner)

def md(s, key):
    return re.findall('^' + re.escape(key) + ': `([^`\\r\\n]*)`$', s, re.M)

def fields(s, expected, where):
    for k, v in expected.items():
        eq(md(s, k), [str(v)], str(where) + ' ' + k)

def syntax_check(d, filename, wanted):
    txt = read(d / 'syntax.txt').decode()
    h = sha(d / filename)
    fields(txt, {'Input exact SHA-256': h, 'Input hash policy': 'SHA-256 of the exact unmodified PDF bytes', 'Tool': 'qpdf', 'Tool version': qpin['QPDF_VERSION'], 'Distribution SHA-256': qpin['QPDF_ARCHIVE_SHA256'], 'Invocation': 'qpdf --check ' + filename, '`' + filename + '` exit code': 0 if wanted == 'pass' else 2, 'Final determination': wanted}, str(d) + ' original syntax')
    fields(read(d / 'syntax.md').decode(), {'Result': wanted, 'Input exact SHA-256': h}, str(d) + ' syntax summary')
    if wanted == 'pass':
        eq('No syntax or stream encoding errors found; the file may still contain\nerrors that qpdf cannot detect' in txt, True, str(d) + ' actual qpdf success')
        eq(re.findall('### Standard error\\n\\n```text\\n(.*?)\\n```', txt, re.S), [''], str(d) + ' clean qpdf stderr')
    else:
        eq('unable to find trailer dictionary while recovering damaged file' in txt, True, str(d) + ' actual truncated-PDF detection')

def standard(d, h, checker, wanted='pass', tuple_name='', edition=''):
    q = profiles[checker]
    pin = pins[checker]
    folder = d / checker if wanted == 'pass' else d
    expected = {'result': wanted, 'profile': P, 'covered-rules': q['required-rules'] if wanted == 'pass' else '', 'executable-sha256': pin['sha256'], 'model-sha256': pin.get('model-sha256', 'none'), 'patch-sha256': pin.get('patch-sha256', 'none'), 'input-sha256': h, 'pin-sha256': sha(pinpaths[checker]), 'profile-sha256': sha(C / (checker + '.properties'))}
    eq(props(folder / 'standards.properties'), expected, str(folder) + ' complete qualified checker binding')
    raw = read(folder / 'findings.txt').decode()
    version, sep, validation = raw.partition('\nValidation exit: ')
    eq(version.startswith('Version exit: 0\n') and pin['version'] in version, True, str(folder) + ' actual observed checker version')
    eq(bool(sep), True, str(folder) + ' actual validation process')
    eq(validation.startswith(('0' if wanted == 'pass' else '1') + '\n'), True, str(folder) + ' actual validation exit')
    positive = validation[2:].partition('\nNegative control ')[0].strip()
    if wanted == 'fail':
        eq('entry=Rect invalid type types.StringLiteral' in positive and 'validation error (obj#:' in positive, True, str(folder) + ' actual public rectangle defect diagnostic')
        return raw
    if checker == 'pdfcpu':
        eq(re.fullmatch('validating\\(mode=strict\\) [^\\r\\n]+ \\.\\.\\.\\n\\n' + re.escape(notice) + '\\nvalidation ok', positive) is not None, True, str(folder) + ' exact frozen PDF2 notice followed strict success')
    else:
        eq(' BEGIN - TestGrammar ' in positive and '\nEND\n' in positive and positive.endswith('DONE - 1 files processed') and ('Error:' not in positive) and ('Warning:' not in positive) and ('Info: Processing as PDF 2.0' in positive), True, str(folder) + ' original qualified Arlington positive')
    for rule in q['required-rules'].split(','):
        control = folder / ('control-' + rule + '.pdf')
        diagfile = folder / ('negative-' + rule + '.txt')
        hcontrol = q['negative.' + rule + '.sha256']
        eq(sha(control), hcontrol, 'retained original rule control ' + str(control))
        eq(sha(C / q['negative.' + rule + '.path']), hcontrol, 'frozen illegal authority ' + rule)
        diag = read(diagfile).decode()
        eq(q['negative.' + rule + '.finding'] in diag, True, 'actual assigned diagnostic ' + str(diagfile))
        eq(diag.startswith('exit=1\n') if checker == 'pdfcpu' else diag.startswith('exit=0\n') and '\nError: ' in diag, True, 'actual control process result ' + str(diagfile))
        eq('Negative control ' + rule + ' sha256=' + hcontrol + ' detected=true' in raw.splitlines(), True, 'actual control qualification ' + rule)
        controls.append({'tuple': tuple_name, 'product': edition, 'checker': checker, 'rule': rule, 'control-sha256': hcontrol, 'diagnostic-sha256': sha(diagfile)})
    return raw
SUCCESS = 'All frozen annotation, Action, target, payload and retained-paint expectations matched.'

def semantic_check(d, pdf, product, actualmode, change=None, source=None):
    h = sha(pdf)
    q = d / 'qpdf'
    r = props(q / 'result.properties')
    wanted = 'fail' if change else 'pass'
    finding = r.get('finding')
    eq(finding.startswith('Frozen semantic mismatch: ') if change else finding == SUCCESS, True, str(d) + ' original semantic finding')
    expected = {'profile': P, 'semantic': wanted, 'input-sha256': h, 'python-version': '3.12.3', 'observer-sha256': semsha, 'python-executable-sha256': pythonsha, 'semantic-scope': 'independent-qpdf-object-graph', 'expectations-sha256': corpussha, 'qpdf-wrapper-sha256': qwrapper, 'qpdf-version': '12.4.0', 'qpdf-binary-sha256': qpin['QPDF_BINARY_SHA256'], 'qpdf-json-sha256': sha(q / 'qpdf.json'), 'finding': finding}
    eq(r, expected, str(q) + ' complete independent semantic identity')
    eq(read(q / 'qpdf-version.txt').decode(), 'qpdf version 12.4.0\nRun qpdf --copyright to see copyright and license information.\n', str(q) + ' actual qpdf version')
    eq(read(q / 'qpdf-version-stderr.txt'), b'', str(q) + ' version stderr')
    eq(read(q / 'qpdf-stderr.txt'), b'', str(q) + ' successful graph stderr')
    text = 'Input exact SHA-256: ' + h + '\n' + finding + '\n'
    eq(read(q / 'semantic.txt').decode(), text, str(q) + ' original semantic transcript')
    eq(read(d / 'semantic.txt').decode(), text, str(d) + ' original semantic transcript')
    eq(read(d / 'semantic-command.txt').decode(), 'python: /usr/bin/python3.12\nobserver: scripts/t12-semantics.py\ninput exact SHA-256: ' + h + '\nexit-code: 0\n\n', str(d) + ' original observer invocation result')
    outer = dict(expected, **{'public-observation': 'indeterminate' if change else 'pass', 'execution-profile': 'unavailable' if change else actualmode})
    if change:
        outer.update({'source-sha256': sha(source), 'control': change})
        eq(props(d / 'result.properties'), outer, str(d) + ' independent negative before public observation')
    else:
        eq(props(d / 'semantic.properties'), outer, str(d) + ' actual selected-mode positive public observation')
        observed = obj(q / 'observed.json')
        eq({k: observed[k] for k in ['pages', 'annotations', 'destinations', 'actions']}, {k: corpus['products'][product][k] for k in ['pages', 'annotations', 'destinations', 'actions']}, str(d) + ' all actual independently observed public values')
    semantics.append({'directory': str(d.relative_to(ROOT)), 'product': product, 'control': change, 'input-sha256': h, 'graph-sha256': sha(q / 'qpdf.json'), 'observed-json-sha256': sha(q / 'observed.json'), 'result': wanted, 'finding': finding, 'actual-positive-public-mode': None if change else actualmode, 'negative-public-observation-boundary': 'independent graph rejection precedes the optional public observer' if change else None})
    return finding

def visual_check(d, product, page, h, expected_ae=0):
    info = corpus['products'][product]['visual'][page - 1]
    vp = props(corpusroot / 'visual' / (product + '-page-' + str(page) + '.properties'))
    prefix = 'page-' + str(page)
    txt = read(d / (prefix + '-visual.txt')).decode()
    wanted = 'pass' if expected_ae == 0 else 'fail'
    hashes = {label + ' raster SHA-256': sha(d / (prefix + '-' + suffix + '.png')) for label, suffix in [('Expected', 'expected'), ('PDFium', 'pdfium'), ('Implementation', 'implementation'), ('Difference', 'difference'), ('Renderer difference', 'renderer-difference')]}
    eq(hashes['Expected raster SHA-256'], info['raster-sha256'], str(d) + ' frozen original expected PNG')
    projection = d / (prefix + '-appearance-projection.pdf')
    fields(txt, dict(hashes, **{'Input exact SHA-256': h, 'Input hash policy': 'SHA-256 of the exact unmodified PDF bytes', 'Original exact SHA-256': h, 'Projection exact SHA-256': sha(projection), 'Profile': vp['PROFILE_ID'], 'DPI': 144, 'Raster dimensions': '240x200', 'Comparison metric': 'AE', 'Comparison fuzz percent': 0, 'Comparison threshold': 0, 'Renderer agreement threshold': 0, 'Expected comparison AE': expected_ae, 'Renderer agreement AE': 0, 'Review required': 'false', 'PDFium CLI version': ppin['PDFIUM_CLI_VERSION'], 'PDFium engine version': ppin['PDFIUM_ENGINE_VERSION'], 'ImageMagick version': mpin['IMAGEMAGICK_VERSION'], 'Implementation renderer version': '3.0.8', 'Final determination': wanted}), str(d) + ' original visual/projection identity')
    for k, field in [('PAGE_BOX', 'Page box'), ('COLOR_POLICY', 'Color policy'), ('FONT_POLICY', 'Font policy'), ('ANTIALIASING_POLICY', 'Antialiasing policy')]:
        fields(txt, {field: vp[k]}, str(d) + ' fixed visual settings')
    cmp = 'magick compare -metric AE -fuzz 0% -highlight-color #ff0000 -lowlight-color #ffffff -define png:exclude-chunk=time,date '
    expected_invocations = ['pdfium --version', 'pdfium flatten annotations.pdf ' + prefix + '-appearance-projection.pdf', 'pdfium render ' + prefix + '-appearance-projection.pdf ' + prefix + '-pdfium.png --dpi 144 --file-type png --pages ' + ('first' if page == 1 else str(page)), 'magick --version', cmp + prefix + '-expected.png ' + prefix + '-pdfium.png ' + prefix + '-difference.png', cmp + prefix + '-pdfium.png ' + prefix + '-implementation.png ' + prefix + '-renderer-difference.png']
    eq(md(txt, 'Invocation'), expected_invocations, str(d) + ' six complete original visual invocations')
    eq(md(txt, 'Exit code'), ['0', '0', '0', '0', '0' if expected_ae == 0 else '1', '0'], str(d) + ' actual6 process results')
    stdout = re.findall('### Standard output\\n\\n```text\\n(.*?)\\n```', txt, re.S)
    stderr = re.findall('### Standard error\\n\\n```text\\n(.*?)\\n```', txt, re.S)
    eq(len(stdout), 6, str(d) + ' complete6 original stdout')
    eq(len(stderr), 6, str(d) + ' complete6 original stderr')
    eq(stdout[:3], ['pdfium version ' + ppin['PDFIUM_CLI_VERSION'], '', 'Rendered page ' + str(page) + ' into ' + prefix + '-pdfium.png'], str(d) + ' actual identity/projection/render output')
    eq(stdout[3].startswith('Version: ImageMagick ' + mpin['IMAGEMAGICK_VERSION'] + ' '), True, str(d) + ' actual comparator version')
    eq(stdout[4:], ['', ''], str(d) + ' actual comparator stdout')
    eq(stderr[:4], ['', '', '', ''], str(d) + ' identity/projection/render stderr')
    eq(re.fullmatch(re.escape(str(expected_ae)) + ' \\([0-9.eE+-]+\\)', stderr[4]) is not None, True, str(d) + ' raw exact primary AE')
    eq(stderr[5], '0 (0)', str(d) + ' raw secondary AE0')
    rgb_counts = re.findall('^Exact changed RGB pixels, expected to PDFium: ([0-9]+)$', txt, re.M)
    eq(len(rgb_counts), 1, str(d) + ' separate original full RGB count')
    rgb_count = int(rgb_counts[0])
    eq(rgb_count > 0 if expected_ae > 0 else rgb_count == 0, True, str(d) + ' raw RGB and comparator zero/nonzero agreement')
    eq('Exact changed RGB pixels, PDFium to secondary: 0' in txt, True, str(d) + ' original full RGB secondary count')
    fields(read(d / (prefix + '-visual.md')).decode(), {'Result': wanted, 'Input exact SHA-256': h, 'Expected raster SHA-256': hashes['Expected raster SHA-256'], 'PDFium raster SHA-256': hashes['PDFium raster SHA-256'], 'Implementation raster SHA-256': hashes['Implementation raster SHA-256'], 'PDFium executable SHA-256': ppin['PDFIUM_EXECUTABLE_SHA256'], 'ImageMagick executable SHA-256': mpin['IMAGEMAGICK_EXECUTABLE_SHA256']}, str(d) + ' existing T12 summary fields')
    visuals.append({'directory': str(d.relative_to(ROOT)), 'product': product, 'page': page, 'input-sha256': h, 'projection-sha256': sha(projection), 'actual-primary-AE': str(expected_ae), 'actual-primary-RGB-different-pixels': rgb_count, 'actual-secondary-AE': 0, 'result': wanted, 'raw-sha256': sha(d / (prefix + '-visual.txt')), 'raster-hashes': hashes})

def safety_check(d, name, major, mode):
    probe = d / 'probe'
    actual = props(probe / 'result.properties')
    wanted = {'profile': P, 'native-execution-profile': mode, 'facade-execution-profile': 'IN_PROCESS', 'result': 'pass', 'signed-source-sha256': sha(probe / 'signed-docmdp-p3.pdf')}
    for api in ['native', 'facade']:
        execution = mode if api == 'native' else 'IN_PROCESS'
        for graph in ['unknown', 'chained']:
            key = api + '.' + graph + '.'
            wanted.update({key + 'execution-profile': execution, key + 'atomic': 'pass', key + 'preserved': 'pass', key + 'replaced': 'pass', key + 'source-unchanged': 'pass', key + 'query-code': 'QUERY_FAILED', key + 'query-capability': 'document.annotations-actions.manage', key + 'query-diagnostic': 'The supported Actions could not be inspected safely.', key + 'copy-code': 'PRESERVATION_UNSUPPORTED', key + 'copy-capability': 'document.page.manipulate-merge-split', key + 'copy-diagnostic': 'The document contains structures that this page operation cannot preserve safely.'})
            for phase in ['source', 'preserved', 'replaced']:
                pdf = probe / (api + '-' + graph + '-' + phase + '.pdf')
                wanted.update({key + phase + '.receipt-status': 'COMMITTED', key + phase + '.partial-output-possible': 'false', key + phase + '.path': '/workspace/' + str(pdf.relative_to(REPO)), key + phase + '.sha256': sha(pdf)})
                eq(read(pdf).startswith(b'%PDF-2.0'), True, str(pdf) + ' actual original public PDF2 product')
        wanted.update({api + '.signed-code': 'SIGNED_REWRITE_REJECTED', api + '.signed-capability': 'document.incremental-signature.protect', api + '.signed-diagnostic': 'A Source with an Existing Signature cannot be published with REWRITE.', api + '.signed-target-unchanged': 'pass'})
        eq(read(probe / (api + '-signed-target.pdf')), b'FOLIO', name + ' exact signed target sentinel ' + api)
    eq(actual, wanted, name + ' full original public safety properties')
    eq(wanted['signed-source-sha256'], '097e5febe12e153f2c95b433ee5d167e59c68f02d846a53fa44be9aded10a8e3', name + ' original synthetic signed fixture')
    b = read(probe / 'signed-docmdp-p3.pdf')
    br = re.search(b'/ByteRange \\[(\\d+) (\\d+) (\\d+) (\\d+)\\]', b)
    eq(br is not None, True, name + ' original signed byte range')
    a0, n0, a1, n1 = map(int, br.groups())
    eq(a0, 0, name + ' signature begin')
    eq(a1 + n1, len(b), name + ' signature whole EOF')
    eq(b[n0:n0 + 1] + b[a1 - 1:a1], b'<>', name + ' excluded signature Contents')
    eq(b'/TransformMethod /DocMDP /TransformParams << /Type /TransformParams /P 3 /V /1.2 >>' in b, True, name + ' DocMDP P3 protection control')
    effects = d / 'effects'
    observed = obj(effects / 'observation.json')
    keys = ['read', 'write', 'script', 'process', 'network']
    counts = observed.get('qualification_counts', {})
    eq(set(counts), set(keys), name + ' all five actual positive control counters')
    eq(all((type(counts[k]) == int and counts[k] > 0 for k in keys)), True, name + ' independently observed real qualification effects')
    java_raw = read(ROOT / ('jdk' + str(major) + '-environment/java-version.txt')).decode()
    javahome = re.search('^\\s*java.home = (.+)$', java_raw, re.M)[1].strip()
    cp = ':'.join(('/workspace/' + s for s in stage['tuples'][0]['staged-classpath-paths']))
    expected_command = [javahome + '/bin/java', '-cp', cp, 'net.zerocloud.pdf.acceptance.T12ActionSafetyProbe', '/workspace', '/workspace/' + str(probe.relative_to(REPO)), mode]
    expected = {'result': 'pass', 'observer_sha256': safetysha, 'python_sha256': pythonsha, 'python_version': '3.12.3 (main, Jun 19 2026, 12:46:00) [GCC 13.3.0]', 'kernel': read(ROOT / ('jdk' + str(major) + '-environment/kernel.txt')).decode().strip(), 'command': expected_command, 'scope': 'Declared Action canary file access, writes, launch access, script file effect and loopback connection; all descendant processes', 'qualification': {k: 'pass' for k in keys}, 'qualification_counts': counts, 'child_exit': 0, 'effects': {k: 0 for k in keys}}
    eq(observed, expected, name + ' complete qualified actual effect observation')
    ep = {'result': 'pass', 'observer-sha256': safetysha, 'python-sha256': pythonsha, 'child-exit': '0'}
    ep.update({'qualification.' + k: 'pass' for k in keys})
    ep.update({'effects.' + k: '0' for k in keys})
    eq(props(effects / 'observation.properties'), ep, name + ' effect properties cross-reference')
    eq(props(d / 'result.properties'), dict(actual, **{'effect-observer-sha256': safetysha, 'effect-observation-sha256': sha(effects / 'observation.json')}), name + ' aggregate safety exact bindings')
    eq(read(d / 'observer-command.txt'), b'\n', name + ' original Linux observer command output')
    eq(read(effects / 'child.log'), b'', name + ' original public Action child completed without diagnostic')
    for kind, data in [('read', b'original canary\n'), ('write', b'qualified'), ('script', b'qualified'), ('process', b'#!/bin/sh\nexit 0\n')]:
        eq(read(effects / 'canaries' / kind), data, name + ' retained actual qualified canary ' + kind)
    safety.append({'tuple': name, 'actual-native-mode': mode, 'actual-facade-mode': 'IN_PROCESS', 'public-action-scenarios': 4, 'qualification-counts': counts, 'effects': observed['effects'], 'child-exit': 0, 'observer-sha256': safetysha, 'effect-observation-sha256': sha(effects / 'observation.json'), 'public-probe-sha256': sha(probe / 'result.properties'), 'selected-mode-preserved-reopened-replaced-scenarios': True, 'scope': observed['scope'], 'signed-source-sha256': wanted['signed-source-sha256']})
    return [p for p in sorted(d.rglob('*')) if p.is_file()]

def changed_product(change):
    if change in ['payload', 'icon']:
        return 'changed'
    if change.startswith('copy-'):
        return 'copied'
    if change == 'merge-name':
        return 'merged'
    if change == 'split-survival':
        return 'left'
    if change == 'open-adoption':
        return 'adopted'
    if change.startswith('flatten-') or change == 'retained-paint':
        return 'flattened'
    return 'created'
for major, mode in TUPLES:
    name = 'jdk' + str(major) + '-' + mode.lower()
    scope = ROOT / name
    obs = scope / 'observations'
    physical = sorted((p for p in scope.rglob('*') if p.is_file()))
    eq(any((p.is_symlink() for p in scope.rglob('*'))), False, name + ' no linked raw evidence')
    physicalrows.extend(({'tuple': name, **ref(p)} for p in physical))
    expected = {'profile': P, 'native-execution-profile': mode, 'facade-execution-profile': 'IN_PROCESS', 'safety': 'pass'}
    expected.update({c: 'pass' for c in chains})
    expected.update({a + '.' + n + '.' + c: 'pass' for a in ['native', 'facade'] for n in names for c in chains})
    eq(props(obs / 'result.properties'), expected, name + ' original aggregate result')
    eq(props(obs / 'products.properties'), {'phase': 'certification', 'profile': P, 'native-execution-profile': mode, 'facade-execution-profile': 'IN_PROCESS'}, name + ' actual certification products')
    log = read(scope / 'contract-tests.txt').decode()
    eq(log.startswith('JUnit version 4.13.2\n') and re.search('\\nTime: [0-9.]+\\n\\nOK \\(47 tests\\)\\n\\n\\Z', log) is not None and ('FAILURES!!!' not in log), True, name + ' complete actual47 contract tests')
    read(scope / 'recorder.txt')
    for edition in editions:
        api, product = edition.split('-', 1)
        d = obs / edition
        pdf = d / 'annotations.pdf'
        h = sha(pdf)
        actualmode = mode if api == 'native' else 'IN_PROCESS'
        count = len(corpus['products'][product]['pages'])
        eq(read(pdf).startswith(b'%PDF-2.0'), True, str(pdf) + ' explicit original PDF2')
        pr = {'execution-profile': actualmode, 'execution-profile-source': 'workflow-outcome' if api == 'native' else 'fixed-facade-contract', 'receipt-count': '1', 'receipt.0.target': product, 'receipt.0.status': 'COMMITTED', 'receipt.0.path': '/workspace/' + str(pdf.relative_to(REPO)), 'receipt.0.partial-output-possible': 'false', 'receipt.0.pdf-sha256': h}
        eq(props(obs / (edition + '-publication.properties')), pr, name + ' exact public receipt ' + edition)
        expected = {'profile': P, 'input-sha256': h, 'execution-profile': actualmode, 'semantic-scope': 'independent-qpdf-object-graph', 'public-observation': 'pass', 'finding': SUCCESS, 'standards-rule-count': '174', 'page-count': str(count)}
        expected.update({c: 'pass' for c in chains})
        expected.update({'page.' + str(i) + '.visual': 'pass' for i in range(1, count + 1)})
        eq(props(d / 'result.properties'), expected, str(d) + ' complete actual public product outcome')
        syntax_check(d, 'annotations.pdf', 'pass')
        combined = ''
        for c in checkers:
            raw = standard(d, h, c, 'pass', name, edition)
            combined += c + '\n' + read(d / c / 'standards.properties').decode() + raw
        eq(read(d / 'standards.txt').decode(), 'Input exact SHA-256: ' + h + '\n' + combined, str(d) + ' all original separate standards findings')
        semantic_check(d, pdf, product, actualmode)
        eq(read(d / 'visual.txt').decode(), 'Input exact SHA-256: ' + h + '\n' + ''.join(('page ' + str(i) + '=pass\n' for i in range(1, count + 1))) + 'result=pass\n', str(d) + ' all original page visual results')
        for i in range(1, count + 1):
            visual_check(d, product, i, h)
        products.append({'tuple': name, 'product': edition, 'pdf-sha256': h, 'actual-mode': actualmode, 'pages': corpus['products'][product]['pages'], 'annotations': len(corpus['products'][product]['annotations']), 'flattened': len(corpus['products'][product]['flattened'])})
    negative = obs / 'negative'
    source = obs / 'native-created/annotations.pdf'
    eq(props(negative / 'result.properties'), dict({c: 'fail' for c in chains}, **{'syntax-source-sha256': sha(source)}), name + ' all separate effective controls')
    eq(read(negative / 'invalid.pdf'), read(source)[:16], name + ' actual16byte product truncation')
    syntax_check(negative, 'invalid.pdf', 'fail')
    malformed = negative / 'invalid-rectangle.pdf'
    h = sha(malformed)
    raw = standard(negative / 'standards', h, 'pdfcpu', 'fail')
    eq(read(negative / 'standards.txt').decode(), 'Actual product rectangle type mutation: ' + h + '\n' + raw + "\nEvery product's three standards groups separately require all 174 rule-specific controls.\n", name + ' actual wrong rectangle strict diagnostic')
    semantic_summary = ''
    for change in changes:
        product = changed_product(change)
        d = negative / 'semantic' / change
        pdf = d.with_suffix('.pdf')
        source = obs / ('native-' + product) / 'annotations.pdf'
        eq(sha(pdf) != sha(source), True, name + ' actual distinct product mutation ' + change)
        finding = semantic_check(d, pdf, product, mode, change, source)
        semantic_summary += change + '=fail ' + finding + '\n'
    eq(read(negative / 'semantic.txt').decode(), semantic_summary, name + ' all18 original semantic control outcomes')
    v = negative / 'visual'
    pixel = v / 'one-pixel'
    expected_original = corpusroot / 'expected/created-page-1.png'
    onepixel = props(pixel / 'result.properties')
    eq(onepixel, {'visual': 'fail', 'threshold': '0', 'fuzz-percent': '0', 'metric': 'AE', 'original-sha256': sha(expected_original), 'changed-sha256': sha(pixel / 'one-pixel.png'), 'comparator-sha256': mpin['IMAGEMAGICK_EXECUTABLE_SHA256'], 'positive-absolute-error': '0', 'negative-absolute-error': '1'}, name + ' exact onepixel original result')
    eq(read(pixel / 'original.png'), read(expected_original), name + ' unchanged pixel-control original')
    ct = read(pixel / 'comparator.txt').decode()
    eq(ct.startswith('magick --version\nVersion: ImageMagick 7.1.2-30 '), True, name + ' original pixel comparator version')
    eq(re.search('original\\.png original\\.png positive-difference\\.png\\nexit=0\\n\\n0 \\(0\\)', ct) is not None, True, name + ' actual positive identical AE0')
    eq(re.search('original\\.png one-pixel\\.png difference\\.png\\nexit=1\\n\\n1 \\([0-9.eE+-]+\\)\\n?\\Z', ct) is not None, True, name + ' actual onepixel AE1')
    eq(ct.count('compare -metric AE -fuzz 0% -highlight-color #ff0000 -lowlight-color #ffffff -define png:exclude-chunk=time,date'), 2, name + ' exact2 fixed comparisons')
    eq(bool(read(pixel / 'difference.png')) and bool(read(pixel / 'positive-difference.png')), True, name + ' retained comparator output images')
    for change in ['appearance', 'rectangle', 'retained-paint']:
        product = changed_product(change)
        source = obs / ('native-' + product) / 'annotations.pdf'
        d = v / change
        pdf = d.with_suffix('.pdf')
        h = sha(pdf)
        eq(read(pdf), read(d / 'annotations.pdf'), name + ' exact visual defect copy ' + change)
        count = len(corpus['products'][product]['pages'])
        expected = {'profile': P, 'input-sha256': h, 'page-count': str(count), 'visual': 'fail', 'source-sha256': sha(source), 'control': change}
        expected.update({'page.' + str(i) + '.visual': 'fail' if i == 1 else 'pass' for i in range(1, count + 1)})
        eq(props(d / 'result.properties'), expected, name + ' actual PDF visual mutation ' + change)
        for i in range(1, count + 1):
            ae = Decimal(md(read(d / ('page-' + str(i) + '-visual.txt')).decode(), 'Expected comparison AE')[0])
            eq(ae > 0 if i == 1 else ae == 0, True, name + ' changedfirstpage preservedlaterpages ' + change)
            visual_check(d, product, i, h, ae)
        eq(read(d / 'visual.txt').decode(), 'Input exact SHA-256: ' + h + '\n' + ''.join(('page ' + str(i) + '=' + ('fail' if i == 1 else 'pass') + '\n' for i in range(1, count + 1))) + 'result=fail\n', name + ' original visual PDF negative result ' + change)
    eq(read(negative / 'visual.txt').decode(), 'one-pixel=fail\nappearance=fail\nrectangle=fail\nretained-paint=fail\n', name + ' all4 independent visual controls')
    safetyfiles = safety_check(obs / 'safety', name, major, mode)
    env = ROOT / ('jdk' + str(major) + '-environment')
    scope_refs = []
    reports = []
    for chain, producer in [('syntax', 'qpdf'), ('standards', 'arlington-t12-r1'), ('semantic', 'folio-pdf-t12'), ('visual', 'pdfium-cli')]:
        rp = scope / (chain + '.yaml')
        jp = scope / (chain + '-report.json')
        record = obj(rp)
        report = obj(jp)
        subset(record, {'schema-version': 1, 'obligation': 'annotations', 'acceptance-profile': P, 'release': '0.1.0', 'candidate-sha256': CID, 'contract-sha256': TID, 'environment-sha256': sha(env / 'environment.yaml'), 'execution-configuration-sha256': sha(scope / 'execution.yaml'), 'execution-profile': mode, 'chain': chain, 'result': 'pass', 'producer': producer}, rp)
        eq(record['configuration'], ref(profile), str(rp) + ' frozen acceptance profile')
        eq(record['report'], ref(jp), str(rp) + ' exact original report')
        eq(record['negative-controls'], report['negative-controls'], str(rp) + ' exact original controls')
        wanted = {'chain': chain, 'result': 'pass', 'products': [], 'findings': [], 'negative-controls': [ref(negative / (chain + '.txt'))]}
        for edition in editions:
            d = obs / edition
            product = edition.split('-', 1)[1]
            wanted['products'].append(ref(d / 'annotations.pdf'))
            wanted['findings'] += [ref(d / (chain + '.txt')), ref(d / 'result.properties')]
            if (d / (chain + '.md')).is_file():
                wanted['findings'].append(ref(d / (chain + '.md')))
            if chain == 'visual':
                for i in range(1, len(corpus['products'][product]['pages']) + 1):
                    for suffix in ['visual.md', 'visual.txt', 'expected.png', 'pdfium.png', 'implementation.png', 'difference.png', 'renderer-difference.png', 'appearance-projection.pdf']:
                        wanted['findings'].append(ref(d / ('page-' + str(i) + '-' + suffix)))
            if chain == 'standards':
                for checker in checkers:
                    f = d / checker
                    wanted['findings'] += [ref(f / 'standards.properties'), ref(f / 'findings.txt')]
                    for rule in profiles[checker]['required-rules'].split(','):
                        wanted['negative-controls'] += [ref(f / ('negative-' + rule + '.txt')), ref(f / ('control-' + rule + '.pdf'))]
            if chain == 'semantic':
                wanted['findings'] += [ref(p) for p in sorted((d / 'qpdf').rglob('*')) if p.is_file()] + [ref(d / 'semantic.properties'), ref(d / 'semantic-command.txt'), ref(obs / (edition + '-publication.properties'))]
        if chain == 'syntax':
            wanted['negative-controls'].append(ref(negative / 'invalid.pdf'))
        if chain == 'standards':
            wanted['negative-controls'] += [ref(negative / 'invalid-rectangle.pdf')] + [ref(p) for p in sorted((negative / 'standards').rglob('*')) if p.is_file()]
        if chain == 'semantic':
            wanted['negative-controls'] += [ref(p) for p in sorted((negative / 'semantic').rglob('*')) if p.is_file()]
            wanted['findings'] += [ref(p) for p in safetyfiles] + [ref(scope / 'contract-tests.txt'), ref(scope / 'contract-tests-command.json')]
            wanted['negative-controls'] += [ref(p) for p in safetyfiles if p.suffix == '.pdf']
        if chain == 'visual':
            wanted['negative-controls'] += [ref(p) for p in sorted((negative / 'visual').rglob('*')) if p.is_file()]
        wanted['environment-observations'] = [ref(p) for p in sorted(env.iterdir()) if p.is_file()]
        eq(report, wanted, str(jp) + ' complete ordered actual report arrays')
        current = list(refs(report, jp))
        scope_refs += current + list(refs(record, rp))
        reports.append({'chain': chain, 'record-sha256': sha(rp), 'report-sha256': sha(jp), 'report-reference-count': len(current), 'counts': {k: len(v) for k, v in report.items() if isinstance(v, list)}})
    allrefs += scope_refs
    tuples.append({'tuple': name, 'physical-original-files': len(physical), 'observation-files': len([p for p in physical if p.is_relative_to(obs)]), 'observed-nested-manifests': len(list(scope.rglob('retained-files.sha256'))), 'reports': reports, 'report-reference-count': sum((r['report-reference-count'] for r in reports)), 'record-report-reference-occurrences': len(scope_refs)})
finish('annotations-' + BATCH + '-evidence-inspection.json', {'scope': 'Only completed immutable tuples in this batch', 'batch': BATCH, 'tuples': tuples, 'physical-original-files': len(physicalrows), 'qualified-standards-rules': 174, 'qualified-rule-control-executions': len(controls), 'public-products': products, 'separate-semantic-observations': semantics, 'separate-page-visual-observations': visuals, 'separate-action-safety-observations': safety, 'T12-requires-T13-producer-manifests': False, 'full-raw-copy': False})
dump(BATCH + '-original-tuple-file-identities.json', physicalrows)
dump(BATCH + '-record-report-reference-identities.json', allrefs)
dump(BATCH + '-rule-control-identities.json', controls)
if errors:
    raise ValueError('Original read-only inspection diagnostics retained; no original evidence was altered')
