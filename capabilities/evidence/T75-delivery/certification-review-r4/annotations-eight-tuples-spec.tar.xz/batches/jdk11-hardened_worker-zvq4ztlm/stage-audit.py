from auditlib import *
import ast, datetime, yaml
BATCH_CONTEXT = obj(OUT / 'batch-context.json')
SCOPE = obj(OUT / 'scope.json')
TUPLES = [tuple(x) for x in SCOPE['tuples']]
preflight = obj(PACKET / 'fixed-protocol-source-preflight-inspection.json')
eq(preflight['errors'], [], 'closed current r4 source preflight')
lineage = obj(PACKET / 'closed-source-lineage-inspection.json')
eq(lineage['errors'], [], 'closed current r4 source/validation identity linkage')
stage = REPO / 'capabilities/evidence/T75-delivery/final-candidate-r4'
build = obj(stage / 'build-inputs.json')
eq(sha(stage / 'build-inputs.json'), preflight['stage-identity-sha256'], 'same r4 stage as current full input preflight')
eq(read(stage / 'build-inputs.json'), read(REPO / 'target/foundation-0.1.0/build-inputs.json'), 'current staged build copy')
candidate = build['candidate']
contract = build['contract-inputs']
groups = {'sources': candidate['inputs'], 'contracts': contract, 'artifacts': candidate['artifacts'], 'harness': build['harness']}
observed = {k: len(v) for k, v in groups.items()}
eq(observed, preflight['current-stage-input-counts'], 'unchanged1933/30/23/24 stage graph')
for group in ['artifacts', 'harness']:
    for row in groups[group]:
        eq(sha(REPO / row['path']), row['sha256'], 'actual staged ' + group + ' identity ' + row['path'])
canonical = lambda kind, rows: ''.join((kind + ' ' + r['path'] + ' ' + r['sha256'] + '\n' for r in sorted(rows, key=lambda r: r['path'])))
cid = lines_hash('release ' + candidate['release'] + '\n' + canonical('input', candidate['inputs']) + canonical('artifact', candidate['artifacts']))
tid = lines_hash(canonical('contract', contract))
eq(cid, CID, 'actual current canonical candidate')
eq(tid, CT, 'actual canonical contract')
eq(obj(stage / 't75-final-stage-r4-result.json')['returncode'], 0, 'actual fresh r4 stage exit0')
source = read(REPO / 'scripts/t03-foundation.py').decode()
tree = ast.parse(source)
literalcase = next((n.value for n in tree.body if isinstance(n, ast.Assign) and any((isinstance(t, ast.Name) and t.id == 'CERTIFICATION_CASES' for t in n.targets))))
textcase = next((v for k, v in zip(literalcase.keys, literalcase.values) if ast.literal_eval(k) == 'annotations'))
case = {ast.literal_eval(k): ast.literal_eval(v) for k, v in zip(textcase.keys, textcase.values) if ast.literal_eval(k) != 'test-classes'}
case['test-classes'] = ['net.zerocloud.pdf.consumer.AnnotationWorkflowTest', 'net.zerocloud.pdf.itext7.consumer.AnnotationFacadeTest']
fn = next((n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'certification_tools'))
toolmeta = ast.literal_eval(next((n.value for n in fn.body if isinstance(n, ast.Assign) and any((isinstance(t, ast.Name) and t.id == 'external' for t in n.targets)))))
envprofiles = {p['identity']['jdk-major']: p for p in yaml.safe_load(read(REPO / 'capabilities/foundation-environments.yaml'))['profiles']}
tools = []
for t in toolmeta:
    pin = props(REPO / t['pin'])
    h = sha(REPO / t['path'])
    eq(h, pin[t['hash-key']], 'tool pin ' + t['id'])
    expected = {k: v for k, v in t.items() if k not in ('path', 'pin', 'hash-key')}
    expected['sha256'] = h
    tools.append(expected)
for label in ['t03', 't09', 't10', 't11', 't12', 't13']:
    tools.append({'id': 'folio-pdf-' + label, 'kind': 'project-test', 'version': '0.1.0', 'chains': ['semantic'], 'sha256': sha(REPO / 'target/foundation-0.1.0/harness/acceptance.jar')})
environments = []
for major, suffix in [(j, suffix) for j in sorted({j for j, m in TUPLES}) for suffix in ['', '-after']]:
    name = 'jdk' + str(major) + '-environment' + suffix
    if name not in BATCH_CONTEXT['allowed-environment-directories']:
        continue
    envprofile = envprofiles[major]
    envbefore = obj(ROOT / ('jdk' + str(major) + '-environment/environment.yaml'))
    eq(envprofile['identity'], envbefore['identity'], name + ' approved environment')
    eq(tools, envbefore['tools'], name + ' fifteen tool observations')
    d = ROOT / name
    osr = {k: v.strip('"') for k, v in props(d / 'os-release.txt').items()}
    jdk = {k: v.strip('"') for k, v in props(d / 'jdk-release.txt').items()}
    runtime = next((line.split('=', 1)[1].strip() for line in read(d / 'java-version.txt').decode().splitlines() if line.strip().startswith('java.runtime.version =')))
    image = read(d / 'image-digest.txt').decode().strip()
    arch = read(d / 'architecture.txt').decode().strip()
    n = obj(d / 'native-observation.json')
    eq(n['result'], 'pass', name + ' native observation')
    helperroot = REPO / '.build-cache/harfbuzz/10.2.0-final'
    eq(n['helper']['sha256'], sha(helperroot / 'bin/folio-harfbuzz'), name + ' helper actual')
    eq(n['installation']['sha256'], sha(helperroot / 'installation.json'), name + ' installed identity')
    eq(n['loaded_engine']['sha256'], sha(helperroot / 'lib/libharfbuzz.so.0.61020.0'), name + ' loaded engine identity')
    eq(n['observer']['sha256'], sha(REPO / 'scripts/t29-native-observation.py'), name + ' actual observer')
    eq(n['python']['sha256'], sha(Path('/usr/bin/python3.12')), name + ' Python executable')
    actual = {'os': osr['ID'], 'os-version': osr['VERSION_ID'], 'architecture': 'x86-64' if arch == 'x86_64' else arch, 'image': envprofile['identity']['image'].split('@')[0] + '@' + image, 'os-release-sha256': sha(d / 'os-release.txt'), 'jdk-major': int(runtime.split('.')[1] if runtime.startswith('1.') else runtime.split('.')[0]), 'jdk-vendor': jdk['IMPLEMENTOR'], 'jdk-build': runtime, 'java-sha256': read(d / 'java-executable.txt').decode().split()[0]}
    reconstructed = {'schema-version': 1, 'profile': envprofile['id'], 'identity': actual, 'host': {'kernel': read(d / 'kernel.txt').decode().strip(), 'architecture': actual['architecture']}, 'native-engine': {'name': 'harfbuzz', 'version': '10.2.0', 'helper-sha256': n['helper']['sha256'], 'library-sha256': n['loaded_engine']['sha256'], 'installation-sha256': n['installation']['sha256']}, 'tools': tools}
    eq(reconstructed, envbefore, name + ' reconstructed returned identity')
    inv = obj(d / 'invocation.json')
    eq(envprofile['identity']['image'] in inv, True, name + ' invocation image')
    eq('--network=none' in inv, True, name + ' no network')
    eq(read(d / 'observer.log'), b'', name + ' observer completed output')
    environments.append({'directory': str(d.relative_to(REPO)), 'reconstructed': reconstructed, 'raw-files': [{'name': p.name, 'sha256': sha(p)} for p in sorted(d.iterdir()) if p.is_file()]})
release = yaml.safe_load(read(REPO / 'capabilities/foundation-release.yaml'))
cp = sorted((p for p in release['required-artifacts'] if p.endswith('.jar') and (not p.endswith(('-sources.jar', '-javadoc.jar'))) and ('itext7-preview' not in p))) + [r['path'] for r in build['harness'] if r['path'].endswith('.jar')]
expectedinputs = set(cp + [r['path'] for r in build['harness']] + ['target/foundation-0.1.0/build-inputs.json', 'target/foundation-0.1.0/build-command.json', 'scripts/imagemagick-runtime.sha256'] + [t['pin'] for t in toolmeta])
for name in case['configuration-paths']:
    p = REPO / name
    expectedinputs.update((str(f.relative_to(REPO)) for f in p.rglob('*') if f.is_file())) if p.is_dir() else expectedinputs.add(name)
tuples = []
for major, mode in TUPLES:
    tuple_name = 'jdk' + str(major) + '-' + mode.lower()
    envprofile = envprofiles[major]
    scope = ROOT / tuple_name
    config = obj(scope / 'execution.yaml')
    command = obj(scope / 'contract-tests-command.json')
    log = read(scope / 'contract-tests.txt').decode()
    eq('OK (47 tests)' in log, True, mode + ' formal JUnit complete47')
    eq('FAILURES!!!' in log, False, mode + ' no failures')
    eq('I' in log.split('Time:')[0].replace('INFO', ''), False, mode + ' placeholder ignore check') if False else None
    expectedconfig = {'schema-version': 1, 'candidate-sha256': cid, 'environment-sha256': sha(ROOT / ('jdk' + str(major) + '-environment/environment.yaml')), 'acceptance-profile': case['profile'], 'execution-profile': mode, 'locale': 'en_US / C.UTF-8', 'timezone': 'UTC', 'settings': {'workflow-policy': case['workflow-policy'], 'fonts': case['fonts'], 'providers': 'none; Stable Facade execution is IN_PROCESS'}}
    subset(config, expectedconfig, mode + ' configuration')
    eq({r['path'] for r in config['inputs']}, expectedinputs, mode + ' exact configuration inventory')
    for r in config['inputs']:
        eq(sha(REPO / r['path']), r['sha256'], mode + ' config ' + r['path'])
    for c in [command, config['command']]:
        eq(c[c.index('-cp') + 1].split(':'), ['/workspace/' + p for p in cp], mode + ' exact staged classpath')
        eq(envprofile['identity']['image'] in c, True, mode + ' pinnedimage')
        eq('-Dfolio.t12.executionProfile=' + mode in c, True, mode + ' Native selection')
        eq('--network=none' in c, True, mode + ' network')
        eq(str(REPO) + ':/workspace:ro' in c, True, mode + ' readonly inputs')
    eq(command[command.index('-cp') + 2:], ['org.junit.runner.JUnitCore'] + case['test-classes'] + ['net.zerocloud.pdf.migration.itext7.contract.JarContractIT', 'net.zerocloud.pdf.migration.itext7.contract.ClasspathExclusivityIT'], mode + ' compiled contract classes')
    eq(config['command'][-5:], ['net.zerocloud.pdf.acceptance.T12EvidenceCommand', '/workspace', '/workspace/' + str(scope.relative_to(REPO)) + '/observations', mode, '0.1.0'], mode + ' actual recorder selection')
    tuples.append({'tuple': str(scope.relative_to(REPO)), 'contract-tests-sha256': sha(scope / 'contract-tests.txt'), 'tests': 47, 'time-seconds': float(re.search('Time: ([\\d.]+)', log)[1]), 'execution-configuration-sha256': sha(scope / 'execution.yaml'), 'configuration-inputs': len(config['inputs']), 'actual-native-mode': mode, 'actual-facade-mode': 'IN_PROCESS', 'staged-classpath-paths': cp})
testcounts = {}
for module, filename, expected in [('pdf-document', 'AnnotationWorkflowTest', 36), ('pdf-migration-itext7', 'AnnotationFacadeTest', 9)]:
    prefix = 'net/zerocloud/pdf/consumer/' if module == 'pdf-document' else 'net/zerocloud/pdf/itext7/consumer/'
    test = read(REPO / module / ('src/test/java/' + prefix + filename + '.java')).decode()
    count = len(re.findall('^    @Test(?:\\(|\\s*$)', test, re.M))
    eq(count, expected, 'current public T03 contract source count ' + filename)
    testcounts[filename] = count
request = read(REPO / 'pdf-document/src/test/java/net/zerocloud/pdf/consumer/AnnotationWorkflowTest.java').decode()
eq('System.getProperty("folio.t12.executionProfile", "IN_PROCESS")' in request, True, 'actual Native selector source')
eq(case['test-count'], 47, 'exact current suite count')
eq(case.get('contract-timeout', 300), 600, 'existing aggregate timeout default')
eq(len(environments), len(BATCH_CONTEXT['allowed-environment-directories']), 'all and only authorized complete environments observed')
eq(len(tuples), len(TUPLES), 'all and only explicit complete tuples observed')
finish(SCOPE['stage-inspection'], {'created-utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'candidate-sha256': cid, 'contract-sha256': tid, 'input-counts': observed, 'matches-r4-fixed-source-preflight': True, 'tools': tools, 'environment-observations': environments, 'tuples': tuples, 'public-contract-source-method-counts': testcounts, 'formal-aggregate-timeout-seconds': 600, 'deferred-environment-post-check': BATCH_CONTEXT['deferred-environment-directories'], 'root-own-index-read': False})
