from auditlib import *
members=[]
for p in sorted(ROOT.iterdir()):
 if not p.is_file():continue
 raw=read(p);row={'path':str(p.relative_to(REPO)),'bytes':len(raw),'sha256':sha(p)}
 if p.suffix=='.json':
  value=obj(p);row['top-level-type']=type(value).__name__
  if isinstance(value,dict):
   row['keys']=list(value);row['array-counts']={k:len(v) for k,v in value.items() if isinstance(v,list)};row['object-keys']={k:list(v) for k,v in value.items() if isinstance(v,dict)}
 else:row['original-text']=raw.decode()
 members.append(row)
finish('root-schema-inspection.json',{'scope':'Only completed authorized r4 annotations root identity/own-index originals; no live authority or outer output read.','members':members,'publication-gate-closed':False})
