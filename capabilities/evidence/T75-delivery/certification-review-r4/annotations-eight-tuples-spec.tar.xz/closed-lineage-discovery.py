from auditlib import *
base=REPO/'capabilities/evidence/T75-delivery';copies=[];fields={}
for rel in ['inventory-read-bound/independent-review-closure.json','inventory-read-bound/five-file-source-delta.json','inventory-read-bound/spec-review-report.md','inventory-read-bound/spec-review-receipt.md','inventory-read-bound/spec-review-archive-identity.json','inventory-read-bound/standards-review-report.md','inventory-read-bound/standards-review-receipt.json','inventory-read-bound/standards-review-archive-identity.json','final-validation-r4/source-and-contract-inputs.json']:
 p=base/rel;copies.append(copy(p,Path('closed-r4-lineage')/rel))
 if p.suffix=='.json':
  d=obj(p)
  fields[rel]=({'type':'object','keys':list(d),'scalars':{k:v for k,v in d.items() if not isinstance(v,(dict,list))},'arrays':{k:len(v) for k,v in d.items() if isinstance(v,list)},'objects':{k:list(v) for k,v in d.items() if isinstance(v,dict)}} if isinstance(d,dict) else {'type':type(d).__name__,'length':len(d),'first-entry':d[0] if d else None})
finish('closed-lineage-schema-inspection.json',{'scope':'Only previously closed r4 source/validation receipt identity schema discovery; no source correction re-review or new test execution','actual-fields':fields,'original-copies':copies,'current-annotations-raw-read':False})
