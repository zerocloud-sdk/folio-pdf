from batch_factory import *
prepare(17,'IN_PROCESS','005-jdk17-in_process-before-complete.json',False)
