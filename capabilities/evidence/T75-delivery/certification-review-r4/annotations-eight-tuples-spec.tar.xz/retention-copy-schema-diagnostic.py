from auditlib import *
original=obj(PACKET/'raw-packet-retention-inspection.json')
catalog=obj(PACKET/'selected-original-copy-identities.json');known={x['copy'] for x in catalog}
missing=[p for p in sorted(PACKET.rglob('*')) if p.is_file() and 'selected-originals' in p.relative_to(PACKET).parts and str(p) not in known]
rows=[]
for p in missing:
 h=sha(p);rows.append({'copy':str(p),'sha256':h,'bytes':len(read(p))})
print(json.dumps(rows,ensure_ascii=False,indent=2))
finish('retention-copy-schema-diagnostic-inspection.json',{'original-retention-diagnostic':original['errors'],'missing-copy-binding-records':rows,'complete-raw-evidence-review-remains-clean':obj(PACKET/'all-eight-complete-raw-inspection.json')['errors']==[],'boundary':'Only independent review-copy catalog schema diagnostic; no certification rerun or original overwrite.'})
