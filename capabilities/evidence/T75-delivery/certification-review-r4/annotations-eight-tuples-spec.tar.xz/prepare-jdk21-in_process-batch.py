from batch_factory import *
prepare(21,'IN_PROCESS','007-jdk21-in_process-before-complete.json',False)
