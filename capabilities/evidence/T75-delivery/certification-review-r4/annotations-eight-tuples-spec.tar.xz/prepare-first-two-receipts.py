from auditlib import *
source=PACKET/'batch-receipt-template.py';data=read(source);copies=[]
for name in ['jdk8-in_process-9i7rufn6','jdk8-hardened_worker-7cl2xyfq']:
 path=PACKET/'batches'/name/'batch-receipt.py'
 with path.open('xb') as f:f.write(data)
 copies.append({'path':str(path),'sha256':sha(path),'byte-exact-template':sha(source)})
finish('first-two-receipt-preparation-inspection.json',{'copies':copies,'reads-current-raw':False})
