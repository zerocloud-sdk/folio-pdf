from pathlib import Path,PurePosixPath
import json,hashlib,datetime,re
REPO=Path('/home/ubuntu/IdeaProjects/open-pdf');OUT=Path(__file__).parent
PACKET=Path('/tmp/t75-final-spec-r4-annotations-eight-2e38t91l');ROOT=REPO/'capabilities/evidence/T75-foundation-20260914-r4/annotations'
OLD=Path('/tmp/t75-final-spec-annotations-eight-hrhtiswy')
CID='ab18cc9c0473730a6aabec5d12e3172f22bea23a0a0f9529052a2bc186cbfc1b';CT='3de508f79fcbef7258feee8abc013d6f02b000840cac1cb263cb0d6f927b8f2b'
files={};errors=[]
def error(w,d):errors.append({'where':str(w),'detail':d})
def allowed_roots():
 result=set()
 for p in sorted((PACKET/'authorizations').glob('*.json')) if (PACKET/'authorizations').is_dir() else []:
  notice=json.loads(p.read_bytes())
  if notice.get('parent-confirmed-complete'):result.update(notice['allowed-root-members'])
 return result
def read(p):
 p=Path(p)
 if p.is_relative_to(ROOT) and (not p.relative_to(ROOT).parts or p.relative_to(ROOT).parts[0] not in allowed_roots()):raise ValueError('Current annotations raw scope is not explicitly complete/authorized: '+str(p))
 oldlive=REPO/'capabilities/evidence/T75-foundation-20260913-r3'
 if p.is_relative_to(oldlive):raise ValueError('Historical live r3 raw tree is excluded; preserved original reviews/archive identities provide lineage')
 if p.is_relative_to(ROOT.parent) and not p.is_relative_to(ROOT) and not (p.name=='observed-index.json' and p.parent.name in ['text','transactions','values','pages','metadata']):raise ValueError('Other-obligation raw scope excluded: '+str(p))
 b=p.read_bytes();row={'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
 if str(p) in files and files[str(p)]!=row:error(p,'input changed during independent read')
 files[str(p)]=row;return b
def sha(p):return hashlib.sha256(read(p)).hexdigest()
def obj(p):return json.loads(read(p))
def props(p):
 result={}
 for line in read(p).decode().splitlines():
  if not line or line[0] in '#!':continue
  k,sep,v=line.partition('=')
  if not sep or k in result:error(p,'duplicate/malformed property '+k);continue
  result[k]=re.sub(r'\\(u[0-9a-fA-F]{4}|.)',lambda m:chr(int(m[1][1:],16)) if m[1].startswith('u') and len(m[1])==5 else {'t':'\t','n':'\n','r':'\r','f':'\f'}.get(m[1],m[1]),v)
 return result
def eq(a,b,w):
 if a!=b:error(w,{'actual':a,'expected':b})
def subset(a,b,w):
 for k,v in b.items():eq(a.get(k),v,str(w)+':'+k)
def lines_hash(t):return hashlib.sha256(t.encode()).hexdigest()
def dump(n,d):
 with (OUT/n).open('x') as f:json.dump(d,f,ensure_ascii=False,indent=2);f.write('\n')
def copy(p,n):
 data=read(p);q=OUT/'selected-originals'/n;q.parent.mkdir(parents=True,exist_ok=True)
 with q.open('xb') as f:f.write(data)
 return {'original':str(p),'copy':str(q.relative_to(OUT)),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
def finish(n,d):
 d['errors']=errors;dump(n,d);dump(n.removesuffix('.json')+'-read-identities.json',list(files.values()))
 print(json.dumps({'inspection':n,'read-files':len(files),'errors':len(errors),'first-errors':errors[:3]},ensure_ascii=False))
 if errors:raise SystemExit(1)
