import java.nio.file.*;
import java.util.Arrays;
import net.zerocloud.pdf.*;
import net.zerocloud.pdf.query.ExtractTextAndStructure;
public final class ObserverBudgetProbe {
 public static void main(String[] args) throws Exception {
  Path source=Paths.get(args[0]); byte[] before=Files.readAllBytes(source);
  ExtractionLimits limits=ExtractionLimits.builder().maximumPages(2).maximumPageTreeNodes(16)
   .maximumContentStreams(16).maximumContentStreamDepth(4).maximumDecodedBytes(Long.parseLong(args[3]))
   .maximumTextItems(16).maximumUnicodeCodePoints(32).maximumToUnicodeMappings(Integer.parseInt(args[2]))
   .maximumFontDataEntries(Integer.parseInt(args[1])).maximumMarkedContentSequences(4)
   .maximumMarkedContentDepth(2).maximumStructureElements(4).maximumStructureItems(4)
   .maximumStructureDepth(2).maximumRoleMappings(2).build();
  boolean expectedPass=Boolean.parseBoolean(args[5]);
  try {
   WorkflowOutcome<TextStructureExtraction> outcome=new DocumentWorkflow().execute(
    WorkflowRequest.builder().source("input",DocumentSource.path(source)).primarySource("input")
     .saveMode(SaveMode.REWRITE).executionProfile(WorkflowExecutionProfile.valueOf(args[4])).build(),
    session -> session.query(ExtractTextAndStructure.version1(limits)));
   if (!expectedPass) throw new AssertionError("Expected extraction limit failure");
   if (outcome.getExecutionProfile()!=WorkflowExecutionProfile.valueOf(args[4])) throw new AssertionError("Mode");
   String actual=outcome.getResult().getPages().get(0).getText();
   if (!"A\u03a9BAB".equals(actual)) throw new AssertionError(actual);
   System.out.println("PASS: detached expected text, actual mode="+outcome.getExecutionProfile());
  } catch(DocumentFailure failure) {
   if (expectedPass || failure.getCode()!=DocumentFailureCode.EXTRACTION_LIMIT_EXCEEDED) throw failure;
   System.out.println("Expected complete failure: "+failure.getCode());
  }
  if (!Arrays.equals(before,Files.readAllBytes(source))) throw new AssertionError("Source changed");
  System.out.println("Source preserved");
 }
}
