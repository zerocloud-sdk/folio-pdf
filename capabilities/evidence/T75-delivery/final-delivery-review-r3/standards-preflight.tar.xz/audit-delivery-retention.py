import collections
import hashlib
import json
import pathlib
import re
import subprocess
import tarfile

REPO = pathlib.Path('/home/ubuntu/IdeaProjects/open-pdf')
OUT = pathlib.Path(__file__).parent
DELIVERY_PREFIX = 'capabilities/evidence/T75-delivery/'

def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def names(file):
    return [x.decode() for x in file.read_bytes().split(b'\0') if x]

untracked = names(OUT/'commands/untracked-nonignored.stdout')
ignored = names(OUT/'commands/ignored-delivery.stdout')
files = sorted(set(untracked + ignored))
assert not any(x.startswith('capabilities/evidence/T75-foundation-20260913-r3/') for x in files)
identities = []
suspicious = []
archive_paths = []
extensions = collections.Counter()
raw_count = 0
raw_trailing_whitespace = 0
raw_crlf = 0
for name in files:
    path = REPO/name
    assert path.is_file() and not path.is_symlink()
    size = path.stat().st_size
    with path.open('rb') as stream:
        prefix = stream.read(16)
    kind = 'regular'
    if prefix.startswith(b'\x7fELF') or prefix.startswith(b'\xca\xfe\xba\xbe') or prefix.startswith(b'MZ'):
        suspicious.append({'path':name,'kind':'executable-or-class-magic','size':size})
    if path.suffix.lower() in {'.class','.jar','.pyc','.pyo','.so','.dll','.exe','.o','.a'} or any(x in path.parts for x in ['__pycache__','target','.build-cache','.idea','.vscode']):
        suspicious.append({'path':name,'kind':'compiled-or-cache-name','size':size})
    if re.search(r'(?:ISO[-_ ]?32000|PDF32000|32000[-_]1[-_]2008|32000[-_]2[-_]2020)', name, re.I) and path.suffix.lower() in {'.pdf','.txt'}:
        suspicious.append({'path':name,'kind':'possible-full-standard-copy-name','size':size})
    if name.endswith(('.tar.xz','.tar.gz','.tgz','.tar')):
        kind = 'retained-archive'
        archive_paths.append(path)
    if name.startswith(DELIVERY_PREFIX) and path.suffix in {'.txt','.log'}:
        raw = path.read_bytes()
        raw_count += 1
        raw_crlf += int(b'\r\n' in raw)
        raw_trailing_whitespace += int(bool(re.search(rb'[ \t]+(?:\r?\n|$)', raw)) or raw.endswith(b'\n\n'))
    extensions[path.suffix] += 1
    identities.append({'path':name,'size':size,'sha256':digest(path),'ignored':name in ignored,'kind':kind})

archive_catalog = []
archive_suspicious = []
for path in archive_paths:
    count = 0
    total = 0
    special = []
    duplicate_names = []
    seen = set()
    with tarfile.open(path,'r|*') as handle:
        for member in handle:
            count += 1
            total += member.size
            if member.name in seen:
                duplicate_names.append(member.name)
            seen.add(member.name)
            parts = pathlib.PurePosixPath(member.name).parts
            if member.name.startswith('/') or '..' in parts or member.issym() or member.islnk() or member.isdev():
                special.append({'name':member.name,'type':member.type.decode('ascii','replace')})
            suffix = pathlib.PurePosixPath(member.name).suffix.lower()
            if suffix in {'.class','.jar','.pyc','.pyo','.so','.dll','.exe','.o','.a'} or '__pycache__' in parts:
                archive_suspicious.append({'archive':str(path.relative_to(REPO)),'member':member.name,'size':member.size,'reason':'compiled-or-cache-name'})
            if re.search(r'(?:ISO[-_ ]?32000|PDF32000|32000[-_]1[-_]2008|32000[-_]2[-_]2020)', member.name, re.I) and suffix in {'.pdf','.txt'}:
                archive_suspicious.append({'archive':str(path.relative_to(REPO)),'member':member.name,'size':member.size,'reason':'possible-full-standard-copy-name'})
    archive_catalog.append({'path':str(path.relative_to(REPO)),'sha256':digest(path),'member-count':count,'uncompressed-byte-count':total,'special-members':special,'duplicate-names':duplicate_names})

attribute_names = [x for x in files if x.startswith(DELIVERY_PREFIX)] + ['.gitattributes','README.md','pdf-document/src/main/java/net/zerocloud/pdf/PdfBoxTextStructureExtractionOperations.java']
argv = ['git','check-attr','-z','--stdin','text','whitespace']
input_bytes = b'\0'.join(x.encode() for x in attribute_names)+b'\0'
process = subprocess.run(argv,cwd=REPO,input=input_bytes,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
assert process.returncode == 0
(OUT/'commands/all-delivery-attributes.stdin').write_bytes(input_bytes)
(OUT/'commands/all-delivery-attributes.stdout').write_bytes(process.stdout)
(OUT/'commands/all-delivery-attributes.stderr').write_bytes(process.stderr)
(OUT/'commands/all-delivery-attributes-result.json').write_text(json.dumps({'argv':argv,'returncode':process.returncode,'stdin-sha256':hashlib.sha256(input_bytes).hexdigest(),'stdout-sha256':hashlib.sha256(process.stdout).hexdigest(),'stderr-sha256':hashlib.sha256(process.stderr).hexdigest()},indent=2)+'\n')
fields = [x.decode() for x in process.stdout.split(b'\0')[:-1]]
attrs = collections.defaultdict(dict)
for index in range(0,len(fields),3):
    name,key,value = fields[index:index+3]
    attrs[name][key] = value
attribute_errors = []
for name in attribute_names:
    expected_raw = name.startswith(DELIVERY_PREFIX) and pathlib.Path(name).suffix in {'.txt','.log'}
    if expected_raw:
        if attrs[name] != {'text':'unset','whitespace':'-blank-at-eol,-blank-at-eof'}:
            attribute_errors.append({'path':name,'observed':attrs[name]})
    elif attrs[name]['whitespace'] != 'unspecified':
        attribute_errors.append({'path':name,'observed':attrs[name]})

result = {'excluded-active-tree':'capabilities/evidence/T75-foundation-20260913-r3/','untracked-nonignored':len(untracked),'ignored-delivery-logs':len(ignored),'all-ignored-delivery-paths-are-log':all(pathlib.Path(x).suffix=='.log' for x in ignored),'reviewed-file-count':len(files),'reviewed-file-bytes':sum(x['size'] for x in identities),'largest-file':max(identities,key=lambda x:x['size']),'files-at-least-50-MiB':[x for x in identities if x['size']>=50*1024*1024],'raw-text-or-log-files':raw_count,'raw-files-with-trailing-whitespace-or-blank-eof':raw_trailing_whitespace,'raw-files-with-CRLF':raw_crlf,'extension-counts':dict(extensions),'standalone-suspicious':suspicious,'archive-count':len(archive_catalog),'archive-header-member-count':sum(x['member-count'] for x in archive_catalog),'archive-suspicious-members':archive_suspicious,'archives-with-special-or-duplicate-members':[x for x in archive_catalog if x['special-members'] or x['duplicate-names']],'attribute-checked-paths':len(attribute_names),'attribute-errors':attribute_errors,'pending-delivery-action':'Intentionally retained ignored logs require the already planned force-add, followed by a mechanical index-path/byte audit. This preflight does not stage files or approve final delivery.'}
(OUT/'delivery-file-identities.json').write_text(json.dumps(identities,indent=2)+'\n')
(OUT/'delivery-archive-header-catalog.json').write_text(json.dumps(archive_catalog,indent=2)+'\n')
(OUT/'ignored-delivery-log-identities.json').write_text(json.dumps([x for x in identities if x['ignored']],indent=2)+'\n')
(OUT/'retention-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
