# T75 independent certification review, current candidate

The independent [Spec report](jdk8-two-tuples-spec-report.md) closes the two
complete JDK 8 text tuples, IN_PROCESS and HARDENED_WORKER, on candidate
`e2dd9ebbeae5668ccc8e2985ccd8af17c8921d1ec5e12e0c913cbd1fa00dfbd6`
and contract
`3de508f79fcbef7258feee8abc013d6f02b000840cac1cb263cb0d6f927b8f2b`.
It found no actionable Spec issue. Both actual contract suites passed 126
cases, with the formal aggregate and method guards unchanged. The exact staged
classpath, 1,933 source inputs, 30 contract inputs, 23 artifacts, 24 harness
inputs, 576 execution inputs per tuple and observed environment identities
agree. Facade execution remains IN_PROCESS in both Native profile tuples.

For each tuple, the review checked all 19,700 original files, 19,698 root-manifest
members, 38,069 report references and 85 manifests including the root. All four
chains, 334 declaration rules, 42 program rules, 3,340 declaration negative
controls, 1,650 program negative controls and 1,730 program producer receipts
match. Separate semantic, visual and syntax controls and the public outcomes
were also checked. The original 144 review files are preserved byte-for-byte in
`jdk8-two-tuples-spec.tar.xz`; its archive identity records every member hash.

This review covers exactly these two completed tuples. It does not infer the
remaining six text tuples, the five prior-obligation refreshes, overall
Foundation readiness or final delivery completion.

The additional [three-tuple Spec report](jdk11-and-jdk17-three-tuples-spec-report.md)
closes JDK 11 IN_PROCESS, JDK 11 HARDENED_WORKER and JDK 17 IN_PROCESS on the
same candidate and contract. Each actual suite passed 126 cases; all four
chains, complete rules and controls, retained public outcomes and original
identities agree. Both JDK 11 and JDK 17 BEFORE/AFTER environment identities
reconstruct equally from their original observations. Its 249 original files
are retained byte-for-byte in `jdk11-and-jdk17-three-tuples-spec.tar.xz`, with
the original receipt and archive identity alongside it.

That review initially recorded 24 diagnostics from an incorrect assumption
that raster control PNG compression bytes must match across JDKs. The separate
closure verifies each control's own recorded SHA and the complete prescribed
decoded RGB pixels. Original diagnostics and the initial JDK 17 AFTER deferral
remain intact, together with their subsequent closure records. No certification
was modified or rerun for this review-method correction. These bounded reviews
do not approve the remaining three text tuples or final delivery.

The historical r2 first-tuple review used the phrase "85 nested manifests".
Its original identity list includes the root manifest: the exact count is 85
total and 84 non-root manifests, as the current independent report states.
`manifest-count-clarification.json` and the retained original identity list
document this wording clarification. The list was checked byte-for-byte
against the original and its retained archive; historical report and evidence
bytes remain unchanged.
