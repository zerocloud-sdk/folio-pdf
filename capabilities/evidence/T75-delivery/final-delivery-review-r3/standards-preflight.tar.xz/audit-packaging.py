import collections
import hashlib
import json
import pathlib
import tarfile

REPO = pathlib.Path('/home/ubuntu/IdeaProjects/open-pdf')
OUT = pathlib.Path(__file__).parent
DELIVERY = REPO / 'capabilities/evidence/T75-delivery'

def digest(path):
    with pathlib.Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def read(path):
    return json.loads(pathlib.Path(path).read_text())

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

jobs = [
    ('final-candidate-r3/original-archive-identities.json', 'staged-build'),
    ('certification-review-r3/jdk8-two-tuples-spec-archive-identity.json', None),
    ('certification-review-r3/jdk11-and-jdk17-three-tuples-spec-archive-identity.json', None),
    ('final-validation-r3/standards-host-review-archive-identity.json', None),
    ('final-validation-r3/standards-matrix-review-archive-identity.json', None),
]
results = []
for identity_name, key in jobs:
    identity_path = DELIVERY / identity_name
    identity = read(identity_path)
    if key:
        identity = identity[key]
    archive = identity_path.parent / identity['archive']
    assert digest(archive) == identity['sha256']
    expected = {m['path']: m for m in identity['members']}
    assert len(expected) == len(identity['members'])
    actual = {}
    errors = []
    frozen_matches = 0
    standalone_matches = 0
    preserved_command_results = []
    with tarfile.open(archive, 'r|*') as handle:
        for member in handle:
            assert member.isfile(), 'non-regular new archive member'
            assert not member.name.startswith('/') and '..' not in pathlib.PurePosixPath(member.name).parts
            assert member.name not in actual, 'duplicate archive name'
            with handle.extractfile(member) as stream:
                actual_sha = hashlib.file_digest(stream, 'sha256').hexdigest()
            expected_member = expected.get(member.name)
            if expected_member is None or expected_member['sha256'] != actual_sha or expected_member['size'] != member.size:
                errors.append({'member': member.name, 'error': 'manifest mismatch'})
            original = pathlib.Path(identity['original']) / member.name
            if original.is_file() and digest(original) == actual_sha:
                frozen_matches += 1
            else:
                errors.append({'member': member.name, 'error': 'missing or differing frozen original'})
            standalone = identity_path.parent / member.name
            if standalone.is_file():
                if digest(standalone) == actual_sha:
                    standalone_matches += 1
                elif member.name != 'README.md':
                    errors.append({'member': member.name, 'error': 'standalone differs'})
            actual[member.name] = {'size': member.size, 'sha256': actual_sha}
            if member.name.endswith(('-command.json', '-result.json')):
                preserved_command_results.append(member.name)
    if set(actual) != set(expected):
        errors.append({'error': 'archive member set differs from manifest'})
    results.append({'identity': str(identity_path.relative_to(REPO)), 'identity-sha256': digest(identity_path), 'archive': str(archive.relative_to(REPO)), 'archive-sha256': identity['sha256'], 'members': len(actual), 'uncompressed-bytes': sum(x['size'] for x in actual.values()), 'frozen-original-byte-matches': frozen_matches, 'standalone-byte-matches': standalone_matches, 'original-command-and-result-members': preserved_command_results, 'errors': errors})

reused = []
for identity_name, prior_dir in [
    ('final-validation-r3/host-full-verify-archive-identity.json', '/tmp/t75-final-standards-host-r3-3s6o831d'),
    ('final-validation-r3/jdk-matrix-archive-identity.json', '/tmp/t75-final-standards-matrix-r3-2aij3rj1'),
]:
    identity_path = DELIVERY / identity_name
    identity = read(identity_path)
    archive = identity_path.parent / identity['archive']
    assert digest(archive) == identity['sha256']
    prior = pathlib.Path(prior_dir)
    assert digest(prior / 'evidence' / identity_path.name) == digest(identity_path)
    reused.append({'identity': str(identity_path.relative_to(REPO)), 'identity-sha256': digest(identity_path), 'archive': str(archive.relative_to(REPO)), 'sha256': digest(archive), 'previous-independent-full-member-audit': str(prior), 'previous-report-sha256': digest(prior/'report.md'), 'scope': 'Compressed archive and exact manifest identity rechecked; original complete member/log/XML/exit audit reused.'})

stage = DELIVERY / 'final-candidate-r3'
stage_result = read(stage/'t75-final-stage-r3-result.json')
stage_command = read(stage/'t75-final-stage-r3-command.json')
stage_process = {'command': stage_command, 'result': stage_result, 'original-durable-matches': []}
for suffix in ['-command.json', '-result.json', '.log']:
    retained = stage/('t75-final-stage-r3'+suffix)
    original = pathlib.Path('/tmp')/retained.name
    assert digest(retained) == digest(original)
    stage_process['original-durable-matches'].append({'path': str(retained.relative_to(REPO)), 'original': str(original), 'sha256': digest(retained)})
assert stage_result['returncode'] == 0
stage_process['actual-exit-zero'] = True

certification = DELIVERY / 'certification-review-r3'
review_receipts = []
for prefix in ['jdk8-two-tuples-spec', 'jdk11-and-jdk17-three-tuples-spec']:
    receipt = read(certification/(prefix+'-receipt.json'))
    report = certification/(prefix+'-report.md')
    archive_manifest = read(certification/(prefix+'-archive-identity.json'))
    original = pathlib.Path(archive_manifest['original'])
    assert digest(report) == digest(original/'report.md')
    archived = {r['path']:r for r in archive_manifest['members']}
    assert archived['report.md']['sha256'] == digest(report)
    review_receipts.append({'receipt': prefix+'-receipt.json','receipt-sha256':digest(certification/(prefix+'-receipt.json')),'report-sha256':digest(report),'independent-reviewer':receipt.get('reviewer'),'candidate':receipt.get('candidate'),'contract':receipt.get('contract'),'bounded-review-scope':receipt.get('tuples',receipt.get('reviewed-complete-four-chain-tuples')),'full-delivery-approved':receipt.get('overall-eight-or-forty-eight-or-delivery-approved',receipt.get('final-delivery-approved'))})

clarification = read(certification/'manifest-count-clarification.json')
historical = certification/'historical-r2-manifest-identities.json'
history = read(historical)
history_rows = history if isinstance(history, list) else next(v for v in history.values() if isinstance(v,list))
history_archive = DELIVERY/'worker-batch-timeout/first-tuple-spec-review.tar.xz'
with tarfile.open(history_archive, 'r:*') as handle:
    archived_raw = handle.extractfile('completed-tuple-manifest-identities.json').read()
assert sha(archived_raw) == digest(historical) == '9f6b1e157c5908e54b21277c6df4532a299d0999eee99d9f3ab2f7f581ddbe45'

(OUT/'archive-byte-audit.json').write_text(json.dumps({'new-full-member-audits': results, 'reused-prior-full-validation-audits': reused, 'new-full-member-count':sum(r['members'] for r in results), 'new-full-uncompressed-bytes':sum(r['uncompressed-bytes'] for r in results)}, indent=2)+'\n')
(OUT/'stage-process-audit.json').write_text(json.dumps(stage_process, indent=2)+'\n')
(OUT/'bounded-review-packaging-audit.json').write_text(json.dumps({'independent-receipts':review_receipts,'historical-manifest-list-count':len(history_rows),'historical-manifest-byte-identity':digest(historical),'clarification':clarification,'current-raw-certification-tree-inspected':False,'full-eight-or-forty-eight-certified-by-this-review':False},indent=2)+'\n')
print(json.dumps({'new-archives':len(results),'new-members':sum(x['members'] for x in results),'new-member-bytes':sum(x['uncompressed-bytes'] for x in results),'errors':[{'archive':r['archive'],'errors':r['errors']} for r in results if r['errors']],'reused-complete-validation-archives':len(reused),'stage-actual-returncode':stage_result['returncode'],'bounded-independent-review-report-count':len(review_receipts),'historical-manifest-count':len(history_rows)},indent=2))
