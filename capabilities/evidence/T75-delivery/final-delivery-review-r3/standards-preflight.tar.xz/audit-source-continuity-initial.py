import hashlib
import json
import pathlib
import yaml

REPO = pathlib.Path('/home/ubuntu/IdeaProjects/open-pdf')
OUT = pathlib.Path(__file__).parent
BASE = '5b1603c435f11c40368f75b7b9a2777c9c5e9761'
EXCLUDED = 'capabilities/evidence/T75-foundation-20260913-r3/'

def read(path):
    return json.loads(pathlib.Path(path).read_text())

def digest(path):
    with pathlib.Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def mapping(rows):
    result = {r['path']: r['sha256'] for r in rows}
    assert len(result) == len(rows), 'duplicate input'
    return result

freeze_path = REPO / 'capabilities/evidence/T75-delivery/final-validation-r3/source-and-contract-inputs.json'
stage_path = REPO / 'capabilities/evidence/T75-delivery/final-candidate-r3/build-inputs.json'
original_path = REPO / 'capabilities/evidence/T75-delivery/final-candidate/build-inputs.json'
delta_path = REPO / 'capabilities/evidence/T75-delivery/worker-batch-timeout/final-reviewed-source-identity-delta.json'
freeze, stage, original, delta = map(read, [freeze_path, stage_path, original_path, delta_path])
sources, contracts = mapping(freeze['inputs']), mapping(freeze['contract-inputs'])
assert mapping(stage['candidate']['inputs']) == sources
assert mapping(stage['contract-inputs']) == contracts
assert len(sources) == 1933 and len(contracts) == 30
source_links = []
source_mismatches = []
for name, sha in {**sources, **contracts}.items():
    assert not name.startswith(EXCLUDED)
    path = REPO / name
    if path.is_symlink():
        source_links.append(name)
    if not path.is_file() or digest(path) != sha:
        source_mismatches.append(name)

foundation = yaml.safe_load((REPO / 'capabilities/foundation-release.yaml').read_text())
enumerated = set()
for name in foundation['source-roots']:
    path = REPO / name
    items = path.rglob('*') if path.is_dir() else [path]
    for file in items:
        if file.is_file() and '__pycache__' not in file.parts:
            enumerated.add(file.relative_to(REPO).as_posix())
enumerated.difference_update(foundation['source-exclusions'])
assert enumerated == set(sources), 'source path-set differs'
contract_paths = {'capabilities/foundation-release.yaml', 'capabilities/capability-matrix.yaml', 'capabilities/facade-surface.yaml', foundation['requirements'], foundation['environments'], foundation['platform-decision']}
requirements = yaml.safe_load((REPO / foundation['requirements']).read_text())
for obligation in requirements['obligations']:
    contract_paths.add(obligation['profile-contract'])
assert contract_paths == set(contracts), 'contract path-set differs'

closures = [
    pathlib.Path('/tmp/t75-final-standards-crosspage-vb_0jzxw/review-record.json'),
    pathlib.Path('/tmp/t75-final-standards-observer-budget-029hl0q1/review-record.json'),
    pathlib.Path('/tmp/t75-final-standards-worker-batch-pcz6savo/review-record.json'),
]
last_reviewed = {}
for closure in closures:
    record = read(closure)
    assert record['baseline'] == BASE
    assert not record['hard-breaches'] and not record['actionable-smells']
    for item in record['source-files']:
        last_reviewed[item['path']] = {'sha256': item.get('current-sha256', item.get('sha256')), 'independent-review': str(closure)}

actual_delta = {}
for label, before, after in [('inputs', mapping(original['candidate']['inputs']), sources), ('contract-inputs', mapping(original['contract-inputs']), contracts)]:
    assert before.keys() == after.keys()
    changed = [{'path': path, 'before': before[path], 'after': after[path], 'independent-review': last_reviewed[path]['independent-review']} for path in sorted(before) if before[path] != after[path]]
    for row in changed:
        assert last_reviewed[row['path']]['sha256'] == row['after']
    assert [{k: x[k] for k in ['path', 'before', 'after']} for x in changed] == [{k: x[k] for k in ['path', 'before', 'after']} for x in delta[label]]
    actual_delta[label] = changed
assert len(actual_delta['inputs']) == 22 and len(actual_delta['contract-inputs']) == 1

original_review = pathlib.Path('/tmp/t75-final-standards-xpr84_u3')
reviewed = {row['path']: row['sha256'] for row in read(original_review / 'source-identities.json')}
reviewed.update({row['path']: row['sha256'] for row in read(original_review / 'supplementary-source-identities.json')})
reviewed.update({path: row['sha256'] for path, row in last_reviewed.items()})
reviewed['.gitattributes'] = '7a6a25de64a0dbc04b9b3fefe0b233775855567ff2934003c33c03b144915981'
tracked = (OUT / 'commands/tracked-changes.stdout').read_text().splitlines()
untracked = [p.decode() for p in (OUT / 'commands/untracked-nonignored.stdout').read_bytes().split(b'\0') if p]
outside_review = []
covered_tracked = []
non_source_tracked = []
for name in tracked:
    if name.startswith(EXCLUDED):
        raise AssertionError('excluded tree in tracked audit')
    if name in reviewed and digest(REPO / name) == reviewed[name]:
        covered_tracked.append(name)
    else:
        outside_review.append(name)
    if name not in sources and name not in contracts:
        non_source_tracked.append(name)
untracked_delivery = [n for n in untracked if n.startswith('capabilities/evidence/T75-delivery/')]
untracked_other = [n for n in untracked if not n.startswith('capabilities/evidence/T75-delivery/')]
untracked_uncovered = [n for n in untracked_other if n not in reviewed or digest(REPO/n) != reviewed[n]]

def lines(kind, values):
    return ''.join(f'{kind} {path} {sha}\n' for path, sha in sorted(values.items()))

candidate = hashlib.sha256(('release ' + stage['candidate']['release'] + '\n' + lines('input', sources) + lines('artifact', mapping(stage['candidate']['artifacts']))).encode()).hexdigest()
contract = hashlib.sha256(lines('contract', contracts).encode()).hexdigest()
assert candidate == 'e2dd9ebbeae5668ccc8e2985ccd8af17c8921d1ec5e12e0c913cbd1fa00dfbd6'
assert contract == '3de508f79fcbef7258feee8abc013d6f02b000840cac1cb263cb0d6f927b8f2b'

result = {
    'baseline': BASE, 'source-count': len(sources), 'contract-count': len(contracts),
    'current-source-mismatches': source_mismatches, 'source-symlinks': source_links,
    'source-path-set-exact': True, 'contract-path-set-exact': True,
    'stage-source-and-contract-inputs-match': True,
    'candidate-calculated-from-retained-stage-inputs': candidate,
    'contract-calculated-from-current-inputs': contract,
    'staged-artifact-count': len(stage['candidate']['artifacts']), 'retained-harness-count': len(stage['harness']),
    'live-artifact-or-environment-observations-run': False,
    'original-complete-review-report-sha256': digest(original_review/'report.md'),
    'cumulative-delta': actual_delta,
    'tracked-change-count': len(tracked), 'tracked-matching-reviewed-identities': len(covered_tracked),
    'tracked-outside-current-source-and-contract-inputs': non_source_tracked,
    'tracked-not-matching-prior-source-review': outside_review,
    'untracked-nonignored-delivery-count': len(untracked_delivery),
    'untracked-other-count': len(untracked_other), 'untracked-other-not-covered-by-independent-source-review': untracked_uncovered,
    'excluded-active-tree': EXCLUDED,
}
(OUT/'source-continuity-audit.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k != 'cumulative-delta'}, indent=2))
