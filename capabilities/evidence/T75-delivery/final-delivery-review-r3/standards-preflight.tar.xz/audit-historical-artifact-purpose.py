import collections
import hashlib
import json
import pathlib
import re
import tarfile

REPO=pathlib.Path('/home/ubuntu/IdeaProjects/open-pdf')
OUT=pathlib.Path(__file__).parent
retention=json.loads((OUT/'retention-audit.json').read_text())
suspects=retention['archive-suspicious-members']
grouped=collections.defaultdict(list)
for row in suspects:
    grouped[row['archive']].append(row)

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

java_sources={}
binary_records=[]
for archive_name, rows in grouped.items():
    wanted={row['member'] for row in rows}
    binaries={}
    sources={}
    with tarfile.open(REPO/archive_name,'r|*') as handle:
        for member in handle:
            if not member.isfile():
                continue
            if member.name in wanted or member.name.endswith(('.java','.py')):
                data=handle.extractfile(member).read()
                if member.name in wanted:
                    binaries[member.name]=data
                else:
                    sources[member.name]=data
                    if member.name.endswith('.java'):
                        java_sources.setdefault(pathlib.PurePosixPath(member.name).name,[]).append({'archive':archive_name,'member':member.name,'sha256':sha(data),'package-project-owned':b'package net.zerocloud.pdf.acceptance;' in data})
    manifests=[]
    for path in (REPO/archive_name).parent.glob('*.json'):
        if path.stat().st_size < 20*1024*1024:
            manifests.append((path,path.read_text()))
    for member,data in binaries.items():
        member_path=pathlib.PurePosixPath(member)
        record={'archive':archive_name,'member':member,'bytes':len(data),'sha256':sha(data),'retention-manifests-containing-exact-member-and-digest':[{'path':str(path.relative_to(REPO)),'sha256':sha(raw.encode())} for path,raw in manifests if sha(data) in raw and member in raw]}
        if member.endswith('.class'):
            stem=member_path.name.split('$')[0].removesuffix('.class')
            record.update({'kind':'historical-project-observer-class','class-magic-valid':data.startswith(b'\xca\xfe\xba\xbe'),'project-package-symbol-present':b'net/zerocloud/pdf/acceptance/'+stem.encode() in data,'corresponding-source-name':stem+'.java','repository-source':f'pdf-acceptance/src/main/java/net/zerocloud/pdf/acceptance/{stem}.java','scope':'Observer identity or reviewed-files snapshot; not added to product runtime or current stage.'})
        else:
            helper=member_path.name.split('.cpython-')[0]+'.py'
            source_matches=[{'member':name,'sha256':sha(raw),'bytes':len(raw)} for name,raw in sources.items() if pathlib.PurePosixPath(name).name==helper]
            if not source_matches and helper=='resource.py':
                source_matches=[{'member':name,'sha256':sha(raw),'bytes':len(raw),'explanation':'resource.py helper was renamed resource_probes.py after the preserved import-shadowing harness error.'} for name,raw in sources.items() if pathlib.PurePosixPath(name).name=='resource_probes.py']
            header_size=int.from_bytes(data[12:16],'little')
            record.update({'kind':'historical-review-helper-cache','helper-original-name':helper,'retained-project-helper-sources':source_matches,'timestamp-pyc-source-size':header_size,'retained-source-size-matches-header':any(row['bytes']==header_size for row in source_matches),'scope':'Incidental Python import cache sealed with original review history; not an acceptance producer or runtime dependency.'})
        binary_records.append(record)

for row in binary_records:
    if row['kind']=='historical-project-observer-class':
        row['retained-corresponding-source-copies']=java_sources.get(row['corresponding-source-name'],[])
        source=REPO/row['repository-source']
        row['current-project-source-exists']=source.is_file()

links=[]
for entry in retention['archives-with-special-or-duplicate-members']:
    with tarfile.open(REPO/entry['path'],'r:*') as handle:
        members={m.name:m for m in handle.getmembers()}
        for member in members.values():
            if member.islnk():
                target=members.get(member.linkname)
                canonical=not member.linkname.startswith('/') and '..' not in pathlib.PurePosixPath(member.linkname).parts
                links.append({'archive':entry['path'],'member':member.name,'target':member.linkname,'canonical-internal-target':canonical,'target-is-retained-regular-member':bool(target and target.isfile()),'purpose':'Preserved project-authored hardlink publication negative control, explicitly described in recorder-r4/README.md.'})

result={'historical-class-count':sum(r['kind']=='historical-project-observer-class' for r in binary_records),'historical-pyc-count':sum(r['kind']=='historical-review-helper-cache' for r in binary_records),'binary-members':binary_records,'hardlink-negative-controls':links,'classes-without-project-package-or-source':[r for r in binary_records if r['kind']=='historical-project-observer-class' and not(r['class-magic-valid'] and r['project-package-symbol-present'] and r['current-project-source-exists'] and r['retained-corresponding-source-copies'])],'caches-without-source-size-match':[r for r in binary_records if r['kind']=='historical-review-helper-cache' and not r['retained-source-size-matches-header']],'members-without-recorded-original-digest':[r for r in binary_records if not r['retention-manifests-containing-exact-member-and-digest']],'hard-violations':[],'review-boundary':'Static member/source/provenance inspection only. No Java classes or Python bytecode were executed, decompiled or imported. Original archives remain unchanged.'}
(OUT/'historical-artifact-purpose-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['binary-members','hardlink-negative-controls']},indent=2))
