# Standards increment — bounded extraction observation allowances

Scope: the frozen 16-file increment (nine consumer tests, six repository-only acceptance observers and provenance), compared with the retained original full-verification failure sources. Earlier full and appearance Standards reviews remain separate.

## Hard breaches

None found. Every Java change is limited to `maximumFontDataEntries` and explanatory comments. The other fourteen extraction dimensions, FontLimits/CompositionLimits, expected results, failure assertions and negative controls are unchanged. No product implementation, public default, API surface or independent reference expectation is modified.

The explicit additions account for 65,536 Identity-H source mappings per selected font dictionary, consistent with ADR-0035 and `docs/text-logical-structure.md`. The retained residual allowance covers other font entries. The bounds remain finite and case-specific: one shared barcode font, two selected fixture fonts, or four command-local shaping pairs. The original T29 corpus/products confirm the four two-font commands. Public observations continue through `DocumentWorkflow.execute`.

## Smell judgments

No actionable smell findings. Repeated arithmetic is documented beside each fixture-specific observation budget; introducing a shared factory would couple separate consumer/profile allowances. This is an accepted local judgment, not an exception to a repository rule. No new abstraction or unrelated responsibility was introduced.

## Verification evidence and boundary

Read-only comparison confirms the 15 Java files differ only in those allowances/comments. Seven minimal-GREEN files differ from their final counterparts only by comments. The original full verification retains four assertion failures and 236 errors across the affected nine classes; acceptance retains its seven actual failures before correction.

Completed supplied logs show FontLoading 22 passing, acceptance seven passing with unchanged negative controls, and all 394 consumer cases passing with no failures, errors or skips. The provided public probe shows the old 64-entry budget fails and the enlarged budget succeeds in both execution modes; separate IN_PROCESS zero-ToUnicode and zero-decoded-byte controls still fail. Probe source, PDF, raw logs and receipts match their original hashes.

All 16 frozen source identities match the repository at closure. Complete consumer log SHA-256: `62338c83a1c4829287cb8808efc48ace775aba4389778aa78c896157e091184c`. Source copies, comparison receipts and original SHA records accompany this report. No project CLI, test, probe or repository mutation was performed by this reviewer. Final whole-project verification and actual candidate/environment certification remain separate required gates.
