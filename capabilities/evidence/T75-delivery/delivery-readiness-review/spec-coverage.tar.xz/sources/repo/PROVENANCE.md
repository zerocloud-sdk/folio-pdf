# Clean-room provenance record

This repository is an independent Apache-2.0 implementation. The accepted
program specification, context glossaries, ADRs, public standards, public API
documentation, and project-owned tests are the permitted design inputs.

## T32.01 Foundation readiness contract (#69)

- Authorship: OpenAI Codex generated the repository-only checker, obligation and
  environment inventories, command-boundary fixtures and documentation at the
  repository operator's direction.
- Project inputs: full GitHub #1, #33 and #69 bodies/comments read using `gh`,
  the approved #69–#97 slice bodies, AGENTS.md and its repository guides,
  CONTEXT.md, CONTRIBUTING.md, RELEASING.md, the accepted ADR set, existing
  Capability Matrix/Facade/evidence schemas and repository inventory/release
  tools. The source requirement catalogue quotes project requirements only.
- Environment inputs: actual local observations of official Eclipse Temurin
  JDK 8/11/17/21 Noble containers, including immutable image digests,
  `/etc/os-release`, JDK release metadata and SHA-256 of the java executable.
  These declarations are not capability certification. The images/OpenJDK
  retain the validation-only origin/license treatment recorded in T01 and are
  not redistributed in runtime artifacts.
- New fixtures are original synthetic YAML, text and byte sequences; they do
  not contain PDF samples, fonts, iText output, backend internals or third-party
  implementation material. A successful synthetic readiness fixture is not
  Foundation product evidence.
- No dependency, runtime library, native binary or font was added. Existing
  repository-only SnakeYAML/JUnit and Java 8 APIs are reused. Inventory tools
  retain their install/deploy skips and exclusion from BOM/product artifacts.
- No iText source/resources, restricted implementation details or closed add-on
  material were used. No proprietary comparison or reverse engineering was
  performed; the Compatibility Curator boundary remains unchanged.

## T01 bootstrap record

- Authorship and certification: OpenAI Codex generated and integrated the T01
  implementation and documentation at repository operator MaBaiqiu's direction.
  MaBaiqiu authorized the commit and is recorded as its author and committer,
  with DCO certification supplied through the `Signed-off-by` trailer.
- Project inputs: issue #1, issue #2, the repository context map and Document
  Engine glossary, and ADR-0002, 0004, 0006, 0008–0010, 0012–0015, 0025,
  0029, 0030, and 0032.
- Runtime and test dependencies: Apache PDFBox 3.0.8 and its required
  transitives are Apache-2.0; JUnit 4.13.2 is EPL-1.0, Hamcrest Core 1.3 is
  BSD-3-Clause, and SnakeYAML 2.2 is Apache-2.0. Exact coordinates and roles are
  recorded in [DEPENDENCIES.md](DEPENDENCIES.md).
- Build tooling: Maven Wrapper 3.3.4 scripts were generated from the official
  Apache Maven plugin under Apache-2.0. The wrapper retrieves Apache Maven
  3.9.16 under Apache-2.0 and verifies the declared distribution SHA-256. Maven
  build plugins declared by the project are Apache-2.0.
- CI tooling: `actions/checkout` at commit `11d5960a326750d5838078e36cf38b85af677262`
  and `actions/setup-java` at commit `cf277c60eb25467037889841efdb72551f06f6c3`
  are official MIT-licensed GitHub Actions.
- Local matrix tooling: the Apache-2.0 Podman CLI runs official Eclipse Temurin
  JDK 8, 11, 17, and 21 images. The image definitions are Apache-2.0 and the
  OpenJDK binaries use GPL-2.0 with the Classpath Exception. These tools are
  validation inputs and are not redistributed in project artifacts.
- Test fixtures: T01 creates temporary blank documents entirely through the
  project-owned Native Interface; no external PDF fixture is included.
- Excluded inputs: no iText source, resource, fixture, decompiled or
  binary-derived implementation detail, closed add-on material, or proprietary
  differential evidence was used.
- Compatibility Curator evidence: none; the role is vacant and the T01
  capability remains `experimental`.

## T02 inventory-authority record

- Authorship and certification: OpenAI Codex generated and integrated the T02
  validator, generator, fixtures, inventories, and documentation at repository
  operator MaBaiqiu's direction. MaBaiqiu authorized this commit and is recorded
  as its author and committer, with DCO certification supplied through the
  `Signed-off-by` trailer.
- Project inputs: issue #1, issue #3, the Migration and Document Engine
  glossaries, ADR-0011, 0020, 0023, and 0029, the accepted T01 authorities and
  evidence, and the repository contribution and release contracts.
- Repository tooling: SnakeYAML 2.2 (Apache-2.0) safely parses YAML and remains
  outside shipped product artifacts. Exec Maven Plugin 3.6.3 (Apache-2.0) is
  version-pinned to expose the Java 8 inventory command through Maven and bind
  its drift check to `verify`. Coordinates, roles, and licenses are recorded in
  [DEPENDENCIES.md](DEPENDENCIES.md).
- Test fixtures: every positive and negative inventory, evidence record, and
  generated-document input under `build-tools/inventory/src/test/resources` is
  project-authored for T02. No external PDF, facade source, or product artifact
  is included.
- Generated documentation: `docs/generated/capability-matrix.md` and
  `docs/generated/facade-surface.md` are deterministic renderings of the two
  YAML authorities and contain no external copied content.
- Excluded inputs: no iText source, resource, fixture, decompiled or
  binary-derived implementation detail, closed add-on material, or proprietary
  differential evidence was used.
- Scope: T02 adds only repository validation and documentation tooling. It
  introduces no Migration Facade type or stub, changes no T01 compatibility
  claim, and leaves independent T06 Acceptance Evidence outstanding.

## T03 transaction-contract record

- Authorship: OpenAI Codex generated and integrated the T03 implementation,
  tests, and documentation at repository operator MaBaiqiu's direction. No
  T03 commit was created in this execution.
- Project inputs: GitHub issues #1 and #4, the Document Engine glossary,
  ADR-0013, ADR-0024, ADR-0025, CONTRIBUTING.md, the accepted T01/T02
  implementation and evidence, and the repository Capability Matrix and
  Facade Surface Manifest.
- Runtime and test dependencies: T03 adds no dependency. Apache PDFBox 3.0.8
  remains the private Apache-2.0 implementation dependency; JUnit 4.13.2
  remains the test dependency. Their coordinates, roles, and licenses remain
  recorded in [DEPENDENCIES.md](DEPENDENCIES.md).
- Test fixtures: all PDFs, failing streams, cancellation signals, and
  deterministic clocks used by T03 tests are project-authored and created in
  memory or temporary test directories. Linux Path-ownership checks inspect
  only the current test process's `/proc/self/fd` links and retain no host
  data. No external PDF fixture is included.
- Excluded inputs: no iText source, resource, fixture, decompiled or
  binary-derived implementation detail, closed add-on material, or proprietary
  differential evidence was used.
- Scope: T03 implements only the trusted in-process transaction boundaries.
  It adds no T04 Migration Facade, T05 Capability Provider, T06 independent
  Acceptance Evidence, T15 incremental publication, T20 comprehensive
  hostile-input policy, or T21 Hardened Worker implementation.
- Compatibility Curator evidence: none; the role remains vacant, the
  capability remains `experimental`, and T06 remains its promotion gate.

## T04 migration-facade record

- Authorship: OpenAI Codex generated and integrated the T04 implementation,
  tests, inventories, and documentation at repository operator MaBaiqiu's
  direction. No T04 commit was created in this execution.
- Project inputs: GitHub issues #1 and #5, the Migration and Document Engine
  glossaries, ADR-0004, ADR-0015, ADR-0020, ADR-0029, the accepted T01–T03
  implementation and evidence, and the repository Capability Matrix and
  Facade Surface Manifest.
- Public interface inputs: the official iText 7.2.6 public Javadocs for
  `PdfWriter`, `PdfReader`, `PdfDocument`, `PdfPage`, layout `Document`, and
  `PdfException` were used only to identify public package, constructor,
  return, close, and checked-exception shapes. They were not used as an
  implementation or behavioral oracle.
- Runtime and test dependencies: T04 adds no third-party dependency. The
  resource-only stable facade has no dependencies. The preview facade depends
  only on the existing first-party `pdf-document` artifact, and JUnit 4.13.2
  remains its test dependency. Existing coordinates, roles, and licenses
  remain recorded in [DEPENDENCIES.md](DEPENDENCIES.md).
- Project-authored resources and fixtures: the stable and preview edition
  marker files, temporary output paths, blank PDFs produced through the Native
  Interface, and subprocess classpath probes are project-authored. No external
  PDF fixture or product artifact is included.
- Generated documentation: `docs/generated/capability-matrix.md` and
  `docs/generated/facade-surface.md` were regenerated deterministically from
  the two YAML authorities with the repository inventory tool.
- Excluded inputs: no iText source, resource, fixture, binary, decompiled or
  binary-derived implementation detail, closed add-on material, proprietary
  differential evidence, or Reference Suite output was used.
- Scope: T04 adds only the Stable and Experimental Migration Facade artifacts
  and the first blank-document workflow mapping. It adds no T05 Capability
  Provider contract, T06 independent Acceptance Evidence, or later facade
  capability mapping.
- Compatibility Curator evidence: none; the role remains vacant, the mapped
  capability remains `experimental`, and T06 remains its promotion gate.

## T05 capability-provider record

- Authorship: OpenAI Codex generated and integrated the T05 implementation,
  tests, inventories, and documentation at repository operator MaBaiqiu's
  direction. The T05 implementation is committed with this change.
- Project inputs: GitHub issues #1 and #6, `CONTEXT.md`, `CONTRIBUTING.md`,
  `SECURITY.md`, the repository inventory contract, ADR-0006, 0007, 0009,
  0011, 0013, 0014, 0016, 0018, 0024, 0025, 0029, and 0031, and the accepted
  T01–T03 implementation and evidence.
- Runtime and test dependencies: T05 adds no third-party dependency. The
  shipped Provider contract and subprocess adapter use Java 8 platform types;
  `pdf-document` and `pdf-conversion` use the first-party
  `pdf-provider-contract`. JUnit 4.13.2 remains the existing test dependency.
  The no-new-dependency statement is recorded in
  [DEPENDENCIES.md](DEPENDENCIES.md).
- Project-authored fixtures: deterministic in-process and remote test
  Providers, byte payloads, temporary staging roots, and the Java subprocess
  protocol fixture are authored for T05. The remote fixture is in memory and
  contacts no network service. The subprocess fixture runs on the test JDK;
  no external engine, document fixture, or binary is included.
- Generated documentation: `docs/generated/capability-matrix.md` and
  `docs/generated/facade-surface.md` are regenerated deterministically from
  the two YAML authorities and contain no copied external content.
- Excluded inputs: no iText source, resource, fixture, binary, decompiled or
  binary-derived implementation detail, closed add-on material, proprietary
  differential evidence, Reference Suite output, or external engine protocol
  was used.
- Scope: T05 adds only the project-owned Capability Provider contract,
  immutable Workflow Environment registration and selection configuration,
  explicit remote-disclosure authorization, and a bounded generic subprocess
  adapter. It adds no T06 Acceptance Evidence infrastructure, T20
  comprehensive hostile-input enforcement, T21 Hardened Worker, downstream
  engine adapter, Migration Facade mapping, external engine, or network call.
- Compatibility Curator evidence: none; the role remains vacant. The T03
  Dependency Gate and T06 independent Acceptance Evidence remain open, so the
  T05 capability stays `experimental` with no certified-platform claim.

## T06 acceptance-evidence record

- Authorship: OpenAI Codex generated and integrated the T06 repository-only
  pipeline, tests, evidence, and documentation at repository operator
  MaBaiqiu's direction. No T06 commit was created in this execution.
- Project inputs: GitHub issues #1 and #7, especially issue #1's Testing
  Decisions, the Document Engine glossary, ADR-0005, ADR-0011, ADR-0023, the
  accepted T03 public transaction seam, and the repository Capability Matrix.
- External syntax producer: the official qpdf 12.4.0 Linux x86-64 binary
  archive from
  `https://github.com/qpdf/qpdf/releases/download/v12.4.0/qpdf-12.4.0-bin-linux-x86_64.zip`,
  verified before use as SHA-256
  `a3bca240f3bb61efdc3a90be89d1da4ed5e125326c3458c4e62df53ff4f153e3`.
  Its `bin/qpdf` is additionally pinned as SHA-256
  `9ac787a28597e8428289a12ba3fedafd74bdfb4b4da1be814722faf76f14f21b`.
  `scripts/qpdf-pin.properties` is the single operational pin authority used
  by provisioning, execution, and evidence generation; the canonical Maven
  profile cannot override the repository wrapper or pin file.
- External-tool licenses: qpdf and libqpdf are Apache-2.0. The archive also
  contains libffi, GnuTLS, Nettle/Hogweed, GNU Libidn2, libjpeg-turbo,
  p11-kit, GNU Libtasn1, and GNU libunistring. Their upstream origins and
  exact license families, together with the host-provided runtime
  prerequisites, are recorded in [DEPENDENCIES.md](DEPENDENCIES.md). The
  archive remains in an ignored local validation cache and is not
  redistributed.
- Project semantic producer: `folio-pdf-semantic-assertions` at Release Train
  `0.1.0-SNAPSHOT` creates, publishes, reopens, and observes the one-page
  sequence and readable object graph entirely through
  `DocumentWorkflow.execute` and project-owned command/query types. Text order
  is explicitly not applicable because this profile emits a blank document.
  PDFBox remains behind that public seam.
- Evidence artifact: `T06-document-blank-output.pdf` is generated by the
  project workflow. Both chain records pin its SHA-256 and retain raw qpdf and
  semantic findings. No external PDF fixture is included.
- Finding incorporated into the implementation: qpdf 12.4.0 initially
  returned its documented warning status because the new blank page omitted
  a Resources dictionary. The internal PDFBox adapter now initializes empty
  page resources; no public API or compatibility surface changed.
- Excluded inputs: no iText source, resource, fixture, decompiled or
  binary-derived implementation detail, closed add-on material, or proprietary
  differential evidence was used.
- Scope and determination: T06 records the syntax and semantic chains for the
  built-in blank-document profile, and both pass for the checked-in artifact.
  T07 now supplies the passing independent visual chain. Standards evidence
  remains absent, so the overall determination is still `indeterminate`, the
  T06 promotion gate remains open, and the capability remains `experimental`.

## T09 document-value-inspection-patch record

- Authorship: OpenAI Codex generated and integrated the T09 implementation,
  tests, inventories, and documentation at repository operator MaBaiqiu's
  direction. No T09 commit was created in this execution.
- Project inputs: GitHub issues #1 and #10, `CONTEXT.md`, ADR-0019 as the
  primary design authority, ADR-0011, 0013, 0017, 0023, 0025, and 0029, the
  repository inventory contract, and the accepted T01–T06 implementation and
  evidence.
- Runtime and test dependencies: T09 adds no third-party dependency. Apache
  PDFBox 3.0.8 remains the private Apache-2.0 implementation dependency, and
  JUnit 4.13.2 remains the existing test dependency. The no-new-dependency
  statement is recorded in [DEPENDENCIES.md](DEPENDENCIES.md).
- Project-authored fixtures: every T09 PDF is created, patched, published, and
  reopened through the project-owned Native Interface in temporary test
  directories. Test values, byte streams, invalid value implementations, and
  failure cases are authored for T09. No external PDF fixture or product
  artifact is included.
- Generated documentation: `docs/generated/capability-matrix.md` and
  `docs/generated/facade-surface.md` are deterministic renderings of the two
  YAML authorities and contain no copied external content.
- Excluded inputs: no iText source, resource, fixture, binary, decompiled or
  binary-derived implementation detail, closed add-on material, proprietary
  differential evidence, Reference Suite output, or external behavioral oracle
  was used.
- Scope: T09 adds bounded trusted in-process PDF Value inspection and validated
  version-1 dictionary-entry Patches only. It adds no downstream page editing,
  extraction, INCREMENTAL or signed-document behavior (T15), comprehensive
  hostile-input policy (T20), Hardened Worker or codec (T21), or Migration
  Facade mapping.
- Compatibility Curator evidence: none; the role remains vacant. The
  blank-document Dependency Gate and T06 promotion gate remain open, all T09
  Acceptance Evidence chains remain absent, and the capability stays
  `experimental` with no certified-platform claim.

## T10 page-manipulation-merge-split record

- Authorship: OpenAI Codex generated and integrated the T10 implementation,
  tests, inventories, and documentation at repository operator MaBaiqiu's
  direction. This record accompanies the repository's one-ticket T10 commit.
- Project inputs: GitHub issues #1 and #11, `CONTEXT.md`, ADR-0013, 0017,
  0019, and 0025, the repository inventory contract, and the accepted T03 and
  T09 public workflow seams and evidence.
- Runtime and test dependencies: T10 adds no third-party dependency. Apache
  PDFBox 3.0.8 remains the private Apache-2.0 implementation dependency, and
  JUnit 4.13.2 remains the existing test dependency. The no-new-dependency
  statement is recorded in [DEPENDENCIES.md](DEPENDENCIES.md).
- Project-authored fixtures: T10 consumer tests construct their own marker
  documents, preservation-sensitive catalog/page/annotation relationship
  structures, custom and external-file content streams, nested content arrays,
  malformed inherited page attributes, structurally inconsistent, missing-type,
  and direct-node page trees, duplicate-scalar indirect objects, caller-failing
  Sources, and a raw nested-page-tree PDF with inherited page boxes,
  rotation, resources, annotations, and content. Every operation,
  terminal-split probe, query non-mutation probe, rejection, reopen,
  rewrite-isolation probe, and semantic assertion crosses
  `DocumentWorkflow.execute`; no externally sourced fixture or product artifact
  is included.
- Acceptance artifacts: the repository-owned acceptance command creates the
  two checked-in T10 split products through all six T10 Commands. The official
  pinned qpdf 12.4.0 distribution checked both products with exit code 0; the
  syntax record retains their hashes, invocations, and raw findings. This is
  syntax evidence only and makes no standards-conformance claim.
- Public implementation references: Apache PDFBox 3.0.8 source and Javadocs
  were consulted for its public page import, split, merge, page-tree, and
  resource behavior. They were obtained from the official Maven artifact and
  used only behind project-owned interfaces.
- Generated documentation: `docs/generated/capability-matrix.md` and
  `docs/generated/facade-surface.md` are deterministic renderings of the two
  YAML authorities and contain no copied external content.
- Excluded inputs: no iText source, resource, fixture, binary, decompiled or
  binary-derived implementation detail, closed add-on material, proprietary
  differential evidence, Reference Suite output, or external behavioral oracle
  was used.
- Scope: T10 adds version-1 page insertion, removal, movement, copying,
  ordered multi-Source merge, exact Target-to-range split, and a page Object
  Reference query. It does not add T11 metadata, outline, destination, or
  attachment management; T12 action management; T15 incremental or signed-
  document behavior; T20 hostile-input policy; T21 Worker codecs; or a
  Migration Facade mapping. Page commands conservatively reject these
  downstream or otherwise unproven catalog, page-tree, page, and annotation
  structures rather than silently altering them.
- Compatibility Curator evidence at the original T10 delivery: none; the role
  was vacant. That delivery retained syntax evidence only and made no compatible
  or certified-platform claim. The later T70 and T72 records supply the
  prerequisite promotion and candidate-bound four-chain evidence without
  relabeling this historical observation.

## T11 metadata-outlines-destinations-attachments record

- Authorship: OpenAI Codex generated and integrated the T11 implementation,
  tests, inventories, and documentation at repository operator MaBaiqiu's
  direction. This record accompanies the repository's one-ticket T11 commit.
- Project inputs: GitHub issues #1 and #12, `CONTEXT.md`, ADR-0013, 0017, and
  0019, the repository inventory contract, ISO 32000-2:2020 document catalog,
  name tree, outline, file specification, and XMP clauses, and the accepted
  T03, T09, and T10 public workflow seams and evidence.
- Runtime and test dependencies: T11 adds no third-party dependency. Apache
  PDFBox 3.0.8 remains the private Apache-2.0 implementation dependency, and
  JUnit 4.13.2 remains the existing test dependency. The no-new-dependency
  statement is recorded in [DEPENDENCIES.md](DEPENDENCIES.md).
- Project-authored fixtures: T11 consumer tests construct their own raw
  marker documents carrying document information entries, XMP packets, flat
  name-tree destinations, outline trees with explicit and named destinations,
  embedded-file specifications and streams, and malformed variants of each
  structure, plus unproven catalog subtrees for the preservation rejection
  matrix. Every command, query, conflict rejection, retarget, reopen, and
  semantic assertion crosses `DocumentWorkflow.execute`; no externally
  sourced fixture or product artifact is included.
- Acceptance artifacts: the repository-owned acceptance command creates the
  two checked-in T11 split products through every T11 Command applied across
  a merge and split. The official pinned qpdf 12.4.0 distribution checked
  both products with exit code 0; the syntax record retains their hashes,
  invocations, and raw findings. This is syntax evidence only and makes no
  standards-conformance claim.
- Public implementation references: Apache PDFBox 3.0.8 source and Javadocs
  were consulted for its public merge, split, name-tree, outline, metadata,
  and embedded-file behavior. They were obtained from the official Maven
  artifact and used only behind project-owned interfaces.
- Generated documentation: `docs/generated/capability-matrix.md` and
  `docs/generated/facade-surface.md` are deterministic renderings of the two
  YAML authorities and contain no copied external content.
- Excluded inputs: no iText source, resource, fixture, binary, decompiled or
  binary-derived implementation detail, closed add-on material, proprietary
  differential evidence, Reference Suite output, or external behavioral
  oracle was used.
- Scope: T11 adds version-1 document information, XMP metadata, named
  destination, outline, and embedded-file commands and queries with
  destination retargeting across the T10 page operations. It does not add T12
  annotation or action management, T13 or T14 extraction, T15 incremental or
  signed-document behavior, T16 encryption, T20 hostile-input policy, T21
  Worker codecs, or a Migration Facade mapping. Structures outside the proven
  safe invariants remain preserved intact or rejected with
  `PRESERVATION_UNSUPPORTED`.
- Compatibility Curator evidence: none; the role remains vacant. The T11
  syntax chain passes, while standards, semantic, and visual Acceptance
  Evidence remain absent. The value-inspection Dependency Gate and the T06
  promotion gate remain open, so the capability stays `experimental` with no
  certified-platform claim.

## T12 annotations-document-actions record

- Authorship: OpenAI Codex generated and integrated the T12 implementation,
  tests, inventories, and documentation at repository operator MaBaiqiu's
  direction. No T12 commit was created in this execution.
- Project inputs: GitHub issues #1 and #13, `CONTEXT.md`, ADR-0005, 0006,
  0009, 0011, 0012, 0013, 0014, 0016, 0017, 0019, 0023, 0025, 0029, and
  0034, the repository inventory contract, ISO 32000-2:2020 annotation,
  appearance-stream, Action, destination, and embedded-file clauses, and the
  accepted T03 and T09 through T11 public workflow seams and evidence.
- Runtime and test dependencies: T12 adds no third-party dependency. Apache
  PDFBox 3.0.8 remains the private Apache-2.0 implementation dependency, and
  JUnit 4.13.2 remains the existing test dependency. The no-new-dependency
  statement is recorded in [DEPENDENCIES.md](DEPENDENCIES.md).
- Project-authored fixtures: T12 consumer tests construct their own Text,
  Stamp, Highlight, FileAttachment, standalone Widget, and Link annotations;
  resource-free normal appearances; direct and named destinations; catalog
  and page Actions; unsupported URI, JavaScript, Launch, and chained Action
  graphs; mixed managed and proven-safe legacy Text annotation arrays,
  including copied legacy identifier suffixing and an unrenamable merge
  collision; a filesystem marker that would expose Action execution; and
  malformed appearance, destination, Action, and annotation variants,
  including scalar update and flattening inputs.
  Every update, query, flatten, retarget, preservation or rejection probe,
  reopen, and semantic assertion crosses `DocumentWorkflow.execute`; no
  externally sourced fixture or product artifact is included.
- Acceptance artifacts: the repository-owned acceptance command creates two
  checked-in T12 split products through the public workflow seam after adding
  all six supported annotation types, document and page Actions, a named
  destination, flattening a Stamp annotation, and copying and splitting pages.
  Newly created split products use a project-authored, streaming content-
  derived trailer identifier when the splitter supplies no identifier;
  existing identifiers and non-split publication are unchanged. An acceptance
  regression executes independent runs and compares the exact T12 product
  bytes and evidence metadata.
  The official pinned qpdf 12.4.0 distribution checks both products; the
  syntax record retains their hashes, invocations, exit codes, and raw
  findings. This is syntax evidence only and makes no standards-conformance
  claim.
- Public implementation references: Apache PDFBox 3.0.8 source and Javadocs
  were consulted for its public annotation, appearance, Action, destination,
  file-specification, page import, and content-stream behavior. They were
  obtained from the official Maven artifact and used only behind project-owned
  interfaces.
- Generated documentation: `docs/generated/capability-matrix.md` and
  `docs/generated/facade-surface.md` are deterministic renderings of the two
  YAML authorities and contain no copied external content.
- Excluded inputs: no iText source, resource, fixture, binary, decompiled or
  binary-derived implementation detail, closed add-on material, proprietary
  differential evidence, Reference Suite output, or external behavioral
  oracle was used.
- Scope: T12 adds immutable version-1 values, Commands, and bounded Queries
  for six annotation types, resource-free normal appearances, non-Widget
  annotation flattening, local direct or named GoTo destinations, and catalog,
  page, and Link Action bindings. Managed targets integrate with T10 and T11
  page move, copy, merge, split, and removal behavior. T12 does not add T13 or
  T14 extraction, T15 incremental or signed-document behavior, T16 encryption,
  T17 canvas composition, T20 comprehensive hostile-input policy, T21 Worker
  codecs, T34/T35 AcroForm field behavior, T36 XFDF, form Actions or form
  flattening, or a Migration Facade mapping. Unsupported Action and appearance
  graphs are preserved only when no interpretation is required and otherwise
  rejected before mutation.
- Compatibility Curator evidence: none; the role remains vacant. The T12
  syntax chain passes, while standards, semantic, and visual Acceptance
  Evidence remain absent. Its value, page, and metadata Dependency Gates and
  the T06 promotion gate remain open, so the capability stays `experimental`
  with no certified-platform claim.

## T13 text-logical-structure extraction record

- Authorship: OpenAI Codex generated and integrated the T13 implementation,
  tests, inventories, evidence, and documentation at repository operator
  MaBaiqiu's direction. No T13 commit was created in this execution.
- Project inputs: GitHub issues #1 and #14, `CONTEXT.md`, ADR-0004, 0005,
  0009, 0011, 0013, 0016, 0017, 0019, 0023, 0025, 0029, and the T13
  decision in ADR-0035, the repository inventory contract, and the accepted
  T03 and T09 public workflow and PDF Value seams.
- Public standards inputs: the freely available ISO 32000-1:2008 document
  published by Adobe, the PDF Association's ISO 32000-2 overview and errata,
  and the PDF Association's Well-Tagged PDF guidance were consulted for text
  showing, `ToUnicode`, marked-content, `MCID`, `ActualText`, `Alt`, structure
  children, role mapping, and language semantics. These public materials were
  used as specification inputs, not copied fixtures or implementation code.
- Public implementation references: Apache PDFBox 3.0.8 public source and
  Javadocs for `PDFStreamEngine`, text and marked-content operators, font
  encodings, embedded font loading, simple and CID width handling, Form
  XObjects, and FontBox `CMapParser` numeric and token behavior were consulted
  to keep the private adapter aligned with its supported API. PDFBox output or
  coercive Unicode results are not a behavioral oracle; T13 independently
  preflights and parses mapping evidence, derives simple-font inference only
  from declared PDF encoding data and the public Adobe Glyph List, and tests
  only Native Interface observations.
- Runtime and test dependencies: T13 adds no third-party dependency. Apache
  PDFBox 3.0.8 and transitive FontBox remain private Apache-2.0
  implementation dependencies, and JUnit 4.13.2 remains the existing test
  dependency. The repository-only acceptance path reuses pinned qpdf 12.4.0.
  Exact facts and roles remain recorded in
  [DEPENDENCIES.md](DEPENDENCIES.md).
- Project-authored fixtures: public-workflow consumer tests construct
  untagged, multi-page, multi-stream, transformed, spaced, rotated, explicitly
  mapped, contradictory, unmapped, marked-content, tagged-structure, nested-
  Form, hostile-CMap, bounded embedded-font/encoding, bounded and hostile CID-
  metric and scalar, malformed-resource, page-geometry, Form-dictionary,
  page-tree, content-array, cross-member content-token, truncated-content,
  trailing-orphan-operand, malformed-operator, unbalanced page/Form operator-
  state, bounded-ExtGState, full-width-integer,
  font-kind, font-data-kind, Type 0 encoding,
  Type 3 glyph-program,
  deep Form and logical-structure, repeated and parent-inconsistent structure,
  namespace, OBJR and Form-stream MCR, transitive and cyclic RoleMap,
  invalid Unicode CMap destination, malformed CMap count and range,
  embedded CMap carry, embedded Type 0 subtype-repair, large-text-item, nested
  marked-content, and exact-limit PDFs from project-owned values. Transparent
  minimal PDF syntax supplies only the cyclic graphs, fully linked tagged
  hierarchy, and hostile structures needed to make those contracts
  observable; it calls no other PDF implementation.
  The
  acceptance command
  rewrites its project-owned fully tagged source and creates the checked-in
  T13 page-text product through `DocumentWorkflow.execute`, validates both
  public Query observations, and submits those exact products to pinned qpdf.
- Generated documentation: `docs/generated/capability-matrix.md` and
  `docs/generated/facade-surface.md` are deterministic renderings of the YAML
  authorities and contain no copied external content.
- Excluded inputs: no iText source, resource, binary, fixture, output,
  decompiled or binary-derived implementation detail, closed add-on material,
  proprietary differential evidence, OCR engine output, or Reference Suite
  behavioral oracle was used.
- Scope: T13 adds only bounded detached page text, source-code mapping
  evidence, marked content, and logical structure through a version-1
  Document Query. It adds no image/resource extraction (T14), incremental or
  signature-aware publication (T15), encryption (T16), drawing (T17),
  comprehensive hostile-input policy (T20), Worker codecs (T21), or Migration
  Facade surface.
- Compatibility Curator evidence: none; the role remains vacant. T13 has a
  passing syntax record only. Mandatory standards, semantic, and visual chains
  remain absent, and its T09 Dependency Gate remains open while that capability
  is `experimental`, so T13 remains `experimental` with no certified-platform
  claim.

## T14 image-resource extraction record

- Authorship: OpenAI Codex generated and integrated the T14 implementation,
  tests, inventories, evidence, and documentation at repository operator
  MaBaiqiu's direction. No T14 commit was created in this execution.
- Project inputs: GitHub issues #1 and #15, `CONTEXT.md`, ADR-0005, 0009, 0011,
  0014, 0016, 0017, 0019, 0023, 0025, 0029, and the T14 byte-lifecycle decision
  in ADR-0036, the repository inventory and evidence contracts, and the
  accepted T03, T09, and T13 public workflow, PDF Value, Object Reference,
  page-tree, and extraction-limit seams.
- Public standards inputs: the freely available ISO 32000-1:2008 document
  published by Adobe was consulted for Resource dictionaries, XObject and
  Form traversal, Image dictionaries, filters and decode parameters, color
  spaces, Image Masks, explicit masks, subsidiary and JPX-embedded soft masks,
  Font dictionaries, font descriptors, embedded font programs, and subset
  naming. These public
  materials were used as specification inputs, not copied fixtures or
  implementation code.
- Public implementation references: Apache PDFBox 3.0.8 public source and
  Javadocs for COS dictionaries, arrays, names, object wrappers, streams,
  public Filter implementations, and raw/decoded stream access were consulted
  to keep the private adapter aligned with its supported API. PDFBox object
  wrappers, image objects, decoded metadata, renderer output, and repaired or
  coercive values are not a behavioral oracle; T14 independently traverses and
  classifies raw PDF values, strictly validates the supported bounded filter
  inputs, and tests only Native Interface observations.
- Runtime and test dependencies: T14 adds no third-party dependency. Apache
  PDFBox 3.0.8 remains the private Apache-2.0 implementation dependency, and
  JUnit 4.13.2 remains the existing test dependency. The repository-only
  acceptance path reuses pinned qpdf 12.4.0. Exact facts and roles remain
  recorded in [DEPENDENCIES.md](DEPENDENCIES.md).
- Project-authored fixtures: public-workflow consumer tests construct
  inherited and direct Resources, shared indirect images and fonts, nested and
  cyclic Forms, direct resources, Image Masks, explicit image and color-key
  masks, subsidiary and JPX-embedded soft masks, named and composite color
  spaces, supported and unsupported filter sequences and effective decode
  parameters, external stream declarations, embedded and unembedded subset
  fonts, repeated hostile
  graphs, malformed dimensions, filters, compressed data, masks, fonts,
  resource categories, colors and page trees, decoded-size overflow, and exact
  page, node, value, depth, pixel, decompression, and returned-byte boundaries
  from project-owned values or transparent minimal PDF syntax. The acceptance
  command rewrites two project-owned sources through
  `DocumentWorkflow.execute`, validates the detached public Query results, and
  submits those exact filtered-image/font and nested-Form/soft-mask products to
  pinned qpdf.
- Generated documentation: `docs/generated/capability-matrix.md` and
  `docs/generated/facade-surface.md` are deterministic renderings of the YAML
  authorities and contain no copied external content.
- Excluded inputs: no iText source, resource, binary, fixture, output,
  decompiled or binary-derived implementation detail, closed add-on material,
  proprietary differential evidence, OCR or renderer output, system font, or
  Reference Suite behavioral oracle was used.
- Scope: T14 adds only bounded, detached page and nested-Form resource
  inventory, image metadata and explicitly selected bytes, and font identity,
  embedding, subset, declaration, and Page Usage through one version-1
  Document Query. It adds no incremental or signature-aware publication (T15),
  encryption (T16), drawing (T17), image embedding (T18), comprehensive
  hostile-input policy (T20), Worker isolation/codecs (T21), or Migration
  Facade surface.
- Compatibility Curator evidence: none; the role remains vacant. T14 has a
  passing syntax record only. Mandatory standards, semantic, and visual chains
  remain absent, and its T09 Dependency Gate remains open while that capability
  is `experimental`, so T14 remains `experimental` with no certified-platform
  claim.

## T15 incremental-signature-protection record

- Authorship: OpenAI Codex generated and integrated the T15 implementation,
  tests, research, evidence, and documentation at repository operator
  MaBaiqiu's direction. No T15 commit was created in this execution.
- Project inputs: GitHub issues #1, #10, and #16; `CONTEXT.md`; ADR-0005,
  0009, 0011, 0013, 0016, 0017, 0019, 0023, 0025, and 0029; the repository
  workflow, annotation, inventory, and acceptance contracts; and the accepted
  T03 and T09 through T14 implementation and evidence.
- Public standards and API inputs: ISO 32000-1:2008 clauses 7.5.6, 12.8.1,
  12.8.2.2, and 12.8.4 and Tables 252, 254, and 258 supplied the public
  incremental-update, signature dictionary, ByteRange, DocMDP, and permissions
  contracts. Official Apache PDFBox 3.0.8 Javadocs and Apache-2.0 source for
  `PDDocument.saveIncremental`, signature discovery, COS loading, and update
  tracking supplied public backend behavior and its limitations. Exact URLs,
  source revisions, retrieval results, line citations, hashes, licenses,
  uncertainties, and derived decisions are recorded in
  `docs/research/T15-incremental-signature-primary-sources.md`.
- Runtime and test dependencies: T15 adds no dependency. Apache PDFBox 3.0.8
  remains the private Apache-2.0 implementation dependency and JUnit 4.13.2
  remains the test dependency; their existing coordinates and licenses remain
  recorded in [DEPENDENCIES.md](DEPENDENCIES.md).
- Project-authored fixtures: every signed fixture is deterministic minimal PDF
  syntax authored for T15 and contains placeholder structural signature bytes,
  not a cryptographically valid third-party signature. Fixtures cover inherited
  fields, optional signature Type, general ByteRange pairs, ordinary and
  DocMDP P=1/P=2/P=3 policies, multiple restrictions, unsupported transforms,
  invalid ranges, cycles, permission contradictions, indirect critical
  DocMDP values, and local field, signature-dictionary, ByteRange, and
  signature-reference policy-limit exhaustion. Acceptance artifacts are
  produced only through the project-owned
  `DocumentWorkflow.execute` seam.
- Evidence boundary: the acceptance command verifies exact Source-prefix
  retention, a non-empty appended revision, a committed receipt, and public
  reopen as an implementation precondition, then submits the unmodified
  original and incremental products to pinned qpdf 12.4.0. Only qpdf's result
  is recorded as independent syntax Acceptance Evidence. The reproducibility
  hash replaces every hexadecimal two-value trailer `/ID` with equal-length
  ASCII zeroes; every other byte remains significant and tool inputs are never
  normalized or rewritten.
- Generated documentation: `docs/generated/capability-matrix.md` and
  `docs/generated/facade-surface.md` are deterministic renderings of the YAML
  authorities and contain no copied external content.
- Excluded inputs: no iText source, resource, fixture, binary, output,
  decompiled or binary-derived implementation detail, closed add-on material,
  proprietary differential evidence, external signed PDF, certificate,
  private key, or Reference Suite behavioral oracle was used.
- Scope: T15 recognizes and protects Existing Signatures, authorizes only the
  narrow version-1 DocMDP P=3 non-Widget annotation footprint, and appends
  Source-preserving revisions. It does not implement encryption (T16),
  comprehensive raw hostile-input enforcement (T20), Worker isolation (T21),
  Forms or signature creation (T34+), or cryptographic signature and trust
  validation (T38+).
- Compatibility Curator evidence: T15 has a passing qpdf syntax record only.
  Mandatory standards, semantic, and visual chains remain absent, its T09
  Dependency Gate remains open while T09 is `experimental`, and T06 remains a
  promotion gate. T15 therefore remains `experimental` with no compatible or
  certified-platform claim.

## T16 pdf-version-password-security record

- Authorship: OpenAI Codex generated and integrated the T16 implementation,
  tests, research, evidence, and documentation at repository operator
  MaBaiqiu's direction. No T16 commit was created in this execution.
- Project inputs: GitHub issues #1 and #17; `CONTEXT.md`, `SECURITY.md`, and
  `CONTRIBUTING.md`; ADR-0002, 0005, 0006, 0010, 0011, 0012, 0013, 0016,
  0017, 0019, 0020, 0021, 0023, 0025, 0028, 0029, and 0037; the repository
  workflow, value, page, metadata, annotation, extraction, inventory, and
  acceptance contracts; the accepted T03 through T15 implementation; and the
  fixed review point `0d74da80c9607d3fbe50cd12fbd13810d69bfc8c`.
- Public standards inputs: the Adobe-hosted authorized ISO 32000-1:2008 copy
  supplied the PDF 1.0–1.7 header/catalog, Standard security-handler,
  crypt-filter, password, permission, and extension contracts. Current ISO
  and PDF Association metadata and EC3 resolutions, plus explicitly
  provisional public ISO/FDIS 32000-2 clause material, supplied corroborated
  PDF 2.0 version and R6 behavior. Adobe's public Extension Level 3 supplement
  supplied R5/AESV3 history. A PDF Association presentation identifies ADBE
  Extension Level 8 as the PDF 1.7 interoperability signal for corrected R6,
  but is not treated as normative evidence. Exact URLs, hashes, copyrights,
  uncertainties, and clause/table mappings are recorded in
  `docs/research/T16-pdf-version-password-security-primary-sources.md`.
- Backend inputs: official Apache PDFBox tag `3.0.8`, peeled commit
  `9286e47d89d6877005c9d2d0f2fd38793a62519a`, and source JAR SHA-256
  `eaed642d27599c78229857e4ab571805979f828f5ec8c695e3135ca933766132`
  were inspected under Apache License 2.0. Public loader, version, encryption,
  permission, incremental-save, and security-handler behavior established the
  private adapter boundary. No PDFBox source was copied or adapted.
- Runtime and test dependencies: T16 adds no dependency. Apache PDFBox 3.0.8
  remains the private Apache-2.0 runtime dependency and JUnit 4.13.2 remains
  the test dependency; their existing coordinates and licenses remain recorded
  in [DEPENDENCIES.md](DEPENDENCIES.md).
- Project-authored fixtures: version and structural encrypted-signature
  fixtures are deterministic minimal PDF
  syntax. Legacy protected fixtures implement the public ISO password padding,
  MD5, RC4, owner/user entry, file-key, and permission algorithms for the exact
  admitted V1/R2, V1/R3, V2/R3, and V4/R4 profiles, including the V4 metadata-
  clear file-key exception. No downloaded protected PDF, standard example, or
  third-party output became a fixture. Test-only credential literals are
  controlled inputs and are not copied into evidence.
- Output validation: staged products are inspected for their exact effective
  version and security state and reopened through public user and owner
  credentials and compared with the requested detached version, authority,
  algorithm, scope, and permissions. Project-owned raw checks verify exact
  header/catalog markers, V/R/Length/CFM/filter entries, the permission word,
  R6 `Perms` integrity, and absence of PDFBox's noncanonical crypt-filter
  Length value. These implementation checks are not independent Acceptance
  Evidence.
- Evidence boundary: the acceptance command creates PDF 1.7 ADBE Extension
  Level 8 and PDF 2.0 AES-256 products through `DocumentWorkflow.execute`,
  verifies public user and owner reopen, then gives both unchanged encrypted
  products to pinned qpdf 12.4.0. qpdf's version, R=6, permission, AESv3, and
  parse findings are independent syntax evidence only. qpdf receives the user
  credential through a deleted temporary password file; its password-valued
  output and the temporary path are redacted. The repeatable security-
  observation hash includes only non-secret version/profile/scope/permission
  and page-count observations and excludes randomized authentication entries,
  identifiers, and ciphertext. No standards, semantic, visual, cryptographic,
  or permission-enforcement claim is inferred from qpdf.
- Generated documentation: `docs/generated/capability-matrix.md` and
  `docs/generated/facade-surface.md` are deterministic renderings of the YAML
  authorities and contain no copied external content.
- Excluded inputs: no iText source, resource, fixture, binary, output,
  decompiled or binary-derived implementation detail, closed add-on material,
  proprietary differential evidence, third-party protected PDF, unapproved
  black-box result, private key, or Reference Suite behavioral oracle was used.
- Scope: T16 adds exact version observation, PDF 1.7/PDF 2.0 publication,
  Standard password authentication, AES-256 secure output, exact documented
  legacy profiles and version minima, credential ownership, independently
  proven owner authority, permission enforcement, named-Source preflight and
  anti-downgrade rules, protected rewrite, and encrypted incremental and
  Existing Signature preservation. It does not implement T17
  drawing, T20 comprehensive hostile-input enforcement, T21 Worker isolation,
  T37 public-key encryption, T38+ signing/trust, metadata-clear or attachment-
  only output, or FIPS validation.
- Compatibility Curator evidence: none; the role remains vacant. T16 has one
  passing qpdf syntax record only. Mandatory standards, semantic, and visual
  chains remain absent, its T09 Dependency Gate remains open while T09 is
  `experimental`, and T06 remains a promotion gate. T16 therefore remains
  `experimental` with no compatible or certified-platform claim.

## T17 canvas-vector-positioned-text record

- Authorship: OpenAI Codex generated and integrated the T17 implementation,
  tests, evidence, and documentation at repository operator MaBaiqiu's
  direction. No T17 commit was created in this execution.
- Project inputs: GitHub issues #1, #18, #19, and #20; `CONTEXT.md`,
  `CONTRIBUTING.md`, the repository issue/domain instructions, and ADR-0004,
  0005, 0009, 0011, 0013, 0014, 0016, 0017, 0019, 0020, 0023, 0025, 0029,
  and 0034; the accepted T03, T09, T12, T13, T14, T15, and T16 public
  transaction, PDF Value, content-preflight, extraction, resource,
  publication, signature, and permission seams; and the fixed review point
  `cbd493376c0c8ea3676f47be3e708ba4c03249fd`.
- Public standards input: the Adobe-hosted authorized ISO 32000-1:2008 copy
  already inventoried for T15/T16, SHA-256
  `9de0ca9e8570d6209e8bd48a355be8eb6ec376acfc3fc3ae97cd8730351417ff`,
  supplied the public graphics-state, current-transformation-matrix, path
  construction/painting/clipping, text-object, text-state, text-matrix,
  rendering-mode, Font-resource, content-stream-array, and page-resource
  concepts. The PDF is copyright Adobe/ISO, all rights reserved, was not
  redistributed, and supplied specification semantics only. Existing project
  contracts were used for the narrower fail-closed version-1 policy; no
  standards-conformance claim is inferred.
- Backend inputs: the existing Apache PDFBox 3.0.8 public COS and parser APIs
  for dictionaries, arrays, indirect objects, streams, names,
  `PDFStreamParser`, and content `Operator` values establish the private
  adapter surface. The official tag is `3.0.8`, peeled commit
  `9286e47d89d6877005c9d2d0f2fd38793a62519a`; its already inventoried source
  JAR SHA-256 is
  `eaed642d27599c78229857e4ab571805979f828f5ec8c695e3135ca933766132`.
  PDFBox is Apache-2.0. No source was copied or adapted, and PDFBox identity,
  serialization choices, text mapping, or renderer output is not the T17
  behavioral oracle.
- Runtime and test dependencies: T17 adds no dependency. Apache PDFBox 3.0.8
  and transitive FontBox remain private Apache-2.0 implementation
  dependencies; JUnit 4.13.2 remains the EPL-1.0 test dependency. Pinned qpdf
  12.4.0 remains an acceptance-only Apache-2.0 tool. Their exact coordinates,
  roles, pins, and licenses remain recorded in
  [DEPENDENCIES.md](DEPENDENCIES.md) and the existing qpdf pin authority.
- Project-authored fixtures and resources: consumer tests create deterministic
  minimal PDF syntax for pages, content, resources, unsigned incremental
  input, structural Existing Signatures, and password permissions. The
  acceptance source is a project-authored one-page PDF containing one short
  path, a private marker resource, and an unembedded standard `/Helvetica`
  Type1 Font declaration; it contains no downloaded font program and performs
  no system-font or network lookup. Glyph code `41` hexadecimal and every
  expected path, matrix, rendering mode, and geometry value are project-owned
  test inputs.
- Output validation and evidence boundary: consumer tests publish and reopen
  products only through `DocumentWorkflow.execute` and public PDF Value, T13,
  and T14 queries. The acceptance command retains the exact workflow product,
  computes the existing ID-neutral hash, and sends the unchanged bytes to
  pinned qpdf 12.4.0 for syntax evidence. A distinct project-test semantic
  producer reopens the same artifact through public queries and compares
  semantic operations, state balance, resource reuse, preservation, all eight
  rendering modes, and glyph geometry with the project-owned Canvas Program.
  Neither chain uses Reference Suite output, PDFBox object identity, a private
  call, or incidental dictionary/resource ordering as an oracle. qpdf does
  not establish standards, semantic, visual, or rendering conformance.
- Generated documentation: `docs/generated/capability-matrix.md` and
  `docs/generated/facade-surface.md` are deterministic renderings of the YAML
  authorities and contain no copied external content.
- Excluded inputs: no iText source, resource, fixture, binary, output,
  decompiled or binary-derived detail, closed add-on material, proprietary
  differential evidence, unauthorized black-box observation, external PDF,
  third-party font, system font, image, renderer output, or Reference Suite
  behavioral oracle was used.
- Scope: T17 adds backend-neutral low-level vector paths, affine transforms,
  clipping, nested graphics state, and explicit existing-resource positioned
  glyphs with Canvas-specific types under the Composition-context Native
  Interface namespace and the shared rendering-mode value below that context,
  while retaining the existing deep Document Engine artifact. It adds no T18
  image embedding; T19 font discovery, loading,
  embedding, subsetting, mapping, or fallback; T20 comprehensive hostile-input
  policy; T21 Worker isolation; T23 rendering; layout; barcodes; Forms;
  tagged-document construction; SVG conversion; redaction; public backend
  SPI; Migration Facade mapping; or new Maven artifact.
- Compatibility Curator evidence: none; the role remains vacant. T17 has
  passing syntax and project-owned semantic chains only. Mandatory standards
  and visual evidence remain absent, its T09 Dependency Gate remains open
  while T09 is `experimental` regardless of the closed implementation issue,
  and T06 remains a promotion gate. T17 therefore remains `experimental` with
  no compatible or certified-platform claim.

## T07 independent-visual-evidence record

- Authorship: OpenAI Codex generated and integrated the T07 repository-only
  profile, provisioning, harness, tests, evidence, and documentation at
  repository operator MaBaiqiu's direction. No T07 commit was created in this
  execution.
- Project inputs: GitHub issues #1, #7, and #8, `CONTEXT.md`, ADR-0002, 0005,
  0007, 0011, 0023, and 0027, the accepted T03 and T06 public-workflow and
  Acceptance Evidence seams, the repository Capability Matrix, and the clean-
  room and dependency authorities.
- Independent renderer: the pdfium-cli v0.11.2 WebAssembly Linux amd64 release
  from `https://github.com/klippa-app/pdfium-cli`, embedding PDFium Chromium
  build 7881, is pinned as both release-asset and executable SHA-256
  `3ef3375c429ce665e834f933a028225bf28ac837695aaa69c6fc21facf6780ab`.
  pdfium-cli and go-pdfium are MIT; PDFium is BSD-3-Clause with its documented
  third-party notices. The linked Go modules and the exact PDFium 7881 archive
  notice set are recorded in
  `docs/third-party/pdfium-cli-v0.11.2.md`, tied to the executable hash and the
  source `pdfium-wasm.tgz` SHA-256
  `added6e8ac024f71cb61cf2b77a205d178e2bdde2e4048fbcd916f68b7264d56`.
  The executable is operator-supplied, verified offline, and retained only in
  the ignored local validation cache.
- Raster comparator: the official ImageMagick 7.1.2-30 GCC x86-64 AppImage
  from `https://github.com/ImageMagick/ImageMagick` is pinned as both release-
  asset and executable SHA-256
  `372af8a3fd61ef5f15c6331cde3e21f840eb165d8b533f34ed05d68736dd682e`
  under the ImageMagick License. The origin and license of every extracted
  shared-library payload component are recorded in
  `docs/third-party/imagemagick-7.1.2-30-appimage.md`, tied to that exact
  AppImage hash. It is operator-supplied, verified offline, and retained only
  in the ignored local validation cache.
- Project-owned expectation: the blank-page expected raster is defined as
  `1224x1584` opaque white sRGB RGB pixels by the T03 visual profile and was
  encoded with the pinned ImageMagick tool using metadata stripping. Its
  SHA-256 is
  `c7bbf03603aee1dba4ef80c9eee9abb93b7f3adfb94b84e4abf0203d78f89011`.
  It is a project-authored expectation derived from page geometry and contains
  no Reference Suite or third-party document content.
- Secondary evidence: Apache PDFBox Renderer 3.0.8, already present under
  Apache-2.0 as the private Document Engine dependency, renders the same
  workflow artifact only to detect renderer disagreement. It cannot make the
  visual chain pass and exposes no backend type through the Native Interface.
- Evidence artifact: PDFium renders the exact PDF created by
  `DocumentWorkflow.execute`; ImageMagick receives only validated fixed-size
  PNG paths. The passing record retains an ID-neutral input hash and exact
  raster hashes, profile settings, both AE metrics, tool identities and
  digests, raw findings, and reviewable difference artifacts. The input hash
  replaces only the fresh trailer `/ID` hex values with zeroes, consistently
  with issue #1's byte-equality exclusion; tools receive the unmodified PDF,
  and repeat-run tests require identical T06/T07 metadata. Independent
  standards evidence remains absent, so the overall T03 determination and
  capability remain
  `indeterminate` and `experimental`.
- Excluded inputs: no iText source, resource, fixture, output, decompiled or
  binary-derived implementation detail, closed add-on material, proprietary
  differential evidence, or system font was used.
- Scope: T07 adds repository-only visual Acceptance Evidence. It adds no T23
  runtime page rendering, Capability Provider, Native Interface or Migration
  Facade surface, stable mapping, or unsupported stub, and does not bundle or
  publish either external executable.

## T08 secure Maven Central rehearsal record

- Authorship: OpenAI Codex generated and integrated the T08 release profile,
  repository command, local Central-layout bundle assembler, validator, tests,
  workflow, and documentation at repository operator MaBaiqiu's direction. No
  T08 commit was created in this execution.
- Project inputs: GitHub issues #1 and #9, `CONTEXT.md`, ADR-0030, ADR-0031,
  ADR-0032, the existing Release Train POMs and BOM, the CI workflow,
  `RELEASING.md`, `SECURITY.md`, `DEPENDENCIES.md`, the inventory authorities,
  and accepted T01-T07/T09-T11 implementation and evidence.
- Public tool references: official Apache Maven Source, Javadoc, and GPG plugin
  documentation; official Sonatype Central Publisher Maven documentation;
  official CycloneDX Maven plugin documentation; official MojoHaus Flatten and
  License plugin documentation; and official OWASP Dependency-Check
  documentation and public issues #8715/#8716. These sources supplied public
  configuration and security contracts only.
- Build plugins and tools: the exact Maven coordinates, versions, roles, and
  licenses are recorded in [DEPENDENCIES.md](DEPENDENCIES.md). Maven 3.9.16,
  GnuPG 2.4.4, and rsync 3.2.7 are operational pins. Every GitHub Action
  reference is a full commit SHA. Release-only tooling is absent from
  `pdf-bom` and product runtime artifacts. Hosted vulnerability suppressions
  are disabled; the checked-in suppression file is the only release-gate
  exception authority.
- Project-authored tests and fixtures: T08 tests create a synthetic
  Central-layout repository from project-authored POM, JAR, SBOM, license, and
  vulnerability-report content. Each test invocation generates a temporary
  non-production RSA signing identity, signs the fixture artifacts with GnuPG,
  and invokes the repository command. Corruption cases remove an artifact,
  damage a signature or checksum, remove POM metadata, add an unexpected
  module, inject an unresolved high-severity vulnerability, or remove an audit
  report. No external binary fixture or private key is committed.
- Rehearsal identity boundary: the real command creates a fresh isolated
  one-day test identity, exports only its public key, and deletes its private
  temporary home. It also creates a temporary Maven settings file with dummy
  server id `central` credentials to satisfy Central Publisher without reading
  production credentials. The production workflow instead pins the approved
  fingerprint and obtains the existing key and passphrase only from the
  protected GitHub Environment.
- Capability and facade determination: T08 adds a repository release gate, not
  a PDF behavioral capability, Native Interface, Acceptance Profile, or
  Migration Facade mapping. The Capability Matrix YAML and generated view
  therefore remain unchanged. The Facade Surface authority remains unchanged,
  and no Stable Migration Facade stub is introduced. The concrete release-gate
  determination is recorded in the T08 evidence record.
- Excluded inputs: no iText source, resource, fixture, binary, decompiled or
  binary-derived implementation detail, closed add-on material, proprietary
  differential evidence, Reference Suite output, production credential,
  production private key, passphrase, generated Maven settings, Central
  deployment, tag, or GitHub Release was used or created.
- Scope: T08 builds and validates a non-publishing Maven Central rehearsal and
  supplies a protected, manually dispatched production staging contract. It
  does not publish, tag, certify the Foundation Release (T32), change product
  behavior, promote a capability, or perform the separate human Central
  publication step.

## T18 canvas-images-colors-transparency record

- Authorship: OpenAI Codex generated and integrated the T18 implementation,
  tests, evidence, inventories, and documentation at repository operator
  MaBaiqiu's direction. No T18 commit was created in this execution.
- Project inputs: GitHub issues #1, #18, #19, and #20; `CONTEXT.md`,
  `CONTRIBUTING.md`, repository issue/domain instructions; ADR-0005, 0010,
  0011, 0017, 0023, 0025, and 0036; the accepted T03, T09, T13, T14, T15,
  T16, and T17 public transaction, value, extraction, identity, publication,
  security, preservation, and Canvas seams; and pre-implementation fixed point
  `182a168e70c7b830de568829dff484e16b1b6cbb`.
- Public standards input: the Adobe-hosted authorized ISO 32000-1:2008 copy
  already inventoried by prior tickets, SHA-256
  `9de0ca9e8570d6209e8bd48a355be8eb6ec376acfc3fc3ae97cd8730351417ff`,
  supplied public Image XObject, color-space, Decode, mask, ExtGState, blend-
  mode, Form Transparency Group, resource, and content-placement concepts. It
  was not redistributed and supplied specification semantics only; no
  standards-conformance claim is inferred.
- Backend inputs: existing Apache PDFBox 3.0.8 public COS, stream, save, and
  renderer APIs remain private implementation/secondary-evidence surfaces.
  Java 8 ImageIO and `java.awt.color.ICC_Profile` provide platform raster and
  profile parsing behind project-owned bounds. No backend type, serialization
  choice, provider exception, or renderer output defines Native Interface
  semantics.
- Optional codec: TwelveMonkeys ImageIO 3.14.0, tag
  `twelvemonkeys-3.14.0`, peeled commit
  `62f6e2fba80b3eee99707985ebf4a4fd33abf07b`, supplies the optional TIFF
  ImageIO provider under BSD-3-Clause. The exact root/transitive coordinates,
  JAR hashes, roles, distribution behavior, copyright, and license text are in
  [DEPENDENCIES.md](DEPENDENCIES.md) and the
  [TwelveMonkeys manifest](docs/third-party/twelvemonkeys-imageio-tiff-3.14.0.md).
  `pdf-document` marks it optional; no Folio PDF artifact shades or bundles
  it. The repository-only acceptance module selects it directly to exercise
  the available path. Provider absence is a first-class tested result.
- Project-authored fixtures: consumer and acceptance tests synthesize their
  raster pixels, JPEG/PNG/TIFF encodings, raw samples, masks, ICC data from the
  JDK sRGB profile, minimal existing-image PDF syntax, signature/password
  inputs, limits, and expected semantic values. No external image, PDF,
  profile, proprietary output, system font, or Reference Suite fixture was
  copied.
- Output validation and evidence boundary: public workflows create, publish,
  reopen, and query every product. T14 observations prove dimensions, filters,
  masks, color/profile identity, Object References, Page Usage, and resource
  counts. The repository acceptance command sends the unchanged ID-neutral-
  hashed T18 artifact to pinned qpdf 12.4.0 and PDFium v0.11.2/Chromium 7881;
  ImageMagick 7.1.2-30 compares validated fixed-size PNGs only. The
  project-owned expected raster is the visually reviewed 144-DPI PDFium
  baseline, SHA-256
  `4027a0a929494c49051a3039be5bd1c06d2a6624ba7c161acb8c1bfe0780024a`.
  Expected comparison requires AE 0; secondary PDFBox Renderer disagreement
  must not exceed AE 2,500 and can never make the chain pass. Repeat-run tests
  require identical records, findings, ID-neutral artifact hashes, and raster
  hashes.
- Generated documentation: `docs/generated/capability-matrix.md` and
  `docs/generated/facade-surface.md` are deterministic renderings of the YAML
  authorities and contain no copied external content.
- Excluded inputs: no iText source, resource, fixture, binary, output,
  decompiled or binary-derived implementation detail, closed add-on material,
  proprietary differential evidence, unauthorized black-box observation,
  downloaded image/PDF/profile, arbitrary URI, or Reference Suite behavioral
  oracle was used.
- Scope: T18 deepens the existing Canvas/Document Engine seam with bounded
  JPEG/PNG/TIFF/raw/existing image declaration and placement, Device/
  calibrated/ICCBased painting color, alpha, explicit and soft masks, standard
  blend modes, reusable transparency groups, deterministic resource reuse,
  optional-codec discovery, stable failures, and T14 ICC profile identity. It
  adds no T19 font acquisition, T20 comprehensive hostile-input enforcement,
  T21 Worker isolation, T23 runtime rendering, layout, Forms, SVG, redaction,
  optimization, Migration Facade surface, backend SPI, or new product module.
- Compatibility Curator evidence: none; the role remains vacant. T18 has
  passing syntax, project-owned semantic, and independent visual chains, but
  mandatory standards evidence remains absent. Its T14 and T17 compatible-
  status Dependency Gates remain open while both capabilities are
  `experimental`, and T06 remains a promotion gate. T18 therefore remains
  `experimental` with no compatible or certified-platform claim.

## T19 font-loading-embedding-subsetting record

- Authorship: OpenAI Codex generated and integrated the T19 implementation,
  tests, evidence, inventories, and documentation at repository operator
  MaBaiqiu's direction. No T19 commit was created or authorized in this
  execution.
- Project inputs: GitHub issues #1, #18, and #20; `CONTEXT.md`,
  `CONTRIBUTING.md`, repository issue/domain instructions; ADR-0002, 0005,
  0006, 0009, 0011, 0013, 0014, 0016, 0022, 0023, 0025, 0026, 0029, and
  0035; the accepted T13, T14, T15, T17, and T18 extraction, resource,
  publication, security, preservation, and borrowed-Canvas-Font seams; and
  pre-implementation fixed point
  `f18bc3fc495bf1357ccfd65318125c2e964b5814`.
- Public standards input: the Adobe-hosted authorized ISO 32000-1:2008 copy
  already inventoried by prior tickets, SHA-256
  `9de0ca9e8570d6209e8bd48a355be8eb6ec376acfc3fc3ae97cd8730351417ff`,
  supplied public Type 0 Font, CIDFontType2, Identity-H, width, embedded-font,
  subset-name, and ToUnicode concepts. Public OpenType specification tables
  supplied sfnt-directory, `head`, `hhea`, `maxp`, `hmtx`, `loca`, `glyf`,
  `name`, `post`, Unicode `cmap`, and OS/2 structure and embedding-permission
  semantics. These sources supplied specification
  semantics only and were not redistributed; no standards-conformance claim
  is inferred.
- Backend inputs: existing Apache PDFBox and FontBox 3.0.8 public loading,
  TrueType parsing, subsetting, COS, content-stream, and save APIs remain
  private implementation/secondary-evidence surfaces. No backend type,
  provider exception, resource name, serialization choice, or renderer output
  defines Native Interface semantics, and T19 introduces no dependency.
- Project-authored fixtures: consumer tests and repository-only Acceptance
  Evidence use `FolioPrimary.ttf` (972 bytes, SHA-256
  `e2fbb634c3c0fe78efb449bde4426d10a93aa813596ff5cf3360f02ec97673fb`)
  and `FolioFallback.ttf` (1,028 bytes, SHA-256
  `ced760bc126036779fa84ad3da4638733032512457bf599c44d8c455360f75e1`).
  The project generated these minimal Apache-2.0 TrueType programs from
  declared tables, mappings, and metrics; their scoped READMEs record origin,
  license, contents, and hashes. They are test/evidence data only and are
  absent from the `pdf-document` main resources and published artifacts.
- Output validation and evidence boundary: public workflows create, publish,
  reopen, and query every product. T13/T14 observations prove explicit source
  text, mapping confidence, geometry, embedded subset resources, identity,
  page usage, and bounded public-object font/ToUnicode details. The repository
  acceptance command sends the unchanged ID-neutral-hashed T19 artifact to
  pinned qpdf 12.4.0 and PDFium v0.11.2/Chromium 7881; ImageMagick 7.1.2-30
  compares validated fixed-size PNGs only. The project-owned expected raster
  is the visually reviewed 144-DPI PDFium baseline, SHA-256
  `d5a0c880a7a58bd0de6a1b7e887b6fe6b5a73f14608355434ee8cf022eb04a31`.
  Expected comparison requires AE 0; secondary PDFBox Renderer disagreement
  must not exceed AE 2,500 and can never make the chain pass. Repeat-run tests
  require identical records, findings, ID-neutral artifact hashes, and raster
  hashes.
- Generated documentation: `docs/generated/capability-matrix.md` and
  `docs/generated/facade-surface.md` are deterministic renderings of the YAML
  authorities and contain no copied external content.
- Excluded inputs: no iText source, resource, fixture, binary, output,
  decompiled or binary-derived implementation detail, closed add-on material,
  proprietary differential evidence, unauthorized black-box observation,
  downloaded font/PDF, installed-font scan, implicit network lookup, native
  shaping library, or Reference Suite behavioral oracle was used.
- Scope: T19 adds bounded explicit byte/path/stream/channel font sources, an
  ordered configured Reference Font Set, a closed TrueType version-1 profile,
  embedding-permission enforcement, deterministic Unicode glyph fallback,
  horizontal metrics, subsetting or documented full embedding, ToUnicode,
  resource reuse, positioned Unicode text, stable failures, and public
  semantic/syntax/visual evidence. It preserves the existing borrowed Canvas
  Font path and adds no T20 hostile-input policy, T21 Worker isolation, T23
  runtime rendering, T24 layout, T28 shaping, T29 HarfBuzz, T33 Asian resource
  profile, Migration Facade surface, backend SPI, system-font acquisition, or
  product-bundled font.
- Compatibility Curator evidence: none; the role remains vacant. T19 has
  passing syntax, project-owned semantic, and independent visual chains, but
  mandatory standards evidence remains absent. Its T13, T14, and T17
  compatible-status Dependency Gates and T06 Promotion Gate remain open. T19
  therefore remains `experimental` with no compatible or certified-platform
  claim.

## T20 trusted-in-process hostile-input-policy record

- Authorship: OpenAI Codex generated and integrated the T20 implementation,
  tests, inventories, evidence record, and documentation at repository
  operator MaBaiqiu's direction. No T20 commit was created or authorized in
  this execution.
- Project inputs: GitHub issues #1 and #21; `CONTEXT.md`, `CONTRIBUTING.md`,
  repository issue/domain instructions; ADR-0013, 0016, 0018, 0019, 0025,
  0031, and 0033; the accepted T03 and T09 transaction, ownership, publication,
  PDF Value, and failure seams; existing operation-local limit contracts; and
  pre-implementation fixed point
  `854fa233b16abf76afcc57ee99c374c2c78f0bd1`.
- Public standards input: the Adobe-hosted authorized ISO 32000-1:2008 copy
  already inventoried by prior tickets, SHA-256
  `9de0ca9e8570d6209e8bd48a355be8eb6ec376acfc3fc3ae97cd8730351417ff`,
  supplied public document, indirect-object, container, page-tree, stream-
  filter, and Image XObject concepts. It was not redistributed and supplied
  specification semantics only; no standards-conformance claim is inferred.
- Backend and platform inputs: existing Apache PDFBox 3.0.8 public loading,
  COS, filter, stream-cache, scratch-file, save, and split APIs remain private
  implementation surfaces. Java 8 `Clock`, `Duration`, NIO storage, streams,
  channels, synchronization, and POSIX permission APIs supply platform
  contracts. T20 adds no dependency; all existing coordinates, roles, and
  licenses remain recorded in [DEPENDENCIES.md](DEPENDENCIES.md).
- Project-authored fixtures: `HostileInputWorkflowTest` constructs every PDF
  byte sequence in memory and supplies deterministic clocks, bounded and
  cancelling streams, cancelling outputs, and latch-controlled workflows.
  Its files live only in temporary test directories. The updated snapshot-
  permission regression inspects only files created beneath the current test
  process's temporary directory. No external PDF, image, font, hostile-input
  corpus, system file, or Reference Suite output is included.
- Accounting and storage boundary: every Source is copied through actual-byte
  accounting before PDFBox opens it; iterative parsed-graph preflight accounts
  valid pages, objects, nesting, supported filter output, and materializable
  image dimensions. PDFBox cache is temp-only under the environment-owned
  transaction root. Source snapshots, filter spill, staged products, and
  target-adjacent commit files share one quota and cleanup lifecycle. The
  owned-memory policy models integrated Folio byte lifetimes and makes no
  JVM-wide or backend-allocation hard-limit claim.
- Generated documentation: `docs/generated/capability-matrix.md` and
  `docs/generated/facade-surface.md` are regenerated deterministically from
  the two YAML authorities and contain no copied external content.
- Excluded inputs: no iText source, resource, fixture, binary, output,
  decompiled or binary-derived implementation detail, closed add-on material,
  proprietary differential evidence, unauthorized black-box observation,
  downloaded hostile document, or Reference Suite behavioral oracle was used.
- Scope: T20 adds only finite-default cooperative policy enforcement for the
  trusted in-process Document Workflow. It does not implement T21 Worker IPC,
  separate-process memory/CPU/time/filesystem/network isolation, hard
  termination, T23 rendering, OCR, LibreOffice, redaction, Migration Facade
  surface, or a new product module, and it makes no global publication-
  atomicity or physical secure-erasure claim.
- Compatibility Curator evidence: none; the role remains vacant. All four
  mandatory Acceptance Evidence chains are absent, the T03 and T09 compatible-
  status Dependency Gates remain open, and T06 remains a Promotion Gate. T20
  therefore remains `experimental` with no compatible or certified-platform
  claim.

## T21 hardened-worker record

- Authorship: OpenAI Codex generated and integrated the T21 implementation,
  tests, inventories, evidence record, and documentation at repository
  operator MaBaiqiu's direction. No T21 commit was created or authorized in
  this execution.
- Project inputs: GitHub issues #1 and #22; `CONTEXT.md`, `CONTRIBUTING.md`,
  repository issue/domain instructions; ADR-0013, 0016, 0018, 0024, 0025,
  and 0031; the accepted T03 callback, ordering, lifecycle, ownership,
  publication, result, receipt, progress, and failure seams; the T20 resource
  and temporary-root contract; the complete library-owned Command and Query
  set accepted by `PdfBoxDocumentSession`; and pre-implementation fixed point
  `5d5cb89f8d25f7ad55a77560f2402a5d93d90065`.
- Public platform inputs: Java SE 8 process, stream, NIO, permissions,
  `SecurityManager`, HMAC-SHA-256, `SecureRandom`, concurrency, duration, and
  resource-ownership contracts plus the Linux `/usr/bin/prlimit` CPU and open-
  file resource controls supplied public interface semantics. These were
  platform contracts only; no external Worker implementation, IPC protocol,
  sandbox profile, fixture, product, or output was used as a behavioral
  oracle.
- Backend and dependency inputs: existing Apache PDFBox 3.0.8 public loading,
  COS, command/query, cache, validation, and save APIs remain private Worker
  implementation surfaces. T21 adds no dependency or product module. Its
  launcher treats the complete-byte SHA-256 values of the four required JARs
  and six optional TIFF-closure JARs as the exact runtime authority; their
  coordinates, roles, hashes, notices, and licenses are recorded in
  [DEPENDENCIES.md](DEPENDENCIES.md).
- Project-authored fixtures: workflow tests construct blank and minimal PDF
  inputs through project APIs or fixed in-memory bytes and use only temporary
  directories, service-free local INET and Unix-domain socket attempts,
  sentinel Target bytes,
  deterministic authentication keys at the package-private protocol seam,
  malformed project-authored frames, distinct marker bytes in concurrently
  live transaction roots, the existing project-authored Apache-2.0 T19 font
  fixture, clocks, tokens, callbacks, and latches.
  No external PDF, hostile corpus, font, network service, system document,
  Reference Suite output, or secret credential is included.
- Protocol and isolation boundary: version-1 framing, opcodes, Command/Query/
  value codecs, HMAC tags, sequence rules, and safe failure mapping are
  project-authored. Each execution creates a fresh key and owner-restricted
  random root, stages the primary Source before launch, requests other named
  Sources one at a time in declaration order under T20 accounting, and resolves
  reusable or explicit fonts lazily at their selecting Command. Commands carry
  opaque font-source identifiers; each program is requested in order and sent
  in a separate bounded frame under the same font-source limits. Eligible
  fixed-size page-structure batches use a memory-negotiated atomic frame only
  when the full encoder, retained/cross-process payload, and completion-control
  peak fits; other, parent-ineligible, or Worker-deferred batches use
  one authenticated count declaration followed by Worker-requested indexed
  preflights, details, and items so later inputs remain unmaterialized after the
  first failure. The launcher clears the child
  environment, restricts the Worker class path to digest-pinned first-party
  class-name inventories and exact-hash dependency JARs, and rejects mixed,
  incomplete, extended, delimiter-bearing, or wildcard-bearing entries before
  launch. It runs one local Worker under heap, direct-memory, stack, CPU, and
  descriptor bounds; denies INET and Unix-domain network, descendant process,
  link, and outside-root filesystem access; samples the environment Clock only
  on the caller thread; and applies a monotonic hard Worker-lifetime watchdog.
  Transport-buffer owned-memory accounting remains in the parent's synchronized
  transaction ledger without evaluating caller time policy on its reader
  thread. The parent retains
  callbacks, Providers, actual Targets, and publication and confirms Worker
  exit before committing a product.
- Generated documentation: `docs/generated/capability-matrix.md` and
  `docs/generated/facade-surface.md` are regenerated deterministically from
  the two YAML authorities and contain no copied external content.
- Clean-room and excluded inputs: no iText source, resource, fixture, binary,
  output, decompiled or binary-derived implementation detail, proprietary
  differential evidence, closed add-on material, unauthorized black-box
  observation, third-party protocol or sandbox configuration, downloaded
  hostile input, or Reference Suite behavioral oracle was used. The public
  Reference Suite is not an implementation oracle and no Reference Suite
  Worker API or output defines Native Interface behavior.
- Scope: T21 adds only the opt-in local Hardened Worker profile for the fixed-
  point Document Workflow contract, including authenticated bounded framing,
  closed codecs, a caller-side proxy Session, parent-side Provider and
  publication brokerage, private staging, supported Linux/JDK resource and
  permission controls, hard Worker termination, cleanup, stable failures, and
  implementation evidence. It adds no remote Worker, arbitrary extension,
  public backend SPI, renderer, new Migration Facade surface, idempotent
  transaction identity, retry or uncertain-publication recovery, large-value
  chunking/staging protocol, 5,000-page or 1-GiB certification, full RSS or
  kernel-container guarantee, physical secure-erasure claim, or downstream
  T22-and-later behavior.
- Compatibility Curator evidence: none; the role remains vacant. All four
  mandatory Acceptance Evidence chains are absent, the T03 and T20 compatible-
  status Dependency Gates remain open, and T06 remains a Promotion Gate. T21
  therefore remains `experimental` with no compatible or certified-platform
  claim.

## T22 worker-recovery-scale record

- Authorship: OpenAI Codex generated and integrated the T22 implementation,
  tests, controlled profiles, inventories, evidence record, domain decision,
  and documentation at repository operator MaBaiqiu's direction. No T22 commit
  was created or authorized in this execution.
- Project inputs: GitHub issues #1 and #23; `CONTEXT.md`, `CONTRIBUTING.md`,
  repository issue/domain instructions; ADR-0013, 0016, 0018, 0023, 0024,
  0025, and 0031; the accepted T03 transaction, ownership, publication,
  receipt, outcome, failure, and callback seams; the T20 resource policy and
  accounting model; the T21 Worker, closed protocol, process isolation,
  classpath authority, parent-side publication, and cleanup contract; and
  pre-implementation/code-review fixed point
  `7c12104960045f3069843f850c4e782cb4d63c77`.
- Public platform inputs: Java SE 8 object identity, weak-reference, digest,
  stream, NIO, duration, synchronization, concurrency, process, and resource-
  ownership contracts plus the existing Linux `/usr/bin/prlimit` execution
  envelope supplied public interface semantics. These were platform contracts
  only; no external idempotency implementation, retry protocol, IPC transfer
  format, scale product, fixture, output, or benchmark was used as a behavioral
  oracle.
- Backend and dependency inputs: existing Apache PDFBox 3.0.8 public loading,
  COS, validation, cache, save, and reopen APIs remain private Worker
  implementation surfaces. T22 adds no dependency, product module, shaded
  code, or redistributed artifact. Existing dependency coordinates, origins,
  licenses, notices, and exact Worker-runtime hashes remain authoritative in
  [DEPENDENCIES.md](DEPENDENCIES.md).
- Project-authored recovery fixtures: public tests use temporary Paths and
  byte/stream Targets, latches, cancellation tokens, short elapsed policies,
  safe callback exceptions that simulate lost caller acknowledgement, a
  caller-owned partial-failure stream, and bounded application transaction
  identifiers. They also use an oversized project-authored Target name under a
  512-byte modeled per-record retention policy and reconstructed equal and
  unequal byte-source declarations. The lower-level fault seam only terminates the real project
  Worker or emits a project-authored authenticated malformed response. No
  external PDF, service, database, durable recovery system, hostile corpus,
  credential, authentication key, or Reference Suite output is included.
- Project-authored transfer fixtures: the multi-frame declaration and chunk
  format, transfer identity, total-length/chunk-count rules, SHA-256 integrity,
  aggregate payload-plus-frame memory admission, and stable failure mappings
  are project-authored. Hostile boundary tests synthesize missing, reordered,
  duplicate, corrupted, wrong-identity, wrong-length, wrong-digest, and excess
  frames with deterministic package-private keys, including an authenticated
  trailing chunk presented while less than one frame of modeled scratch is
  available. Public workflow tests create
  4-KiB metadata against a 2-KiB physical-message bound and validate it only
  through publish/reopen semantics.
- Project-authored scale fixtures: the 5,000-page profile constructs 5,000
  `AddBlankPage` commands through the public API. The exact 1-GiB profile uses
  a constant-memory clean-room InputStream that emits a short PDF header,
  newline fill, and a hand-authored valid one-page indirect-object/xref tail at
  byte 1,073,741,824. The concurrency profile uses two latch-held public
  workflows and one first-excess request. Every product and transaction root
  exists only beneath a test temporary directory and is removed; no large
  fixture or product is committed.
- Controlled observations: on 2026-09-04, Linux 6.8.0-136-generic amd64 and
  GraalVM Community Java 17.0.9 completed the opt-in page, input, and
  concurrency profiles. Their exact construction, complete policy, modeled
  memory and temporary-storage high-water marks, accounted elapsed time, wall
  time, and concurrency are recorded in
  [the T22 evidence record](capabilities/evidence/T22-worker-recovery-scale.md).
  These are implementation observations, not independent evidence, a
  benchmark, whole-process measurement, or certified-platform result.
- Generated documentation: `docs/generated/capability-matrix.md` and
  `docs/generated/facade-surface.md` are regenerated deterministically from
  the two YAML authorities and contain no copied external content. The exact
  first-party Worker inventory remains generated from project production
  classes and adds no artifact or external source.
- Clean-room and excluded inputs: no iText source, binary, resource, fixture,
  output, decompiled or binary-derived detail, closed add-on material,
  proprietary differential evidence, unauthorized black-box observation,
  downloaded large document, third-party recovery/transfer protocol, external
  scale corpus, or Reference Suite behavioral oracle was used. qpdf was
  already present locally, while PDFium and ImageMagick were absent from their
  documented cache paths; no external evidence tool was downloaded,
  provisioned, or used to convert an incomplete T22 evidence chain into a
  pass.
- Scope: T22 adds optional environment-local finite idempotency state and
  lookup, deterministic recoverable/final classification, no-replay Path and
  stream uncertainty semantics, bounded authenticated large-value chunking,
  authenticated public resource observations, and opt-in generated controlled
  scale profiles. It adds no remote Worker, durable or distributed recovery,
  automatic retry service, renderer, downstream-ticket behavior, public
  backend SPI, arbitrary extension mechanism, Migration Facade surface,
  dependency, product module, cross-Target atomicity, whole-process RSS/native-
  memory guarantee, kernel-container certification, or physical secure-
  erasure claim.
- Compatibility Curator evidence: none; the role remains vacant. The T22
  syntax, standards, semantic, and visual chains are `INDETERMINATE`; project-
  authored contracts and controlled observations are implementation evidence
  only. The T21 compatible-status Dependency Gate and T06 Promotion Gate
  remain open. T22 therefore remains `experimental` with no compatible or
  certified-platform claim.

## T23 bounded-rendering record

- Authorship: OpenAI Codex authored this contribution at the repository
  operator's direction. The work is an uncommitted implementation of #24;
  no DCO sign-off or commit has been created.
- Requirements and permitted references: GitHub #24 and parent #1, the
  repository instructions, CONTEXT.md, applicable ADRs, the existing T05
  Provider, T20 resource, T21/T22 Worker, T18 image/color, T19 font, and
  acceptance contracts, plus existing public workflow tests and fixtures.
- Backend reference: the existing Apache-2.0 PDFBox 3.0.8 source archive and
  official tagged [PDFRenderer.java](https://raw.githubusercontent.com/apache/pdfbox/3.0.8/pdfbox/src/main/java/org/apache/pdfbox/rendering/PDFRenderer.java),
  [PageDrawer.java](https://raw.githubusercontent.com/apache/pdfbox/3.0.8/pdfbox/src/main/java/org/apache/pdfbox/rendering/PageDrawer.java),
  PDFStreamEngine, PDFGraphicsStreamEngine, FontMappers, and FontMapperImpl
  were inspected to check geometry, cooperative operator hooks, existing
  annotation appearance behavior, font fallback, and image-codec boundaries.
  The integration calls/subclasses the approved private dependency; it copies
  no backend implementation into the public interface. Existing coordinates,
  licenses, artifact hashes, and notices remain in DEPENDENCIES.md.
- Public implementation and protocol: requests/results, numeric profile,
  fixed PNG assembly using JDK Deflater/CRC32, Provider FRQ1/FRS1 envelopes,
  enum diagnostics, result lifetime, bounded Worker values, and shared live
  temporary-storage grants are project-authored. Bounded ImageIO header reads
  verify terminal JPEG/JPX/JBIG2 dimensions before platform decoding. Java 8
  JDK APIs and the existing project codecs supply the foundations. No new production or Maven
  dependency, font, codec bundle, module, or public backend SPI is added.
- Test fixtures: the public Rendering suite authors small PDF object/xref
  documents, axis-aligned colors, normal/missing annotation appearances,
  explicit half alpha, a referenced nonembedded standard font for diagnostic
  behavior, and deterministic seeded raw image samples. These project-authored
  Apache-2.0 fixtures are generated in test memory and never use another
  implementation's output as the public-test oracle. Temporary files,
  failure streams, clocks, and Providers are also project-authored. Runtime
  system-font substitution is tested only for diagnostics, not compatibility.
- Independent visual inputs: the base T23 PDF is created through public
  Commands and contains red page content and a resource-free green stamp
  appearance. Its analytical expected raster is reproducible with
  [generate-t23-expected.py](scripts/generate-t23-expected.py), authored with
  already installed Pillow 10.2.0 (HPND license) as an offline fixture tool
  outside Maven and published artifacts. The expected SHA-256 is
  `ba2aa587629d5e67d7659ca3ac34933fb15e7d9fdff0fa76976f1aceebc6a4e9`.
  The image and font profiles reuse the existing project-owned T18/T19
  acceptance products and expected rasters unchanged. Their origins and
  licenses remain covered by the T18/T19 records and the
  [font fixture authority](pdf-document/src/test/resources/net/zerocloud/pdf/fixtures/README.md).
  The font profile uses only the two embedded project subsets with their
  pinned source hashes, never an installed font as evidence.
- Evidence tools: already provisioned, hash-checked qpdf 12.4.0, pdfium-cli
  v0.11.2 / PDFium chromium-7881, and ImageMagick 7.1.2-30 ran offline on
  2026-09-05. Exact distribution/component hashes, licenses, and notices remain
  in scripts/*-pin.properties and capabilities/README.md. The public
  RenderPage/RenderedPage implementation is under test; the acceptance-only
  ImplementationRenderer is not the T23 implementation. Raw command results,
  both renderer PNGs, expected PNGs, difference PNGs, input hashes, and fixed
  profiles are retained under capabilities/evidence and capabilities/profiles.
  Initial annotation disagreement was resolved by adding the documented
  PDFium --render-annotations option; no threshold was relaxed. The existing
  T18 JPEG produces the pinned PLATFORM_IMAGE_CODEC diagnostic.
- Inventory/documents: the two YAML authorities, their generated Markdown,
  Worker class inventory/hash, English contract, and Chinese usage guide
  describe this scoped behavior. Required independent standards and formal
  semantic evidence, compatible prerequisites, and promotion/platform gates
  remain open. The capability remains experimental.
- Clean-room statement: no iText source, binary-derived implementation,
  proprietary add-on material, restricted fixture, Reference Suite output,
  external hostile corpus, or Compatibility Curator evidence was used. No
  implicit network/font download or external evidence-tool installation was
  performed. The Compatibility Curator role remains vacant.

## T24 paragraph-composition record

- Author: OpenAI Codex acting on the user's issue #25 implementation request.
  The initial delivery was reviewed as uncommitted changes. The user subsequently
  authorized a commit with DCO sign-off using the repository's configured Git
  identity, a GitHub push, and closure of issue #25.
- References: GitHub issues #25 and #1, the supplied goal text, AGENTS.md,
  CONTRIBUTING.md, CONTEXT.md, the listed Composition/Workflow ADRs, existing
  T17/T18 Canvas, T19 font, T20 resource and Worker code and public-workflow
  tests, and the repository's acceptance/inventory/font documentation. Public
  PDF/OpenType foundations remain those recorded for T17/T18/T19. No new
  third-party source, fixture, font, resource or dependency was introduced.
- Code: the paragraph, flow, page, margin and limit declarations, deterministic
  wrapping and area progression, font-measurement integration, detached page
  painting, Worker codecs/catalogs and T24 tests were authored for this project
  under Apache-2.0. No backend SPI or placeholder module was added. Java 8 and
  the locked dependency versions are retained.
- Fonts: the existing Apache-2.0 project-authored FolioPrimary and FolioFallback
  fixtures have decoded SHA-256
  `e2fbb634c3c0fe78efb449bde4426d10a93aa813596ff5cf3360f02ec97673fb` and
  `ced760bc126036779fa84ad3da4638733032512457bf599c44d8c455360f75e1`.
  Tests and acceptance verify these hashes. These are test data, not a runtime
  font bundle, Foundation Noto profile or installed-font dependency.
- Graphics and expectations: the blue unit-square group, corpus, hand-calculated
  placements and reference PDF are project-authored Apache-2.0 data.
  `T24ParagraphExpectations` is independent of the layout algorithm.
  `T24ParagraphProducts.createReference` positions that oracle through existing
  Canvas/T19 commands and never calls paragraph composition. Expected PNGs
  were rendered from this reference using pinned PDFium and visually inspected
  on 2026-09-05; a T24-produced raster was not adopted as its own golden. Hashes
  and regeneration inputs are in the T24 profile/evidence. All new PDF, PNG and
  text evidence is project data under Apache-2.0.
- Tools: existing offline hash-verified qpdf 12.4.0, pdfium-cli v0.11.2 / PDFium
  chromium-7881 and ImageMagick 7.1.2-30. Distribution, executable, component and
  license authorities remain `scripts/*-pin.properties` and `docs/third-party/`.
  No tool or font download occurred. PDFBox is secondary disagreement evidence,
  not the independent visual oracle.
- Clean-room exposure: the implementing assistant did not access iText source,
  resources, binary-derived implementation, closed add-on information or curator
  black-box output during this work. Missing standards evidence, open Dependency
  Gates and lack of Foundation compatibility certification remain explicit.

Future changes append or update a scoped record and supply the pull-request
provenance statement required by [CONTRIBUTING.md](CONTRIBUTING.md).


## T25 advanced-paragraph-pagination record

- Author: OpenAI Codex acting on the user's issue #26 implementation goal.
  The implementation was verified and reviewed as an uncommitted working tree.
  The user subsequently authorized a DCO-signed commit, a GitHub push and closure
  of issue #26.
- References: the complete public GitHub issues #26 and #1 and their comments,
  closed prerequisite #25, the user-supplied goal attachment, AGENTS.md,
  CONTRIBUTING.md, CONTEXT.md, docs/agents/{issue-tracker,domain}.md and ADRs
  0009, 0013, 0022, 0023, 0024, 0025 and 0029. Implementation references are
  this repository's T24 paragraph declarations/layout, T19 explicit fonts,
  T17/T18 Canvas, page operations, workflow resource/lifecycle/publication
  contracts, Worker codecs/catalogs/class-inventory checks, and T24 independent
  acceptance infrastructure. Public PDF/OpenType foundations remain the
  previously recorded T17/T18/T19 sources. No new runtime dependency was
  introduced; additional acceptance-tool references are recorded below.
- Code: version 2 declarations, explicit tab stops and hard pagination search,
  bounded buffered relayout/flush, page-tail replacement, Worker transport and
  its closed outcome/failure vocabulary, public behavior tests and the T25
  acceptance producer were authored for this Apache-2.0 project. Java 8 and
  the existing locked dependencies remain in force. No table, Unicode layout,
  shaping, backend SPI, runtime font bundle or Migration Facade stub is added.
- Resources: the existing project-authored Apache-2.0 FolioPrimary and
  FolioFallback fonts are reused without modification. Their SHA-256 values are
  `e2fbb634c3c0fe78efb449bde4426d10a93aa813596ff5cf3360f02ec97673fb`
  and `ced760bc126036779fa84ad3da4638733032512457bf599c44d8c455360f75e1`.
  Signature/password test inputs reuse project-owned generators. There are no
  new downloaded fixtures, system fonts, online font inputs or third-party
  resources. Newly added PDF, PNG, Markdown, text and properties artifacts are
  generated from project-owned declarations under Apache-2.0.
- Oracle: `T25ParagraphExpectations` pins numeric coordinates, character widths,
  page counts and order independently of the layout implementation. Each of
  the twelve reference PDFs uses only `AddBlankPage` and the existing T19
  positioned-text command. Its expected PNGs were rendered on 2026-09-05 with
  the already pinned independent PDFium CLI v0.11.2 / Chromium 7881 at 144 DPI,
  opaque white sRGB. Expected hashes, zero-fuzz AE 0 and the secondary-renderer
  threshold of 2500 were fixed before rendering T25 paragraph products. No
  actual paragraph raster was used as its own oracle, and no threshold was
  widened to admit observed output. Negative tests move or remove text and
  prove that each independent semantic observer rejects the mutation.
- Tool provenance: qpdf 12.4.0, PDFium and ImageMagick 7.1.2-30 retain the
  existing scripts/*-pin.properties authorities and third-party notices. These
  are isolated acceptance tools and never production runtime dependencies.
- Clean-room statement: this contribution does not copy/adapt iText source,
  resources, fixtures, binary-derived implementation details or closed add-on
  material, and no such material was accessed in this execution. Issue/API
  inventory names are capability descriptions, not correctness goldens.
  Standards evidence, compatibility Dependency Gates and all required
  Foundation font/platform certifications remain open.
- Additional acceptance-tool references: the public ImageMagick CLI documentation
  at https://imagemagick.org/compare/ and the permissively licensed tagged
  ImageMagick 7.1.2-30 files `MagickWand/compare.c` and `MagickCore/compare.c`
  at https://github.com/ImageMagick/ImageMagick/tree/7.1.2-30 were inspected to
  explain the actual comparator's nonzero AE with exit status 0. The tagged
  command computes status from normalized distortion with a 1e-6 cutoff; its
  printed AE is scaled by raster area. The recorder preserves the measured
  value for the unchanged profile thresholds, and T25 additionally checks exact
  changed RGB pixel counts. The two new acceptance regressions prove that a
  tiny nonzero primary metric still fails AE 0 and that a usable secondary
  result does not become INDETERMINATE merely because of the tool's exit cutoff.
  No ImageMagick implementation code was copied. The existing tool license and
  pinned distribution are unchanged.

## T26 bounded-table-composition record

- Authorship: OpenAI Codex, implementing the user's approved issue-27 goal in
  this repository. The implementation was verified and reviewed as an
  uncommitted working tree. The user subsequently authorized a DCO-signed
  commit using the repository's configured Git identity, a GitHub push and
  closure of issue #27 after repairing the failing GitHub Actions checks.
- References: public GitHub issues 27, 1, 25 and 28 and their comments; AGENTS.md,
  CONTRIBUTING.md, CONTEXT.md and ADR-0009/0010/0013/0020/0022/0023/0026/0029;
  existing T24/T25 paragraph, T19 explicit-font, Canvas, transactional Workflow,
  Worker resource/codec/catalog and independent acceptance implementations.
  Public PDF/OpenType foundations retain the previously recorded T17/T18/T19
  references. No iText implementation or output was accessed.
- Code: immutable table/row/cell/width/padding/border/limit declarations,
  deterministic interval column solving and span geometry, mixed-flow
  integration, Worker transport and public behavior/acceptance tests were
  authored for this Apache-2.0 project. No dependency was added or upgraded;
  Java 8 and existing backend isolation remain in force.
- Resources: existing Apache-2.0 project-authored FolioPrimary and FolioFallback
  are reused unchanged, with SHA-256
  `e2fbb634c3c0fe78efb449bde4426d10a93aa813596ff5cf3360f02ec97673fb` and
  `ced760bc126036779fa84ad3da4638733032512457bf599c44d8c455360f75e1`.
  Signature and password fixtures reuse project-owned generators. New PDFs,
  PNGs, Markdown, properties and text records derive solely from project-owned
  declarations under Apache-2.0. No system/online font or third-party fixture
  was introduced.
- Oracle: docs/table-composition.md fixed numeric examples before implementation.
  T26TableExpectations translates those coordinates onto the acceptance pages;
  its reference producer uses AddBlankPage, T19 positioned text and Canvas only.
  On 2026-09-05, the already pinned PDFium CLI v0.11.2 / Chromium 7881 rendered
  that independent reference at 144 DPI, opaque-white sRGB. Coordinates,
  zero-fuzz AE 0 and secondary changed-pixel bound 2500 preceded actual table
  rendering. Expected PNG hashes are recorded in the three T26 profiles. No
  threshold was widened and no table output was used as its own golden.
- Tools: the existing qpdf 12.4.0, PDFium and ImageMagick 7.1.2-30 pins and
  third-party notices are unchanged. Acceptance tools stay outside production
  runtime; the additional exact changed-pixel check reuses the T25 recorder.
- Clean-room statement: no iText source, resources, binary-derived details or
  non-public/closed add-on material was read, copied, adapted or reverse
  engineered for this work. Reference Suite names identify inventory scope,
  never a correctness golden. Standards, dependency compatibility and
  Foundation font/platform certification remain open.

## T27 table-pagination implementation record

- Authorship: OpenAI Codex implementing the user's issue-28 execution contract
  as an uncommitted diff based on
  `1d1bf4a92eecf42dc370872fe1bcf5b142e42452`. Full verification and separate
  independent Standards/Spec reviews are complete. The user subsequently
  authorized committing the reviewed changes, pushing them to GitHub and
  closing issue #28. Publication uses the repository's configured Git identity
  and required DCO sign-off. This scoped delivery does not establish Foundation
  compatibility.
- References: public GitHub issues 28 and 1, prerequisite issues 26 and 27,
  including their comments; AGENTS.md, CONTRIBUTING.md, CONTEXT.md,
  docs/agents, and ADR-0002/0006/0009/0013/0018/0022/0023/0024/0025/0026/0029;
  the existing project T24/T25/T26 Composition, T19 fonts, Canvas, Workflow,
  Worker resource/transport and independent acceptance code and contracts.
  The public [iText 7.2.6 Table API](https://api.itextpdf.com/iText/java/7.2.6/com/itextpdf/layout/element/Table.html)
  supplies fixed-reference facts about fixed large-table layout, retained
  table width, repeated headers/footers, flush and complete. Its implementation
  and output were not consulted.
- New code and declarations: project-owned versioned pagination and tests;
  no dependency addition or upgrade, public backend SPI, module restructuring
  or Migration Facade stub. Java 8 and backend isolation remain constraints.
- Resources: unchanged Apache-2.0 project-authored T19 FolioPrimary and
  FolioFallback with SHA-256
  `e2fbb634c3c0fe78efb449bde4426d10a93aa813596ff5cf3360f02ec97673fb` and
  `ced760bc126036779fa84ad3da4638733032512457bf599c44d8c455360f75e1`.
  New input declarations, tests and numeric examples are authored for this
  Apache-2.0 project. No system font, online font or third-party fixture is
  introduced. The retained-graphics regression generates its own 512x512
  grayscale samples and nested unit-square groups in Java; no image asset,
  encoded third-party resource or external fixture was added.
- Oracle: docs/table-pagination.md fixes numerical examples and geometry /
  raster thresholds before paginator implementation. T27TableExpectations
  independently declares all scalar and border coordinates for nineteen pages.
  T27TableProducts creates the reference with AddBlankPage, positioned T19
  text and Canvas rectangles only; that path invokes no paragraph/table layout
  or incremental table Commands. The nineteen new Apache-2.0 expected PNGs in
  capabilities/expected were rendered from that reference with pinned PDFium
  CLI v0.11.2 / chromium-7881 and visually inspected before actual-product
  comparison. Their SHA-256 values are fixed in the nineteen T27 visual
  profiles. No actual paginator output generated its own correctness golden.
  The recorder and public semantic observer extend the project-owned T26
  evidence pattern; missing text, wrong repetition and a one-point movement
  are independently authored negative controls. Existing qpdf 12.4.0 and
  ImageMagick 7.1.2-30 pins and licenses are unchanged.
- Clean-room statement: no iText source, resources, binary-derived details,
  non-public implementation details or closed add-on material was accessed,
  copied, adapted or reverse engineered for T27. Separate standards evidence,
  dependency compatibility and Foundation font/platform gates remain open.

## CI cold-font-discovery and Worker-stop record

- Authorship: OpenAI Codex at repository operator MaBaiqiu's direction. The
  user authorized fixing GitHub Actions, committing with the configured real
  Git identity and DCO sign-off, pushing GitHub, and closing #27 after CI passes.
- References: CI run 33957144822 on aac85eb, existing public rendering and real
  Worker tests, CONTEXT.md, ADR-0024/0025/0031, and the project-owned rendering
  log scope, Worker protocol and resource-failure implementations.
- Backend references: the locally resolved official Apache PDFBox and FontBox
  3.0.8 source artifacts, specifically FileSystemFontProvider, TTFParser,
  FontFileFinder and UnixFontDirFinder, were inspected to distinguish a skipped
  installed-font discovery warning from a page rendering failure. These
  dependencies retain their recorded Apache-2.0 licenses and pinned versions;
  no dependency implementation was copied or adapted.
- Fixtures: the cold-start test authors a 12-byte sfnt header with no font
  tables inside an isolated temporary home. It reuses the project's existing
  public Workflow rendering, privacy and missing-resource assertions. No
  external font or new dependency is added. Existing installed NotoColorEmoji
  triggered the original local reproduction; its bytes are not retained and
  its rendering is not used as compatibility evidence.
- The fixes and regression tests are original contributions to this Apache-2.0
  project. No iText source, non-public implementation, closed add-on material
  or restricted fixture was accessed.

## T28 unicode-composition record

- Authorship: original implementation, public contract tests, offline reference
  tooling and documentation authored by OpenAI Codex at the user's direction
  on 2026-09-06. The review fixed point is
  `875c140fc4617f8a9649f1c9bed8034c52bd6dfa`. The initial delivery was verified
  and independently reviewed as an uncommitted working tree. The user
  subsequently authorized a DCO-signed commit, pushing it to GitHub and
  closing issue #29 after the push. Publication uses the repository's
  configured Git identity.
- Scope and architectural inputs: issue #29 and its parent #1; the existing
  project-owned T19 font, T24/T25 paragraph, T26/T27 table, Workflow and Worker
  contracts; CONTRIBUTING, CONTEXT and ADR-0010/0022/0023/0026. No new module,
  backend SPI, Facade stub, HarfBuzz adapter, Asian resource product or
  Foundation platform certification is claimed.
- Unicode authority: Unicode 16
  [UAX #9 revision 50](https://www.unicode.org/reports/tr9/tr9-50.html),
  [UAX #14 revision 53](https://www.unicode.org/reports/tr14/tr14-53.html),
  [UAX #24 revision 38](https://www.unicode.org/reports/tr24/tr24-38.html),
  [UAX #29 revision 45](https://www.unicode.org/reports/tr29/tr29-45.html),
  and the [ICU boundary-analysis documentation](https://unicode-org.github.io/icu/userguide/boundaryanalysis/).
  ICU4J 77.1 is the only new product dependency. Its complete unbundled JAR,
  full SHA-256 and consolidated Unicode/third-party notices are recorded in
  [the dependency notice](docs/third-party/icu4j-77.1.md) and root NOTICE.
  Its responsibility is segmentation, script classification and bidi, not shaping.
- Font-format inputs: the public Microsoft OpenType TrueType, cmap, glyf,
  head, hhea, hmtx, loca, maxp, name, post and OS/2 specifications. In
  particular, the [loca specification](https://learn.microsoft.com/en-us/typography/opentype/spec/loca)
  defines long entries as actual byte offsets. Permissively licensed
  PDFBox/FontBox 3.0.8 parser, cmap and subsetter source/API behavior was
  inspected to establish safe supported format boundaries. No dependency
  source was copied into this implementation.
- Metadata accounting additionally uses the public OpenType
  [GSUB structures](https://learn.microsoft.com/en-us/typography/opentype/spec/gsub)
  and [common layout tables](https://learn.microsoft.com/en-us/typography/opentype/spec/chapter2).
  The pinned FontBox `GlyphSubstitutionTable`, `GlyphSubstitutionDataExtractor`
  and `Language` source artifacts were inspected to identify eagerly read data
  and object lifetimes. The original preflight bounds those records and counts
  parsed aliases and materialized maps without executing substitution. The
  new negative fixtures change only a GSUB version, lookup reference or glyph
  delta, or a vertical-metric count in a pinned Noto copy and repair ordinary
  sfnt checksums. The [vhea](https://learn.microsoft.com/en-us/typography/opentype/spec/vhea)
  and [vmtx](https://learn.microsoft.com/en-us/typography/opentype/spec/vmtx)
  specifications define the checked header/count/length relationship; pinned
  FontBox vertical-table readers establish the eager allocation boundary.
  Original font resources
  and independent expected data remain unchanged.
- Full fonts: Noto Sans Regular 2.008 and Noto Sans Hebrew Regular 3.000 are
  unchanged static files from notofonts/noto-fonts commit
  `ffebf8c1ee449e544955a7e813c54f9b73848eac`. CJK SC/TC/JP/KR are complete
  65,535-glyph Regular static instances of the regional TrueType variable
  sources from notofonts/noto-cjk Sans2.004, commit
  `523d033d6cb47f4a80c58a35753646f5c3608a78`. The offline fontTools 4.59.2
  recipe pins source/tool hashes, preserves source timestamps, sets only
  `wght=400` and updates names from source STAT metadata. It does not reduce
  coverage or strip tables to accommodate the validator. Original/final
  SHA-256 values, URLs, byte lengths, instance settings and both unchanged
  OFL-1.1 notices are retained with [the Noto resources](pdf-acceptance/src/main/resources/net/zerocloud/pdf/acceptance/fonts/noto/README.md).
  These files enter only acceptance and test resources, never default
  product runtime or system-font discovery.
- Test tooling: [fontTools 4.59.2](docs/third-party/fonttools-4.59.2.md) is a
  separately installed MIT-licensed Python tool, not a Maven dependency.
  Its wheel SHA-256 and both complete LICENSE files are retained. Source-pin
  rejection and full static generation have command-level Red/Green tests.
- Independent oracle: the short multilingual corpus, manual line lists and
  bidi display order are project-authored examples based on the Unicode
  rules. JDK java.text.Bidi/BreakIterator supplied independent cross-checks,
  without invoking ICU or Folio. Before executing the CJK punctuation probe,
  a transcription that incorrectly made the parenthesized phrase atomic was
  corrected using the legal offsets `0,1,2,4,6,7,9`. Source hmtx inspection
  also fixed each Jamo advance at 920 units, hence 22.08 points per two-scalar
  cluster. Neither correction used producer output or relaxed a threshold.
- The [raw reference writer](scripts/t28-unicode-reference.py) uses source
  cmap/head/hmtx values and fontTools subsets with retained original GIDs to
  write an independent seven-page PDF and tab-separated expected geometry.
  It performs no segmentation, bidi, shaping or Folio calls. Those artifacts,
  corpus and generation hashes are retained in acceptance resources. Pinned
  PDFium CLI v0.11.2 / chromium-7881 renders the reference to the seven expected
  PNGs. The 0.0001-point geometry tolerance, 144-DPI opaque-white sRGB policy,
  zero-fuzz primary AE/changed-pixel limit zero and secondary changed-pixel
  bound 12000 were fixed before implementation comparisons. qpdf 12.4.0 and
  ImageMagick 7.1.2-30 reuse the already-noticed repository tools.
- Public observations: all product contracts use DocumentWorkflow.execute,
  public Commands/Queries and published/reopened results. Independent
  negative artifacts are changed through DocumentPatch to split a cluster,
  reverse the Hebrew pair, substitute a different regional font resource or
  displace geometry by one point. The observer checks their independently
  declared text, original glyph IDs, font names and coordinates.
- No iText source, resource, fixture, binary-derived implementation detail,
  non-public or closed add-on material was accessed or used for T28. No
  Reference Suite output acts as the oracle. Full Foundation standards,
  dependency and required font/platform gates remain open; test results do
  not imply compatible status.

## T29 shaping contribution (in progress)

- Author: Codex, working from the user-provided #30 execution contract,
  public #30/#1 issue bodies and comments, and this repository's ADRs.
- Native reference: unchanged HarfBuzz 10.2.0 source archive and official
  public C buffer/shaping documentation. Its MIT-Old notice, source hash,
  explicit local build recipe and observed tool/library closure are retained
  in [the native dependency record](docs/third-party/harfbuzz-10.2.0.md).
- Fonts: complete static Noto Sans Arabic 2.009, Devanagari 2.002 and Thai
  2.000 from noto-fonts commit `ffebf8c1ee449e544955a7e813c54f9b73848eac`.
  These are copied without modification, retain the existing upstream OFL
  notice, and have individual URLs, hashes, lengths and glyph counts in the
  Noto resource manifests. Existing Sans/Hebrew reference resources are reused.
- The four short logical corpora and manual line/visual-run declarations are
  project-authored. Official `hb-shape` produced glyph IDs, clusters, advances
  and offsets before the product adapter or Composition shaping existed.
  The separate reference writer uses those results and already-pinned
  fontTools 4.59.2 subsets by glyph ID, reusing only T28's independent raw PDF
  object/xref writer. It never calls Folio, PDFBox, ICU or the project adapter.
- The reference generation CLI has recorded Red/Green tests for numeric/PDF
  output and independence from the native installation path. Fixed font-unit,
  geometry, pagination and visual tolerances are declared in
  [the T29 profile](capabilities/profiles/T29-shaping-reference.md) before
  comparing any implementation output.
- The project-owned explicit installation CLI consumes that pinned upstream
  archive without downloading or modifying it. Its Meson adapter build uses
  the public [executable/install-rpath](https://mesonbuild.com/Reference-manual_functions_executable.html)
  and [pkg-config](https://mesonbuild.com/Dependencies.html#pkg-config)
  contracts, consulted 2026-09-06. HarfBuzz 10.2.0's permissively licensed
  `meson.build` was read to establish why a disabled FreeType option still
  performs an optional pkg-config probe. The installer isolates that search
  and records actual build/source/tool/library hashes. No upstream build or
  engine implementation was copied into the project adapter.
- Linker provenance uses the compiler's public `-print-prog-name` query with
  effective `-B` and linker-selection options; the GCC
  [link options](https://gcc.gnu.org/onlinedocs/gcc/Link-Options.html) and
  [developer options](https://gcc.gnu.org/onlinedocs/gcc/Developer-Options.html)
  were consulted on 2026-09-06. The real Linux CLI regression copies the
  installed GNU linker only into a disposable fixture directory, changes its
  file identity with a trailing marker, and verifies the selected executable
  hash. No compiler/linker binary enters repository or product artifacts.
- The repository-only native observation CLI uses the documented Linux
  [procfs process mappings](https://docs.kernel.org/filesystems/proc.html),
  consulted 2026-09-06. It reads a real owned helper's startup mappings and
  compares installed and loaded-file hashes; no kernel implementation code
  was copied. Preload/audit interposition is not certified. The negative
  fixture temporarily copies the MIT-Old HarfBuzz engine and changes its ELF
  SONAME string to demonstrate that file-name selection cannot establish
  symbol ownership. This disposable copy is not distributed.
- The Java Provider, detached request/result types, parent/Worker shaping
  exchange, original-grapheme line refitting, shaped subset writer and owned
  plan lifetimes are project-authored extensions of the repository's existing
  Provider/font/ICU/Workflow seams. Direct positioned text remains unshaped.
  Public Workflow and reopened-output tests supply product observations;
  actual external helper tests supply the native protocol boundary. T29's
  independent qpdf/fontTools subset verifier compares glyph outlines and
  transitive composite dependencies with the pinned original fonts.
- Marked-content replacement text follows
  [ISO 32000-1 §14.9.4](https://opensource.adobe.com/dc-acrobat-sdk-docs/standards/pdfstandards/pdf/PDF32000_2008.pdf),
  cross-checked with the PDF Association's
  [published clause and errata](https://pdf-issues.pdfa.org/32000-2-2020/clause14.html)
  on 2026-09-06. It requires PDF 1.5; the public regression reuses the
  project-authored BMP-only T19 font and constructs a minimal older-version
  PDF from project-authored PDF object declarations. No external fixture or
  implementation is copied.
- The evidence entry adds T29 records to the existing repository-only Maven
  execution. The root test profile consumes only an explicitly supplied
  helper path; the Linux JDK matrix mounts the separate installation. Native
  libraries are absent from Maven artifacts. Capability/facade authorities
  retain experimental state and an explicit shaping mapping exclusion.
- The required JDK 8 regression gate exposed Worker heap exhaustion while
  loading full CJK fonts. Disposable diagnostic runs used OpenJDK 8's heap
  dump and jhat tools; the public
  [HPROF record format](https://github.com/openjdk/jdk8u/blob/master/hotspot/src/share/vm/services/heapDumper.cpp)
  was consulted on 2026-09-06 to hash the captured font arrays. No debugger
  implementation or heap dump is distributed. Aggregate observations found
  duplicate private snapshots retained for distinct borrowed declarations.
  Project-authored repair shares only byte-identical immutable snapshots
  while charging both unique content and every retained declaration. Public
  Workflow regressions establish bounded repeated use, declaration accounting,
  read-once borrowed ownership and reopened embedded-font output. Diagnostic
  changes and JVM heap flags remain outside product source; resource defaults
  and Worker heap settings are unchanged. This establishes a repair for the
  observed failure, not that T29 introduced the pre-existing cache behavior.
- No iText source, resources, fixtures, non-public implementation details or
  closed add-on material was accessed or used. Reference Suite binaries and
  output are not correctness oracles. The post-review Linux run retains six
  passing chains and exact source/artifact identities in
  [its run receipt](capabilities/evidence/artifacts/T29-linux-run.json).
  Independent Standards and Spec review closed the three initial source
  defects after public regressions. The
  earlier [full root verify](capabilities/evidence/artifacts/T29-final-root-verification.json)
  and inventory check passed before the font snapshot repair. A separately recorded
  [Javadoc-only delta](capabilities/evidence/artifacts/T29-final-javadoc-delta.json)
  preserves the tested source identities and verifies identical executable
  instructions and metadata apart from changed debug line numbers for that
  intermediate revision. The current source includes the font snapshot repair
  and its public regression. Current-source Linux acceptance passes all six
  chains. Complete [root verification](capabilities/evidence/artifacts/T29-verified-root-verification.json)
  and each of the [four JDK gates](capabilities/evidence/artifacts/T29-verified-jdk-matrix.json)
  pass 1019 tests, with zero failures/errors and three unchanged optional
  scale skips. Actual Windows x86-64/macOS x86-64/arm64 evidence remains
  incomplete.

## T30 one-dimensional barcodes (#31)

- Author: OpenAI Codex, implementing for the Folio PDF by ZeroCloud contributors.
- The [frozen T30 profile](capabilities/profiles/T30-one-dimensional-barcodes.md)
  records the public Reference Suite API inventory, GS1 21.0.1 and archived
  USPS references consulted on 2026-09-07. iText documentation is used only
  to identify public modes and options. No iText source, resources, fixtures,
  binaries, non-public implementation details or closed add-on material was
  accessed, copied or adapted, and iText output is not an oracle.
- [OkapiBarcode 0.5.6](docs/third-party/okapibarcode-0.5.6.md) is the encoder
  selected by ADR-0010. Its permissively licensed Maven source archive was
  inspected for supported options and protected extension points. Product
  integration and PDF drawing are project-authored. The JCommander CLI
  dependency is excluded.
- ZXing core 3.5.3, Copyright ZXing authors, Apache-2.0, provides independent
  module expectations and decoding only in tests/acceptance. Its source JAR was inspected for reader
  contracts; no reader source is copied into product code. Binary SHA-256:
  `8d8064c1636fdaef7189dd9055c7d59950a8940a12f2293956446ec3c109fd82`;
  source SHA-256:
  `f983454400d73652ad5236413ba7eba48072e042982a84b10e1468506f4b28ae`.
  Its reader class-file version is 52 (Java 8). Literal inputs and expected
  checksums are project-owned worked examples, fixed before product output.
- The original add-on, MSI and POSTNET/PLANET readers consume observed module
  widths or heights, verify framing and parity/checksums, and never call the
  encoder. The profile cites the GS1/USPS tables used. MSI options and
  modulo-ten behavior were checked against the public
  [Seagull Scientific MSI Plessey guide](https://help.seagullscientific.com/2022/en/content/symb_MSIPlessey.htm)
  and [TEC-IT barcode reference, version 11](https://www.tec-it.com/download/PDF/Barcode_Reference_EN.pdf).
  Pulse/BCD decoding and fixed check examples are project-authored; no source
  implementation or reference output was copied.
- T30 reuses the existing OFL Noto Sans Regular reference asset, SHA-256
  `b85c38ecea8a7cfb39c24e395a4007474fa5a4fc864f6ee33309eb4948d232d5`.
  A project-authored OpenType reader follows Microsoft's `head`, `cmap`
  format 4 and `hmtx` documentation to obtain independent source metrics.
  Reference pages use independent modules and calculated label coordinates
  through existing Canvas/T19 commands; they never invoke barcode generation.
  Shared Canvas/font dependencies remain explicit experimental gates.
- The T30-only Maven recording profile and canonical acceptance command retain
  fresh public Workflow products, independent reference PDFs, all actual,
  reference and difference PNGs, observed path/text coordinates, independent
  decode findings, qpdf/PDFium/ImageMagick identities and SHA-256 hashes. The
  [delivery record](capabilities/evidence/T30-one-dimensional-barcodes.md)
  distinguishes actual evidence, development runs, final verification and
  independent review. No existing non-T30 evidence is regenerated or replaced.
- Independent Spec review reproduced an AUTO/FNC4 numeric-run payload error
  through published PDFs in both execution profiles. The project-authored
  repair restricts AUTO selection to Okapi's existing A/B option when explicit
  FNC4 is present. GS1 21.0.1 section 5.4.3.4.2 supplies the shift/latch
  expectations; new literal numeric examples are independently decoded from
  actual PDF paths and rasters. Earlier observations remain retained as
  historical evidence; current-source evidence and verification are linked
  from the delivery record.
## T31 two-dimensional barcodes

- Scope: #32 and the predeclared [T31 Acceptance Profile](capabilities/profiles/T31-two-dimensional-barcodes.md).
  Product code and fixtures are authored by the Codex implementation agent,
  with the explicit upstream/data adaptations identified here. During this
  contribution the agent did not inspect iText source, binaries, resources,
  private implementation material or output; none was used.
- The fixed 7.2.6 QR, DataMatrix and PDF417 public API documents linked by the
  profile are used only to inventory modes and options. They are not an
  implementation or correctness oracle.
- [OkapiBarcode 0.5.6](docs/third-party/okapibarcode-0.5.6.md) supplies runtime
  encoding, protected extension points, and the narrowly adapted ECC200
  grid/table implementation, PDF417 symbol table and Macro data compaction documented there. The
  dependency pin is unchanged. Raw PDF417 framing and GF(929) polynomial
  arithmetic are project-authored and independently tested with ZXing.
- Independent review probes exposed RAW PDF417 byte state loss at charset ECI
  and ECC200 EDIFACT termination changing with selected capacity. Original
  project validator repairs preserve the explicit byte state and reserve
  sufficient EDIFACT capacity. Public Workflow regressions and unchanged
  reviewer probes independently decode the repaired outputs with ZXing; its
  permissively licensed decoder control rules informed the validation fixes.
  No upstream encoder implementation or iText material was used for these repairs.
- [Unicode character-set data](docs/third-party/barcode-character-sets.md)
  supplies portable ISO-8859-10/-14/-16 mappings, with original source hashes
  and the complete Unicode License V3 notice in NOTICE. Original mapping
  files also support the repository-only, decoding-only Charset provider.
- ZXing core 3.5.3 remains independent test/acceptance code; it is not a
  runtime dependency or fallback encoder. Public workflow tests read actual
  published PDF Values, reconstruct modules and decode them with ZXing.
  The repository-only ECC200 decoder adaptation and original source hashes
  are recorded in [ZXing provenance](docs/third-party/zxing-3.5.3.md); it repairs
  Structured Append header consumption without using the product encoder.
  QR coordinate reading/traversal, original exact function/BCH/padding/cluster
  assertions and the independently recomputed negative ECC fixture are also
  identified there. The decoding-only Charset provider and its original
  resources exist solely in the non-distributed acceptance module or tests.
- The T31 recorder generates both Workflow profiles, qualifies every actual
  matrix through public PDF Values and independent decoding, then paints a
  separate geometry reference with existing Canvas commands. Literal profile
  dimensions/color/placement drive that painter. Unqualified product output
  cannot define its own reference. Actual PDFium pixels are decoded afresh;
  pinned qpdf, ImageMagick comparisons and deliberately corrupted public PDFs
  provide separate syntax, geometry and negative-control observations.
- The [delivery record](capabilities/evidence/T31-two-dimensional-barcodes.md)
  owns current verification and independent-review status, artifact/source/tool
  identities and residual limits. This provenance statement grants no
  standards certification, compatible status or Foundation release approval.

## T70 document transactions and Stable lifecycle mappings

- Scope: #70, its parent #33 and governing #1, with ADR-0040's actual
  Ubuntu/JDK certification boundary. New acceptance code, control PDFs and
  documentation are authored by the Codex implementation agent. Existing
  project lifecycle mappings are reused. No iText source, binaries, resources,
  private implementation details or proprietary materials were consulted.
- ISO 32000-1:2008 clauses 7.7.2–7.7.3 define the T03 structural expectations.
  The independent Apache-2.0 pdfcpu 0.15.0 process and Arlington TestGrammar
  0.81 at the fixed public source commit are qualified on project-authored
  invalid controls. [Tool provenance](docs/third-party/t03-standards-tools.md)
  records exact distribution, executable and model hashes, source, licenses,
  build settings and the unbundled acceptance boundary. Their implementation
  code and model resources are not copied into product or acceptance sources.
- The [T03 standards corpus](capabilities/profiles/T03-standards/README.md)
  consists of elementary project-authored PDF dictionaries and xref offsets,
  serialized by task-local Python. Each negative changes one specified rule;
  the bytes are retained as Apache-2.0 fixtures. No product-generated PDF or
  Reference Suite result defines the expected output. Existing T03 visual
  expectations and tolerances are retained.
- This section records authorship and sources; final candidate certification
  and independent Standards/Spec review must be recorded separately.

T70 also reuses the existing first-party T04 lifecycle sources in both mutually
exclusive artifacts, fixes outer-transaction receipt ownership at the Worker
callback boundary, and stages sources/Javadocs from the same shared Java source.
No iText implementation, resource or proprietary material was consulted or copied.
The added SnakeYAML dependency is test-scoped and uses the existing repository
pin; Python/PyYAML and all PDF checkers are acceptance tooling only. Native and
Facade products are generated through public APIs. The two-page semantic negative
uses Native page creation; the visual negative changes one pixel in a separate
copy of the independently defined blank expectation, leaving the canonical
expected raster unchanged. T06/T07 historical outputs and determinations remain
historical and are not relabeled as current candidate certification.

The T70 container run exposed missing ImageMagick host libraries. Five unmodified
Ubuntu 24.04 libraries are retained only in the ignored private comparator cache,
with exact hashes in `scripts/imagemagick-runtime.sha256`, package versions and
licenses in `docs/third-party/t03-standards-tools.md`, and original package notices
in `capabilities/evidence/T70-comparator-runtime/`. The existing AppImage, golden
raster and visual tolerances are unchanged. This acceptance runtime is separate
from both the Java products and the explicit Folio HarfBuzz 10.2.0 installation.

## T09 Foundation values expansion (#71)

This entry records the current development inputs; certification and final
artifact checks remain separate required work in `docs/t09-implementation-plan.md`.
The Native Patch and Facade implementation was authored from the project issues,
its public Native contract and the standards/API inputs below. No iText source,
resource, fixture or nonpublic implementation was used.

- The [authorized ISO 32000-1:2008 copy](https://opensource.adobe.com/dc-acrobat-sdk-docs/standards/pdfstandards/pdf/PDF32000_2008.pdf)
  supplies object, array, dictionary, reference, stream and filter structure,
  text-string encoding (§7.9.2.2), and PDFDocEncoding (Annex D.3, Table D.2).
  The [PDF Association explanation of PDF 2.0 UTF-8](https://pdfa.org/understanding-utf-8-in-pdf-2-0/)
  supplies the UTF-8 BOM boundary for text interpretation. Original byte strings
  remain independent of that interpretation.
- The official iText 7.2.6 public API pages for
  [PdfObject](https://api.itextpdf.com/iText/java/7.2.6/com/itextpdf/kernel/pdf/PdfObject.html),
  [constant values](https://api.itextpdf.com/iText/java/7.2.6/constant-values.html),
  [PdfNumber](https://api.itextpdf.com/iText/java/7.2.6/com/itextpdf/kernel/pdf/PdfNumber.html),
  [PdfNull](https://api.itextpdf.com/iText/java/7.2.6/com/itextpdf/kernel/pdf/PdfNull.html),
  [PdfBoolean](https://api.itextpdf.com/iText/java/7.2.6/com/itextpdf/kernel/pdf/PdfBoolean.html),
  [PdfString](https://api.itextpdf.com/iText/java/7.2.6/com/itextpdf/kernel/pdf/PdfString.html),
  [PdfArray](https://api.itextpdf.com/iText/java/7.2.6/com/itextpdf/kernel/pdf/PdfArray.html),
  [PdfDictionary](https://api.itextpdf.com/iText/java/7.2.6/com/itextpdf/kernel/pdf/PdfDictionary.html),
  [PdfName](https://api.itextpdf.com/iText/java/7.2.6/com/itextpdf/kernel/pdf/PdfName.html),
  [PdfIndirectReference](https://api.itextpdf.com/iText/java/7.2.6/com/itextpdf/kernel/pdf/PdfIndirectReference.html),
  [PdfReader](https://api.itextpdf.com/iText/java/7.2.6/com/itextpdf/kernel/pdf/PdfReader.html),
  [PdfWriter](https://api.itextpdf.com/iText/java/7.2.6/com/itextpdf/kernel/pdf/PdfWriter.html),
  and [PdfStream](https://api.itextpdf.com/iText/java/7.2.6/com/itextpdf/kernel/pdf/PdfStream.html)
  were consulted for the frozen call shapes, constants and documented behavior.
  Project text-conversion rules are explicit; no undocumented default encoding
  was inferred from reference-library implementation behavior.
- Integration reuses the approved Apache PDFBox 3.0.8 dependency. Its local
  public dependency sources were consulted for public COS object identity,
  incremental update and raw stream I/O APIs. Patch validation, reversible
  changes, bounded stream scratch ownership and Facade bridging are project
  code. No reflection into backend storage or custom PDF serializer was added.
- The five PDFs under `pdf-document/src/test/resources/net/zerocloud/pdf/consumer/t09/`
  were authored from original object bodies and calculated xref offsets.
  They cover protected metadata, hidden aliases, an existing Owner cycle,
  an indirect Version alias, and a private unknown encoded resource with a
  separately painted page. Pinned qpdf 12.4.0 checked their syntax; its public
  raw-stream output independently checked the 27 authored opaque bytes.
  No reference-library fixture was copied or adapted. Development outcomes
  and RED/GREEN logs are recorded in `docs/t09-development.md`.
  The independent core-structure review probes and regression products use
  these project-owned public APIs and authored Sources. Their malformed outputs
  are retained as historical review observations, not imported reference data
  or certification of the corrected candidate.

T09 acceptance adds the project-authored `values.pdf` corpus and an incremental
re-encoding negative under `capabilities/profiles/T09-values/fixtures/`. The
Source object bodies, original xref offsets, private values, painting operators
and revised object were authored from ISO 32000-1:2008. The negative retains the
complete Source prefix and identical decoded Flate data, but its current object
has a different raw encoding. Pinned qpdf's public JSON v2 interface with
`--decode-level=none` observes the final effective streams; raw bytes are never
obtained through a backend test seam. The golden RGB/sRGB PNG is independently
defined by a white 1224×1584 pixel grid and the exact blue rectangle geometry at
144 DPI. It is not a raster copied from product or reference-suite output.

The [T09 standards profile](capabilities/profiles/T09-standards/README.md) adds
29 original illegal PDFs and one legal null-DecodeParms control to T03's existing
22 structural rules. Normative inputs are the same authorized ISO standard's
stream/trailer/Catalog/Page/viewer/Info/page-piece/data requirements (Tables
5, 8, 15, 28–30, 150, 317–319) and the pinned public Arlington model. No reference
implementation was inspected. Actual qualification output from both existing
checkers is retained under `capabilities/evidence/T71-standards-qualification/`,
including known missed controls; a missed or generic traversal observation does
not become claimed rule coverage. Each final product repeats the selected
illegal-control checks. Existing qpdf 12.4.0, pdfcpu 0.15.0, Arlington 0.81,
PDFium v0.11.2/Chromium 7881 and ImageMagick 7.1.2-30 pins and licenses are reused.
No product dependency or version was added for certification.

The extended runner and read-only provisional inventory evaluation are
project-owned acceptance tooling. Candidate-specific records, raw JSON/PDF/PNG
artifacts and public contract suites bind actual staged bytes. Atomic index
replacement preserves valid other-obligation references and leaves historical
records unchanged. This mechanism does not sign, upload, publish or establish
Foundation readiness for unfinished slices.

## T72 page certification work

The T03/T09 validation wiring and unavailable-executable regression were authored
by OpenAI Codex for the maintainer from the repository's public recorder and
Maven test interfaces. Inputs were issues #72/#33/#1 and the retained CI run
34289416825, existing project-owned T03 fixtures and tool pins, and ADR-0023.
The missing-tool control copies the existing authored corpus and points tool
configuration at absent paths. It contains no third-party PDF fixture, substitute
checker, new tool version, or product runtime dependency. Test category selection
separates ordinary build verification from explicit independent-tool validation;
it does not alter the certification runner or qualify an unobserved chain.

The existing project-authored T10 Workflow tests now select the requested Native
execution profile explicitly and assert the actual public Workflow Outcome mode.
This test-only wiring introduces no new PDF fixture or Native implementation.
The first Worker-selected outcome assertion failed against the previous
IN_PROCESS-only test setup before the request builder was changed.

Public iText 7.2.6 API documentation for
[PdfDocument](https://api.itextpdf.com/iText/java/7.2.6/com/itextpdf/kernel/pdf/PdfDocument.html),
[PdfPage](https://api.itextpdf.com/iText/java/7.2.6/com/itextpdf/kernel/pdf/PdfPage.html),
[PdfMerger](https://api.itextpdf.com/iText/java/7.2.6/com/itextpdf/kernel/utils/PdfMerger.html), and
[PdfSplitter](https://api.itextpdf.com/iText/java/7.2.6/com/itextpdf/kernel/utils/PdfSplitter.html)
was consulted for the frozen Facade subset in `docs/page-manipulation.md`. No iText implementation
source, binary-derived internals, fixtures or proprietary add-on material was
consulted or copied. The page handles, named declarations, merger/splitter views
and actual receipt accessor were authored by OpenAI Codex for the maintainer,
using the existing project-owned Native Workflow, Commands and Values adapters.
The public-consumer fixtures use authored ASCII page labels and a minimal
three-object PDF with a deliberately missing Page Type for a lifecycle regression.
They are Apache-2.0 project test material, with no imported library fixture.
The independent Standards reviewer authored the corresponding public Facade
probe; its failure and corrected observations are retained in the T72 development
record. No product runtime dependency or Native page implementation was added.
Actual Stable and Preview jars are checked against the exact declared page,
merger, and splitter classes and members. The manifest distinguishes direct
source mappings, adapted source shapes, and Folio coordination extensions; an
extension records the public Reference namespace without inventing a Reference
member. Both jar orders reject a mixed Stable/Preview classpath.

The T10 corpus generator, 3 Sources, 7 original RGB rasters and standards
negative generator were authored by OpenAI Codex for the maintainer as
Apache-2.0 project material. Normative inputs are the public
[ISO 32000-1:2008](https://opensource.adobe.com/dc-acrobat-sdk-docs/pdfstandards/PDF32000_2008.pdf),
particularly Tables 28–36, 95, 151 and 164. PDF object bodies, byte offsets,
content programs, geometric clipping/rotation and expected pixels are original;
neither product rendering nor Reference Suite output supplies a fixture.

Actual qualification exposed four gaps in existing standards-tool diagnostics.
The [acceptance-only Arlington source patch](build-tools/acceptance/arlington/README.md)
uses the same public Apache-2.0 TestGrammar source and bundled PDFium as the
original T03 installation. The small normative checks and distinct version
identifier are project-authored; upstream source/model attribution and component
licenses are preserved. The source archive, model, patch and compiled binary
are separately identified. No product runtime dependency or Conformance API is
added. The original tools, controls and failed qualification observations remain
available; missing or unqualified rules cannot pass.

During checker capability investigation, the public
[pdfcpu validation configuration](https://pdfcpu.io/config/config_list/),
[veraPDF rule documentation](https://docs.verapdf.org/validation/rules/) and
[veraPDF model declarations](https://github.com/veraPDF/veraPDF-model/tree/integration/src/main/java)
were inspected. No veraPDF code, model, binary, fixture or dependency was
incorporated into the implementation or acceptance suite.

The T72 acceptance producer, Foundation runner integration, 56 new standards
fixtures, product PDFs, negative PDFs, semantic expectations, and visual
profiles were authored by OpenAI Codex for the maintainer. They combine with 28
qualified T03/T09 rules to form the frozen 84-rule T10 union. Pinned qpdf is used
only for syntax; pdfcpu strict/offline and the separately versioned Arlington
T10 r1 executable provide the standards observations; public Folio Native reopen
provides semantic observations; PDFium renders fixed 144-DPI pages and
ImageMagick performs zero-fuzz, AE-zero comparison. The secondary PDFBox renderer
is disagreement evidence and never the visual authority. All eight products and
real syntax, standards, semantic, and one-pixel controls are retained
with exact hashes. Missing tools, rules, profiles, or identities cannot produce
PASS.

Product semantic testing exposed one Native preservation gap: PDFBox's managed
Text-annotation reconstruction introduced a `/Name` key absent from the legacy
source dictionary. The project-authored public regression failed before the
adapter captured the source key set. The correction removes reconstructed
optional keys that were absent while retaining only the required `/P` page
retargeting and deterministic `/NM` collision change. This is a bounded fix to
the observed T10 preservation contract, not a new command or backend surface.

The Foundation page runner executes the public 53-case Native suite under the
actual selected IN_PROCESS or HARDENED_WORKER profile, the 10-case Facade suite
in its fixed IN_PROCESS mode, and both actual-jar contracts. It binds the staged
0.1.0 artifacts, harness, immutable Ubuntu/JDK environment, tool catalog,
configuration, eight products, four chains and controls. The current Foundation
Evidence inventory is the authority for candidate-specific claims; historical
T70/T71 records keep their bytes and are refreshed only by new observations of
the same staged candidate. No signing, upload, publication, Windows claim, or
macOS claim is performed by this work.

## T73 metadata certification work

OpenAI Codex authored the metadata Facade mappings and public consumer tests
for the maintainer from issues #73/#33/#1/#12, the existing project-owned Native
Commands, Queries, values and Facade lifecycle, and the public iText 7.2.6 API
documentation for
[PdfDocument](https://api.itextpdf.com/iText/java/7.2.6/com/itextpdf/kernel/pdf/PdfDocument.html),
[PdfDocumentInfo](https://api.itextpdf.com/iText/java/7.2.6/com/itextpdf/kernel/pdf/PdfDocumentInfo.html),
[PdfOutline](https://api.itextpdf.com/iText/java/7.2.6/com/itextpdf/kernel/pdf/PdfOutline.html),
and [PdfFileSpec](https://api.itextpdf.com/iText/java/7.2.6/com/itextpdf/kernel/pdf/filespec/PdfFileSpec.html).
During review remediation, public iText 7.2.5 `PdfDocumentInfo` source was
briefly inspected only to confirm that the public `addCreationDate()` and
`addModDate()` conveniences use the current time. No implementation code,
binary-derived internals, fixtures, or closed add-on material was copied.
Folio's implementation was authored independently from the ISO 32000 date
syntax and public API contract. The new data values reuse Folio's existing
model; no runtime dependency was added.

The new minimal PDF, XML packets, Unicode labels and attachment bytes are
original Apache-2.0 project test material. Known ASCII payloads `abc` and
`hello` followed by LF have independently fixed SHA-256 and MD5 expectations;
expected hashes are not inferred from a product-reported digest. Public tests
observe round trips, original Source bytes, receipt ordering, ownership and
lifetimes without backend object-identity or private-call assertions.

The public [ISO 32000-1:2008](https://opensource.adobe.com/dc-acrobat-sdk-docs/pdfstandards/PDF32000_2008.pdf)
is the normative metadata/navigation reference. Table 151 exposed a Native
gap for nullable FitH, FitV, FitBH and FitBV coordinates. An original raw-PDF
Workflow regression failed on query before the value factories and reader were
corrected; rectangle coordinates remain required. Clause 14.3.3 also requires
custom Info entries to be strings, so the independent positive corpus keeps
private structural data in the Catalog. Safe preservation tests for existing
non-string Info entries make no standards-conformance claim for those files.

The metadata suite's execution-identity assertion first detected its previous
IN_PROCESS-only requests before the test request builder gained explicit
profile selection. Facade execution remains IN_PROCESS. Development tests and
the frozen contracts do not themselves establish Foundation certification;
candidate claims require the separate qualified chains and actual environment
records described by the T11 contract.

The T73 public regression also demonstrated that removing a named destination
could orphan an existing outline. The metadata owner now validates surviving
encoded name keys against the already validated outline graph before mutation;
its fixed safe diagnostic is included in the closed Worker failure vocabulary.
The full 57-test Native metadata suite subsequently passed under actual
HARDENED_WORKER execution, and both Facade editions passed nine metadata tests.
These development results do not constitute independent certification.

Independent Spec review identified the two current-date conveniences as missing
from the frozen `PdfDocumentInfo` surface. Exact jar-contract assertions and
public consumer assertions failed before both fluent methods were implemented,
then passed with PDF date syntax and the current system offset. The same review
identified an annotation MIME edit as downstream #74 scope; it was reverted in
full. Standards review led to descriptor-based certification report layouts and
T10/T11 visual profile families without changing their frozen observations.

`scripts/generate-t11-corpus.py` authors original PDF Sources, literal metadata
expectations and 144-DPI RGB pixel grids without reading Folio products or
renderer output. It reuses only project-owned T10 pixel/PNG serialization.
`scripts/generate-t11-standards.py` authors 104 original metadata defects and
retains the established core/navigation checker assignments in a separate
required-rule catalog. Existing evidence and historical profiles are untouched.

Before any T73 product observations, pinned pdfcpu strict validation rejected the
original fixture's PDF 1.7 declaration because it contained AFRelationship.
The profile now explicitly uses PDF 2.0, consistent with ISO 32000-2:2020 Table 43
and the PDF Association's published corrections at
https://pdf-issues.pdfa.org/32000-2-2020/clause07.html . The original PDF 2.0 fixture
passes that initial strict check. The Facade's additional declaration constructor
selects the existing Native PdfVersion explicitly for all Targets; other
constructors retain their PDF 1.7 default. No security-policy mapping is added.

Baseline CI run 34435836626 eventually completed with all four JDK jobs failing
on stale `docs/generated/foundation-readiness.md`. The retained baseline is
55528893ed7167e103365eb4bff2062f839f2835; this failure is not a successful current
validation result and must be resolved by final candidate regeneration/checks.

The T11 standards checker is a separately versioned Arlington
`0.81-folio-t11-r1` build from the same pinned public upstream source, with the
project-owned patch at `build-tools/acceptance/arlington/t11-r1.patch`. Its
supplemental predicates use Arlington's independent PDFium graph, decoded
stream bytes and existing PDFium MD5 implementation. Expat 2.6.1 is linked
statically for XML parsing; the Ubuntu package, archive hash and MIT license are
recorded in `scripts/t11-arlington-pin.properties`. No Expat dependency was
added to any Folio runtime module. Only Expat's public API documentation
(https://libexpat.github.io/doc/api/latest/) and installed public headers were
used for the parser calls.

Qualification exposed 24 missing or unbounded checker behaviors, including a
cyclic name tree that previously recursed without a cycle diagnostic. Focused
public standards-recorder tests failed against those gaps before the predicate
implementations, then passed against the actual rebuilt and repinned checker.
The complete frozen union of 170 rules subsequently qualified with real illegal
controls. This qualifies tools and original fixtures; final products and all
required environment/execution tuples still need their own retained records.

The first independently generated corpus draft mixed PDF string encodings in a
way that could not express one self-consistent name-tree key order. It was
discarded before candidate certification. The replacement uses explicit ASCII
keys (`b`, `bh`, `bv`, `fit`, `h`, `r`, `shared`, `v`, `xyz`, `z`, `za` and
`secondary.bin`) whose encoded-byte order is worked in the frozen corpus; the
separate inherited high-byte and equivalent-encoding controls retain coverage
of those ordering rules. No observation from the discarded draft is evidence.

A public serialized-output regression then exposed MIME subtype double escaping:
pre-escaping `/` before constructing a PDF name emitted `#23` followed by `2F`
rather than the required single `#2F` escape. The writer now passes the decoded
printable-ASCII subtype to the PDF name implementation exactly once, and the
reader returns its decoded value. The regression inspects the published bytes,
and all T11 product semantics were rerun after the correction.

The XML safety probe is project-authored and executes each Native and Facade
case in an isolated child JVM. Targeted access counters first prove that their
exact canary file and loopback endpoint are observable, then prove that file and
network external entities are rejected without access or mutation, malformed
packets are rejected atomically, and an XInclude-looking element remains inert.
The signed-document probe authors a structural DocMDP P=3 Source and proves that
T11 `REWRITE` changes are rejected with `SIGNED_REWRITE_REJECTED` while Source
and sentinel Target bytes remain unchanged. These probes add no runtime
dependency and make no signature-validity or Trust claim.


## T74 annotation certification work

Authored by OpenAI Codex for the Folio PDF by ZeroCloud contribution, against
issue #74 and fixed implementation/review baseline
`db88f8c21dcd2e8f33613838b71cd42216254527`. No commit, publication, tracker edit,
or external review message is part of this work.

The governing references are the complete public issues #1, #13, #33, #72,
#73 and #74 and their comments; repository ADRs 0017, 0020, 0023, 0025, 0029,
0034 and 0040; `docs/annotations-actions.md`; and ISO 32000-2 requirements for
annotations, appearances, actions, destinations, embedded files and page
structure. The public iText Core 7.2.6 API documentation for
[PdfPage](https://api.itextpdf.com/iText/java/7.2.6/com/itextpdf/kernel/pdf/PdfPage.html),
[PdfCatalog](https://api.itextpdf.com/iText/java/7.2.6/com/itextpdf/kernel/pdf/PdfCatalog.html),
[PdfAnnotation](https://api.itextpdf.com/iText/java/7.2.6/com/itextpdf/kernel/pdf/annot/PdfAnnotation.html)
and PdfAction supplied mapping names/signatures only. Adapted signatures and
Folio extensions are explicit in the manifest. No iText implementation,
resource, fixture, reverse-engineered binary detail, non-public implementation
material or closed add-on material was consulted or copied.

The T12 corpus, programs, original semantic expectations, independent raster
grids and control defects are original Apache-2.0 project work. The authoring
scripts reuse the repository-owned T10 raster primitives and T11 PDF/embedded-
file authoring conventions. No Folio output, PDF renderer output or iText asset
is used to author expected pixels. An original raster copy with exactly one
changed pixel additionally qualifies AE=1 at the unchanged zero threshold. Sources A/B/C/D, eight Native and eight
Facade products, nonzero AP bounding boxes, identity matrices, explicit/named
GoTo operands, copy/merge/split collisions and retained page paint are frozen
in `capabilities/profiles/T12-annotations`. `scripts/t12-semantics.py` observes
actual qpdf JSON independently of Folio getters and product authoring code.
Original positives and 18 isolated semantic defects qualify that observer;
actual product mutations additionally qualify its use on published bytes.

Standards qualification reuses 137 already authored T10/T09/T11 predicates
and adds 37 original T12 defects with matching diagnostics. Every one of the
174 required predicates is assigned exactly once to strict offline pdfcpu
0.15.0 or the Arlington checker. `build-tools/acceptance/arlington/t12-r1.patch`
is a cumulative Apache-2.0 supplement to pinned upstream commit
`fe4a1a8897ec07f674c73160c35d748b29052f8f`. It retains the qualified T10/T11
predicates and adds narrowly scoped page-local NM uniqueness, optional P-owner
identity and Link Dest/A exclusivity checks. Legal same-name annotations on
different pages, absent P/unbound Link, and null P/null A are positive controls.
The fixed source, patch, model, executable and compiler/build provenance are
recorded in `scripts/t12-arlington-pin.properties` and the acceptance tool README.
No diagnostic is promoted globally from warning to failure.

The existing PDFium v0.11.2/chromium-7881 CLI's independent flatten operation
projects AP streams for visual observation because its direct page rendering
omits standalone Widgets. Every projection and unchanged original has its
exact hash recorded. All 26 original reference pages qualify this projection
against the independently authored pixels with zero AE and zero renderer
agreement error. Secondary PDFBox rendering reads the original document.
Native flattening remains separately checked on the original product's object
graph and paint/placement instructions. ImageMagick 7.1.2-30 and all inherited
runtime dependencies keep their existing pins and licenses.

`scripts/t12-safety-observer.py` is original acceptance-only Python standard-
library code using Linux inotify and a loopback listener. Every invocation
qualifies real read, write, executable-launch, script-file-effect and network
observations before executing the public Native/Facade probe in a child JVM.
It watches declared canary paths and the endpoint across descendant processes;
it does not assert a private backend or claim to trace a JavaScript interpreter.
The signed-Source probe reuses T11's original synthetic DocMDP P=3 PDF; it makes
no cryptographic signing or trust-validation claim. Tool code, corpus fixtures,
rasters and observer processes stay outside product runtime artifacts.

Public verification exposed two Native gaps: explicit numeric identity
appearance matrices were rejected despite the approved identity contract,
and FileAttachment MIME names were double escaped. Minimal fixes accept the
explicit identity while rejecting other matrices and let the PDF name serializer
perform the single escape step, retaining literal hash sequences after reading.
Worker failure transport now retains the page capability for an Annotation/Action
preservation rejection. All observations use public Workflow outcomes, detached
values, reopened products, receipts and stable safe errors; no new private
engine testing seam was introduced.

Container qualification exposed checkout-specific absolute paths in generated
readiness findings. The repository-only Markdown now uses relative paths. An
original synthetic relocation test exercises the public generate/check/readiness
commands and preserves the stale-evidence diagnosis and NOT READY result after
moving the checkout.

## T75 extraction certification record

OpenAI Codex authored the #75 implementation increments, original synthetic PDF
fixtures, command-boundary regressions and documentation at the repository
operator's direction. The fixed baseline is
`5b1603c435f11c40368f75b7b9a2777c9c5e9761`. Delivery requires the final
candidate's certification and validation gates; the user's subsequent
instruction authorizes a DCO commit, push and closure only after those pass.
Independent Codex reviewers inspected Standards and Spec; their reviews are
implementation checks, not external acceptance-tool evidence.

Inputs include issues #1, #33, #71 and #75 and their available comments,
`CONTEXT.md`, the repository contribution/inventory/domain contracts, ADRs 0013,
0016, 0017, 0020, 0023, 0024, 0025, 0029, 0035 and 0040, the existing project-owned
T13 implementation and fixtures, and the T03/T09/T10/T11/T12 certification
patterns. The existing baseline CI failure and local/clean-archive reproductions
are retained in `capabilities/evidence/T75-delivery/`.

Public standards references are Adobe's authorized
[ISO 32000-1:2008](https://opensource.adobe.com/dc-acrobat-sdk-docs/pdfstandards/PDF32000_2008.pdf),
including §§7.9.7, 9, 14.6, 14.7 and 14.9, and the PDF Association's public
[PDF 2.0 document-interchange errata](https://pdf-issues.pdfa.org/32000-2-2020/clause14.html).
Namespace dictionary field kinds and indirect-reference requirements were
cross-checked against the PDF Association's Apache-2.0 Arlington model
[`Namespace.tsv`](https://github.com/pdf-association/arlington-pdf-model/blob/master/tsv/latest/Namespace.tsv),
[`RoleMapNS.tsv`](https://github.com/pdf-association/arlington-pdf-model/blob/master/tsv/latest/RoleMapNS.tsv)
and [`ArrayOf_RoleMapNS.tsv`](https://github.com/pdf-association/arlington-pdf-model/blob/master/tsv/latest/ArrayOf_RoleMapNS.tsv).
The Association's [Logical Structure Objects](https://pdfa.org/download-area/cheat-sheets/LogicalStructureObjects.pdf)
and [Standard Structure Elements](https://pdfa.org/download-area/cheat-sheets/StandardStructureElements.pdf)
cheat sheets supplied cross-checks of object relationships and the two standard
role sets. These references supplied facts; no model files, example objects or
cheat-sheet artwork were copied into runtime or fixtures. The public
[WTPDF 1.0](https://pdfa.org/wp-content/uploads/2024/02/Well-Tagged-PDF-WTPDF-1.0.pdf)
and [EA-PDF 1.0](https://pdfa.org/download-area/specifications/EA-PDF-v1.pdf)
were consulted only as corroborating guidance; their additional conformance
requirements do not define this extraction Query.
The Association's CC-BY-4.0
[Deriving HTML from PDF 1.0, §4.3.2](https://pdfa.org/download-area/specifications/Deriving_HTML_from_PDF.pdf)
corroborates stopping extraction role resolution at a supported explicit
namespace. [PDF issues discussion 65](https://github.com/pdf-association/pdf-issues/issues/65#issuecomment-820584433)
clarifies the default-namespace destination. A search-indexed excerpt of
Adobe's public ISO 32000-2 draft Table 356 was consulted; its direct PDF URL
returned 404, so this record does not claim the complete draft or final standard
was read. Final base-standard wording for every transitive namespace return
remains unverified; the contract records bounded unresolved extraction separately
from conformance.
The pinned Apache-2.0 PDFBox/FontBox 3.0.8 source archives already in the local
dependency cache were inspected for pre-construction safety and metric flow:
`PDType3Font`, `PDFStreamEngine`, `CMap`, `CMapParser`, `PDFont`, `PDType0Font`,
`PDFontFactory`, `PDCIDFont`, `COSStream` and `COSString`. The same pinned FontBox archive's `Identity-H`
and `Identity-V` resources were read to establish exact construction charges;
their Adobe three-clause BSD notices were inspected in place. The same archive's
`Adobe-Japan1-UCS2` resource and notice were inspected for the named-parent
case: 284,124 bytes, 23,058 declared source mappings and one codespace, counted
from the pinned data independently of the product parser. The four Adobe
CNS1/GB1/Japan1/Korea1 UCS2 resources remain in their existing licensed dependency.
No resource was copied into the repository. Independent Spec review also read
Adobe's published
[`Adobe-CNS1-7/cid2code.txt`](https://github.com/adobe-type-tools/cmap-resources/blob/master/Adobe-CNS1-7/cid2code.txt),
[`Adobe-GB1-6/cid2code.txt`](https://github.com/adobe-type-tools/cmap-resources/blob/master/Adobe-GB1-6/cid2code.txt),
[`Adobe-Japan1-7/cid2code.txt`](https://github.com/adobe-type-tools/cmap-resources/blob/master/Adobe-Japan1-7/cid2code.txt)
and
[`Adobe-Korea1-2/cid2code.txt`](https://github.com/adobe-type-tools/cmap-resources/blob/master/Adobe-Korea1-2/cid2code.txt).
Their explicit Unicode values independently establish full-carry boundary
mappings in the predefined resources (CIDs 12106, 4918, 21991 and 1238,
respectively); they are distinct from the inline PDF ToUnicode final-byte rule.
Only facts and original fixtures were used; no mapping table was copied into
runtime or the repository. Adobe's public
[Technical Note 5014, Adobe CMap and CIDFont Files Specification](https://adobe-type-tools.github.io/font-tech-notes/pdfs/5014.CIDFont_Spec.pdf)
(the inspected PDF is dated June 1993), its
[CMap resource repository](https://github.com/adobe-type-tools/cmap-resources),
and the PDF Association's
[PDF 2.0 text errata](https://pdf-issues.pdfa.org/32000-2-2020/clause09.html#9.10.3)
supplied inheritance and predefined-resource facts. The fixed 61 Encoding
names were transcribed from ISO 32000-1 Table 118; every referenced parent is
also in that set. Original development code independently counted their
decoded bytes, nodes, codespaces, CID and notdef source cardinalities from the
pinned archive, with the resulting fact table retained under T75-delivery.
Specific 83pv-RKSJ and 90ms-RKSJ mappings supply independently specified CID
metric observations, including the vertical override for source 8141.
Technical Note 5014 §§5.3, 5.4 and 7.3 supplied codespace-domain, inheritance
and declaration-order requirements. Original independent reviewer probes
contrast valid mixed-length mappings with out-of-domain and ambiguous sources;
they also check shared CID width-table construction against literal entry
budgets. Their output is retained under `T75-delivery/encoding-independent-review`.
No resource program was copied into runtime or the repository. ISO §9.7.3
establishes Registry/Ordering compatibility without Supplement equality, and
§§9.7.4.2–3 and 9.7.6.2–3 distinguish CID metrics from glyph substitution;
substitute-renderer equivalence remains outside this declared-metric profile.
Apache's
[PDFBOX-6251](https://issues.apache.org/jira/browse/PDFBOX-6251) corroborates a
CID-range inheritance defect in the pinned dependency; it is not a normative
standard and no dependency update has been made. This is permitted
dependency-source review, distinct from the iText API inventory references.
Public iText Core 7.2.6 API documentation was consulted for inventory/member
shapes only: `PdfTextExtractor`, `PdfDocument`, `TextRenderInfo`,
`IStructureNode`, `PdfStructElem`, `PdfStructTreeRoot`, `PdfMcr`, `PdfObjRef`
and `PdfNamespace`, beneath `https://api.itextpdf.com/iText/java/7.2.6/`.
The matching Facade contract records its exact member and return adaptations.
Its six implemented members delegate to the existing public Native Query.
Facade tests reuse the original T13 deterministic, tagged role/language and
depth-boundary fixture conventions, with original malformed-page, uncertainty
and caller-stream controls. Independent Standards review and independent
Stable/Preview public Spec probes found no Facade implementation defect;
those reports remain implementation evidence, not tool qualification.

New fixtures use original authored PDF dictionaries, streams and literal
expectations, including Form/annotation relationships and malformed graph
controls. They are project contributions under Apache-2.0. No copied or adapted
iText implementation, source, resources, fixtures, binary-derived behavior,
non-public material or proprietary add-on material was used or inspected. No
new product runtime dependency has been introduced; existing runtime pins and
Java 8 compatibility remain binding. Acceptance additions are identified below.

Historical T13 evidence is preserved with its original bytes and status in
`T75-delivery/historical-T13-text-logical-structure.md`. The updated profile and
four chain indices bind the qualified scope; actual candidate and environment
certification is governed by `capabilities/foundation-evidence.yaml`.
Implementation and qualification history alone supplies neither final
eight-environment certification nor global Foundation readiness.

Final source review also reconciled Native appearance handling with the already
qualified independent structure controls. New original public Workflow cases
cover omitted/null optional StmOwn, normal AP roots without their own structure
items, actual nested Do page associations, and whole Form OBJRs reached through
appearances. A separate cross-page control requires an OBJR for every page
reached through normal appearances, while same-page repeats and a merely
declared uninvoked resource retain their distinct behavior.
ISO 32000-1 Table 324 and §§14.7.4.2–14.7.4.3 define the ownership,
internal-MCID and whole-object distinctions. Direct annotation ownership stays
separate from a descendant's page association; no owner identity is fabricated.
The original failed candidate, compilation attempts and actual public RED/GREEN
observations are retained as development history, not completed certification.

Full verification also exposed pre-T75 font-data budgets in existing consumer
tests and acceptance observers. Their bounded observation allowances now include
the complete Identity-H tables for the selected font dictionaries: two for the
font/layout fixtures, eight for the four command-local shaping font pairs, and
one shared Session font for the barcode labels. Existing product FontLimits,
CompositionLimits, output expectations and unrelated extraction bounds remain
intact. Original full-build and acceptance failures, the public two-mode probe
and subsequent regressions are retained as revalidation history. The probe's
separate zero-bound controls cover ToUnicode mapping entries and decoded bytes.

The original `scripts/generate-t13-corpus.py` reuses only the project's T10/T11
PDF, PNG and properties serializers. Its Type3 rectangle glyph, split source
token, Form placements, tagged relationships, replacement/language values and
literal pixel grids are new Apache-2.0 project data. They contain no third-party
font or renderer-derived expectation. Independent Spec review consulted the
PDF Association's [Annex L matrix](https://www.pdfa.org/norm-refs/ISO32000-2_AnnexL_matrix-version072024.pdf)
and the public Table 355 errata when correcting the original positive structure.
The reviewer's clearly labeled source transcription is retained; direct PDF
downloads returned HTTP 403 and no original Annex L PDF hash is claimed.
The original qpdf graph observer and negative controls reuse the project's
external-process/recording patterns and the already pinned qpdf distribution.
They import no Folio parser or generator, and the graph expectation is the
independent original Source. Complete public result expectations are authored
separately. Qualified development-host visual and semantic observations are
retained under `T75-delivery`; final-environment certification is a separate
mandatory gate under the T13 contract.

`scripts/generate-t13-fonts.py` authors the original TrueType, name-keyed CFF and
CID-keyed CFF resources under `capabilities/profiles/T13-fonts`. They contain
only an empty `.notdef` and a 400 by 600 unit rectangle, all widths 500. Font
outlines, naming and character collection are original Apache-2.0 project data.
The existing MIT-licensed fontTools 4.59.2 authoring tool and reviewed wheel are
reused; its original license bytes were verified against the checked notice.
Its FontBuilder/cffLib public implementation and API were consulted from the
pinned source. No tool or font is added to product runtime. The TrueType `post`
fixed-pitch definition was checked in Microsoft's public
[OpenType post specification](https://learn.microsoft.com/en-us/typography/opentype/spec/post);
font and PDF metadata now explicitly identify these equal-width fonts.

The direct-CMap reference PDF was authored with the project serializer and these
original font bytes, before the direct-font Folio product observation. Pinned
PDFium CLI v0.11.2/chromium-7881 renders its frozen reference PNG so font smoothing
has a defined reference; neither the reference PDF nor its geometry comes from
Folio. The original mathematical ink rectangles remain separately specified.
Primary raster comparison remains exact; the new font-only secondary bound is
the independently calculated one-pixel boundary shell around seven rectangles.
The inherited-CMap case retains its independent standards/semantic obligations.
Its earlier renderer failures remain historical INDETERMINATE observations,
not passing visual evidence or a certified rendering claim.

The T13 acceptance-only Arlington supplement is original project-authored
Apache-2.0 work against the already reviewed upstream commit
`fe4a1a8897ec07f674c73160c35d748b29052f8f` and archive. It reuses the existing
PDFium SDK shim and static Expat setup. Sources for the new font and CMap
predicates are ISO 32000-1 §§9.7.4.3, 9.8.1 and 9.10.3, Adobe Technical Note
5014, and the PDF Association's approved
[PDF 2.0 Table 120 correction](https://pdf-issues.pdfa.org/32000-2-2020/clause09.html#9.8.1).
That correction makes FontName optional for Type3 and requires it to match
a supplied owning Name. The original marked corpus now supplies both names;
its previously unnamed legal form remains a qualification positive. All source
and observer identities are refreshed when this original fixture changes.
The new pin is separate from the earlier T03/T09/T10/T11/T12 pins. Tool source,
patch replay, original controls and actual results are development qualification
evidence; none introduces a product runtime dependency or global conformance claim.

Subsequent original Arlington changes qualify simple-font Widths cardinality,
missing/null required fields and the current 334-rule PDF 2.0 declaration union.
They use the pinned model, ISO 32000-1 font tables and original isolated controls.
The legacy PDF 1.7 conditional-required findings remain preserved and unqualified.

The separate `scripts/t13-program-standards.py` observer is original Apache-2.0
acceptance code over the existing pinned qpdf 12.4.0 executable and Python
standard library for CMaps. It imports no Folio implementation or fixture
generator. Its CMap rules were authored from ISO 32000-1 §§7.3.10,
9.7.5, 9.7.6 and 9.10.3, Adobe Technical Note 5014 §§5.1, 5.3, 5.4 and 7.3,
and the official
[PostScript Language Reference, third edition](https://www.adobe.com/jp/print/postscript/pdfs/PLRM.pdf)
§3.2 and Table 5.18. PostScript names and comment termination are distinguished
from PDF dictionary lexing. Ten project-owned review fixtures retain the
independent reviewers' original probes, with exact SHA-256 identities and
Apache-2.0 provenance under `T13-standards/review-fixtures`. Raw initial and
corrected observations remain in T75 delivery evidence. This initial CMap
qualification preceded the font, content and structure scopes described below;
the complete current bounded profile is fixed by the T13 certification contract.
Final candidate certification remains a separate mandatory gate.

The observer's font scope reuses the existing MIT-licensed fontTools 4.59.2
wheel as a binary reader, separately from the authoring command. The exact wheel
SHA-256 is `8bd0f759020e87bb5d323e6283914d9bf4ae35a7307dafb2cbd1e379e720ad37`;
version, import location, before/after wheel bytes and Python optimization level
are recorded. Optimized Python execution is unqualified because this reader
uses assertions for checksums. The pinned cffLib, ttLib and psCharStrings source
was consulted to identify lazy decoding, INDEX counts and silent unsupported
operators. A local reader dispatch guard rejects unknown or reserved CFF DICT
operators without modifying the dependency. Rules come from ISO 32000-1 §9.9,
[Adobe CFF Technical Note 5176](https://adobe-type-tools.github.io/font-tech-notes/pdfs/5176.CFF.pdf)
§§4–9, 13–14 and 18, and Microsoft's
[OpenType font organization specification](https://learn.microsoft.com/en-us/typography/opentype/spec/otff).
Eight further Apache-2.0 review PDFs preserve the independent reviewers' binary
font probes, with identities in `review-fixtures/font-sha256.json`. Header,
declared CFF kind, Top DICT, glyph-count and readable-table checks are an initial
increment; they do not establish complete font metrics or outline semantics.

The original CIDFontType2 fixture now uses a fourth font resource,
`FolioT13RectangleCID.ttf`, rather than sharing the simple TrueType program.
The same licensed authoring tool removes `cmap` while preserving glyph IDs,
outlines, horizontal tables and name data; OS/2 character-range fields change
with the removed mapping, while its height metrics remain the authored values.
The three previous font programs remain byte-identical. This conservative
split follows the directly read ISO 32000-1 §9.9 CIDFont table rule and a
search-indexed Adobe PDF 2.0 draft; the 2020 final clause was not directly read.
Before the change, 369 corpus/control/reference files were archived and every
member byte-verified. The revised original reference PDF was rendered with the
same pinned PDFium CLI; its PNG is byte-identical to the earlier reference.
Source, corpus, control and semantic-observer identities are refreshed together;
historical qualifications are preserved under their original identities.

The subsequent font-program increment consults Adobe 5176 §14 for declared
CharstringType, [Adobe Type 2 Technical Note 5177](https://adobe-type-tools.github.io/font-tech-notes/pdfs/5177.Type2.pdf)
§§3–4 for bounded path execution, OpenType font organization for sfnt layout
and checksums, and the [OpenType glyf table](https://learn.microsoft.com/en-us/typography/opentype/spec/glyf)
for bounds over on-curve and off-curve coordinates. The
[Apple TrueType name table](https://developer.apple.com/fonts/TrueType-Reference-Manual/RM06/Chap6name.html)
and [OpenType name table](https://learn.microsoft.com/en-us/typography/opentype/spec/name)
inform program-name qualification. A ninth independent font review fixture
preserves conflicting Macintosh/Windows names with recomputed valid checksums.
Its original mutator and both axes' complete layout/outline/name review probes
and closure results are archived under `T75-delivery/standards-r7`, with every
member byte-verified. These are original Apache-2.0 acceptance controls.

FontBBox qualification uses ISO 32000-1 §§7.3.10, 7.9.5, 8.3.2.4 and 9.8.1
Table 122, Adobe 5014's 1000/em CID FontBBox convention, and OpenType head
unitsPerEm bounds. The pinned fontTools BoundsPen measures the already checked
outlines. Independent review exposed indirect-coordinate handling, missing CID
font dictionary selection and unsound general CFF matrix interpretation. The
first two have explicit checks; explicit Top DICT/selected FD FontMatrix values
are outside qualification and return INDETERMINATE. The required original
corpus uses implicit matrices. Five further original review PDFs and their
mutators/results are preserved in `standards-r8`; every archived member was
read back and byte-verified. No proprietary font material is used.

Font-width qualification follows ISO 32000-1 Table 111, §§9.6.6.4 and 9.7.4.3,
and Adobe 5176 §15 Table 23. Simple WinAnsi ASCII selection uses the pinned
fontTools Adobe Glyph List data under the already retained Adobe three-clause
BSD notice in LICENSE.external. The pinned BoundsPen, transform and quadratic
calculation source was read to identify floating-point conversion boundaries.
TrueType polygon coordinates and advances retain exact integer ratios;
curved glyphs and CFF real DICT widths remain outside their respective exact
qualification scopes. The required original corpus uses polygons and integer
DICT widths. Independent reviewers' original numeric PDFs, mutators and
closure reports are Apache-2.0 project material with exact identities retained
under `T75-delivery/standards-r9`. No dependency or product runtime changes are
introduced by these acceptance predicates.

The T13 qpdf identity closure reuses the existing official qpdf 12.4.0
Linux x86-64 distribution and unchanged wrapper/pin. The new acceptance-only
`scripts/t13-qpdf-runtime.sha256` manifest binds eleven runtime paths to the
already pinned [official release archive](https://github.com/qpdf/qpdf/releases/tag/v12.4.0).
The archive SHA-256 remains
`a3bca240f3bb61efdc3a90be89d1da4ed5e125326c3458c4e62df53ff4f153e3`;
every library was byte-compared with its ZIP entry, including the libqpdf
SONAME link. The receipt is retained in `T75-delivery/recorder-r2`.
Independent original controls alter task-owned wrapper/configuration paths,
GNU build-id metadata or two qpdf job entry points in a copied library.
Raw observations, source identities and exact byte-edit reconstruction recipes
are retained; the external ELF payloads are omitted from review archives.
These controls and the observer fixes introduce no runtime dependency or
change to the existing tool pins and license notices.

The independent content predicates reuse the original bounded literal reader
with explicit PDF name/comment/value rules, keeping PostScript CMap parsing
separate. Sources are ISO 32000-1 §§7.2–7.3, 7.8.3, 8.2 Figure 9, 8.4.2,
8.10, 9.3–9.4 and 14.6–14.7. Type3 rectangular glyph-body checks use
§§8.5.2–8.5.3 and 9.6.5 Tables 112–113; exact rational bounds and the specified
all-zero FontBBox behavior are original implementation work. Other glyph
graphics and multi-contour winding analysis remain outside qualification.
The controls modify only the project's original PDF objects/programs, without
using Folio parsing or rendering to determine expected outcomes. These are
Apache-2.0 acceptance-only contributions, with no product runtime changes.

Content review also consulted the approved PDF 2.0 corrections to
[§§7.2.2, 7.8.2–7.8.3](https://pdf-issues.pdfa.org/32000-2-2020/clause07.html)
and [Table 93](https://pdf-issues.pdfa.org/32000-2-2020/clause08.html),
and qpdf's public [JSON v2 name representation](https://qpdf.readthedocs.io/en/12.4/json.html).
Original byte-preserving resource lookup, PDF brace lexing, paired graphics/
marked nesting and local Form resource checks were written from these
specifications. No external implementation was copied. Legacy Form resource
inheritance remains explicitly outside this acceptance profile; selected
font-state inheritance is separately observed through legal original inputs.

The original structure hierarchy predicates follow ISO 32000-1 §§14.7.2,
14.9.2–14.9.4 and Tables 322–323, with PDF 2.0 Tables 354–355 corrections.
Independent review of optional K null consulted the general §§7.3.7/7.3.9
dictionary omission rule and the PDF Association's public issues
[157](https://github.com/pdf-association/pdf-issues/issues/157) and
[308](https://github.com/pdf-association/pdf-issues/issues/308). The latter
approved correction concerns null array children. These sources support
preserving optional dictionary-null equivalence without inventing a raw-byte
conformance predicate. Exact assessments and the original failing test
expectations remain in `T75-delivery/standards-r11`.

Original ParentTree predicates use ISO 32000-1 §7.9.7 Table 37 and
§14.7.4.4 Tables 322/326, including ordered integer keys, descendant ranges,
indirect structural parent values and optional NextKey. Namespace declaration
predicates use PDF 2.0 §14.7.4 and Tables 354–355, cross-checked with the pinned
Arlington Namespace, ArrayOfNamespace and RoleMapNS declarations. Their
qualification covers declared types and identity edges, without claiming
complete Tagged PDF role resolution. Independent original malformed PDFs
exposed stream/dictionary conflation, missing indirect parent identity,
empty element K arrays and an optional NextKey type bypass. The fixes use
qpdf's retained object kinds and the normative declarations, including
[PDF 2.0 Catalog Table 29](https://pdf-issues.pdfa.org/32000-2-2020/clause07.html#H7.7.2).
ISO 32000-1 does not impose the same indirect-root declaration; its empty
direct root remains a legal control. Both original review trees are archived
with every member read back and verified against its original bytes.

The subsequent original structure-content predicates use ISO 32000-1
§14.7.4.1–14.7.4.4 Tables 324–326 for typed references, MCID definitions,
ParentTree backlinks, content leaves and Form invocation restrictions.
Annotation membership and appearance ownership use §12.5.5 Table 168 and
the annotation page relationship. Unexecuted definition traversal reuses the
independent acceptance PDF tokenizer; no Folio or fixture-authoring code is
imported by the observer. Its original small PDF controls use literal
structure/stream objects with exact byte lengths and xrefs. Independent
hierarchy/namespace closure archives retain 53 Standards and 116 Spec CLI
observations, all with stable input and tool identities; the later content
scope is a separate review increment.

Content review additionally uses Form Table 95 for optional Type and
annotation Tables 164–165 for page backlinks and visibility flags. Original
independent controls distinguish actual page calls, normal AP roots,
alternative appearances, hidden appearances and unknown AP font state.
Page-selected fonts are not used as an oracle for independent appearance
validation. Frozen snapshots, literal controls and byte-verified raw review
archives remain under `T75-delivery/standards-r12`; declaration aggregation
continues to execute the already qualified pdfcpu/Arlington checks and their
334 original negative controls through the public recorder CLI.

The Foundation text collector is original repository-only Python code. Its
protocol tests synthesize reports rather than claiming PDF/tool qualification.
The four PNG protocol fixtures are byte-for-byte copies of the project-authored
Java raster controls retained in the R5 evidence tree; their original locations
and hashes are recorded in `scripts/tests/fixtures/t13-foundation/origins.json`.
The collector's bounded PNG sample decoder uses Python's existing standard
library and an original implementation of PNG reconstruction. Review consulted
the W3C [PNG Third Edition, sections 9 and 11.3.1.1](https://www.w3.org/TR/2025/REC-png-3-20250624/)
for filter reconstruction and transparent-color semantics. No W3C example code
was copied. The qualified control format permits only opaque, noninterlaced
RGB8 IHDR/IDAT/IEND data and verifies the exact project-authored pixel changes.
It does not add a product image decoder or a runtime dependency. Original
RED/GREEN observations and independent reviews are retained under
`T75-delivery/recorder-r6`.
