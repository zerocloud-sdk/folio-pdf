from pathlib import Path
import json,hashlib,datetime,sys
p=Path(__file__).parent
name='archive-manifest.json'
def write(n,v):(p/n).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
command={'command':[sys.executable,'-B',str(p/'archive-manifest.py')],'cwd':str(p),'started-utc':started,'script-sha256':sha(p/'archive-manifest.py'),'scope':'Own /tmp archive inventory only; no project commands or modifications'}
write('archive-manifest-command.json',command)
assert not (p/name).exists(),'Do not overwrite an existing manifest'
receipt=json.loads((p/'receipt.json').read_bytes())
assert sha(p/'report.md')==receipt['report']['sha256']
for row in json.loads((p/'source-copy-identities.json').read_bytes()):assert sha(p/row['copy'])==row['sha256']
for row in json.loads((p/'source-contract-scope-inspection.json').read_bytes())['baseline-observations']:assert sha(p/row['baseline-copy'])==row['baseline-sha256']
for f in p.rglob('*'):assert not f.is_symlink(),str(f)
write('archive-manifest-result.json',dict(command,returncode=0,completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),report_sha256=sha(p/'report.md'),receipt_sha256=sha(p/'receipt.json'),all_retained_source_and_baseline_copies_verified=True))
rows=[]
for f in sorted(p.rglob('*')):
 if f.is_file() and f.name!=name:rows.append({'path':f.relative_to(p).as_posix(),'sha256':sha(f),'bytes':f.stat().st_size})
write(name,{'schema-version':1,'review-directory':str(p),'excludes-itself-explicitly':True,'excluded':[name],'member-count':len(rows),'total-bytes':sum(r['bytes'] for r in rows),'members':rows})
print(json.dumps({'directory':str(p),'report-sha256':sha(p/'report.md'),'receipt-sha256':sha(p/'receipt.json'),'manifest-sha256':sha(p/name),'members-excluding-manifest':len(rows),'total-retained-bytes-excluding-manifest':sum(r['bytes'] for r in rows)}))
