from auditlib import *
import datetime
receipt={'created-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'The final two JDK21 tuples are immutable; actual outer publication remains unobserved.','completed-last-two':[]}
for m in ['in_process','hardened_worker']:
 d=ROOT/('jdk21-'+m);rr=[]
 for c in ['syntax','standards','semantic','visual']:
  f=d/(c+'.yaml');v=obj(f);eq(v['result'],'pass','actual lowercase schema '+str(f));rr.append({'path':str(f),'sha256':sha(f),'actual-result':v['result']})
 receipt['completed-last-two'].append({'tuple':d.name,'records':rr})
f=ROOT/'observed-index.json';receipt['observed-index']={'path':str(f),'sha256':sha(f)};receipt['actual-outer-result-exists']=Path('/tmp/t75-final-metadata-certify-r3-result.json').exists()
receipt['reader-diagnostic-closure']={'original':str(OUT/'scope-amendment-reader-diagnostic.txt'),'original-sha256':sha(OUT/'scope-amendment-reader-diagnostic.txt'),'cause':'The reader used uppercase PASS; original record schema uses lowercase pass. All eight final-JDK records are lowercase pass. This was solely a reader predicate error; no project or original evidence was changed, no certification was rerun.'}
finish('all-eight-complete-scope-amendment.json',receipt)
