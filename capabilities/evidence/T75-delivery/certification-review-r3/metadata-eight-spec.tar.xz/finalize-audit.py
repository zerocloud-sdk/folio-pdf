from auditlib import *
import datetime
from collections import Counter
inspections=['stage-environment-contract-all-eight-inspection.json','metadata-first-six-evidence-inspection.json','metadata-last-two-evidence-inspection.json','complete-rgb-raster-inspection.json','complete-config-and-index-inspection.json','source-contract-scope-inspection.json','publication-inspection.json']
values={n:obj(OUT/n) for n in inspections}
for n,v in values.items():eq(v['errors'],[],'closed independent inspection '+n)
stage=values[inspections[0]];first=values[inspections[1]];last=values[inspections[2]];rgb=values[inspections[3]];config=values[inspections[4]];sc=values[inspections[5]];pub=values[inspections[6]]
originals=[];references=[]
for n in ['first-six-original-tuple-file-identities.json','last-two-original-tuple-file-identities.json']:originals+=obj(OUT/n)
for n in ['first-six-original-report-reference-identities.json','last-two-original-report-reference-identities.json']:references+=obj(OUT/n)
eq(len(originals),24448,'all eight exact physical source files');eq(len({r['path'] for r in originals}),len(originals),'no duplicate physical originals');eq(len(references),47240,'all record/report reference occurrences')
inputs={};read_manifests=sorted(OUT.glob('*-read-identities.json'))
for p in read_manifests:
 for r in obj(p):
  name=r['path']
  if name.startswith(str(OUT)+'/'):continue
  if name in inputs:eq(inputs[name]['sha256'],r['sha256'],'same inspected original across independent audits '+name)
  inputs[name]=r
mutable={str(Path('/tmp/t75-final-metadata-certify-r3.log'))};verified=[]
for name,r in sorted(inputs.items()):
 p=Path(name)
 if name in mutable:continue
 eq(sha(p),r['sha256'],'final unchanged original source '+name);verified.append(r)
for r in originals:eq(sha(REPO/r['path']),r['sha256'],'final physical tuple unchanged '+r['path'])
for major in [8,11,17,21]:
 for mode in ['in_process','hardened_worker']:
  name='jdk'+str(major)+'-'+mode;expected={r['path'] for r in originals if r['tuple']==name};actual={str(p.relative_to(REPO)) for p in (ROOT/name).rglob('*') if p.is_file()};eq(actual,expected,'complete unchanged source tree '+name)
copyset={Path(r['path']) for r in verified if Path(r['path']).is_relative_to(ROOT)}
for r in sc['baseline-observations']:copyset.add(REPO/r['source'])
for name in ['capabilities/profiles/T11-metadata','capabilities/profiles/T11-standards']:
 copyset.update(p for p in (REPO/name).rglob('*') if p.is_file())
for name in ['scripts/t03-foundation.py','docs/third-party/t03-standards-tools.md','build-tools/acceptance/arlington/README.md','build-tools/acceptance/arlington/t11-r1.patch','capabilities/foundation-environments.yaml','capabilities/foundation-release.yaml','capabilities/foundation-requirements.yaml','capabilities/facade-surface.yaml','capabilities/evidence/T75-delivery/final-delivery-review-r3/historical-facade-counts.md','capabilities/evidence/T75-delivery/final-candidate-r3/build-inputs.json','capabilities/evidence/T75-delivery/final-candidate-r3/t75-final-stage-r3-result.json','capabilities/evidence/T75-delivery/final-validation-r3/source-and-contract-inputs.json','scripts/t11-arlington-pin.properties','scripts/pdfcpu-pin.properties','scripts/qpdf-pin.properties','scripts/pdfium-pin.properties','scripts/imagemagick-pin.properties','scripts/imagemagick-runtime.sha256']:
 copyset.add(REPO/name)
for name in ['pdf-acceptance/src/main/java/net/zerocloud/pdf/acceptance/StandardsEvidenceCommand.java','pdf-acceptance/src/main/java/net/zerocloud/pdf/acceptance/ExternalProcess.java','pdf-document/src/main/java/net/zerocloud/pdf/HardenedWorkerEngine.java','pdf-document/src/main/java/net/zerocloud/pdf/HardenedWorkerMain.java']:
 copyset.add(REPO/name)
copyset.add(Path('/home/ubuntu/.codex/attachments/77353239-0dda-4ee1-b4bb-ce7fb3fa0f9b/pasted-text-1.txt'));copyset.add(Path('/tmp/t75-worker-batch-fix-98ncwne7/current-source-and-contract-inputs.json'))
for base in ['/tmp/t75-final-spec-pages-eight-btlle2s_','/tmp/t75-final-spec-pages-publication-y9t6trcf','/tmp/t75-final-spec-values-eight-64rr4_uc','/tmp/t75-final-spec-values-publication-vh2_ayq8','/tmp/t75-final-spec-transactions-eight-5yptf21z','/tmp/t75-final-spec-text-publication-du17bdo8']:
 for name in ['report.md','receipt.json']:copyset.add(Path(base)/name)
copies=[]
for p in sorted(copyset):
 b=read(p);rel=Path('originals/repository')/p.relative_to(REPO) if p.is_relative_to(REPO) else Path('originals/external-paths')/str(p).lstrip('/');dest=OUT/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b);h=hashlib.sha256(b).hexdigest();eq(hashlib.sha256(dest.read_bytes()).hexdigest(),h,'byte exact source copy '+str(p));copies.append({'path':str(p),'copy':str(rel),'sha256':h,'bytes':len(b)})
for row in pub['authority-snapshots']:
 b=(OUT/row['copy']).read_bytes();eq(hashlib.sha256(b).hexdigest(),row['sha256'],'preserved authority original snapshot');a=json.loads(b)
 for obligation in ['text','transactions','values','pages']:eq([c for c in a['certifications'] if c['obligation']==obligation],obj(REPO/('capabilities/evidence/T75-foundation-20260913-r3/'+obligation+'/observed-index.json'))['certifications'],'exact prior publication preserved '+obligation)
for r in pub['original-command'],pub['original-log-snapshot']:
 eq(hashlib.sha256((OUT/r['copy']).read_bytes()).hexdigest(),r['sha256'],'original outer command/log snapshot preserved')
current_output={str(r['path']):r for r in verified}
for r in files.values():
 if not r['path'].startswith(str(OUT)+'/') and r['path'] not in mutable:current_output[r['path']]=r
combined=sorted(current_output.values(),key=lambda r:r['path']);dump('inspected-input-identities.json',combined);dump('source-copy-identities.json',copies);dump('original-tuple-file-identities.json',originals);dump('original-record-report-reference-identities.json',references)
controls=[]
for n in ['first-six-standards-control-identities.json','last-two-standards-control-identities.json']:controls+=obj(OUT/n)
eq(len(controls),10880,'all standards controls in actual eight tuples');dump('all-standards-control-identities.json',controls)
counts={'actual-complete-tuples':8,'actual-formal-tests-per-tuple':73,'actual-Native-tests-per-tuple':62,'actual-Facade-IN_PROCESS-tests-per-tuple':9,'actual-artifact-test-classes-per-tuple':2,'physical-tuple-files':len(originals),'physical-files-per-tuple':3056,'observations-per-tuple':3044,'observed-nested-manifests-per-tuple':0,'T11-requires-nested-producer-manifests':False,'qualified-rule-union':170,'pdfcpu-rules':31,'Arlington-T11-core-rules':35,'Arlington-T11-metadata-rules':104,'retained-rule-control-executions':len(controls),'actual-product-PDFs':64,'positive-page-visual-records':192,'negative-page-visual-records':8,'original-complete-RGB-raster-observations':rgb['input-raster-observations'],'distinct-encoded-and-prescribed-RGB-pairs':rgb['distinct-encoded-and-prescribed-raster-pairs'],'report-reference-occurrences':sum(t['report-reference-count'] for t in first['tuples']+last['tuples']),'record-and-report-reference-occurrences':len(references),'configuration-inputs-per-tuple':177,'observed-tool-identities-per-environment':15,'before-after-environment-pairs':4,'current-Arlington-model-TSVs':613,'inspected-input-identities':len(combined),'source-copies':len(copies),'fixed-baseline-source-copies':len(sc['baseline-observations']),'actual-XML-scenarios':64,'actual-Worker-per-scenario-file-network-process-control-sets':16,'actual-host-file-network-observer-positive-control-sets':16,'actual-signed-rewrite-rejections':16,'full-corpus-property-count':rgb['complete-corpus-property-count']}
conclusion={'created-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'All eight complete T11/metadata original r3 observation tuples; read-only independent Spec audit. No other-obligation/whole-release/commit approval.','counts':counts,'source-inputs':stage['input-counts'],'observed-index-sha256':config['observed-index-sha256'],'metadata-publication-gate-closed':pub['metadata-eight-publication-gate-closed'],'deferred-gate':pub['deferred-gate'],'unchanged-originals-rehashed':len(verified),'prior-reviewed-raw-audits-replayed':False,'errors':errors};dump('final-integrity-inspection.json',conclusion)
if errors:raise ValueError('Independent final identity reconciliation failed; original diagnostic retained')
report='''CLEAN for the eight complete r3 metadata/T11 observation tuples; no actionable Spec finding.

Fixed baseline: `5b1603c435f11c40368f75b7b9a2777c9c5e9761`. Candidate: `e2dd9ebbeae5668ccc8e2985ccd8af17c8921d1ec5e12e0c913cbd1fa00dfbd6`; contract: `3de508f79fcbef7258feee8abc013d6f02b000840cac1cb263cb0d6f927b8f2b`.

The Goal requires “Refresh invalidated certifications rather than reusing stale hashes” and disallows added functionality during revalidation (original Goal:131–133). All 155 inspected T11 dedicated source, test, contract and fixture files remain byte-identical to baseline. All 1,933 source, 30 contract, 23 artifact and 24 harness identities match the reviewed r3 Worker correction and refreshed host/JDK validation.

Eight original suites actually pass 73 cases each: 62 selected-mode Native, nine actual IN_PROCESS Stable Facade, and two artifact classes. Exact classpaths, 177 configuration inputs, 15 tool identities and all four reconstructed BEFORE/AFTER environments agree. Formal 600-second and recorder 1,800-second guards remain unchanged. Preview coverage is artifact reflection; the nine Facade workflows do not claim Preview execution.

Read and hashed 24,448 tuple files, 32 records and 25,128 report references. Verified 64 public products and all 170 assigned rules (31 pdfcpu, 35 Arlington core, 104 Arlington metadata), with 10,880 original illegal-control/diagnostic pairs (docs/t11-certification.md:76–84,135–157). Separate non-PDF, five semantic mutations, signed-Source rejection and one-pixel controls all retain their required outcomes. Every byte of 612 decoded RGB inputs matches prescribed geometry and pixels, with zero AE/fuzz thresholds and per-file original PNG hashes (contract:17–22,105–109).

All 64 XML scenarios retain their safety results; every one of the 16 actual Worker scenarios has file, network and distinct-process controls from the same active Session after the candidate (contract:95–103; T11XmlSafetyProbe.java:229–270). Exact metadata, unknown values, navigation, payloads, declaration-order receipts, terminal split, caller ownership and Source/sibling isolation remain covered (contract:24–72,86–93; DocumentMetadataFacadeTest.java:264–460). The 64 MiB command and finite policy boundaries are unchanged (contract:113–116).

Reader casing/path diagnostics remain preserved with separate clean closures. Prior text/transactions/values/pages review identities and exact published subsets are unchanged. T11 requires no T13 producer manifests; zero were observed. Metadata actual outer exit and exact authority publication remain deferred. No all48, final-delivery or completion-criterion approval is given.
'''
assert len(report.split())<400
(OUT/'report.md').write_text(report)
def localref(name):
 p=OUT/name;b=p.read_bytes();return {'path':str(p),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
receipt={'created-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'verdict':'CLEAN; eight complete metadata observations reviewed, actual outer publication deferred','baseline':sc['baseline'],'candidate-sha256':stage['candidate-sha256'],'contract-sha256':stage['contract-sha256'],'report':localref('report.md'),'report-word-count':len(report.split()),'scope':localref('scope.json'),'complete-scope-amendment':localref('all-eight-complete-scope-amendment.json'),'inspections':[localref(n) for n in inspections],'integrity-inspection':localref('final-integrity-inspection.json'),'exact-inspected-counts':counts,'source-and-build-input-counts':stage['input-counts'],'original-observed-index-sha256':config['observed-index-sha256'],'tuple-observations':[{k:v for k,v in t.items() if k!='staged-classpath-paths'} for t in stage['tuples']],'input-identities':localref('inspected-input-identities.json'),'source-copy-identities':localref('source-copy-identities.json'),'all-original-physical-file-identities':localref('original-tuple-file-identities.json'),'all-original-record-report-reference-identities':localref('original-record-report-reference-identities.json'),'all-original-standard-control-identities':localref('all-standards-control-identities.json'),'original-reader-diagnostics-closure':localref('reader-diagnostic-closures.json'),'prior-closed-review-linkage':config['closed-prior-linkage'],'actual-publication':pub,'immutable-originals-unchanged':True,'active-outer-log-snapshots-preserved-separately':True,'no-project-command-or-renderer-executed':True,'only-review-files-written-under':str(OUT),'original-reader-history-preserved':True,'other-obligations-all48-or-final-delivery-approved':False,'completion-criteria-marked':False,'archive-manifest-policy':'archive-manifest.json is generated after this finalizer and its actual wrapper result complete. It lists every retained regular review file and explicitly excludes itself.'};dump('receipt.json',receipt)
print(json.dumps({'report-sha256':receipt['report']['sha256'],'report-words':receipt['report-word-count'],'receipt-sha256':hashlib.sha256((OUT/'receipt.json').read_bytes()).hexdigest(),'counts':counts,'publication-deferred':not pub['metadata-eight-publication-gate-closed'],'errors':errors}))
