from pathlib import Path
import json,subprocess,sys,datetime,hashlib
out=Path(__file__).parent
name=sys.argv[1]
allowed={'stage-audit.py','reference-audit.py','qualification-audit.py','chain-controls-audit.py','report-coverage-audit.py','raster-controls-audit.py','source-copy-audit.py'}
if name not in allowed:raise ValueError('Read-only audit script not authorized')
command=[sys.executable,'-B',str(out/name)]
meta={'command':command,'cwd':str(out),'started-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'script-sha256':hashlib.sha256((out/name).read_bytes()).hexdigest(),'scope':'independent read-only source and original-evidence inspection, not project tool/test execution'}
prefix=name.removesuffix('.py')
(out/(prefix+'-command.json')).write_text(json.dumps(meta,indent=2)+'\n')
with (out/(prefix+'-output.txt')).open('wb') as log: result=subprocess.run(command,cwd=out,stdout=log,stderr=subprocess.STDOUT)
meta.update({'returncode':result.returncode,'completed-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stdout-stderr-sha256':hashlib.sha256((out/(prefix+'-output.txt')).read_bytes()).hexdigest()})
(out/(prefix+'-result.json')).write_text(json.dumps(meta,indent=2)+'\n')
print((out/(prefix+'-output.txt')).read_text())
print(json.dumps(meta))
sys.exit(result.returncode)
