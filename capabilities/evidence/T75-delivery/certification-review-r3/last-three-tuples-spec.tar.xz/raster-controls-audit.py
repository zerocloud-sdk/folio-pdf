from auditlib import *
import zlib,struct
prior=Path('/tmp/t75-final-spec-r3-three-tuples-smdhs3w8/raster-control-method-closure.json');previous=obj(prior);eq(previous['errors'],[],'prior decoded-RGB method closure');eq(previous['all-original-diagnostics-accounted-for'],True,'prior original diagnostics retained and closed');case_names=['edge-only','missing-glyph','interior-hole','outside-ink'];expected_metrics={'edge-only':(1,0),'missing-glyph':(432,308),'interior-hole':(1,1),'outside-ink':(1,1)}
def rgb(p):
 data=read(p);eq(data[:8],b'\x89PNG\r\n\x1a\n',str(p)+' PNG signature');eq(len(data)<=4*1024*1024,True,str(p)+' encoded byte bound');pos=8;chunks=[];compressed=[];width=height=None
 while pos<len(data):
  length=int.from_bytes(data[pos:pos+4],'big');kind=data[pos+4:pos+8];payload=data[pos+8:pos+8+length];crc=data[pos+8+length:pos+12+length];eq(len(payload),length,str(p)+' chunk byte length');eq(zlib.crc32(kind+payload)&0xffffffff,int.from_bytes(crc,'big'),str(p)+' original chunk CRC');eq(kind in [b'IHDR',b'IDAT',b'IEND'],True,str(p)+' opaque control chunk kinds');chunks.append({'kind':kind.decode(),'length':length})
  if kind==b'IHDR':
   width,height,depth,color,compression,filtering,interlace=struct.unpack('>IIBBBBB',payload);eq([width,height,depth,color,compression,filtering,interlace],[240,200,8,2,0,0,0],str(p)+' fixed opaque RGB8 control format')
  elif kind==b'IDAT':compressed.append(payload)
  elif kind==b'IEND':eq(length,0,str(p)+' empty final IEND');eq(pos+12,len(data),str(p)+' complete PNG bytes');break
  pos+=length+12
 eq(chunks[0]['kind'],'IHDR',str(p)+' first chunk');eq(chunks[-1]['kind'],'IEND',str(p)+' terminal chunk');stride=width*3;expected=height*(stride+1);inflater=zlib.decompressobj();decoded=inflater.decompress(b''.join(compressed),expected+1);eq(len(decoded),expected,str(p)+' exact decoded scanline bound');eq(inflater.eof and not inflater.unused_data and not inflater.unconsumed_tail,True,str(p)+' complete bounded zlib stream');pixels=bytearray(width*height*3)
 for y in range(height):
  start=y*(stride+1);f=decoded[start];eq(f in range(5),True,str(p)+' PNG filter');row=decoded[start+1:start+1+stride]
  for x,val in enumerate(row):
   offset=y*stride+x;a=pixels[offset-3] if x>=3 else 0;b=pixels[offset-stride] if y else 0;c=pixels[offset-stride-3] if y and x>=3 else 0
   if f==0:predictor=0
   elif f==1:predictor=a
   elif f==2:predictor=b
   elif f==3:predictor=(a+b)//2
   else:
    base=a+b-c;da,db,dc=abs(base-a),abs(base-b),abs(base-c);predictor=a if da<=db and da<=dc else b if db<=dc else c
   pixels[offset]=(val+predictor)&255
 return bytes(pixels),{'path':str(p.relative_to(REPO)),'encoded-sha256':sha(p),'encoded-bytes':len(data),'decoded-rgb-sha256':hashlib.sha256(pixels).hexdigest(),'width':width,'height':height,'chunks':chunks}
ref=ROOT/'jdk8-in_process/observations/negative/visual/raster';original,originalrecord=rgb(ref/'original.png');reference={}
for name in case_names:reference[name]=rgb(ref/name/'secondary.png')
records=[]
for major,mode in TUPLES:
 tuple_name='jdk'+str(major)+'-'+mode.lower();d=ROOT/tuple_name/'observations/negative/visual/raster';actualoriginal,originaldata=rgb(d/'original.png');eq(actualoriginal,original,tuple_name+' unchanged original reference pixels');eq(originaldata['encoded-sha256'],originalrecord['encoded-sha256'],tuple_name+' frozen original authority bytes')
 for name in case_names:
  pixels,record=rgb(d/name/'secondary.png');expected=bytearray(original)
  positions=[(20,136)] if name=='edge-only' else [(23,139)] if name=='interior-hole' else [(1,1)] if name=='outside-ink' else [(x,y) for y in range(135,161) for x in range(19,37)]
  for x,y in positions:offset=(y*240+x)*3;expected[offset:offset+3]=b'\x00\x00\x00' if name=='outside-ink' else b'\xff\xff\xff'
  eq(pixels,bytes(expected),tuple_name+'/'+name+' entire prescribed RGB defect');eq(pixels,reference[name][0],tuple_name+'/'+name+' identical qualified JDK8 decoded control');changed=sum(pixels[i:i+3]!=original[i:i+3] for i in range(0,len(original),3));eq(changed,expected_metrics[name][0],tuple_name+'/'+name+' independent changed-pixel count');observed=props(d/name/'result.properties');eq(observed,{'profile':'T13-text-logical-structure-embedded-font-kinds-page-1','raster-agreement':'pass' if name=='edge-only' else 'fail','primary-sha256':originaldata['encoded-sha256'],'secondary-sha256':record['encoded-sha256'],'changed-pixels':str(expected_metrics[name][0]),'outside-edge-pixels':str(expected_metrics[name][1])},tuple_name+'/'+name+' retained own-byte identity and qualified metric');records.append({'tuple':tuple_name,'control':name,**record,'reference-jdk8-encoded-sha256':reference[name][1]['encoded-sha256'],'same-decoded-RGB-as-qualified-JDK8':pixels==reference[name][0],'entire-prescribed-defect-matches':pixels==bytes(expected),'independently-observed-changed-RGB-pixels':changed,'recorded-outside-edge-pixels':observed['outside-edge-pixels']})
finish('complete-raster-control-inspection.json',{'scope':'Independent read-only complete decoded RGB and original raw SHA inspection for the 12 controls of the final three r3 text tuples.','prior-review-method-closure':{'path':str(prior),'sha256':sha(prior),'original-diagnostics-preserved-and-closed':True},'reference-raster':originalrecord,'controls':records,'original-project-evidence-modified':False,'project-collector-renderer-or-pixel-tool-executed':False,'independent-decoding':'Only retained opaque RGB8 PNG bytes were parsed with CRC, bounded decompression and filter checks. Entire RGB compared with prescribed defects and qualified JDK8 pixels; no rendered or edited images.'})
