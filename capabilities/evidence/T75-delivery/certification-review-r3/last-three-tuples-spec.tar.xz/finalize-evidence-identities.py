from pathlib import Path
import json,hashlib,datetime,yaml
OUT=Path(__file__).parent
REPO=Path('/home/ubuntu/IdeaProjects/open-pdf')
ROOT=REPO/'capabilities/evidence/T75-foundation-20260913-r3/text'
errors=[]
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def write(n,v):
 p=OUT/n
 if p.exists():raise ValueError('Historical output already exists '+str(p))
 p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
def check(p,expected):
 got=sha(p)
 if got!=expected:errors.append({'path':str(p),'expected':expected,'actual':got})
 return {'path':str(p),'sha256':got,'bytes':p.stat().st_size,'unchanged-after-audit':got==expected}
identities={};conflicts=[]
for f in sorted(OUT.glob('*read-identities.json'))+[OUT/'source-copy-identities.json']:
 for row in json.loads(f.read_text()):
  key=row['path'];prior=identities.get(key)
  if prior and (prior['sha256'],prior['bytes'])!=(row['sha256'],row['bytes']):conflicts.append({'path':key,'first':prior,'second':row})
  if not prior:identities[key]={'path':key,'sha256':row['sha256'],'bytes':row['bytes'],'observed-by':[]}
  identities[key]['observed-by'].append(f.name)
  if 'copy' in row:
   identities[key]['copy']=row['copy'];check(OUT/row['copy'],row['sha256'])
errors.extend(conflicts)
stagepath=REPO/'capabilities/evidence/T75-delivery/final-candidate-r3/build-inputs.json';build=json.loads(stagepath.read_text());check(stagepath,'edc129bd06eb5ee6ac00c4653173a524f72367f73ac1c14f040f8f5c9eb8aa70');groups=[]
for name,rows in [('sources',build['candidate']['inputs']),('contracts',build['contract-inputs']),('artifacts',build['candidate']['artifacts']),('harness',build['harness'])]:
 start=len(errors)
 for row in rows:check(REPO/row['path'],row['sha256'])
 groups.append({'group':name,'count':len(rows),'mismatches':errors[start:]})
endrows=[]
for major in [8,11,17,21]:
 for mode in ['in_process','hardened_worker']:
  scope=ROOT/('jdk'+str(major)+'-'+mode)
  for suffix in ['execution.yaml','syntax.yaml','standards.yaml','semantic.yaml','visual.yaml','syntax-report.json','standards-report.json','semantic-report.json','visual-report.json','observations/retained-files.sha256','observations/result.properties','contract-tests.txt','contract-tests-command.json']:
   p=scope/suffix;endrows.append(check(p,identities[str(p)]['sha256']))
envrows=[]
for major in [8,11,17,21]:
 for suffix in ['','-after']:
  for p in sorted((ROOT/('jdk'+str(major)+'-environment'+suffix)).iterdir()):
   if p.is_file():envrows.append(check(p,identities[str(p)]['sha256']))
index=ROOT/'observed-index.json';check(index,'53c201c9ce9ab815171438f9712b40752ccb9adef58280dfe16959f7f8e5eb9e')
authoritypath=REPO/'capabilities/foundation-evidence.yaml';authoritybytes=authoritypath.read_bytes();authority=yaml.safe_load(authoritybytes);snapshot=OUT/'end-of-evidence-review-authority.yaml';snapshot.write_bytes(authoritybytes)
authoritystate={'path':str(authoritypath),'copy':snapshot.name,'sha256':hashlib.sha256(authoritybytes).hexdigest(),'bytes':len(authoritybytes),'text-certification-count':len([c for c in authority['certifications'] if c['obligation']=='text']),'other-obligation-certification-count':len([c for c in authority['certifications'] if c['obligation']!='text']),'interpretation':'Authority may atomically publish this text obligation and later gain other obligations. No global unchanged-baseline assertion applies; publication closure is separate.'}
write('inspected-source-sha256.json',list(identities[k] for k in sorted(identities)))
result={'at-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cross-audit-identity-conflicts':conflicts,'final-input-groups':groups,'final-eight-tuple-envelope-identities':endrows,'final-eight-environment-raw-identities':envrows,'authority-observation':authoritystate,'outer-result-exists-at-evidence-close':Path('/tmp/t75-final-text-certify-r3-result.json').exists(),'outer-exit-and-publication-approved':False,'unique-inspected-paths':len(identities),'original-small-copies':len(json.loads((OUT/'source-copy-identities.json').read_text())),'errors':errors}
write('end-of-evidence-review-identities.json',result)
print(json.dumps({'unique-inspected-paths':len(identities),'groups':groups,'tuple-final-checks':len(endrows),'environment-final-checks':len(envrows),'small-original-copies':result['original-small-copies'],'errors':len(errors),'outer-result-exists':result['outer-result-exists-at-evidence-close'],'authority-text-count':authoritystate['text-certification-count']}))
if errors:raise SystemExit(1)
