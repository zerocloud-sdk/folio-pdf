from sourcecopylib import *
old=Path('/tmp/t75-final-spec-r3-three-tuples-smdhs3w8')
paths=[]
for row in obj(old/'source-copy-identities.json'):
 p=row['path']
 if p==str(REPO/'capabilities/foundation-evidence.yaml'):continue
 for a,b in [('jdk11-in_process','jdk17-hardened_worker'),('jdk11-hardened_worker','jdk21-in_process'),('jdk17-in_process','jdk21-hardened_worker'),('jdk11-environment','jdk21-environment')]:
  if p.startswith(str(ROOT)+'/'):p=p.replace('/'+a+'/', '/'+b+'/')
 paths.append(Path(p))
for n in ['report.md','receipt.json','end-of-review-identities.json','complete-reference-inspection.json','raster-control-method-closure.json','separate-chain-control-inspection.json','jdk17-after-environment-closure.json']:
 paths.append(old/n)
for name in ['jdk17-environment','jdk17-environment-after','jdk21-environment','jdk21-environment-after']:
 paths.extend(p for p in sorted((ROOT/name).iterdir()) if p.is_file())
paths.extend(ROOT/n for n in ['observed-index.json','identities.json','prior-index.sha256'])
for p in ['/tmp/t75-final-spec-6avdtb8v/report.md','/tmp/t75-final-spec-crosspage-closure-p2k77wkr/report.md','/tmp/t75-final-spec-observer-closure-f22wcurv/report.md','/tmp/t75-final-spec-git-retention-fm7yf1sg/report.md']:
 paths.append(Path(p))
rows=[]
for p in sorted(set(paths)):
 b=read(p)
 relative=Path('sources/repo')/p.relative_to(REPO) if p.is_relative_to(REPO) else Path('sources/external')/p.as_posix().lstrip('/')
 destination=OUT/relative;destination.parent.mkdir(parents=True,exist_ok=True);eq(destination.read_bytes(),b,'earlier identical partial copy '+str(destination)) if destination.exists() else destination.write_bytes(b)
 rows.append({'path':str(p),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'copy':relative.as_posix()})
dump('source-copy-identities.json',rows)
finish('source-copy-completion-inspection.json',{'original-copies':len(rows),'copy-directory':'sources','original-bytes-preserved':True,'initial-copy-attempt':{'path':str(OUT/'source-copy-audit-result.json'),'sha256':sha(OUT/'source-copy-audit-result.json'),'classification':'Review copy-reader allowlist omitted the already authorized identities.json/prior-index.sha256 index metadata. Guard stopped the copy only; corrected separate reader permits exactly those two names. No project failure or repository mutation.'}})
