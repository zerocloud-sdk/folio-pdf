from linkauditlib import *
from collections import Counter
import datetime,ast
prior_specs=[(Path('/tmp/t75-final-spec-r3-two-tuples-_xr8bj_5'),'a3b4c9767d5c1cd6619fb34890c2f29c4a60f4e5d4aa88ecdc5666a3a3d59baa','39d01f29952d3b18c8ac0e0bcb6f58a9c8efdf4d0005113e9e4d536a48880a4c'),(Path('/tmp/t75-final-spec-r3-three-tuples-smdhs3w8'),'928d8d32a554e571550319637f279aac5470d40a3ad5f7b1eb382f99b24cfccb','bdc9df75d1acb62dbb20305e3bc5d5c3be661d494fc14b3b59f0565e951840df')]
prior_scopes={'jdk8-in_process','jdk8-hardened_worker','jdk11-in_process','jdk11-hardened_worker','jdk17-in_process','jdk8-environment','jdk8-environment-after','jdk11-environment','jdk11-environment-after','jdk17-environment','jdk17-environment-after'}
expected={};prior_reports=[]
for folder,reporthash,receipthash in prior_specs:
 eq(sha(folder/'report.md'),reporthash,'frozen previous report');eq(sha(folder/'receipt.json'),receipthash,'frozen previous receipt')
 receipt=obj(folder/'receipt.json');rows=obj(folder/'inspected-source-sha256.json')
 if 'input-identities' in receipt:eq(sha(folder/'inspected-source-sha256.json'),receipt['input-identities']['sha256'],'prior input identities receipt')
 eq(receipt.get('candidate',receipt.get('candidate-sha256')),'e2dd9ebbeae5668ccc8e2985ccd8af17c8921d1ec5e12e0c913cbd1fa00dfbd6','previous candidate lineage');eq(receipt.get('contract',receipt.get('contract-sha256')),'3de508f79fcbef7258feee8abc013d6f02b000840cac1cb263cb0d6f927b8f2b','previous contract lineage')
 for row in rows:
  p=Path(row['path'])
  if p.is_relative_to(ROOT) and p.relative_to(ROOT).parts[0] in prior_scopes:
   if str(p) in expected:eq(expected[str(p)],row['sha256'],'prior review common original identity '+str(p))
   expected[str(p)]=row['sha256']
 prior_reports.append({'report-path':str(folder/'report.md'),'report-sha256':reporthash,'receipt-sha256':receipthash,'input-manifest-sha256':sha(folder/'inspected-source-sha256.json')})
counts=Counter()
for name,h in sorted(expected.items()):
 p=Path(name);eq(sha(p),h,'previously reviewed original remains byte-exact '+name);counts[p.relative_to(ROOT).parts[0]]+=1
stage=obj(OUT/'stage-environment-contract-inspection.json');current=obj(OUT/'complete-reference-inspection.json');eq(current['errors'],[],'last three complete original reference inspection');eq(stage['errors'],[],'last three environment/config/contract inspection')
index=obj(ROOT/'observed-index.json');build=obj(REPO/'capabilities/evidence/T75-delivery/final-candidate-r3/build-inputs.json');identities=obj(ROOT/'identities.json');eq(identities,{'Candidate':stage['candidate-sha256'],'Contract':stage['contract-sha256']},'actual observed identities')
eq(sha(ROOT/'observed-index.json'),sha(OUT/'initial-publication-observations/observed-index.json'),'complete observed index immutable during review')
def ref(p):return {'path':str(p.relative_to(REPO)),'sha256':sha(p)}
tree=ast.parse(read(REPO/'scripts/t03-foundation.py').decode());literalcase=next(n.value for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='CERTIFICATION_CASES' for t in n.targets));case=ast.literal_eval(next(v for k,v in zip(literalcase.keys,literalcase.values) if ast.literal_eval(k)=='text'))
classpath=':'.join('/workspace/'+p for p in stage['tuples'][0]['staged-classpath-paths']);configuration_inputs=obj(ROOT/'jdk17-hardened_worker/execution.yaml')['inputs'];testclasses=case['test-classes']+['net.zerocloud.pdf.migration.itext7.contract.JarContractIT','net.zerocloud.pdf.migration.itext7.contract.ClasspathExclusivityIT']
commandobservations=[]
def exact_commands(scope,mode,environment,configuration_sha):
 inside='/workspace/'+str(scope.relative_to(REPO));image=environment['identity']['image'];options=['-Xmx1024m','-Duser.language=en','-Duser.country=US','-Duser.timezone=UTC','-Dfolio.harfBuzzHelper=/folio-harfbuzz/bin/folio-harfbuzz','-Dfolio.t13.executionProfile='+mode]
 command=['podman','run','--rm','--network=none','--userns=keep-id','--volume',str(REPO)+':/workspace:ro','--volume',str(REPO/'.build-cache/harfbuzz/10.2.0-final')+':/folio-harfbuzz:ro','--volume','/usr/bin/python3.12:/usr/bin/python3.12:ro','--volume','/usr/lib/python3.12:/usr/lib/python3.12:ro','--volume',str(Path('/lib/x86_64-linux-gnu/libexpat.so.1').resolve())+':/lib/x86_64-linux-gnu/libexpat.so.1:ro','--workdir','/workspace','--env','LANG=C.UTF-8','--env','LC_ALL=C.UTF-8','--env','TZ=UTC','--env','FOLIO_HARFBUZZ_HELPER=/folio-harfbuzz/bin/folio-harfbuzz','--volume',str(scope)+':'+inside+':rw',image]
 recorder=command+['java']+options+['-cp',classpath,'net.zerocloud.pdf.acceptance.T13EvidenceCommand','/workspace',inside+'/observations',mode,'0.1.0']
 testoptions=['-DrepositoryRoot=/workspace','-DartifactPath=/workspace/target/foundation-0.1.0/artifacts/pdf-migration-itext7-preview-0.1.0.jar','-DstableArtifactPath=/workspace/target/foundation-0.1.0/artifacts/pdf-migration-itext7-0.1.0.jar','-DdocumentArtifactPath=/workspace/target/foundation-0.1.0/artifacts/pdf-document-0.1.0.jar','-DtestClassesPath=/workspace/target/foundation-0.1.0/harness/facade-tests.jar']
 tests=command+['java']+options+testoptions+['-cp',classpath,'org.junit.runner.JUnitCore']+testclasses
 config=obj(scope/'execution.yaml');eq(config,{'schema-version':1,'candidate-sha256':stage['candidate-sha256'],'environment-sha256':configuration_sha,'acceptance-profile':case['profile'],'execution-profile':mode,'command':recorder,'java-options':options,'locale':'en_US / C.UTF-8','timezone':'UTC','settings':{'workflow-policy':case['workflow-policy'],'fonts':case['fonts'],'providers':'none; Stable Facade execution is IN_PROCESS'},'inputs':configuration_inputs},scope/'complete configuration and recorder arguments')
 eq(obj(scope/'contract-tests-command.json'),tests,scope/'complete actual formal test arguments');commandobservations.append({'tuple':scope.name,'recorder-arguments':len(recorder),'contract-arguments':len(tests),'java-options':options,'actual-native-mode':mode,'actual-facade-mode':'IN_PROCESS','complete-command-arrays-match':True})
environments=[];certifications=[];tuple_records=[]
for major in [8,11,17,21]:
 env='ubuntu-24.04-linux-x86-64-jdk'+str(major);ep=ROOT/('jdk'+str(major)+'-environment/environment.yaml');er=ref(ep);environments.append({'profile':env,'record':er})
 for mode in ['IN_PROCESS','HARDENED_WORKER']:
  name='jdk'+str(major)+'-'+mode.lower();scope=ROOT/name;configuration=ref(scope/'execution.yaml');records=[];exact_commands(scope,mode,obj(ep),er['sha256'])
  for chain in ['syntax','standards','semantic','visual']:
   p=scope/(chain+'.yaml');r=obj(p);subset(r,{'obligation':'text','chain':chain,'result':'pass','candidate-sha256':stage['candidate-sha256'],'contract-sha256':stage['contract-sha256'],'execution-profile':mode,'environment-sha256':er['sha256'],'execution-configuration-sha256':configuration['sha256']},name+' original index record');records.append(ref(p))
  certification={'obligation':'text','environment':env,'execution-profile':mode,'configuration':configuration,'records':records};certifications.append(certification);tuple_records.append({'tuple':name,'configuration-sha256':configuration['sha256'],'record-sha256':[r['sha256'] for r in records]})
eq(index,{'schema-version':1,'candidate':build['candidate'],'environments':environments,'certifications':certifications},'exact complete eight-tuple observed text index')
finish('eight-tuple-review-linkage-inspection.json',{'at-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'prior-reviews':prior_reports,'prior-reviewed-original-files-rehashed':len(expected),'prior-scope-rehash-counts':dict(sorted(counts.items())),'last-three-reference-inspection-sha256':sha(OUT/'complete-reference-inspection.json'),'observed-index-sha256':sha(ROOT/'observed-index.json'),'candidate-sha256':stage['candidate-sha256'],'contract-sha256':stage['contract-sha256'],'exact-text-tuple-count':len(certifications),'exact-chain-record-count':sum(len(c['records']) for c in certifications),'tuples':tuple_records,'exact-complete-command-observations':commandobservations,'complete-eight-evidence-review-linked':True,'outer-exit-and-publication-conclusion':'Deferred to separate original outer result and current authority text-subset inspection','all48-or-finaldelivery-approved':False})
