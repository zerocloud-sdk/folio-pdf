from auditlib import *
import datetime
from collections import Counter
inspections=['stage-environment-contract-all-eight-inspection.json','pages-first-six-evidence-inspection.json','pages-last-two-evidence-inspection.json','complete-rgb-raster-inspection.json','complete-config-and-index-inspection.json','source-contract-inspection.json','publication-inspection.json']
values={n:obj(OUT/n) for n in inspections}
for n,v in values.items():eq(v['errors'],[],'closed independent inspection '+n)
stage=values[inspections[0]];first=values[inspections[1]];last=values[inspections[2]];rgb=values[inspections[3]];config=values[inspections[4]];sc=values[inspections[5]];pub=values[inspections[6]]
originals=[];references=[]
for n in ['first-six-original-tuple-file-identities.json','last-two-original-tuple-file-identities.json']:originals+=obj(OUT/n)
for n in ['first-six-original-report-reference-identities.json','last-two-original-report-reference-identities.json']:references+=obj(OUT/n)
eq(len(originals),13424,'all eight exact physical source files');eq(len({r['path'] for r in originals}),len(originals),'no duplicate physical originals');eq(len(references),24960,'all record/report reference occurrences')
inputs={};read_manifests=sorted(OUT.glob('*-read-identities.json'))
for p in read_manifests:
 for r in obj(p):
  name=r['path']
  if name.startswith(str(OUT)+'/'):continue
  if name in inputs:eq(inputs[name]['sha256'],r['sha256'],'same inspected original across independent audits '+name)
  inputs[name]=r
mutable={str(Path('/tmp/t75-final-pages-certify-r3.log'))};verified=[]
for name,r in sorted(inputs.items()):
 p=Path(name)
 if name in mutable:continue
 eq(sha(p),r['sha256'],'final unchanged original source '+name);verified.append(r)
for r in originals:eq(sha(REPO/r['path']),r['sha256'],'final physical tuple unchanged '+r['path'])
for major in [8,11,17,21]:
 for mode in ['in_process','hardened_worker']:
  name='jdk'+str(major)+'-'+mode;expected={r['path'] for r in originals if r['tuple']==name};actual={str(p.relative_to(REPO)) for p in (ROOT/name).rglob('*') if p.is_file()};eq(actual,expected,'complete unchanged source tree '+name)
copyset={Path(r['path']) for r in verified if Path(r['path']).is_relative_to(ROOT)}
for r in sc['unchanged-baseline-source-documents']:copyset.add(REPO/r['source'])
for name in ['capabilities/profiles/T10-pages','capabilities/profiles/T10-standards']:
 copyset.update(p for p in (REPO/name).rglob('*') if p.is_file())
for name in ['scripts/t03-foundation.py','docs/third-party/t03-standards-tools.md','build-tools/acceptance/arlington/README.md','build-tools/acceptance/arlington/t10-r1.patch','capabilities/foundation-environments.yaml','capabilities/foundation-release.yaml','capabilities/foundation-requirements.yaml','capabilities/facade-surface.yaml','capabilities/evidence/T75-delivery/final-delivery-review-r3/historical-facade-counts.md','capabilities/evidence/T75-delivery/final-candidate-r3/build-inputs.json','capabilities/evidence/T75-delivery/final-candidate-r3/t75-final-stage-r3-result.json','capabilities/evidence/T75-delivery/final-validation-r3/source-and-contract-inputs.json','scripts/t10-arlington-pin.properties','scripts/pdfcpu-pin.properties','scripts/qpdf-pin.properties','scripts/pdfium-pin.properties','scripts/imagemagick-pin.properties','scripts/imagemagick-runtime.sha256']:
 copyset.add(REPO/name)
copyset.add(Path('/home/ubuntu/.codex/attachments/77353239-0dda-4ee1-b4bb-ce7fb3fa0f9b/pasted-text-1.txt'));copyset.add(Path('/tmp/t75-worker-batch-fix-98ncwne7/current-source-and-contract-inputs.json'))
for base in ['/tmp/t75-final-spec-values-eight-64rr4_uc','/tmp/t75-final-spec-values-publication-vh2_ayq8','/tmp/t75-final-spec-transactions-eight-5yptf21z','/tmp/t75-final-spec-text-publication-du17bdo8']:
 for name in ['report.md','receipt.json']:copyset.add(Path(base)/name)
copies=[]
for p in sorted(copyset):
 b=read(p);rel=Path('originals/repository')/p.relative_to(REPO) if p.is_relative_to(REPO) else Path('originals/external-paths')/str(p).lstrip('/');dest=OUT/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b);h=hashlib.sha256(b).hexdigest();eq(hashlib.sha256(dest.read_bytes()).hexdigest(),h,'byte exact source copy '+str(p));copies.append({'path':str(p),'copy':str(rel),'sha256':h,'bytes':len(b)})
for row in pub['authority-snapshots']:
 b=(OUT/row['copy']).read_bytes();eq(hashlib.sha256(b).hexdigest(),row['sha256'],'preserved authority original snapshot');a=json.loads(b)
 for obligation in ['text','transactions','values']:eq([c for c in a['certifications'] if c['obligation']==obligation],obj(REPO/('capabilities/evidence/T75-foundation-20260913-r3/'+obligation+'/observed-index.json'))['certifications'],'exact prior publication preserved '+obligation)
for r in pub['original-command'],pub['original-log-snapshot']:
 eq(hashlib.sha256((OUT/r['copy']).read_bytes()).hexdigest(),r['sha256'],'original outer command/log snapshot preserved')
current_output={str(r['path']):r for r in verified}
for r in files.values():
 if not r['path'].startswith(str(OUT)+'/') and r['path'] not in mutable:current_output[r['path']]=r
combined=sorted(current_output.values(),key=lambda r:r['path']);dump('inspected-input-identities.json',combined);dump('source-copy-identities.json',copies);dump('original-tuple-file-identities.json',originals);dump('original-record-report-reference-identities.json',references)
controls=[]
for n in ['first-six-standards-control-identities.json','last-two-standards-control-identities.json']:controls+=obj(OUT/n)
eq(len(controls),5376,'all standards controls in actual eight tuples');dump('all-standards-control-identities.json',controls)
counts={'actual-complete-tuples':8,'actual-formal-tests-per-tuple':65,'actual-Native-tests-per-tuple':53,'actual-Facade-IN_PROCESS-tests-per-tuple':10,'actual-artifact-test-classes-per-tuple':2,'physical-tuple-files':len(originals),'physical-files-per-tuple':1678,'observations-per-tuple':1666,'observed-nested-manifests-per-tuple':0,'T10-requires-nested-producer-manifests':False,'qualified-rule-union':84,'pdfcpu-rules':68,'Arlington-T10-r1-rules':16,'retained-rule-control-executions':len(controls),'actual-product-PDFs':64,'positive-page-visual-records':240,'negative-page-visual-records':8,'original-complete-RGB-raster-observations':rgb['input-raster-observations'],'distinct-encoded-and-prescribed-RGB-pairs':rgb['distinct-encoded-and-prescribed-raster-pairs'],'report-reference-occurrences':sum(t['report-reference-count'] for t in first['tuples']+last['tuples']),'record-and-report-reference-occurrences':len(references),'configuration-inputs-per-tuple':190,'observed-tool-identities-per-environment':15,'before-after-environment-pairs':4,'current-Arlington-model-TSVs':613,'inspected-input-identities':len(combined),'source-copies':len(copies),'fixed-baseline-source-copies':len(sc['unchanged-baseline-source-documents'])}
conclusion={'created-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'All eight complete T10/pages original r3 observation tuples; read-only independent Spec audit. No other-obligation/whole-release/commit approval.','counts':counts,'source-inputs':stage['input-counts'],'observed-index-sha256':config['observed-index-sha256'],'pages-publication-gate-closed':pub['pages-eight-publication-gate-closed'],'deferred-gate':pub['deferred-gate'],'unchanged-originals-rehashed':len(verified),'prior-reviewed-raw-audits-replayed':False,'errors':errors};dump('final-integrity-inspection.json',conclusion)
if errors:raise ValueError('Independent final identity reconciliation failed; original diagnostic retained')
report='''CLEAN for the eight complete r3 pages/T10 observation tuples; no actionable Spec finding.

Fixed baseline: `5b1603c435f11c40368f75b7b9a2777c9c5e9761`. Candidate: `e2dd9ebbeae5668ccc8e2985ccd8af17c8921d1ec5e12e0c913cbd1fa00dfbd6`; contract: `3de508f79fcbef7258feee8abc013d6f02b000840cac1cb263cb0d6f927b8f2b`.

The Goal requires “Refresh invalidated certifications rather than reusing stale hashes” and forbids additional functionality during revalidation (original Goal, lines 131–133). Eleven T10 source/contract documents remain byte-identical to baseline. All 1,933 source, 30 contract, 23 artifact and 24 harness identities match the reviewed Worker correction and refreshed host/JDK validation inputs.

All eight original suites actually report 65 PASS cases: 53 selected-mode Native, 10 actual IN_PROCESS Facade, and two artifact classes (docs/t10-certification.md:58–63). Exact classpaths, 190 configuration inputs, pinned tools and all four reconstructed BEFORE/AFTER environments agree. The 600-second formal and 1,800-second recorder guards remain unchanged.

Read and hashed 13,424 tuple files, including 32 records and 14,016 report references. Verified 64 public products, every 84-rule assignment (68 pdfcpu + 16 Arlington), 5,376 original illegal-control/diagnostic pairs, separate syntax/wrong-order/one-pixel controls, and 759 complete RGB raster observations covering every authored page (contract:67–102). Zero fuzz/AE thresholds, ordered content/Form programs, boxes/rotation, annotation/destination retargeting, declaration-order receipts, terminal split, caller ownership and Source/sibling isolation retain their specified boundaries (contract:37–56,79–94). T10 requires no T13 producer manifests; each observed tree contains zero. PNG bytes retain their individual SHA; decoded pixels establish agreement.

Original exploratory path and selector-literal reader diagnostics are retained with separate clean closures. Existing text/transactions/values review identities and their exact published subsets remain unchanged; their large raw audits were not replayed. Current jar reflection and historical count/probe boundaries remain as recorded in the prior values review.

Pages outer result remains absent at the preserved publication inspection; actual exit0 and exact pages8 authority publication are deferred. No all48, final-delivery or completion-criterion approval is given.
'''
assert len(report.split())<400
(OUT/'report.md').write_text(report)
def localref(name):
 p=OUT/name;b=p.read_bytes();return {'path':str(p),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
receipt={'created-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'verdict':'CLEAN; eight complete pages observations reviewed, actual outer publication deferred','baseline':sc['baseline'],'candidate-sha256':stage['candidate-sha256'],'contract-sha256':stage['contract-sha256'],'report':localref('report.md'),'report-word-count':len(report.split()),'scope':localref('scope.json'),'complete-scope-amendment':localref('all-eight-completion-scope-amendment.json'),'inspections':[localref(n) for n in inspections],'integrity-inspection':localref('final-integrity-inspection.json'),'exact-inspected-counts':counts,'source-and-build-input-counts':stage['input-counts'],'original-observed-index-sha256':config['observed-index-sha256'],'tuple-observations':[{k:v for k,v in t.items() if k!='staged-classpath-paths'} for t in stage['tuples']],'input-identities':localref('inspected-input-identities.json'),'source-copy-identities':localref('source-copy-identities.json'),'all-original-physical-file-identities':localref('original-tuple-file-identities.json'),'all-original-record-report-reference-identities':localref('original-record-report-reference-identities.json'),'all-original-standard-control-identities':localref('all-standards-control-identities.json'),'original-reader-diagnostics-closure':localref('reader-diagnostic-closures.json'),'prior-closed-review-linkage':config['closed-prior-linkage'],'actual-publication':pub,'originals-unchanged':True,'no-project-command-or-renderer-executed':True,'only-review-files-written-under':str(OUT),'original-reader-history-preserved':True,'other-obligations-all48-or-final-delivery-approved':False,'completion-criteria-marked':False,'archive-manifest-policy':'archive-manifest.json is generated after this finalizer and its actual wrapper result complete. It lists every retained regular review file and explicitly excludes itself.'};dump('receipt.json',receipt)
print(json.dumps({'report-sha256':receipt['report']['sha256'],'report-words':receipt['report-word-count'],'receipt-sha256':hashlib.sha256((OUT/'receipt.json').read_bytes()).hexdigest(),'counts':counts,'publication-deferred':not pub['pages-eight-publication-gate-closed'],'errors':errors}))
