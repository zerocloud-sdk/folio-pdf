from pathlib import Path
out=Path(__file__).parent;prior=Path('/tmp/t75-final-spec-transactions-eight-5yptf21z')
s=(prior/'evidence-audit.py').read_text();base=s[:s.index('for major,mode in TUPLES:')]
base=base.replace('T03-document-workflow-transaction','T09-document-value-inspection-patch').replace('T03-standards','T09-standards').replace('T03-document-blank-visual','T09-values-visual').replace('T03-document-blank-144dpi-srgb','T09-values-144dpi-srgb').replace('T03EvidenceCommand.java','T09IndependentEvidence.java').replace(".split('private static final String[] CHAINS',1)[0]",".split('));',1)[0]").replace('len(rules),22','len(rules),51').replace('twenty-two required rules','fifty-one required rules').replace('complete hard-coded T03','complete hard-coded T09').replace('all-white raster authority','blue-rectangle raster authority')
a=base.index('def neutral(');b=base.index('def visual_check',a);base=base[:a]+base[b:]
base=base.replace('T07-document-blank','T09-values').replace('blank.pdf','values.pdf').replace("'Input ID-neutral SHA-256':neutral(d/'values.pdf')","'Input exact SHA-256':h,'Input hash policy':'SHA-256 of the exact unmodified PDF bytes'")
base=base.replace("fields(rec,dict(hashes,**{", "fields(rec,dict({k:v for k,v in hashes.items() if k in ['Expected raster SHA-256','PDFium raster SHA-256','Implementation raster SHA-256']},**{")
(out/'evidence-audit.py').write_text(base)
s=(prior/'raster-audit.py').read_text().replace('T03-document-blank-144dpi-srgb','T09-values-144dpi-srgb').replace('T07-document-blank','T09-values').replace("key=(current[:3],previous[:3],previous is ZERO,kind)","key=(current,previous,kind)")
s=s.replace("ZERO=b'\\x00'*stride;", "ZERO=b'\\x00'*stride;BLUE=WHITE[:300]+b'\\x00\\x00\\xff'*200+WHITE[900:];")
s=s.replace('current=BLACK_FIRST if oneblack and y==0 else WHITE;', 'current=BLACK_FIRST if oneblack and y==0 else BLUE if 1304<=y<1464 else WHITE;')
s=s.replace('for y in range(1,height):rgb.update(WHITE)', 'for y in range(1,height):rgb.update(BLUE if 1304<=y<1464 else WHITE)')
s=s.replace("'all-other-pixels-white':True", "'expected-blue-pixels':32000,'blue-rectangle-pixels':'100<=x<300 and 1304<=y<1464','all-other-pixels-white':True")
s=s.replace("for api in ['native','facade']:", "for api in ['source','native-rewrite','native-incremental','facade']:")
s=s.replace('against prescribed all-white RGB or exactly one black pixel at (0,0)', 'against the prescribed blue rectangle on white RGB, plus exactly one black pixel at (0,0) only for the negative golden')
(out/'raster-audit.py').write_text(s)
