from auditlib import *
import datetime
copies=[]
def copy(p):
 p=Path(p);b=read(p);rel=Path('publication-originals')/p.name;dest=OUT/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b);copies.append({'path':str(p),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'copy':str(rel)});return b
commandpath=Path('/tmp/t75-final-values-certify-r3-command.json');resultpath=Path('/tmp/t75-final-values-certify-r3-result.json');logpath=Path('/tmp/t75-final-values-certify-r3.log');command=json.loads(copy(commandpath));eq(command['command'],['/usr/bin/python3','scripts/t03-foundation.py','certify','capabilities/evidence/T75-foundation-20260913-r3/values','--obligation','values'],'original actual values outer command');eq(command['cwd'],str(REPO),'actual original working directory');eq(command['explicit-environment'],{'FOLIO_HARFBUZZ_HELPER':str(REPO/'.build-cache/harfbuzz/10.2.0-final/bin/folio-harfbuzz')},'actual explicit environment');eq(command['original-log'],str(logpath),'actual original stdout location')
index=obj(ROOT/'observed-index.json');closed=obj(OUT/'complete-config-and-index-inspection.json');eq(closed['errors'],[],'closed configuration/index inspection');eq(sha(ROOT/'observed-index.json'),closed['observed-index-sha256'],'unchanged current values observed index');result=None;expectedlog=[]
for j in [8,11,17,21]:expectedlog+=['T09 environment JDK '+str(j),'T09 certification JDK '+str(j)+' / IN_PROCESS','T09 certification JDK '+str(j)+' / HARDENED_WORKER']
if resultpath.exists():
 result=json.loads(copy(resultpath));log=copy(logpath).decode()
 for k,v in command.items():eq(result[k],v,'original result binds original command '+k)
 eq(result['returncode'],0,'actual values outer exit0');eq(log,'\n'.join(expectedlog+['Recorded exactly eight T09 certifications; retained 16 current certifications for other obligations.'])+'\n','complete original outer stdout')
else:
 b=logpath.read_bytes();log=b.decode();(OUT/'publication-originals/outer-log-pending-snapshot.txt').write_bytes(b);dump('publication-pending-original-log-identity.json',{'path':str(logpath),'copy':'publication-originals/outer-log-pending-snapshot.txt','sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'observed-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'mutable-progress-only':True});eq(log.startswith('\n'.join(expectedlog)+'\n'),True,'all eight progress lines retained; no exit conclusion')
eq(log.startswith(read(OUT/'outer-pending-log-snapshot.txt').decode()),True,'initial pending log remains original exact prefix')
authoritypath=REPO/'capabilities/foundation-evidence.yaml';b=authoritypath.read_bytes();authority=json.loads(b);(OUT/'publication-originals/authority-snapshot.json').write_bytes(b);counts={};indexes={'values':index}
for obligation in ['text','transactions']:
 oldindex=REPO/('capabilities/evidence/T75-foundation-20260913-r3/'+obligation+'/observed-index.json');priorindex=obj(oldindex);priorlink=next(x for x in closed['closed-prior-linkage'] if x['obligation']==obligation);eq(sha(oldindex),priorlink['observed-index-sha256'],'unchanged prior index '+obligation);indexes[obligation]=priorindex
key=lambda c:(c['environment'],c['execution-profile'])
for obligation,expected in indexes.items():
 actual=[c for c in authority['certifications'] if c['obligation']==obligation];counts[obligation]=len(actual)
 if obligation!='values' or result is not None or actual:eq(sorted(actual,key=key),sorted(expected['certifications'],key=key),'exact published subset '+obligation)
 for c in expected['certifications']:
  eq(sha(REPO/c['configuration']['path']),c['configuration']['sha256'],'original exact configuration '+obligation)
  for r in c['records']:eq(sha(REPO/r['path']),r['sha256'],'original exact record '+obligation)
eq(authority['candidate'],index['candidate'],'authority and actual candidate match');envmap={e['profile']:e['record'] for e in authority['environments']}
for e in index['environments']:
 eq(sha(REPO/e['record']['path']),e['record']['sha256'],'actual completed values environment');eq(envmap[e['profile']]['sha256'],e['record']['sha256'],'authority shared environment identity');eq(sha(REPO/envmap[e['profile']]['path']),e['record']['sha256'],'original authority environment reference')
counts['other']=len(authority['certifications'])-sum(counts.values());authorityref={'path':str(authoritypath),'copy':'publication-originals/authority-snapshot.json','sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'observed-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'counts':counts};dump('publication-authority-identity.json',authorityref);dump('publication-original-copy-identities.json',copies)
finish('values-publication-inspection.json',{'scope':'Original actual values outer command and conditional publication gate; exact existing text8 and transactions8 retention','original-command':{'path':str(commandpath),'sha256':sha(commandpath)},'actual-outer-result-exists':result is not None,'actual-outer-result':result,'actual-outer-result-identity':{'path':str(resultpath),'sha256':sha(resultpath)} if result is not None else None,'actual-complete-stdout-identity':{'path':str(logpath),'sha256':sha(logpath)} if result is not None else None,'values-exit-and-publication-gate-closed':result is not None and not errors,'publication-conclusion':'Actual values exit0 and exact eight publication observed' if result is not None else 'DEFERRED: original actual outer result absent; eight observations alone do not establish publication','authority':authorityref,'retained-text-certifications':counts['text'],'retained-transaction-certifications':counts['transactions'],'unchanged-prior-chain-records-rehashed':64,'prior-huge-raw-trees-replayed':False,'earlier-pending-observations-preserved':True,'other-obligations-all48-finaldelivery-approved':False})
