from pathlib import Path
import datetime,hashlib,json,sys
OUT=Path(__file__).parent;REPO=Path('/home/ubuntu/IdeaProjects/open-pdf');ROOT=REPO/'capabilities/evidence/T75-foundation-20260913-r3/values';errors=[]
def dump(n,d):(OUT/n).write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
def digest(p):
 h=hashlib.sha256();size=0
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b);size+=len(b)
 return h.hexdigest(),size
def eq(a,b,w):
 if a!=b:errors.append({'where':w,'actual':a,'expected':b})
def obj(p):return json.loads(p.read_bytes())
merged={}
for m in sorted(OUT.glob('*-read-identities.json')):
 for e in obj(m):
  p=e['path']
  if p in merged:eq(e['sha256'],merged[p]['sha256'],'same observed identity '+p);eq(e['bytes'],merged[p]['bytes'],'same observed byte count '+p)
  else:merged[p]={'path':p,'sha256':e['sha256'],'bytes':e['bytes'],'observed-in':[]}
  merged[p]['observed-in'].append(m.name)
copied=[]
for n in ['source-copy-identities.json','publication-original-copy-identities.json']:
 for e in obj(OUT/n):
  h,z=digest(OUT/e['copy']);eq(h,e['sha256'],'exact source copy '+e['copy']);eq(z,e['bytes'],'exact source copy size '+e['copy']);copied.append(e)
  if e['path'] in merged:eq(e['sha256'],merged[e['path']]['sha256'],'copy matches original read '+e['path'])
  else:merged[e['path']]={'path':e['path'],'sha256':e['sha256'],'bytes':e['bytes'],'observed-in':[n]}
for p,e in sorted(merged.items()):h,z=digest(Path(p));eq(h,e['sha256'],'unchanged inspected bytes '+p);eq(z,e['bytes'],'unchanged inspected size '+p)
expected={str(REPO/e['path']):e['sha256'] for e in obj(OUT/'original-tuple-file-identities.json')};actual={str(p) for j in [8,11,17,21] for m in ['in_process','hardened_worker'] for p in (ROOT/f'jdk{j}-{m}').rglob('*') if p.is_file()};eq(actual,set(expected),'complete original eight tree membership')
for p,h in expected.items():eq(merged[p]['sha256'],h,'same original tuple identity '+p)
index=obj(ROOT/'observed-index.json');pub=obj(OUT/'values-publication-inspection.json');authoritypath=REPO/'capabilities/foundation-evidence.yaml';b=authoritypath.read_bytes();authority=json.loads(b);key=lambda c:(c['environment'],c['execution-profile']);counts={}
for obligation in ['text','transactions','values']:
 expectedindex=obj(REPO/('capabilities/evidence/T75-foundation-20260913-r3/'+obligation+'/observed-index.json'));actual=[c for c in authority['certifications'] if c['obligation']==obligation];counts[obligation]=len(actual)
 if obligation!='values' or pub['values-exit-and-publication-gate-closed'] or actual:eq(sorted(actual,key=key),sorted(expectedindex['certifications'],key=key),'final exact authority subset '+obligation)
eq(authority['candidate'],index['candidate'],'same authority candidate');counts['other']=len(authority['certifications'])-sum(counts.values());(OUT/'publication-originals/final-authority-snapshot.json').write_bytes(b);ar={'path':str(authoritypath),'copy':'publication-originals/final-authority-snapshot.json','sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'observed-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'counts':counts,'other-obligation-additions-permitted':True}
prior=obj(OUT/'publication-authority-identity.json');h,z=digest(OUT/prior['copy']);eq(h,prior['sha256'],'prior authority snapshot preserved');eq(z,prior['bytes'],'prior authority size preserved')
for n in ['stage-environment-contract-inspection.json','complete-config-and-index-inspection.json','values-evidence-inspection.json','complete-rgb-raster-inspection.json','raw-preservation-inspection.json','source-contract-inspection.json','values-publication-inspection.json']:eq(obj(OUT/n)['errors'],[],'closed phase '+n)
eq(obj(OUT/'raw-preservation-audit-result.json')['returncode'],1,'initial reader diagnostic retained');eq(obj(OUT/'raw-reader-pin-field-closure.json')['all-original-diagnostics-accounted-for'],True,'initial reader diagnosis separately closed')
identities=sorted(merged.values(),key=lambda e:e['path']);dump('inspected-input-identities.json',identities);dump('final-authority-identity.json',ar);result={'created-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'unique-original-identities-rehashed':len(identities),'total-original-bytes-rehashed':sum(e['bytes'] for e in identities),'byte-exact-original-copies':len(copied),'selected-source-copies':len(obj(OUT/'source-copy-identities.json')),'original-outer-copies':len(obj(OUT/'publication-original-copy-identities.json')),'authority-snapshots':2,'original-eight-tuple-files':len(expected),'all-original-tree-membership-and-identities-unchanged':not errors,'final-authority':ar,'values-publication-gate-closed':pub['values-exit-and-publication-gate-closed'],'outer-result-exists-at-final-identity-check':Path('/tmp/t75-final-values-certify-r3-result.json').exists(),'preserved-initial-reader-pin-key-diagnostic':True,'historical-count-boundary-and-current-delivery-addendum-reviewed':True,'other-obligations-all48-or-finaldelivery-approved':False,'errors':errors};dump('final-identity-inspection.json',result);print(json.dumps(result,ensure_ascii=False));sys.exit(bool(errors))
