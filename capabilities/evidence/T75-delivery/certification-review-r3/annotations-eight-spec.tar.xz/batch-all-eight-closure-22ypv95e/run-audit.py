from pathlib import Path
import sys,subprocess,hashlib,json,datetime
out=Path(__file__).parent
name=sys.argv[1]
if name not in {'raster-audit.py','stage-audit.py','evidence-audit.py','graph-audit.py','source-contract-audit.py','complete-config-audit.py','finalize-audit.py'}:raise ValueError('Unapproved read-only audit')
prefix=name.removesuffix('.py');paths=[out/(prefix+s) for s in ['-command.json','-output.txt','-result.json']]
for p in paths:
 if p.exists():raise FileExistsError('Refusing to overwrite any review execution output: '+str(p))
command=[sys.executable,'-B',str(out/name)];meta={'command':command,'cwd':str(out),'started-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'script-sha256':hashlib.sha256((out/name).read_bytes()).hexdigest(),'scope':'Independent read-only inspection; no project tool/test execution'}
with paths[0].open('x') as f: f.write(json.dumps(meta,indent=2)+'\n')
with paths[1].open('xb') as log: r=subprocess.run(command,cwd=out,stdout=log,stderr=subprocess.STDOUT)
meta.update({'returncode':r.returncode,'completed-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stdout-stderr-sha256':hashlib.sha256(paths[1].read_bytes()).hexdigest()})
with paths[2].open('x') as f: f.write(json.dumps(meta,indent=2)+'\n')
print(paths[1].read_text()[:5000]);print(json.dumps(meta));sys.exit(r.returncode)
