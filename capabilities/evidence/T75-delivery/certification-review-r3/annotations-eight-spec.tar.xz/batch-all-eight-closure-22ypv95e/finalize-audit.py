from auditlib import *
import datetime,shutil,yaml
BASE=OUT.parent;J21=BASE/'batch-jdk21-p77mn8_t';J17RGB=BASE/'batch-jdk17-rgb-3tv5tg6z';SOURCE=BASE/'batch-source-contract-vnok5ax0';DIAG=BASE/'batch-reader-closures-1jc5jl38'
clean={'stage':[BASE/'stage-environment-contract-first-four-inspection.json',BASE/'stage-environment-contract-jdk17-inspection.json',J21/'stage-environment-contract-jdk21-inspection.json'],'evidence':[BASE/'annotations-first-four-evidence-inspection.json',BASE/'annotations-jdk17-evidence-inspection.json',J21/'annotations-jdk21-evidence-inspection.json'],'graph':[BASE/'annotations-first-four-revalidation-direct-graph-inspection.json',BASE/'annotations-jdk17-scope-closure-direct-graph-inspection.json',J21/'annotations-jdk21-direct-graph-inspection.json'],'rgb':[BASE/'annotations-first-four-schema-closure-complete-rgb-raster-inspection.json',J17RGB/'annotations-jdk17-complete-rgb-raster-inspection.json',J21/'annotations-jdk21-complete-rgb-raster-inspection.json'],'source':[SOURCE/'source-contract-inspection.json'],'config':[OUT/'complete-config-and-index-inspection.json']}
results={};seen={};linkage=[]
for group,paths in clean.items():
 results[group]=[]
 for p in paths:
  value=obj(p);eq(value['errors'],[],'clean original independent '+str(p));results[group].append(value);ip=p.with_name(p.stem+'-read-identities.json');ids=obj(ip)
  for r in ids:
   name=r['path']
   if name in seen:eq(r['sha256'],seen[name]['sha256'],'same inspected input across batches '+name)
   seen[name]=r
  linkage.append({'kind':group,'path':str(p),'sha256':sha(p),'input-identity-list':str(ip),'identity-list-sha256':sha(ip)})
# Verify every exact input of the successful audits is unchanged. The appendable
# outer certifier log is handled later as a dated snapshot, not an immutable input.
for name,r in sorted(seen.items()):eq(sha(Path(name)),r['sha256'],'inspected input unchanged '+name)
physical=[];references=[]
for root,batch in [(BASE,'first-four'),(BASE,'jdk17'),(J21,'jdk21')]:
 physical+=obj(root/(batch+'-original-tuple-file-identities.json'));references+=obj(root/(batch+'-record-report-reference-identities.json'))
eq(len({r['path'] for r in physical}),len(physical),'unique complete original tuple files');eq(len(physical),sum(x['physical-original-files'] for x in results['evidence']),'all original byte catalogs agree')
expected=set()
for j,m in TUPLES:expected.update(str(p.relative_to(REPO)) for p in (ROOT/('jdk'+str(j)+'-'+m.lower())).rglob('*') if p.is_file())
eq({r['path'] for r in physical},expected,'full eight physical tree inventory unchanged')
for r in physical:eq(sha(REPO/r['path']),r['sha256'],'original tuple unchanged '+r['path'])
for r in references:eq(sha(REPO/r['path']),r['sha256'],'every original report/record reference unchanged '+r['path'])
counts={'tuples':sum(len(r['tuples']) for r in results['evidence']),'physical-original-files':len(physical),'observation-files':sum(t['observation-files'] for r in results['evidence'] for t in r['tuples']),'chain-records':sum(len(t['reports']) for r in results['evidence'] for t in r['tuples']),'report-reference-occurrences':sum(t['report-reference-count'] for r in results['evidence'] for t in r['tuples']),'record-report-reference-occurrences':len(references),'qualified-standards-rules':174,'qualified-rule-control-executions':sum(r['qualified-rule-control-executions'] for r in results['evidence']),'public-products':sum(len(r['public-products']) for r in results['evidence']),'positive-qpdf-graphs':sum(r['positive-graphs'] for r in results['graph']),'actual-semantic-mutation-graphs':sum(r['actual-mutation-graphs'] for r in results['graph']),'positive-page-visual-observations':sum(sum(x['result']=='pass' for x in r['separate-page-visual-observations'] if '/negative/' not in x['directory']) for r in results['evidence']),'actual-PDF-visual-defects':24,'one-pixel-controls':8,'full-RGB-input-observations-unique-paths':len({r['path'] for x in results['rgb'] for r in x['observations']}),'nested-manifests-observed':sum(t['observed-nested-manifests'] for r in results['evidence'] for t in r['tuples']),'baseline-identical-selected-T12-files':results['source'][0]['dedicated-T12-files'],'configuration-inputs-per-tuple':156,'before-after-environment-observations':sum(len(x['environment-observations']) for x in results['stage'])}
eq(counts['tuples'],8,'complete exactly eight observations');eq(counts['qualified-rule-control-executions'],128*174,'every product qualifies all assigned controls');eq(counts['full-RGB-input-observations-unique-paths'],26+8*(52*3+9*3+2),'all original and actual full RGB inputs')
selected=set()
for r in obj(SOURCE/'source-contract-inspection-read-identities.json'):
 p=Path(r['path'])
 if p.is_file():selected.add(p)
C=REPO/'capabilities/profiles/T12-standards'
for checker in ['pdfcpu','arlington-core','arlington-annotations']:
 q=props(C/(checker+'.properties'))
 for rule in q['required-rules'].split(','):selected.add((C/q['negative.'+rule+'.path']).resolve())
selected.update([ROOT/'observed-index.json',ROOT/'candidate-probe.json',ROOT/'candidate-identity.txt',ROOT/'identities.json',ROOT/'prior-index.sha256',REPO/'capabilities/evidence/T75-delivery/final-candidate-r3/build-inputs.json'])
for j,m in TUPLES:
 scope=ROOT/('jdk'+str(j)+'-'+m.lower());obs=scope/'observations';selected.update(p for p in scope.iterdir() if p.is_file());selected.update(p for p in obs.iterdir() if p.is_file());selected.update(p for p in (obs/'safety').rglob('*') if p.is_file());selected.update(p for p in (obs/'negative').iterdir() if p.is_file())
 for api in ['native','facade']:
  for product in ['created','changed','flattened','copied','merged','adopted','left','right']:
   d=obs/(api+'-'+product)
   for name in ['annotations.pdf','result.properties']:selected.add(d/name)
   if (api=='native' and product in ['created','flattened']) or (j==8 and m=='IN_PROCESS' and api=='facade' and product in ['created','flattened']):
    selected.update(p for p in d.iterdir() if p.is_file());selected.update(p for p in (d/'qpdf').iterdir() if p.is_file())
    for checker in ['pdfcpu','arlington-core','arlington-annotations']:
     selected.update([d/checker/'standards.properties',d/checker/'findings.txt'])
 for p in (obs/'negative').rglob('*'):
  if p.is_file() and (p.name in ['result.properties','semantic.txt','comparator.txt'] or (j==8 and m=='IN_PROCESS')):selected.add(p)
for j in [8,11,17,21]:
 for suffix in ['', '-after']:selected.update(p for p in (ROOT/('jdk'+str(j)+'-environment'+suffix)).iterdir() if p.is_file())
for link in results['config'][0]['prior-linkage']:
 selected.update([Path(link['report-path']),Path(link['receipt-path']),ROOT.parent/link['obligation']/'observed-index.json'])
copies=[];target=BASE/'selected-originals';target.mkdir()
for p in sorted(selected):
 if p.is_relative_to(REPO):rel=Path('repository')/p.relative_to(REPO)
 else:rel=Path('external-originals')/str(p).lstrip('/')
 dest=target/rel;dest.parent.mkdir(parents=True,exist_ok=True);b=read(p)
 with dest.open('xb') as f:f.write(b)
 eq(sha(dest),hashlib.sha256(b).hexdigest(),'exact selected copy '+str(p));copies.append({'original':str(p),'copy':str(dest.relative_to(BASE)),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)})
# Current authority can atomically gain annotations only after the original
# publisher exits successfully. Preserve a dated snapshot without pretending a
# pending outer process has finished.
outer_prefix=Path('/tmp/t75-final-annotations-certify-r3');commandpath=Path(str(outer_prefix)+'-command.json');logpath=Path(str(outer_prefix)+'.log');resultpath=Path(str(outer_prefix)+'-result.json');authoritypath=REPO/'capabilities/foundation-evidence.yaml';observed=datetime.datetime.now(datetime.timezone.utc).isoformat();commanddata=commandpath.read_bytes();logdata=logpath.read_bytes();authdata=authoritypath.read_bytes();command=json.loads(commanddata);eq(command['command'],['/usr/bin/python3','scripts/t03-foundation.py','certify',str(ROOT.relative_to(REPO)),'--obligation','annotations'],'original actual annotations outer command');eq(command['cwd'],str(REPO),'original outer cwd');eq(command['started-utc'],'2026-09-13T11:32:07.253285+00:00','actual annotations start constant');eq(command['wrapper-pid'],3566940,'actual annotations wrapper');eq(command['explicit-environment'],{'FOLIO_HARFBUZZ_HELPER':str(REPO/'.build-cache/harfbuzz/10.2.0-final/bin/folio-harfbuzz')},'actual outer helper')
outer=[]
for label,p,b in [('original-command.json',commandpath,commanddata),('pending-or-complete-outer-log.txt',logpath,logdata),('authority-snapshot.yaml',authoritypath,authdata)]:
 dest=OUT/label
 with dest.open('xb') as f:f.write(b)
 outer.append({'original':str(p),'snapshot':str(dest),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'observed-utc':observed})
authority=yaml.safe_load(authdata);priorcounts={}
for obligation in ['text','transactions','values','pages','metadata']:
 priorindex=obj(ROOT.parent/obligation/'observed-index.json');actual=[x for x in authority['certifications'] if x['obligation']==obligation];eq(actual,priorindex['certifications'],'prior exact subset preserved at final raw gate '+obligation);priorcounts[obligation]=len(actual)
actual_annotations=[x for x in authority['certifications'] if x['obligation']=='annotations'];result_present=resultpath.exists();publication=False
if result_present:
 b=resultpath.read_bytes();result=json.loads(b);eq(result['returncode'],0,'actual outer result');eq(actual_annotations,obj(ROOT/'observed-index.json')['certifications'],'actual unchanged T12 eight publication');eq(logdata.decode().rstrip().endswith('Recorded exactly eight T12 certifications; retained 40 current certifications for other obligations.'),True,'actual outer completion line');publication=result['returncode']==0 and actual_annotations==obj(ROOT/'observed-index.json')['certifications']
 with (OUT/'original-outer-result.json').open('xb') as f:f.write(b)
 outer.append({'original':str(resultpath),'snapshot':str(OUT/'original-outer-result.json'),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'observed-utc':observed})
else:eq(len(actual_annotations) in [0,8],True,'only atomic absent-or-complete T12 subset while outer result pending')
reader=obj(DIAG/'reader-diagnostics-and-closure-receipt.json');eq(reader['original-summaries-recovered'],False,'do not mislabel fresh read as recovered old summaries');eq(reader['all-prior-derived-review-bytes-preserved'],False,'explicit lost own derived bytes boundary')
dump('selected-original-copy-identities.json',copies);dump('successful-inspection-input-identities.json',list(seen.values()));dump('complete-original-tuple-file-identities.json',physical);dump('complete-record-report-reference-identities.json',references)
finish('final-raw-evidence-inspection.json',{'created-utc':observed,'scope':'Only current eight T12 observations; no all48/inventory/delivery approval','counts':counts,'clean-inspection-linkage':linkage,'selected-original-copies':len(copies),'selected-original-bytes':sum(x['bytes'] for x in copies),'certification-raw-originals-unchanged':True,'all-input-identities-unchanged':True,'selected-copy-catalog':str(OUT/'selected-original-copy-identities.json'),'outer-original-snapshots':outer,'actual-outer-result-present':result_present,'annotations-publication-gate-closed':publication,'annotations-current-authority-count':len(actual_annotations),'prior-authority-subsets-retained':priorcounts,'reader-incident-closure':{'path':str(DIAG/'reader-diagnostics-and-closure-receipt.json'),'sha256':sha(DIAG/'reader-diagnostics-and-closure-receipt.json'),'all-prior-derived-review-bytes-preserved':False,'certification-originals-changed':False,'fresh-first-four-independent-read':'CLEAN'},'remaining-gate':'Actual outer exit and exact publication deferred' if not publication else 'T12 publication closed only; all48/inventory/index/delivery separate'})
if errors:raise ValueError('Final read-only diagnostics retained; originals untouched')
