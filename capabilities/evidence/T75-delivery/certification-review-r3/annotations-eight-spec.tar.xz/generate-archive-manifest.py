from pathlib import Path
import hashlib,json,datetime,sys
root=Path(__file__).parent
manifest=root/'original-archive-manifest.json'
if manifest.exists():raise FileExistsError('Refusing to overwrite the review archive manifest')
allpaths=sorted(p for p in root.rglob('*') if p.is_file())
if any(p.is_symlink() for p in root.rglob('*')):raise ValueError('Review archive contains a symbolic link')
entries=[]
for p in allpaths:
 if p==manifest:continue
 data=p.read_bytes();entries.append({'path':str(p.relative_to(root)),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
value={'schema-version':1,'created-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'original-root':str(root),'generation-command':[sys.executable,'-B',str(Path(__file__))],'entry-count':len(entries),'excluded-paths':['original-archive-manifest.json'],'exclusion-reason':'The manifest excludes itself; all other actual retained regular-file bytes are included.','history-limitation':'Two early first-four derived graph summaries were overwritten by the reader; retained current bytes at those paths are JDK17. The incident record identifies the lost prior bytes and fresh first-four reinspection. This manifest makes no claim that those lost original derived summaries are recovered. Certification raw originals were unchanged.','entries':entries}
with manifest.open('x') as f:json.dump(value,f,ensure_ascii=False,indent=2);f.write('\n')
observed=json.loads(manifest.read_bytes());assert len(observed['entries'])==len(allpaths)
for row in observed['entries']:
 p=root/row['path'];data=p.read_bytes();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
print(json.dumps({'manifest':str(manifest),'sha256':hashlib.sha256(manifest.read_bytes()).hexdigest(),'entry-count':len(entries),'total-archive-files-including-manifest':len(entries)+1,'manifest-excludes-itself':True,'all-listed-bytes-verified':True},indent=2))
