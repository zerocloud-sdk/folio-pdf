from auditlib import *
import zlib,struct,copy
from collections import Counter
from decimal import Decimal
BATCH='first-four-schema-closure'
C=REPO/'capabilities/profiles/T12-annotations';corpus=obj(C/'corpus.json');eq(sha(C/'corpus.json'),'fa6834bb206298743aba8f54af658315b1dee54b86319afbddb427af8676ad9a','frozen independent corpus JSON');eq(sha(C/'corpus.properties'),'c1e18a08e9479ab881c6f3d1ebb431348680b4fb7a01fc976add795344c5ecb1','frozen semantic corpus properties')
flat={}
def flatten(v,prefix=''):
 if isinstance(v,dict):
  for k,x in v.items():flatten(x,prefix+'.'+k if prefix else k)
 elif isinstance(v,list):
  flat[prefix+'.count']=str(len(v))
  for i,x in enumerate(v):flatten(x,prefix+'.'+str(i))
 else:flat[prefix]='' if v is None else str(v)
flatten(corpus);eq(props(C/'corpus.properties'),flat,'complete original JSON/properties equivalence')
for name,entry in corpus['sources'].items():eq(sha(C/entry['path']),entry['sha256'],'original authored source '+name)
EXPECTED_PRODUCTS={'created':['A','B','C'],'changed':['A','B','C'],'flattened':['A','B','C'],'copied':['A','B','C','A','B'],'merged':['A','B','C','D'],'adopted':['A','B','C','D'],'left':['A','B'],'right':['C','D']}
eq({k:v['pages'] for k,v in corpus['products'].items()},EXPECTED_PRODUCTS,'prescribed exact page order')
colours={'A':(255,0,0),'B':(0,255,0),'C':(0,0,255),'D':(0,0,0)}
for name,colour in colours.items():
 info=corpus['pages'][name];eq([info[k] for k in ['media-box','crop-box','rotation']],[[0,0,120,100],[0,0,120,100],0],'authored geometry '+name);eq(info['paints'],[[10,20,40,30]+list(colour)],'prescribed base rectangle '+name)
 program='q '+' '.join(str(c//255) for c in colour)+' rg 10 20 40 30 re f Q\n'+('2 0 0 2 13 17 cm\n0 0 1 1 re W n\n' if name=='A' else '')
 eq(info['contents'],[program],'complete prescribed page content and retained state '+name)
rows={};geometries=[];allprofiles=[]
for product,p in corpus['products'].items():
 for number,name in enumerate(p['pages'],1):
  base=[10,20,40,30]+list(colours[name]);paints=[base]
  for a in p['flattened']+p['annotations']:
   if a['page']!=number:continue
   ap=a['appearance'];eq(ap['box'],[2,3,12,13],product+' nonzero appearance origin');eq(ap['matrix'],[1,0,0,1,0,0],product+' explicit identity appearance matrix');eq(ap['resources'],'empty',product+' resource-free AP');eq(ap['program'],'q '+' '.join(map(str,ap['color']))+' rg 2 3 10 10 re f Q\n',product+' actual opaque whole-bbox AP program');x0,y0,x1,y1=a['rectangle'];paints.append([x0,y0,x1-x0,y1-y0]+[int(c*255) for c in ap['color']])
  info=p['visual'][number-1];eq(info['paints'],paints,product+' page '+str(number)+' derived paint order from base, flattened Forms then annotations');eq({k:info[k] for k in ['marker','media-box','crop-box','rotation','contents']}, {k:corpus['pages'][name][k] for k in ['marker','media-box','crop-box','rotation','contents']},product+' full authored page visual identity');eq([info['raster-width'],info['raster-height']],[240,200],'144 DPI dimensions')
  def make(paintlist):
   r=[bytearray(b'\xff'*720) for y in range(200)]
   for x,y,w,h,red,green,blue in paintlist:
    assert all(float(v).is_integer() for v in [x*2,y*2,w*2,h*2]);left,right=int(x*2),int((x+w)*2);top,bottom=int(200-(y+h)*2),int(200-y*2)
    for row in range(top,bottom):r[row][left*3:right*3]=bytes([red,green,blue])*(right-left)
   return [bytes(v) for v in r]
  rows[(product,number,None)]=make(paints);eq(sha(C/info['raster']),info['raster-sha256'],'frozen authored expected PNG '+product+str(number));counts=Counter(tuple(v[x:x+3]) for v in rows[(product,number,None)] for x in range(0,720,3));geometries.append({'product':product,'page':number,'source-page':name,'prescribed-paints':paints,'prescribed-decoded-rgb-sha256':hashlib.sha256(b''.join(rows[(product,number,None)])).hexdigest(),'colour-pixel-counts':{','.join(map(str,c)):n for c,n in counts.items()}})
  vp=C/'visual'/(product+'-page-'+str(number)+'.properties');expected={'PROFILE_ID':'T12-annotations-document-actions-'+product+'-page-'+str(number),'PAGE_COUNT':str(len(p['pages'])),'PAGE_SELECTION':str(number),'PAGE_BOX':'effective CropBox [0 0 120 100] points','DPI':'144','COLOR_POLICY':'sRGB, opaque 8-bit RGB PNG after compositing over opaque white','FONT_POLICY':'not applicable; the artifact has no text or font resources and uses no system fonts','ANTIALIASING_POLICY':'pinned PDFium default smoothing; vector edges are axis-aligned','BACKGROUND':'opaque white (#ffffff)','RASTER_WIDTH':'240','RASTER_HEIGHT':'200','COMPARISON_METRIC':'AE','COMPARISON_FUZZ_PERCENT':'0','COMPARISON_THRESHOLD':'0','RENDERER_AGREEMENT_THRESHOLD':'0','EXPECTED_RASTER':'../'+info['raster'],'EXPECTED_RASTER_SHA256':info['raster-sha256']};eq(props(vp),expected,'complete original T12 visual profile '+str(vp));allprofiles.append({'path':str(vp.relative_to(REPO)),'sha256':sha(vp),'actual':expected})
  for change in ['appearance','rectangle'] if product=='created' else ['retained-paint'] if product=='flattened' else []:
   changed=copy.deepcopy(paints)
   if number==1:
    if change=='retained-paint':changed[0][0]=11
    else:
     widget=next(a for a in p['annotations'] if a['type']=='WIDGET');i=next(i for i,q in enumerate(changed) if q[:4]==[widget['rectangle'][0],widget['rectangle'][1],widget['rectangle'][2]-widget['rectangle'][0],widget['rectangle'][3]-widget['rectangle'][1]])
     if change=='appearance':changed[i][4:]=[255,0,0]
     else:changed[i][0]=101;changed[i][2]=14
   rows[(product,number,change)]=make(changed)
rows[('created',1,'one-pixel')]=list(rows[('created',1,None)]);rows[('created',1,'one-pixel')][0]=b'\x00'*3+rows[('created',1,'one-pixel')][0][3:]
filter_cache={};encoded_cache={};observations=[];negative_counts=[]
def filtered(current,previous,kind):
 key=(current,previous,kind)
 if key in filter_cache:return filter_cache[key]
 out=bytearray(len(current))
 for x,v in enumerate(current):
  a=current[x-3] if x>=3 else 0;b=previous[x];c=previous[x-3] if x>=3 else 0
  if kind==0:predict=0
  elif kind==1:predict=a
  elif kind==2:predict=b
  elif kind==3:predict=(a+b)//2
  else:
   p=a+b-c;pa,pb,pc=abs(p-a),abs(p-b),abs(p-c);predict=a if pa<=pb and pa<=pc else b if pb<=pc else c
  out[x]=(v-predict)&255
 filter_cache[key]=bytes(out);return filter_cache[key]
def inspect(p,product,number,change=None):
 data=read(p);h=hashlib.sha256(data).hexdigest();grid=rows[(product,number,change)];decodedsha=hashlib.sha256(b''.join(grid)).hexdigest();key=(h,decodedsha)
 if key not in encoded_cache:
  eq(data[:8],b'\x89PNG\r\n\x1a\n',str(p)+' PNG signature');pos=8;compressed=[];chunks=[]
  while pos<len(data):
   n=int.from_bytes(data[pos:pos+4],'big');kind=data[pos+4:pos+8];payload=data[pos+8:pos+8+n];crc=data[pos+8+n:pos+12+n];eq(len(payload),n,str(p)+' exact PNG chunk length');eq(zlib.crc32(kind+payload)&0xffffffff,int.from_bytes(crc,'big'),str(p)+' original CRC');chunks.append(kind.decode())
   if kind==b'IHDR':eq(list(struct.unpack('>IIBBBBB',payload)),[240,200,8,2,0,0,0],str(p)+' opaque RGB8 comparator input')
   elif kind==b'IDAT':compressed.append(payload)
   elif kind==b'IEND':eq(pos+12,len(data),str(p)+' exact original PNG EOF');break
   pos+=n+12
  eq(chunks[0],'IHDR',str(p)+' first IHDR');eq(chunks[-1],'IEND',str(p)+' final IEND');eq('tRNS' in chunks,False,str(p)+' no transparency');n=200*721;inflate=zlib.decompressobj();scan=inflate.decompress(b''.join(compressed),n+1);eq(len(scan),n,str(p)+' bounded complete inflation');eq(inflate.eof and not inflate.unused_data and not inflate.unconsumed_tail,True,str(p)+' exact single zlib stream');previous=b'\x00'*720;filters=Counter()
  for y,current in enumerate(grid):
   start=y*721;kind=scan[start];eq(kind in range(5),True,str(p)+' valid filter');eq(scan[start+1:start+721],filtered(current,previous,kind),str(p)+' every RGB byte in row '+str(y));previous=current;filters[kind]+=1
  encoded_cache[key]={'encoded-sha256':h,'prescribed-decoded-rgb-sha256':decodedsha,'pixel-count':48000,'width':240,'height':200,'original-chunks':chunks,'original-filter-counts':dict(filters)}
 observations.append({'path':str(p.relative_to(REPO)),'product':product,'page':number,'prescribed-control':change,**encoded_cache[key]})
for product,p in corpus['products'].items():
 for i,v in enumerate(p['visual'],1):inspect(C/v['raster'],product,i)
for major,mode in TUPLES:
 name='jdk'+str(major)+'-'+mode.lower();obs=ROOT/name/'observations'
 for api in ['native','facade']:
  for product,p in corpus['products'].items():
   for i in range(1,len(p['pages'])+1):
    for suffix in ['expected','pdfium','implementation']:inspect(obs/(api+'-'+product)/('page-'+str(i)+'-'+suffix+'.png'),product,i)
 neg=obs/'negative/visual';inspect(neg/'one-pixel/original.png','created',1);inspect(neg/'one-pixel/one-pixel.png','created',1,'one-pixel')
 for change,product in [('appearance','created'),('rectangle','created'),('retained-paint','flattened')]:
  for i in range(1,4):
   d=neg/change;inspect(d/('page-'+str(i)+'-expected.png'),product,i)
   for suffix in ['pdfium','implementation']:inspect(d/('page-'+str(i)+'-'+suffix+'.png'),product,i,change)
   before=b''.join(rows[(product,i,None)]);after=b''.join(rows[(product,i,change)]);diff=sum(before[x:x+3]!=after[x:x+3] for x in range(0,len(before),3));raw=read(d/('page-'+str(i)+'-visual.txt')).decode();eq(int(re.search(r'^Exact changed RGB pixels, expected to PDFium: (\d+)$',raw,re.M)[1]),diff,name+' exact geometry-derived negative RGB '+change+str(i));ae=Decimal(re.search(r'^Expected comparison AE: `([^`]+)`$',raw,re.M)[1]);eq(ae>0 if diff else ae==0,True,name+' separate ImageMagick AE zero/nonzero '+change+str(i));eq(diff,({'appearance':900,'rectangle':60,'retained-paint':200}[change] if i==1 else 0),name+' complete changed pixel extent '+change+str(i));negative_counts.append({'tuple':name,'control':change,'page':i,'geometric-rgb-difference':diff,'actual-ImageMagick-AE':str(ae),'secondary-RGB-difference':0})
finish('annotations-'+BATCH+'-complete-rgb-raster-inspection.json',{'scope':'Only completed immutable T12 tuples in '+BATCH,'method':'Read-only CRC, bounded zlib and every scanline byte verified against independently constructed authored page/AP/flattened-order RGB geometry. Exact own-file PNG hashes, never cross-JDK compression equality. No renderer/image utility/project command executed.','complete-corpus-property-count':len(flat),'authored-product-pages':geometries,'visual-profiles':allprofiles,'input-raster-observations':len(observations),'distinct-encoded-and-prescribed-raster-pairs':len(encoded_cache),'observations':observations,'negative-pixel-observations':negative_counts,'ImageMagick-vs-RGB':'AE is its original decimal metric; exact RGB changed-pixel count is a separate integer. Both must detect nonzero defects; no assertion that their nonzero magnitudes coincide.','difference-raster-boundary':'All optimized comparator difference images retain original hashes/process findings in complete evidence audit; opaque RGB controls are the full comparator inputs.'})
if errors:raise ValueError('Read-only raster inspection diagnostics retained; original evidence unchanged')
