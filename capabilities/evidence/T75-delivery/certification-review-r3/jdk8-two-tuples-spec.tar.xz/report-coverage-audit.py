from auditlib import *
products=['nested-split-type3','marked-structure','embedded-font-kinds','embedded-font-inheritance','uncertain-geometry'];summaries=[]
for mode in ['IN_PROCESS','HARDENED_WORKER']:
 scope=ROOT/('jdk8-'+mode.lower());obs=scope/'observations'
 for chain in ['syntax','standards','semantic','visual']:
  wanted={'products':[],'findings':[],'negative-controls':[]};observed=obj(scope/(chain+'-report.json'));under=lambda d:sorted(p for p in d.rglob('*') if p.is_file())
  for api in ['native','facade']:
   for product in products:
    if chain=='visual' and product not in products[:3]:continue
    d=obs/(api+'-'+product);wanted['products'].append(d/'extraction.pdf');folders=['declarations','programs'] if chain=='standards' else [chain]
    for folder in folders:wanted['findings']+=under(d/folder)
    if chain=='standards':
     wanted['negative-controls']+=[p for p in under(d/'declarations') if p.name.startswith(('negative-','control-'))]
     wanted['negative-controls']+=[p for p in under(d/'programs') if p.name.startswith('control-') or (d/'programs/qualifications') in p.parents]
    wanted['findings'] += [d/'result.properties',d/'retained-files.sha256']
    if chain=='semantic':wanted['findings'] += [d/n for n in ['publication.properties','observation.properties','reopened.properties']]
  wanted['negative-controls'] += under(obs/'negative'/chain)+[obs/'negative'/n for n in ['result.properties','retained-files.sha256']]
  wanted['findings'] += [obs/n for n in ['result.properties','retained-files.sha256','products.properties']]
  if chain=='semantic':wanted['findings'] += [scope/'contract-tests.txt',scope/'contract-tests-command.json']
  for category,paths in wanted.items():eq([r['path'] for r in observed[category]],[str(p.relative_to(REPO)) for p in paths],mode+'/'+chain+'/'+category+' exact required original-file coverage and order')
  summaries.append({'tuple':mode,'chain':chain,'matched-original-required-array-counts':{k:len(v) for k,v in wanted.items()}})
finish('report-array-coverage-inspection.json',{'method':'Independent original-file inventory compared with each complete chain report array, including negative-control qualification originals and semantic public outcomes. Identity checks are retained separately.','reports':summaries})
