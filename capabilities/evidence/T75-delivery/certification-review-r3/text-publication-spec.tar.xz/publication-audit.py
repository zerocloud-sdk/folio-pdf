from pathlib import Path
import hashlib,json,datetime
OUT=Path(__file__).parent
REPO=Path('/home/ubuntu/IdeaProjects/open-pdf')
ROOT=REPO/'capabilities/evidence/T75-foundation-20260913-r3/text'
PRIOR=Path('/tmp/t75-final-spec-r3-last-three-d_5tt9z2')
CID='e2dd9ebbeae5668ccc8e2985ccd8af17c8921d1ec5e12e0c913cbd1fa00dfbd6';TID='3de508f79fcbef7258feee8abc013d6f02b000840cac1cb263cb0d6f927b8f2b';INDEX='53c201c9ce9ab815171438f9712b40752ccb9adef58280dfe16959f7f8e5eb9e'
files={};copies=[];errors=[]
def eq(a,b,where):
 if a!=b:errors.append({'where':str(where),'actual':a,'expected':b})
def remember(p,h,size):
 key=str(p)
 if key in files:eq(files[key]['sha256'],h,'fixed reviewed bytes unchanged '+key)
 files[key]={'path':key,'sha256':h,'bytes':size}
def read(p,copy=False):
 b=p.read_bytes();h=hashlib.sha256(b).hexdigest();remember(p,h,len(b))
 if copy:
  rel=Path('originals/repo')/p.relative_to(REPO) if p.is_relative_to(REPO) else Path('originals/external')/p.as_posix().lstrip('/')
  dest=OUT/rel;dest.parent.mkdir(parents=True,exist_ok=True)
  if dest.exists():eq(dest.read_bytes(),b,'original copy remains unchanged')
  else:dest.write_bytes(b)
  item={'path':str(p),'sha256':h,'bytes':len(b),'copy':rel.as_posix()}
  if item not in copies:copies.append(item)
 return b
def digest(p):
 h=hashlib.sha256();size=0
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b);size+=len(b)
 v=h.hexdigest();remember(p,v,size);return v
def obj(p,copy=False):return json.loads(read(p,copy))
def write(n,v):(OUT/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def ref(p):return {'path':str(p),'sha256':digest(p),'bytes':p.stat().st_size}
commandpath=Path('/tmp/t75-final-text-certify-r3-command.json');resultpath=Path('/tmp/t75-final-text-certify-r3-result.json');logpath=Path('/tmp/t75-final-text-certify-r3.log')
command=obj(commandpath,True);result=obj(resultpath,True);log=read(logpath,True).decode();expectedcommand=['python3','scripts/t03-foundation.py','certify','capabilities/evidence/T75-foundation-20260913-r3/text','--obligation','text']
eq(command['command'],expectedcommand,'actual exact outer command');eq(command['cwd'],str(REPO),'original cwd');eq(command['explicit-environment'],{'FOLIO_HARFBUZZ_HELPER':str(REPO/'.build-cache/harfbuzz/10.2.0-final/bin/folio-harfbuzz')},'original explicit helper environment');eq(command['original-log'],str(logpath),'original log path')
for k,v in command.items():eq(result[k],v,'same original invocation '+k)
eq(result['returncode'],0,'actual outer exit');eq(result['completed-utc'],'2026-09-13T08:52:24.284424+00:00','actual original completion timestamp');eq(isinstance(result['command-pid'],int) and result['command-pid']>0,True,'actual child process receipt');started=datetime.datetime.fromisoformat(result['started-utc']);completed=datetime.datetime.fromisoformat(result['completed-utc']);eq(completed>started,True,'actual complete process duration')
expectedlog=[]
for major in [8,11,17,21]:expectedlog+=['T13 environment JDK '+str(major),'T13 certification JDK '+str(major)+' / IN_PROCESS','T13 certification JDK '+str(major)+' / HARDENED_WORKER']
expectedlog+=['Recorded exactly eight T13 certifications; retained 0 current certifications for other obligations.'];eq(log,'\n'.join(expectedlog)+'\n','exact complete original outer stdout')
priorreport=read(PRIOR/'report.md',True);eq(hashlib.sha256(priorreport).hexdigest(),'3097a16e2cd97f3596369a90776679f3659a8369fe12ad0f953a1c73bc829b69','deferred report preserved');receipt=obj(PRIOR/'receipt.json',True);eq(digest(PRIOR/'receipt.json'),'701e3256db91fbd0f507f6160e34544fb4663df17a974886b22e4a83dc78ed5d','prior receipt preserved');eq(receipt['complete-eight-evidence-review-linked'],True,'previous complete evidence scope');eq(receipt['unresolved-Spec-findings'],[],'previous complete evidence review findings');eq(receipt['candidate'],CID,'previous candidate');eq(receipt['contract'],TID,'previous contract');eq(receipt['outer-exit-and-text-publication-approved'],False,'previous explicit deferral retained')
for n in ['eight-tuple-review-linkage-inspection.json','end-of-evidence-review-identities.json']:
 p=PRIOR/n;data=obj(p,True);wanted=next(x['inspection']['sha256'] for x in receipt['phases'] if x['inspection']['path']==n);eq(digest(p),wanted,'prior original inspection '+n);eq(data['errors'],[],'prior clean inspection '+n)
link=obj(PRIOR/'eight-tuple-review-linkage-inspection.json');end=obj(PRIOR/'end-of-evidence-review-identities.json');eq(link['exact-text-tuple-count'],8,'previous eight tuples');eq(link['exact-chain-record-count'],32,'previous four chains each');eq(link['observed-index-sha256'],INDEX,'previous reviewed observed index');eq(digest(PRIOR/'inspected-source-sha256.json'),receipt['evidence-identities']['sha256'],'previous full evidence source identity manifest')
reviewed={r['path']:r['sha256'] for r in end['final-eight-tuple-envelope-identities']+end['final-eight-environment-raw-identities']}
buildpath=REPO/'capabilities/evidence/T75-delivery/final-candidate-r3/build-inputs.json';build=obj(buildpath,True);eq(digest(buildpath),'edc129bd06eb5ee6ac00c4653173a524f72367f73ac1c14f040f8f5c9eb8aa70','original r3 stage manifest');eq(digest(REPO/'target/foundation-0.1.0/build-inputs.json'),digest(buildpath),'current staged build manifest linkage')
canon=lambda kind,rows:''.join(kind+' '+r['path']+' '+r['sha256']+'\n' for r in sorted(rows,key=lambda r:r['path']))
candidate=build['candidate'];eq(hashlib.sha256(('release '+candidate['release']+'\n'+canon('input',candidate['inputs'])+canon('artifact',candidate['artifacts'])).encode()).hexdigest(),CID,'canonical tested candidate');eq(hashlib.sha256(canon('contract',build['contract-inputs']).encode()).hexdigest(),TID,'canonical contract');eq(obj(ROOT/'identities.json',True),{'Candidate':CID,'Contract':TID},'actual certifier identities')
script=REPO/'scripts/t03-foundation.py';read(script,True);eq(digest(script),next(x['sha256'] for x in candidate['inputs'] if x['path']=='scripts/t03-foundation.py'),'published original certifier source identity')
index=obj(ROOT/'observed-index.json',True);eq(digest(ROOT/'observed-index.json'),INDEX,'complete reviewed observed index unchanged');eq(index['candidate'],candidate,'observed tested artifacts and candidate inputs');eq(len(index['certifications']),8,'exact observed tuple count');eq(len(index['environments']),4,'exact observed environments')
rows=[];environment={}
for item in index['environments']:
 p=REPO/item['record']['path'];data=obj(p,True);h=digest(p);eq(h,item['record']['sha256'],'actual before environment reference');eq(h,reviewed[str(p)],'closed environment identity unchanged');environment[item['profile']]=(item['record'],data)
expectedscopes={(f'ubuntu-24.04-linux-x86-64-jdk{j}',m) for j in [8,11,17,21] for m in ['IN_PROCESS','HARDENED_WORKER']};eq({(c['environment'],c['execution-profile']) for c in index['certifications']},expectedscopes,'complete actual profile combinations')
for c in index['certifications']:
 eq(c['obligation'],'text','only text observed obligation');configpath=REPO/c['configuration']['path'];config=obj(configpath,True);eq(digest(configpath),c['configuration']['sha256'],'actual execution configuration');eq(digest(configpath),reviewed[str(configpath)],'closed configuration unchanged');eq(config['candidate-sha256'],CID,'actual configuration candidate');eq(config['environment-sha256'],environment[c['environment']][0]['sha256'],'actual configuration environment');eq(config['execution-profile'],c['execution-profile'],'actual Native mode');eq(config['settings']['providers'],'none; Stable Facade execution is IN_PROCESS','actual Facade scope')
 eq(len(c['records']),4,'exact independent chain cardinality');chains=[]
 for item in c['records']:
  p=REPO/item['path'];record=obj(p);h=digest(p);eq(h,item['sha256'],'actual published chain record');eq(h,reviewed[str(p)],'fully reviewed chain bytes unchanged');chains.append(record['chain'])
  for key,value in {'obligation':'text','acceptance-profile':'T13-text-logical-structure','release':'0.1.0','candidate-sha256':CID,'contract-sha256':TID,'environment-sha256':environment[c['environment']][0]['sha256'],'execution-configuration-sha256':c['configuration']['sha256'],'execution-profile':c['execution-profile'],'result':'pass'}.items():eq(record[key],value,'original chain binding '+str(p)+' '+key)
  reportpath=REPO/record['report']['path'];rh=digest(reportpath);eq(rh,record['report']['sha256'],'actual original report hash');eq(rh,reviewed[str(reportpath)],'fully reviewed report bytes unchanged');profilepath=REPO/record['configuration']['path'];eq(digest(profilepath),record['configuration']['sha256'],'actual frozen profile binding')
 eq(chains,['syntax','standards','semantic','visual'],'complete four-chain ordered records');rows.append({'environment':c['environment'],'native-mode':c['execution-profile'],'actual-facade-mode':'IN_PROCESS','configuration-sha256':c['configuration']['sha256'],'chain-records':c['records']})
authorityobservations=[]
def authority_snapshot(label):
 p=REPO/'capabilities/foundation-evidence.yaml';b=p.read_bytes();data=json.loads(b);dest=OUT/('originals/'+label+'-foundation-evidence.yaml');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b);textrows=[c for c in data['certifications'] if c['obligation']=='text'];key=lambda c:(c['environment'],c['execution-profile']);eq(sorted(textrows,key=key),sorted(index['certifications'],key=key),label+' authority exact unchanged eight text certifications');eq(data['candidate'],candidate,label+' authority actual candidate');amap={e['profile']:e['record'] for e in data['environments']}
 for profile,(record,envdata) in environment.items():eq(amap[profile]['sha256'],record['sha256'],label+' authority environment identity allowing equivalent later observation path')
 item={'path':str(p),'copy':str(dest.relative_to(OUT)),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'at-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'text-certifications':len(textrows),'other-obligation-certifications':len(data['certifications'])-len(textrows),'exact-text-subset-match':True};authorityobservations.append(item);return item
first=authority_snapshot('first');eq(digest(ROOT/'observed-index.json'),INDEX,'reviewed index still unchanged');eq(digest(logpath),'e4e7bfa228bec08a11e447a3f5f17944c82e7119482cbc9a7c2db87f01daebfd','outer original log preserved');eq(digest(commandpath),'0afdcb850b778c6e7f0ba392ae8879c832f70a6c89c528ccccf81a351d0d1008','outer original command preserved');eq(digest(resultpath),'25aeb00bcf232885b38c8f838ed83288a2e80740d9c17112df9bfaa24f2b4d15','outer original result preserved');last=authority_snapshot('final')
write('inspected-input-identities.json',list(files.values()));write('original-copy-identities.json',copies);write('authority-snapshot-identities.json',authorityobservations)
summary={'completed-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Deferred r3 text original outer-exit and authority publication gate only','original-command':ref(commandpath),'original-log':ref(logpath),'original-result':ref(resultpath),'original-outer-started-utc':result['started-utc'],'original-outer-completed-utc':result['completed-utc'],'original-outer-exit':result['returncode'],'original-duration-seconds':(completed-started).total_seconds(),'prior-deferred-review':ref(PRIOR/'report.md'),'prior-closed-receipt':ref(PRIOR/'receipt.json'),'prior-complete-evidence-source-identities':ref(PRIOR/'inspected-source-sha256.json'),'candidate-sha256':CID,'contract-sha256':TID,'observed-index-sha256':INDEX,'tested-source-contract-artifact-harness-counts':{'sources':len(candidate['inputs']),'contracts':len(build['contract-inputs']),'artifacts':len(candidate['artifacts']),'harness':len(build['harness'])},'current-fixed-stage-manifest-matches':True,'source-and-raw-qualification-revalidation-method':'Reuse frozen complete review; direct current index, stage metadata, environment, configuration, 32 record and 32 report SHA verification. No raw qualification replay.','exact-authority-text-certifications':8,'exact-chain-records':32,'tuples':rows,'authority-observations':authorityobservations,'text-eight-publication-gate-closed':not errors,'other-obligations-all48-and-final-delivery-approved':False,'original-deferred-report-modified':False,'project-commands-executed':False,'repository-mutated':False,'errors':errors}
write('publication-inspection.json',summary);print(json.dumps({'read-inputs':len(files),'selected-original-copies':len(copies),'authority-snapshots':len(authorityobservations),'outer-exit':result['returncode'],'closed-text-certifications':8,'chain-records':32,'errors':errors[:5],'error-count':len(errors)}));
if errors:raise SystemExit(1)
