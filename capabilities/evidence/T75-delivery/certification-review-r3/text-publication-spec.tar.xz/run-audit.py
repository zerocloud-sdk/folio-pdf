from pathlib import Path
import subprocess,sys,datetime,json,hashlib
out=Path(__file__).parent;command=[sys.executable,'-B',str(out/'publication-audit.py')]
meta={'command':command,'cwd':str(out),'started-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'script-sha256':hashlib.sha256((out/'publication-audit.py').read_bytes()).hexdigest(),'scope':'Independent read-only metadata and original byte identity inspection; no project execution'}
(out/'audit-command.json').write_text(json.dumps(meta,indent=2)+'\n')
with (out/'audit-output.txt').open('wb') as log:r=subprocess.run(command,cwd=out,stdout=log,stderr=subprocess.STDOUT)
meta.update({'returncode':r.returncode,'completed-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stdout-stderr-sha256':hashlib.sha256((out/'audit-output.txt').read_bytes()).hexdigest()});(out/'audit-result.json').write_text(json.dumps(meta,indent=2)+'\n');print((out/'audit-output.txt').read_text());print(json.dumps(meta));sys.exit(r.returncode)
