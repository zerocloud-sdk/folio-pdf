from pathlib import Path
import json,hashlib,datetime
OUT=Path(__file__).parent
assert OUT.is_relative_to('/tmp')
def read(n):return json.loads((OUT/n).read_bytes())
def ref(n):
 p=OUT/n;b=p.read_bytes();return {'path':str(p),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
v=read('publication-closed-inspection.json');assert v['errors']==[] and v['metadata-eight-actual-exit-and-publication-gate-closed'];assert read('publication-audit-result.json')['returncode']==0;assert read('outer-command-closure-audit-result.json')['returncode']==0;assert read('reader-timestamp-closure-inspection.json')['errors']==[]
ids={}
for name in ['publication-inspection-read-identities.json','reader-timestamp-closure-inspection-read-identities.json']:
 for row in read(name):
  if row['path'] in ids:assert row['sha256']==ids[row['path']]['sha256']
  ids[row['path']]=row
for row in ids.values():assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256']
copies=read('source-copy-identities.json')
for row in copies:assert hashlib.sha256((OUT/row['copy']).read_bytes()).hexdigest()==row['sha256']
(OUT/'inspected-input-identities.json').write_text(json.dumps(sorted(ids.values(),key=lambda r:r['path']),indent=2)+'\n')
counts={'inspected-identities':len(ids),'all-original-chain-records-rehashed':len(v['actual-records-rehashed']),'all-original-configurations-rehashed':len(v['actual-configurations-rehashed']),'metadata-original-reports-rehashed':len(v['metadata-reports-rehashed']),'metadata-BEFORE-AFTER-original-environment-files-rehashed':len(v['metadata-original-before-after-environment-files']),'source-copies':len(copies),'original-command-archive-members-checked':len(v['command-archive-members']),'authority-snapshots':len(v['authority-snapshots'])}
assert counts['all-original-chain-records-rehashed']==160 and counts['all-original-configurations-rehashed']==40 and counts['metadata-original-reports-rehashed']==32 and counts['metadata-BEFORE-AFTER-original-environment-files-rehashed']==84
report='''CLEAN: only the deferred metadata/T11 actual exit and publication gate is now closed.

The original certifier exited 0 at `2026-09-13T11:32:07.174509Z`. Its command, start, PIDs and complete stdout match the preserved pending observations. The final line records eight T11 certifications and retention of 32 prior certifications. Original command, log and result bytes are copied and independently hashed.

The authority contains exactly the eight reviewed metadata certifications, matching unchanged observed-index SHA `ea29f82496b04a18bcda38546aff6f69f0e4a53cde620ef740e8d3e6c1d2c924`. Exact text8, transactions8, values8 and pages8 subsets remain intact. Both current atomic snapshots and the dated retention snapshot agree. Later additions of other obligations are permitted.

Rehashed 160 chain records, 40 configurations, 32 metadata reports and all 84 original metadata BEFORE/AFTER environment files. Candidate `e2dd9ebbeae5668ccc8e2985ccd8af17c8921d1ec5e12e0c913cbd1fa00dfbd6` and contract `3de508f79fcbef7258feee8abc013d6f02b000840cac1cb263cb0d6f927b8f2b` retain the frozen baseline and complete review linkage. Facade actual execution remains IN_PROCESS. The prior eight-tuple raw review, deferred report, snapshots and diagnostics remain byte-identical. Its archived map has 24,970 members, including the manifest whose 24,969 entries exclude itself.

This reader initially carried an incorrect expected timestamp because global T10-to-T11 replacement also changed a prior ISO timestamp. The original actual result was correct throughout. The diagnostic and original reader output are preserved; a separate clean inspection reconciles the exact result, archived copy and retention receipt. No certification failure or rerun resulted.

This closes the Goal's existing-obligation refresh gate (original Goal:131–133) and T11's candidate-bound atomic publication requirement (docs/t11-certification.md:117–123,247–253). No full raw audit replay, project command or repository mutation occurred. No all48, inventory/index, completion-criterion or final-delivery approval is given.
'''
assert len(report.split())<400
(OUT/'report.md').write_text(report)
receipt={'created-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'verdict':'CLEAN; only metadata8 actual exit/publication gate closed','baseline':v['baseline'],'candidate-sha256':v['candidate-sha256'],'contract-sha256':v['contract-sha256'],'report':ref('report.md'),'report-word-count':len(report.split()),'scope':ref('scope.json'),'independent-inspection':ref('publication-closed-inspection.json'),'original-diagnostic-inspection':ref('publication-inspection.json'),'reader-diagnostic-closure':ref('reader-timestamp-closure-inspection.json'),'actual-independent-command':ref('publication-audit-command.json'),'actual-independent-result':ref('publication-audit-result.json'),'actual-independent-output':ref('publication-audit-output.txt'),'actual-independent-script':ref('publication-audit.py'),'actual-reader-closure-command':ref('outer-command-closure-audit-command.json'),'actual-reader-closure-result':ref('outer-command-closure-audit-result.json'),'actual-reader-closure-output':ref('outer-command-closure-audit-output.txt'),'actual-reader-closure-script':ref('outer-command-closure-audit.py'),'original-command':v['original-command'],'original-stdout':v['original-stdout'],'original-result':v['original-result'],'actual-original-returncode':v['original-returncode'],'actual-original-completed-utc':v['original-completed-utc'],'original-metadata-observed-index-sha256':v['metadata-observed-index-sha256'],'prior-deferred-report':v['prior-deferred-report'],'prior-deferred-receipt':v['prior-deferred-receipt'],'prior-closed-review-linkage':v['prior-closed-review-linkage'],'exact-inspected-counts':counts,'metadata-eight-publication-gate-closed':True,'exact-prior-text8-retained':True,'exact-prior-transactions8-retained':True,'exact-prior-values8-retained':True,'exact-prior-pages8-retained':True,'authority-snapshots':v['authority-snapshots'],'source-copy-identities':ref('source-copy-identities.json'),'inspected-identities':ref('inspected-input-identities.json'),'prior-full-review-archive-linkage':v['prior-full-review-archive-linkage'],'original-pending-and-reader-history-unchanged':True,'huge-raw-audits-replayed':False,'other-obligation-additions-permitted':True,'other-obligations-all48-inventory-index-or-final-delivery-approved':False,'completion-criteria-marked':False}
(OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'report-sha256':receipt['report']['sha256'],'receipt-sha256':ref('receipt.json')['sha256'],'report-words':len(report.split()),'counts':counts,'scope':'Only deferred metadata publication gate closed'}))
