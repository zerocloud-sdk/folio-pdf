from auditlib import *
from collections import Counter
stage=obj(OUT/'stage-environment-contract-inspection.json');cid=stage['candidate-sha256'];tid=stage['contract-sha256'];summary=[];allrefs=[];allman=[];resolved_paths={}
def hashed(p):return files[str(p)]['sha256'] if str(p) in files else sha(p)
def references(j,owner):
 if isinstance(j,dict):
  if isinstance(j.get('path'),str) and isinstance(j.get('sha256'),str):
   n=j['path'];q=PurePosixPath(n);p=REPO/n
   if q.is_absolute() or '..' in q.parts or q.as_posix()!=n:error(owner,'noncanonical file reference '+n)
   if not p.is_file():error(owner,'missing reference '+n)
   else:
    if str(p) not in resolved_paths:resolved_paths[str(p)]=p.resolve()
    if resolved_paths[str(p)]!=p:error(owner,'linked file reference '+n)
    eq(hashed(p),j['sha256'],str(owner)+' -> '+n)
   yield {'owner':str(owner.relative_to(REPO)),'path':n,'sha256':j['sha256']}
  for v in j.values():yield from references(v,owner)
 elif isinstance(j,list):
  for v in j:yield from references(v,owner)
for major,mode in TUPLES:
 tuple_name='jdk'+str(major)+'-'+mode.lower()
 scope=ROOT/tuple_name;obs=scope/'observations';physical=sorted(p for p in obs.rglob('*') if p.is_file());roots={str(p.relative_to(obs)):sha(p) for p in physical};rootmanifest=manifest(obs/'retained-files.sha256');eq(rootmanifest,{n:h for n,h in roots.items() if n not in ('result.properties','retained-files.sha256')},mode+' root exact coverage');eq(props(obs/'result.properties')['retained-files-sha256'],sha(obs/'retained-files.sha256'),mode+' root manifest digest')
 manifests=sorted(obs.rglob('retained-files.sha256'));entrycount=0
 for p in manifests:
  entries=manifest(p);entrycount+=len(entries)
  for n,h in entries.items():eq(hashed(p.parent/n),h,str(p)+' member '+n)
  excluded={'retained-files.sha256','result.properties'}
  if p.parent.parent==obs:excluded.update(('observation.properties','reopened.properties','publication.properties'))
  under={str(x.relative_to(p.parent)):hashed(x) for x in physical if x.is_relative_to(p.parent) and str(x.relative_to(p.parent)) not in excluded}
  eq(entries,under,str(p)+' exact nested coverage');result=props(p.parent/'result.properties');eq(result.get('retained-files-sha256'),hashed(p),str(p)+' result binds own manifest');allman.append({'tuple':tuple_name,'path':str(p.relative_to(REPO)),'sha256':hashed(p),'members':len(entries)})
 chains=[];reportcount=0;scope_refs=[]
 config_hash=sha(scope/'execution.yaml');env_hash=sha(ROOT/('jdk'+str(major)+'-environment/environment.yaml'));profile_hash=sha(REPO/'capabilities/evidence/T13-text-logical-structure.md')
 for chain,producer in [('syntax','qpdf'),('standards','arlington-t13-r1'),('semantic','folio-pdf-t13'),('visual','pdfium-cli')]:
  recordpath=scope/(chain+'.yaml');reportpath=scope/(chain+'-report.json');record=obj(recordpath);report=obj(reportpath)
  subset(record,{'schema-version':1,'obligation':'text','acceptance-profile':'T13-text-logical-structure','release':'0.1.0','candidate-sha256':cid,'contract-sha256':tid,'environment-sha256':env_hash,'execution-configuration-sha256':config_hash,'execution-profile':mode,'chain':chain,'result':'pass','producer':producer},recordpath)
  eq(record['report'],{'path':str(reportpath.relative_to(REPO)),'sha256':sha(reportpath)},recordpath/'report');eq(record['configuration'],{'path':'capabilities/evidence/T13-text-logical-structure.md','sha256':profile_hash},recordpath/'profile');eq(record['negative-controls'],report['negative-controls'],recordpath/'exact negative controls');subset(report,{'chain':chain,'result':'pass'},reportpath)
  rr=list(references(report,reportpath));reportcount+=len(rr);scope_refs+=rr;scope_refs+=list(references(record,recordpath));chains.append({'chain':chain,'record-sha256':sha(recordpath),'report-sha256':sha(reportpath),'producer':producer,'counts':{k:len(report[k]) for k in ('products','findings','negative-controls','environment-observations')}})
  products=[str((obs/(a+'-'+p)/'extraction.pdf').relative_to(REPO)) for a in ['native','facade'] for p in ['nested-split-type3','marked-structure','embedded-font-kinds','embedded-font-inheritance','uncertain-geometry'] if chain!='visual' or p in ['nested-split-type3','marked-structure','embedded-font-kinds']]
  eq([r['path'] for r in report['products']],products,chain+' complete ordered corpus');eq(report['environment-observations'],[{'path':str(p.relative_to(REPO)),'sha256':hashed(p)} for p in sorted((ROOT/('jdk'+str(major)+'-environment')).iterdir()) if p.is_file()],chain+' all original environment references')
 for p in sorted(obs.rglob('*.json')):scope_refs+=list(references(obj(p),p))
 eq(any(p.is_symlink() for p in obs.rglob('*')),False,mode+' no symlinks');summary.append({'tuple':str(scope.relative_to(REPO)),'chains':chains,'physical-observation-files':len(physical),'root-manifest-entries':len(rootmanifest),'root-manifest-sha256':hashed(obs/'retained-files.sha256'),'manifests-including-root':len(manifests),'nested-manifests-excluding-root':len(manifests)-1,'all-manifest-entry-occurrences':entrycount,'report-reference-count':reportcount,'all-record-report-json-reference-occurrences':len(scope_refs),'unique-reference-paths':len({r['path'] for r in scope_refs}),'whole-root-manifest-exact':True});allrefs+=scope_refs
finish('complete-reference-inspection.json',{'method':'Independent direct SHA-256, path, record, report and complete file-manifest inspection; no project checker or producer was imported or executed.','tuples':summary,'all-record-report-json-reference-occurrences':len(allrefs)})
dump('complete-report-reference-identities.json',allrefs);dump('complete-manifest-identities.json',allman)
