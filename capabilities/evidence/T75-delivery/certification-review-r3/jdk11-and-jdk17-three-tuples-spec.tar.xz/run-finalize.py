from pathlib import Path
import json,subprocess,datetime,hashlib,sys
out=Path(__file__).parent
cmd=[sys.executable,'-B',str(out/'finalize-identities.py')]
meta={'command':cmd,'cwd':str(out),'started-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'script-sha256':hashlib.sha256((out/'finalize-identities.py').read_bytes()).hexdigest(),'scope':'read-only final source/contract/artifact/harness and three tuple/environment identity receipt'}
(out/'finalize-identities-command.json').write_text(json.dumps(meta,indent=2)+'\n')
with (out/'finalize-identities-output.txt').open('wb') as f:r=subprocess.run(cmd,cwd=out,stdout=f,stderr=subprocess.STDOUT)
meta.update({'returncode':r.returncode,'completed-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stdout-stderr-sha256':hashlib.sha256((out/'finalize-identities-output.txt').read_bytes()).hexdigest()})
(out/'finalize-identities-result.json').write_text(json.dumps(meta,indent=2)+'\n')
print((out/'finalize-identities-output.txt').read_text());print(json.dumps(meta));sys.exit(r.returncode)
