from pathlib import Path
import json,hashlib,datetime
OUT=Path(__file__).parent
REPO=Path('/home/ubuntu/IdeaProjects/open-pdf')
ROOT=REPO/'capabilities/evidence/T75-foundation-20260913-r3/text'
errors=[]
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def write(n,v):
 p=OUT/n
 if p.exists():raise ValueError('No historical output overwrite: '+str(p))
 p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
def check(p,expected):
 got=sha(p)
 if got!=expected:errors.append({'path':str(p),'expected':expected,'actual':got})
 return {'path':str(p),'sha256':got,'bytes':p.stat().st_size,'unchanged-after-audit':got==expected}
identities={};conflicts=[]
for f in sorted(OUT.glob('*read-identities.json'))+[OUT/'source-copy-identities.json']:
 for row in json.loads(f.read_text()):
  key=row['path'];prior=identities.get(key)
  if prior and (prior['sha256'],prior['bytes'])!=(row['sha256'],row['bytes']):conflicts.append({'path':key,'first':prior,'second':row})
  if not prior:identities[key]={'path':key,'sha256':row['sha256'],'bytes':row['bytes'],'observed-by':[]}
  identities[key]['observed-by'].append(f.name)
  if 'copy' in row:
   identities[key]['copy']=row['copy']
   check(OUT/row['copy'],row['sha256'])
errors.extend(conflicts)
stagepath=REPO/'capabilities/evidence/T75-delivery/final-candidate-r3/build-inputs.json'
stage=json.loads(stagepath.read_text());check(stagepath,'edc129bd06eb5ee6ac00c4653173a524f72367f73ac1c14f040f8f5c9eb8aa70')
groups=[]
for name,rows in [('sources',stage['candidate']['inputs']),('contracts',stage['contract-inputs']),('artifacts',stage['candidate']['artifacts']),('harness',stage['harness'])]:
 start=len(errors)
 for row in rows:check(REPO/row['path'],row['sha256'])
 groups.append({'group':name,'count':len(rows),'mismatches':errors[start:]})
endrows=[]
for t in ['jdk11-in_process','jdk11-hardened_worker','jdk17-in_process']:
 for suffix in ['execution.yaml','syntax.yaml','standards.yaml','semantic.yaml','visual.yaml','syntax-report.json','standards-report.json','semantic-report.json','visual-report.json','observations/retained-files.sha256','observations/result.properties','contract-tests.txt','contract-tests-command.json']:
  p=ROOT/t/suffix
  row=identities[str(p)];endrows.append(check(p,row['sha256']))
envrows=[]
for name in ['jdk11-environment','jdk11-environment-after','jdk17-environment','jdk17-environment-after']:
 for p in sorted((ROOT/name).iterdir()):
  if p.is_file():envrows.append(check(p,identities[str(p)]['sha256']))
authority=[]
for rel,expected in [('capabilities/foundation-evidence.yaml','5ce28dc586c25486baefc48e2fd95003b46822d73fbd1db15e56b63d0d24d5b8'),('capabilities/foundation-environments.yaml','38006b863158c908608305197e9f3aabbad8139d7ed00280fc212faaa4c10733')]:
 authority.append(check(REPO/rel,expected))
write('inspected-source-sha256.json',list(identities[k] for k in sorted(identities)))
write('end-of-review-identities.json',{'at-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cross-audit-identity-conflicts':conflicts,'final-input-groups':groups,'final-tuple-envelope-identities':endrows,'final-environment-raw-identities':envrows,'authorities-unchanged-from-previously-verified-baseline':authority,'complete-eight-tuple-index-exists-at-close':(ROOT/'observed-index.json').exists(),'forbidden-tuple-scopes-read':False,'unique-inspected-paths':len(identities),'original-small-copies':len(json.loads((OUT/'source-copy-identities.json').read_text())),'errors':errors})
print(json.dumps({'unique-inspected-paths':len(identities),'groups':groups,'tuple-final-checks':len(endrows),'environment-final-checks':len(envrows),'errors':len(errors),'complete-eight-tuple-index-exists-at-close':(ROOT/'observed-index.json').exists()}))
if errors:raise SystemExit(1)
