from pathlib import Path
import json,hashlib,datetime,sys
root=Path(__file__).parent
assert root.is_relative_to('/tmp')
receipt=json.loads((root/'receipt.json').read_bytes());assert hashlib.sha256((root/'report.md').read_bytes()).hexdigest()==receipt['report']['sha256'];assert json.loads((root/'finalize-audit-result.json').read_bytes())['returncode']==0;assert json.loads((root/'publication-inspection.json').read_bytes())['errors']==[]
for row in json.loads((root/'source-copy-identities.json').read_bytes()):assert hashlib.sha256((root/row['copy']).read_bytes()).hexdigest()==row['sha256']
assert not any(p.is_symlink() for p in root.rglob('*'))
seal={'command':[sys.executable,'-B',str(root/'seal-archive.py')],'verified-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'report-sha256':receipt['report']['sha256'],'receipt-sha256':hashlib.sha256((root/'receipt.json').read_bytes()).hexdigest(),'verified-source-copies':receipt['exact-inspected-counts']['source-copies'],'final-independent-audit-actual-returncode':0,'scope':'Byte-exact sealing of independent pages publication closure only'}
(root/'archive-sealing-inspection.json').write_text(json.dumps(seal,indent=2)+'\n')
entries=[]
for p in sorted(root.rglob('*')):
 if p.is_file() and p.name!='archive-manifest.json':
  b=p.read_bytes();entries.append({'path':str(p.relative_to(root)),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)})
m={'schema-version':1,'original-directory':str(root),'created-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'excludes':['archive-manifest.json'],'exclusion-reason':'Self-reference cannot carry the manifest exact SHA; every other retained regular file is listed.','member-count':len(entries),'total-member-bytes':sum(e['bytes'] for e in entries),'members':entries};p=root/'archive-manifest.json';p.write_text(json.dumps(m,indent=2)+'\n')
print(json.dumps({'directory':str(root),'report-sha256':seal['report-sha256'],'receipt-sha256':seal['receipt-sha256'],'archive-manifest-sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'archive-members':m['member-count'],'archive-member-bytes':m['total-member-bytes']}))
