from pathlib import Path,PurePosixPath
import json,hashlib,datetime,tarfile,io,ast
REPO=Path('/home/ubuntu/IdeaProjects/open-pdf');OUT=Path(__file__).parent;ROOT=REPO/'capabilities/evidence/T75-foundation-20260913-r3/annotations';files={};errors=[];copies=[]
def read(p):
 p=Path(p);b=p.read_bytes();h=hashlib.sha256(b).hexdigest();key=str(p)
 if key in files and files[key]['sha256']!=h:errors.append({'where':key,'detail':'Inspected immutable bytes changed'})
 files[key]={'path':key,'sha256':h,'bytes':len(b)};return b
def sha(p):return hashlib.sha256(read(p)).hexdigest()
def obj(p):return json.loads(read(p))
def eq(a,b,label):
 if a!=b:errors.append({'where':str(label),'actual':a,'expected':b})
def subset(a,b,label):
 for k,v in b.items():eq(a.get(k),v,str(label)+':'+k)
def save(name,value):
 p=OUT/name
 if p.exists():raise FileExistsError(str(p))
 with p.open('x') as f:json.dump(value,f,ensure_ascii=False,indent=2);f.write('\n')
def copy(p):
 p=Path(p);b=read(p);rel=Path('originals/repository')/p.relative_to(REPO) if p.is_relative_to(REPO) else Path('originals/external')/str(p).lstrip('/');dest=OUT/rel;dest.parent.mkdir(parents=True,exist_ok=True)
 if dest.exists():eq(dest.read_bytes(),b,'previous exact selected copy '+str(p));return b
 with dest.open('xb') as f:f.write(b)
 copies.append({'original':str(p),'copy':str(rel),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)});return b
scope=obj(OUT/'scope.json');CID=scope['candidate-sha256'];TID=scope['contract-sha256'];PRIOR=Path(scope['prior-raw-review']);oldreport=copy(PRIOR/'report.md');oldreceipt=json.loads(copy(PRIOR/'receipt.json'));oldmanifest=json.loads(copy(PRIOR/'original-archive-manifest.json'))
eq(sha(PRIOR/'report.md'),'eff940968aedd38064573dbd967fb08fc79062e816dc7c6aa2aa8b74de303ad7','exact original deferred raw report');eq(sha(PRIOR/'receipt.json'),'33e2ae0fe1116621a01f77773b0024afee01f3062d90686d415aec432e7a085c','exact original deferred raw receipt');eq(sha(PRIOR/'original-archive-manifest.json'),'d0b96db7607db814ff4cc57317effc7fed0c67bf4c1ed54f67260e0a3974f241','exact original independently sealed manifest');eq(oldmanifest['entry-count'],2941,'original manifest member count');eq(oldmanifest['excluded-paths'],['original-archive-manifest.json'],'original manifest explicit self exclusion');subset(oldreceipt,{'candidate-sha256':CID,'contract-sha256':TID,'annotations-eight-raw-gate-closed':True,'annotations-eight-publication-gate-closed':False,'all-earlier-derived-review-bytes-preserved':False},'original raw history and incident boundary')
oldmap={r['path']:r for r in oldmanifest['entries']};oldids={r['path']:r for r in obj(Path(oldreceipt['inspected-input-identities']['path']))};eq(sha(Path(oldreceipt['inspected-input-identities']['path'])),oldreceipt['inspected-input-identities']['sha256'],'exact closed original input identity catalog')
for name in ['initial-pending-observation.json','initial-pending-outer-log.txt','reader-output-incident-and-closure.json','reader-schema-diagnostic.json','reader-boolean-schema-diagnostic.json','batch-reader-closures-1jc5jl38/reader-diagnostics-and-closure-receipt.json','batch-all-eight-closure-22ypv95e/final-raw-evidence-inspection.json','batch-all-eight-closure-22ypv95e/complete-config-and-index-inspection.json','batch-all-eight-closure-22ypv95e/pending-or-complete-outer-log.txt','batch-all-eight-closure-22ypv95e/authority-snapshot.yaml']:
 copy(PRIOR/name);eq(sha(PRIOR/name),oldmap[name]['sha256'],'unchanged original deferred/diagnostic '+name)
incident=obj(PRIOR/'reader-output-incident-and-closure.json');eq(len(incident['lost-derived-summary-paths']),2,'two disclosed lost own summaries retained as limitation');eq(incident['fresh-first-four-reinspection']['result'],'CLEAN','fresh original graph reinspection closed')
goal=Path('/home/ubuntu/.codex/attachments/77353239-0dda-4ee1-b4bb-ce7fb3fa0f9b/pasted-text-1.txt');copy(goal);eq(sha(goal),'794423d41161169ea6a4fee993553f777d6249cb05c5fe4d34f59657ab18f83f','original Goal identity')
commandpath=Path('/tmp/t75-final-annotations-certify-r3-command.json');logpath=Path('/tmp/t75-final-annotations-certify-r3.log');resultpath=Path('/tmp/t75-final-annotations-certify-r3-result.json');command=json.loads(copy(commandpath));log=copy(logpath).decode();actual_result=json.loads(copy(resultpath));expected_command=['/usr/bin/python3','scripts/t03-foundation.py','certify',str(ROOT.relative_to(REPO)),'--obligation','annotations'];eq(command['command'],expected_command,'exact original outer command');subset(command,{'cwd':str(REPO),'started-utc':scope['started-utc'],'wrapper-pid':scope['wrapper-pid'],'original-log':str(logpath),'explicit-environment':{'FOLIO_HARFBUZZ_HELPER':str(REPO/'.build-cache/harfbuzz/10.2.0-final/bin/folio-harfbuzz')}},'original annotations command facts');subset(actual_result,command,'same actual command result');subset(actual_result,{'command-pid':scope['command-pid'],'returncode':0,'completed-utc':scope['completed-utc']},'actual same-process completion');eq(sha(commandpath),'86dd22bbc613f5c33393d8c5571417b90c9daba0dd8e190d3dfa87c08ae4e038','same previously pending outer command')
expected=[]
for j in [8,11,17,21]:expected += ['T12 environment JDK '+str(j),'T12 certification JDK '+str(j)+' / IN_PROCESS','T12 certification JDK '+str(j)+' / HARDENED_WORKER']
expected.append('Recorded exactly eight T12 certifications; retained 40 current certifications for other obligations.');eq(log,'\n'.join(expected)+'\n','exact complete actual outer stdout')
for name in ['initial-pending-outer-log.txt','batch-all-eight-closure-22ypv95e/pending-or-complete-outer-log.txt']:eq(log.startswith(read(PRIOR/name).decode()),True,'preserved pending stdout prefix '+name)
indexes={};priorlinks=oldreceipt['prior-evidence-review-lineage'];indexspec=[{'obligation':'annotations','observed-index-sha256':oldreceipt['observed-index-sha256']}]+priorlinks
for link in indexspec:
 ob=link['obligation'];p=ROOT.parent/ob/'observed-index.json';indexes[ob]=json.loads(copy(p));eq(sha(p),link['observed-index-sha256'],'unchanged completely reviewed '+ob+' index');eq(len(indexes[ob]['certifications']),8,'exact reviewed8 '+ob)
for link in priorlinks:
 for label in ['report','receipt']:
  p=Path(link[label+'-path']);copy(p);eq(sha(p),link[label+'-sha256'],'prior closed '+label+' '+link['obligation'])
buildpath=REPO/'capabilities/evidence/T75-delivery/final-candidate-r3/build-inputs.json';build=json.loads(copy(buildpath));eq(sha(buildpath),'edc129bd06eb5ee6ac00c4653173a524f72367f73ac1c14f040f8f5c9eb8aa70','historical frozen r3 stage');candidate=build['candidate'];canonical=lambda label,rows:''.join(label+' '+r['path']+' '+r['sha256']+'\n' for r in sorted(rows,key=lambda r:r['path']));eq(hashlib.sha256(('release '+candidate['release']+'\n'+canonical('input',candidate['inputs'])+canonical('artifact',candidate['artifacts'])).encode()).hexdigest(),CID,'historical staged candidate identity');eq(hashlib.sha256(canonical('contract',build['contract-inputs']).encode()).hexdigest(),TID,'historical staged contract identity')
staged_counts={'sources':len(candidate['inputs']),'contracts':len(build['contract-inputs']),'artifacts':len(candidate['artifacts']),'harness':len(build['harness'])};eq(staged_counts,{'sources':1933,'contracts':30,'artifacts':23,'harness':24},'reviewed r3 input cardinalities')
staged_artifacts=[]
for r in candidate['artifacts']+build['harness']:
 p=REPO/r['path'];eq(sha(p),r['sha256'],'unaltered retained staged artifact/harness '+r['path']);staged_artifacts.append(r)
# Source/contract rows are bound to the frozen r3 stage and prior source review.
# Root is diagnosing a new inventory reader limit; this does not certify any new
# workspace edits. No inference that current working source remains r3 is made.
for r in candidate['inputs']+build['contract-inputs']:
 eq(r['sha256'],oldids[str(REPO/r['path'])]['sha256'],'frozen source/contract prior-review identity '+r['path'])
records=[];configs=[];reports=[];envs=[];rawenv=[];profiles=[]
for ob,index in indexes.items():
 eq(index['candidate'],candidate,'same historical candidate '+ob);envmap={e['profile']:e['record'] for e in index['environments']}
 for e in index['environments']:
  p=REPO/e['record']['path'];eq(sha(p),e['record']['sha256'],'bound environment record '+ob);envs.append({'obligation':ob,**e})
 for c in index['certifications']:
  cp=REPO/c['configuration']['path'];eq(sha(cp),c['configuration']['sha256'],'bound exact configuration '+ob);config=obj(cp);subset(config,{'candidate-sha256':CID,'execution-profile':c['execution-profile'],'environment-sha256':envmap[c['environment']]['sha256']},'actual configuration identity '+ob);eq(config['settings']['providers'],'none; Stable Facade execution is IN_PROCESS','actual Facade scope '+ob);configs.append({'obligation':ob,**c['configuration']});eq([Path(r['path']).stem for r in c['records']],['syntax','standards','semantic','visual'],'exact ordered4 chain records '+ob)
  if ob=='annotations':eq(sha(cp),oldids[str(cp)]['sha256'],'same fully reviewed T12 config');copy(cp)
  for r in c['records']:
   p=REPO/r['path'];eq(sha(p),r['sha256'],'exact original record '+ob);record=obj(p);subset(record,{'schema-version':1,'release':'0.1.0','candidate-sha256':CID,'contract-sha256':TID,'obligation':ob,'result':'pass','execution-profile':c['execution-profile'],'environment-sha256':envmap[c['environment']]['sha256'],'execution-configuration-sha256':c['configuration']['sha256'],'acceptance-profile':config['acceptance-profile'],'chain':p.stem},'actual record binding '+ob);records.append({'obligation':ob,**r});rp=REPO/record['report']['path'];eq(sha(rp),record['report']['sha256'],'same exact original report '+ob);report=obj(rp);subset(report,{'chain':p.stem,'result':'pass'},'actual existing report result '+ob);eq(record['negative-controls'],report['negative-controls'],'same retained control references '+ob);reports.append({'obligation':ob,**record['report']});profile=REPO/record['configuration']['path'];eq(sha(profile),record['configuration']['sha256'],'frozen profile referenced by '+ob);profiles.append({'obligation':ob,**record['configuration']})
   if ob=='annotations':eq(sha(p),oldids[str(p)]['sha256'],'same completely reviewed T12 record');eq(sha(rp),oldids[str(rp)]['sha256'],'same completely reviewed T12 report');eq(sha(profile),oldids[str(profile)]['sha256'],'same fully reviewed T12 profile')
eq(len(records),192,'all192 record identity links');eq(len(configs),48,'all48 configurations');eq(len(reports),192,'all192 report identities')
for link in oldreceipt['clean-inspections']:
 if link['kind']!='stage':continue
 p=Path(link['path']);eq(sha(p),link['sha256'],'original complete environment reconstruction review');stage=obj(p)
 for e in stage['environment-observations']:
  d=REPO/e['directory'];eq(sorted(p.name for p in d.iterdir() if p.is_file()),sorted(r['name'] for r in e['raw-files']),'original complete T12 BEFORE/AFTER inventory')
  for r in e['raw-files']:
   p=d/r['name'];eq(sha(p),r['sha256'],'unchanged originally reconstructed T12 environment '+str(p));eq(sha(p),oldids[str(p)]['sha256'],'prior environment raw identity');copy(p);rawenv.append({'path':str(p.relative_to(REPO)),'sha256':sha(p)})
authoritypath=REPO/'capabilities/foundation-evidence.yaml';snapshots=[]
def check_authority(data,label):
 a=json.loads(data);eq(a['candidate'],candidate,label+' exact historical candidate');counts={}
 for ob,index in indexes.items():
  actual=[c for c in a['certifications'] if c['obligation']==ob];eq(actual,index['certifications'],label+' exact ordered8 '+ob);counts[ob]=len(actual)
 eq(sum(counts.values()),len(a['certifications']),label+' no unreviewed extra subset at observation');mapping={e['profile']:e['record'] for e in a['environments']}
 for e in indexes['annotations']['environments']:
  eq(mapping[e['profile']]['sha256'],e['record']['sha256'],label+' same observed environment identity');eq(sha(REPO/mapping[e['profile']]['path']),e['record']['sha256'],label+' retained authority environment binding')
 return counts
def snapshot(label):
 data=authoritypath.read_bytes();p=OUT/('authority-'+label+'.json')
 with p.open('xb') as f:f.write(data)
 counts=check_authority(data,label);snapshots.append({'original':str(authoritypath),'snapshot':str(p),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'observed-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'counts':counts})
snapshot('first')
D=REPO/'capabilities/evidence/T75-delivery/final-certification-r3';aid=json.loads(copy(D/'annotations-command-archive-identity.json'));archive=D/aid['archive'];eq(sha(archive),aid['sha256'],'exact retained command archive');eq(aid['original'],'/tmp/t75-final-annotations-certified-r3-2ppy0b0r','original command archive location');eq(aid['symbolic_links'],[],'no command archive symbolic links');expected={r['path']:r for r in aid['members']};eq(len(expected),9,'all9 original command archive members');actual_members=[]
with tarfile.open(fileobj=io.BytesIO(read(archive)),mode='r:xz') as t:
 regular=[m for m in t.getmembers() if not m.isdir()];eq({m.name.removeprefix('./') for m in regular},set(expected),'exact original command archive membership')
 for m in regular:
  name=m.name.removeprefix('./');q=PurePosixPath(name);eq(m.isfile() and not q.is_absolute() and '..' not in q.parts,True,'safe regular archive original');data=t.extractfile(m).read();h=hashlib.sha256(data).hexdigest();eq(h,expected[name]['sha256'],'original command archive member SHA '+name);eq(len(data),expected[name]['size'],'original command archive member size '+name);eq(data,read(Path(aid['original'])/name),'byte exact archive/original '+name);dest=OUT/'original-command-archive-members'/name;dest.parent.mkdir(parents=True,exist_ok=True)
  with dest.open('xb') as f:f.write(data)
  actual_members.append({'path':name,'sha256':h,'bytes':len(data),'copy':str(dest.relative_to(OUT))})
  if name=='authority-at-retention.yaml':retention_counts=check_authority(data,'dated parent retention')
  if name in ['command.json','command.log','result.json']:eq(data,read({'command.json':commandpath,'command.log':logpath,'result.json':resultpath}[name]),'archive exact actual process original '+name)
parent=json.loads(copy(D/'annotations-receipt.json'));eq(parent['actual-command-result'],actual_result,'parent correctly records actual completed process');eq(parent['authority-snapshot-obligation-counts'],retention_counts,'parent correctly labels dated retention48');eq(parent['recorded-utc'],'2026-09-13T13:41:13.737892+00:00','observed retention timestamp, distinct from actual exit');eq(parent['candidate'],CID,'retention same candidate');eq(parent['contract'],TID,'retention same contract')
A=REPO/'capabilities/evidence/T75-delivery/certification-review-r3';reviewid=json.loads(copy(A/'annotations-eight-spec-archive-identity.json'));eq(reviewid['original'],str(PRIOR),'prior review original source');eq(reviewid['symbolic_links'],[],'prior review archive no symlinks');reviewarchive=A/reviewid['archive'];eq(sha(reviewarchive),reviewid['sha256'],'prior encoded archive identity');wanted={r['path']:{'size':r['bytes'],'sha256':r['sha256']} for r in oldmanifest['entries']};wanted['original-archive-manifest.json']={'size':len(read(PRIOR/'original-archive-manifest.json')),'sha256':sha(PRIOR/'original-archive-manifest.json')};eq({r['path']:{'size':r['size'],'sha256':r['sha256']} for r in reviewid['members']},wanted,'prior archived byte map exact2941+self');eq(len(reviewid['members']),2942,'original review archive actual members');eq(sha(A/'annotations-eight-spec-report.md'),sha(PRIOR/'report.md'),'archived deferred report unchanged');eq(sha(A/'annotations-eight-spec-receipt.json'),sha(PRIOR/'receipt.json'),'archived deferred receipt unchanged');eq(sha(A/'annotations-reader-output-incident-and-closure.json'),sha(PRIOR/'reader-output-incident-and-closure.json'),'archived incident disclosure unchanged')
archive_link={'archive':str(reviewarchive),'sha256':sha(reviewarchive),'archive-identity-sha256':sha(A/'annotations-eight-spec-archive-identity.json'),'manifest-sha256':sha(PRIOR/'original-archive-manifest.json'),'members':2942,'full-raw-or-review-archive-replayed':False}
for path,r in list(files.items()):eq(hashlib.sha256(Path(path).read_bytes()).hexdigest(),r['sha256'],'all inspected immutable originals unchanged '+path)
for r in copies:eq(hashlib.sha256((OUT/r['copy']).read_bytes()).hexdigest(),r['sha256'],'selected original copy unchanged '+r['copy'])
snapshot('final');save('source-copy-identities.json',copies);save('inspected-input-identities.json',list(files.values()));save('publication-inspection.json',{'created-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Historical r3 T12 actual exit and exact8 publication only; preserve prior40. Current inventory issue remains separate.','baseline':scope['baseline'],'candidate-sha256':CID,'contract-sha256':TID,'actual-original-process':actual_result,'original-command':files[str(commandpath)],'original-stdout':files[str(logpath)],'original-result':files[str(resultpath)],'annotations-index-sha256':oldreceipt['observed-index-sha256'],'original-raw-report':files[str(PRIOR/'report.md')],'original-raw-receipt':files[str(PRIOR/'receipt.json')],'prior-review-archive-linkage':archive_link,'staged-counts':staged_counts,'retained-staged-artifact-harness-identity-count':len(staged_artifacts),'source-identity-boundary':'Frozen r3 source/contract rows match the completely reviewed identity catalog. New current workspace changes for the inventory reader issue are not claimed certified.','records-rehashed':records,'configurations-rehashed':configs,'report-identities-rehashed':reports,'environment-record-identities':envs,'T12-before-after-original-files':rawenv,'exact-prior-review-linkage':priorlinks,'authority-snapshots':snapshots,'original-command-archive-members':actual_members,'selected-source-copy-count':len(copies),'annotations-eight-actual-exit-and-publication-gate-closed':not errors,'exact-prior40-preserved':True,'raw-review-history-and-incident-unchanged':True,'all-earlier-derived-raw-review-bytes-preserved':False,'historical-raw-overwrite-incident-recovered':False,'initial-read-path-diagnostic-closed':True,'current-inventory-block-reported-by-root':scope['new-external-status'],'full-raw-audit-replayed':False,'project-rerun':False,'repo-mutated':False,'all48-inventory-or-final-delivery-approved':False,'findings':errors,'unresolved-publication-findings':len(errors)})
print(json.dumps({'read-files':len(files),'actual-records':len(records),'configurations':len(configs),'reports':len(reports),'T12-before-after-files':len(rawenv),'errors':errors[:4],'error-count':len(errors)}))
if errors:raise ValueError('Read-only publication findings retained; original history unchanged')
