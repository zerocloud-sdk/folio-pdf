from pathlib import Path
import hashlib,json,datetime,sys
root=Path(__file__).parent
manifest=root/'original-archive-manifest.json'
if manifest.exists():raise FileExistsError('Review manifest already exists')
paths=sorted(p for p in root.rglob('*') if p.is_file())
if any(p.is_symlink() for p in root.rglob('*')):raise ValueError('Unexpected symbolic link')
entries=[]
for p in paths:
 data=p.read_bytes();entries.append({'path':str(p.relative_to(root)),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
value={'schema-version':1,'created-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'original-root':str(root),'generation-command':[sys.executable,'-B',str(Path(__file__))],'entry-count':len(entries),'excluded-paths':['original-archive-manifest.json'],'exclusion-reason':'Self exclusion; every other actual retained regular file is included.','scope':'Historical r3 annotations publication-only independent closure. Earlier raw review and its disclosed lost derived summaries are linked without rewriting that history.','entries':entries}
with manifest.open('x') as f:json.dump(value,f,ensure_ascii=False,indent=2);f.write('\n')
for r in entries:
 data=(root/r['path']).read_bytes();assert len(data)==r['bytes'] and hashlib.sha256(data).hexdigest()==r['sha256']
print(json.dumps({'manifest':str(manifest),'sha256':hashlib.sha256(manifest.read_bytes()).hexdigest(),'entry-count':len(entries),'archive-files-with-manifest':len(entries)+1,'all-listed-bytes-verified':True,'manifest-excludes-itself':True},indent=2))
