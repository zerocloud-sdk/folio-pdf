The nested-appearance positive belongs to the existing profile and closes the original optional-StmOwn finding; it does not expand scope.

The frozen text contract (94–100) supports page/Form MCRs, optional StmOwn, and bounded appearance definitions, ancestry and nested Do relationships. The certification contract (78, 89–92, 116–121) requires successful Form MCRs, permits no extracted occurrence for unexecuted referenced Forms, and forbids replacing required success with safe rejection. The original independent test (scripts/tests/test_t13_structure_standards.py:105–126) explicitly removes the page XObject entry, makes normal AP root A invoke child F, retains only F’s internal MCR, and expects a single invocation to PASS. The currently observed Native helper isPageAppearance recognizes only direct AP ownership; that is insufficient for this positive.

Keep two relations separate:

- If StmOwn explicitly names annotation O, O’s appearance dictionary must directly contain the referenced Stm stream (including an appearance-state entry), and O must belong to Pg. An annotation that owns A does not directly own every Form F called by A. Do not make ownsAppearance transitive.
- If StmOwn is absent, Pg association can be established by Pg’s normal appearance root A and bounded Do edges A → ordinary Forms → F. Preserve Stm=F, F’s MCID/StructParents backlink, and an empty public stream-owner Optional; do not invent O as F’s owner. Merely listing F in an AP resource dictionary does not establish an observed Do edge.
- The MCR’s provisional F definition start is not another rendering entry point. A single AP path to F counts once; a second page/AP path must trigger complete-query failure for internally structured F. Preserve empty Page Text/extracted-sequence observations when the page itself does not execute it.

Only files were read. No project CLI, Maven, tests or probes ran. Original frozen sources and the separately observed in-progress source copies have individual SHA-256 receipts; the latter are not a final-candidate freeze or certification.
