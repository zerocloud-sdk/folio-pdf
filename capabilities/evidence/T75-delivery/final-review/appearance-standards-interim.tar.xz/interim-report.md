# Incremental Standards assessment — appearance revision

Status: interim source assessment; final closure remains pending the newly reported cross-page whole-Form/AP missing-OBJR correction.

Scope: nine supplied source/contract files, `source.diff` against the original frozen implementation, and the final documentation correction (`docs/text-logical-structure.md` SHA-256 `4f032156c378ae1b6ddbef7759183122fb181dd33e26f8ab8e697fb378fa5b9a`). This supplements the original full Standards review, without recertifying that superseded candidate.

## Hard breaches

None found in this increment. The private `StructureExtractor` retains backend encapsulation and bounded, iterative traversal. Omitted/null StmOwn produces no invented owner identity. Deferred appearance-page claims are cleared through actual bounded Do traversal and checked before the complete result returns. New cases observe public `DocumentWorkflow.execute`, detached values, unchanged Source bytes and safe whole-query failure. Plan and contract counts agree at 123: 112 Native, nine Stable Facade and two artifact cases.

The final prose correction now describes registration and decoding of all normal AP roots when Form MCR validation or unresolved object page association needs them; it removes the stale claim that unrelated appearance programs are not decoded.

## Smell judgments

No actionable smell findings. The shared private page-association method serves MCR and OBJR consistently; pending claims, normal-root registration and bounded traversal remain cohesive. Existing owner checks and normal-root selection answer different relationship questions, so their separate scans are not an actionable duplication.

## Evidence and remaining boundary

Read-only log inspection confirms actual behavioral REDs for optional ownership, normal-root repetition, transitive association and whole-Form association, followed by passing regressions. Compilation failures and the rolled-back unverified implementation attempt are retained separately and are not counted as behavioral RED/GREEN. Complete supplied logs record Native 112/0/0/0, targeted Worker 6/0/0/0 and two independent controls passing. Earlier Worker 111-case output remains historical.

The completed Worker log SHA-256 is `8c54dd92d92b4a83665beea6ef96b10346193133cccc2dad5c3eed9b142d0421`; its earlier incomplete snapshot is preserved separately. Source copies, logs and original hashes accompany this report. No project CLI, tests, probes or repository mutations were performed. Subsequent cross-page correction, final actual tuples and delivery gates are not approved here.
