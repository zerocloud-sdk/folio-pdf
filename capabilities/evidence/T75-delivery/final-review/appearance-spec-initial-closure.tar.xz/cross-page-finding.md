[P2] Cross-page whole-Form appearances can lack a required per-page OBJR.

Frozen Native `recordPageAssociation` (3227–3237) immediately accepts a Form directly owned by the declared page’s annotation AP. With only whole-object references, `registerNormalAppearances` (3457–3460) then returns because there are no internal MCRs or pending associations. The final rendered-page check (2611–2620) reads `state.renderedObjectPages`, populated only by the page-content Do handler (2358–2359), not normal AP roots or their Do descendants.

Concrete case: two pages have separate visible F=0 annotations whose normal appearances render the same whole Form F. F has `StructParent k`, and `ParentTree[k]` identifies element E; E has only an OBJR declaring page 1. Neither page’s content executes F. Page 1 association passes, page 2 is never included in the coverage check, and the Query can succeed despite its missing page-2 OBJR. An ordinary AP root invoking F has the same gap.

The frozen certification contract (87–88) says “a rendering on another page requires its own OBJR”; ISO 32000-1 §14.7.4.3/Table 325, p. 564, distinguishes required references on multiple pages from allowed same-page repetition. The Goal (63–67) requires the approved Logical Structure relationships and source-traceable blocker resolution. The independent checker’s narrower observed-page-content coverage is not a Native scope waiver.

Include actual normal AP roots and their bounded Do paths in whole-object page coverage. Preserve same-page repetition, require the second page’s OBJR when F appears there, and accept corresponding OBJRs for both pages. Generic MCR/OBJR validation roots must not invent rendering entry points. Public direct/nested AP contrasts should exercise these cases.

This is a separate open finding in the newly admitted whole-Form AP path. It does not replace the original two P2 reports. Source inspection only; no probes/tests ran. Primary source URL: https://opensource.adobe.com/dc-acrobat-sdk-docs/pdfstandards/PDF32000_2008.pdf ; original SHA-256: `9de0ca9e8570d6209e8bd48a355be8eb6ec376acfc3fc3ae97cd8730351417ff`.
