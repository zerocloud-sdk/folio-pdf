Read-only closure of the original appearance findings, baseline `5b1603c435f11c40368f75b7b9a2777c9c5e9761`.

The original two P2 findings and the adjacent single-page MCR/whole-Form associations are closed in the inspected source:

- `recordPageAssociation` accepts direct appearance ownership, retains absent/null StmOwn as absent, and defers otherwise-unproven descendant associations until bounded actual Do traversal succeeds. Explicit annotation ownership remains direct. Pending unresolved pages fail before any result returns.
- Normal AP roots are registered independently of their own structure items when internal MCIDs or pending associations require them. Page and AP invocation paths share checks; ordinary intermediate Forms cannot hide repeats. Redundant definition starts do not manufacture invocations.
- Whole-Form OBJRs now support direct and nested AP association while preserving StructParent/whole-object semantics and same-page repetition. Removing the needed Do path fails rather than accepting mere resource membership.

Public source tests cover omitted/null owners, ordinary AP intermediates, missing Do associations, repeated internal MCIDs and whole-Form positive/negative counterparts. Supplied final logs show 112 full Native tests, six targeted Worker tests, two independent AP controls and one 123-case plan check passing. The older full 111-Worker run predates the last changes; no full 112-Worker or final eight-tuple certification is claimed here. This reviewer ran no tests, probes or project CLI.

One stale bounds statement still said unrelated AP programs were not decoded. The separately frozen documentation correction removes it and states the actual traversal condition; that documentation finding is closed.

Inspected Native SHA-256: `89468e9ea71937c158e82171bde94d9a0b73323a33f7eaf9f053d7f6ea495c8c`; Native test SHA-256: `40725c24bba8472e291c9b65b8f5b50b9903017b96db13d164ca5c0f01cc7642`; corrected text-contract SHA-256: `4f032156c378ae1b6ddbef7759183122fb181dd33e26f8ab8e697fb378fa5b9a`. All nine inspected source identities and complete original log copies are recorded in the adjacent manifests.

A distinct adjacent P2 remains open: cross-page normal appearances of a whole Form are not checked for an OBJR on every page. See `cross-page-finding.md`. Consequently this is closure of the enumerated original paths, not approval of the whole candidate or ticket. Original findings and subsequent scope addenda remain unchanged in their original review trees.
