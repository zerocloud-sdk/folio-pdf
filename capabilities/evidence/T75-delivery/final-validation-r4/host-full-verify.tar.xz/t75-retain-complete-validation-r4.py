#!/usr/bin/env python3
"""Retain completed host/matrix validation before another build overwrites reports."""
from collections import Counter
from datetime import datetime,timezone
import hashlib,importlib.util,json,re,shutil,sys,tempfile
from pathlib import Path
import xml.etree.ElementTree as ET
import yaml
ROOT=Path('/home/ubuntu/IdeaProjects/open-pdf')
DEST=ROOT/'capabilities/evidence/T75-delivery/final-validation-r4'
MODE=sys.argv[1];assert MODE in ('host','matrix')
NAME='host-full-verify' if MODE=='host' else 'jdk-matrix'
PREFIX=Path('/tmp/t75-final-'+('full-verify' if MODE=='host' else 'jdk-matrix')+'-r4')
EXPECTED_COMMAND=['./mvnw','-B','-ntp','verify'] if MODE=='host' else ['./scripts/verify-jdk-matrix.sh']
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
result=json.loads(Path(str(PREFIX)+'-result.json').read_bytes());assert result['returncode']==0;assert result['command']==EXPECTED_COMMAND
log=Path(str(PREFIX)+'.log').read_text()
parts=[log] if MODE=='host' else re.split(r'^==> Verifying Folio PDF on JDK ',log,flags=re.M)[1:]
majors=[17] if MODE=='host' else [8,11,17,21]
assert len(parts)==len(majors)
runs=[]
for major,part in zip(majors,parts):
    if MODE=='matrix':assert part.startswith(str(major)+' (') and '@sha256:' in part.splitlines()[0]
    rows=re.findall(r'Tests run: (\d+), Failures: (\d+), Errors: (\d+), Skipped: (\d+).* -- in ([\w.]+)',part)
    totals=[sum(int(row[i]) for row in rows) for i in range(4)]
    assert totals==[1507,0,0,4],(major,totals)
    assert len(rows)==87 and re.findall(r'BUILD (SUCCESS|FAILURE)',part)==['SUCCESS']
    modules=re.findall(r'^\[INFO\] Folio PDF .* SUCCESS .*$',part,flags=re.M);assert len(modules)==10
    assert not re.search(r'^\[ERROR\]',part,flags=re.M)
    native=[r for r in rows if r[-1]=='net.zerocloud.pdf.consumer.TextStructureExtractionWorkflowTest'];assert len(native)==1 and native[0][:4]==('115','0','0','0')
    inventory=[r for r in rows if r[-1]=='net.zerocloud.pdf.tools.inventory.FoundationReadinessCommandTest'];assert len(inventory)==1 and inventory[0][:4]==('10','0','0','0')
    runs.append({'jdk-major':major,'header':part.splitlines()[0],'totals':dict(zip(('tests','failures','errors','skipped'),totals)),'class-results':87,'reactor-results':modules,'result':'PASS'})
foundation=module('t75_validation_input_capture',ROOT/'scripts/t03-foundation.py');contract=yaml.safe_load((ROOT/'capabilities/foundation-release.yaml').read_bytes())
frozen=json.loads((DEST/'source-and-contract-inputs.json').read_bytes());assert foundation.capture_build_inputs(ROOT,contract)==frozen
old=json.loads((ROOT/'capabilities/evidence/T75-delivery/final-validation-r3/host-full-verify-receipt.json').read_bytes())
reports=[];xmlrows=[];skipped=[]
for item in old['reports']:
    p=ROOT/item['path'];assert p.is_file();reports.append({'path':item['path'],'sha256':sha(p)})
    if p.name.startswith('TEST-') and p.suffix=='.xml':
        suite=ET.parse(p).getroot();xmlrows.append(tuple(suite.attrib.get(k,'0') for k in ('tests','failures','errors','skipped'))+(suite.attrib['name'],))
        props={x.attrib['name']:x.attrib['value'] for x in suite.findall('./properties/property')};assert props['java.specification.version']==str(majors[-1]),(p,props.get('java.version'))
        for case in suite.findall('testcase'):
            if case.find('skipped') is not None:skipped.append({'report':item['path'],'class':case.attrib['classname'],'method':case.attrib['name'],'message':case.find('skipped').attrib.get('message','')})
assert len(reports)==177 and len(xmlrows)==87 and len(skipped)==4
assert Counter(xmlrows)==Counter(rows)
helper=Path(result['explicit-environment']['FOLIO_HARFBUZZ_HELPER']);assert sha(helper)=='169389e19e28bc96e3e878a9468671c31ccc6d5e7abbc3d38c4b8470526cdc65'
for suffix in ('.tar.xz','-archive-identity.json','-receipt.json'):assert not (DEST/(NAME+suffix)).exists()
original=Path(tempfile.mkdtemp(prefix='t75-final-'+NAME+'-r4-green-'))
for src in (Path(str(PREFIX)+'.log'),Path(str(PREFIX)+'-command.json'),Path(str(PREFIX)+'-result.json'),DEST/'source-and-contract-inputs.json',Path('/tmp/t75-run-retained.py'),Path(__file__)):
    shutil.copyfile(src,original/src.name);assert sha(src)==sha(original/src.name)
for item in reports:
    p=original/item['path'];p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/item['path'],p);assert sha(p)==item['sha256']
receipt={'recorded-utc':datetime.now(timezone.utc).isoformat(),'actual-result':result,'result':'pass','runs':runs,'original-log':str(PREFIX)+'.log','log-sha256':sha(Path(str(PREFIX)+'.log')),'source-and-contract-inputs-unchanged':True,'source-count':len(frozen['inputs']),'contract-count':len(frozen['contract-inputs']),'helper-sha256':sha(helper),'reports':reports,'skipped-cases':skipped,'report-boundary':'All 177 retained original reports and 87 XML suite results match the host log.' if MODE=='host' else 'The serial matrix overwrites shared Maven reports. These 177 reports and87XMLresults match the last JDK21 run only. Earlier JDK XML reports are not claimed separately retained.','skip-boundary':'Three unselected opt-in Worker scale profiles and one offline T30 raster profile, unchanged. Formal text certification remains a separate required gate.'}
(original/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
retain=module('t75_validation_retention',ROOT/'capabilities/evidence/T75-delivery/recorder-r4/retain-programs.py');retain.destination=DEST
identity=retain.archive(NAME,original)
with (DEST/(NAME+'-archive-identity.json')).open('x') as out:out.write(json.dumps(identity,indent=2)+'\n')
with (DEST/(NAME+'-receipt.json')).open('xb') as out:out.write((original/'receipt.json').read_bytes())
for suffix in ('.log','-command.json','-result.json'):
    src=Path(str(PREFIX)+suffix);target=DEST/src.name;assert not target.exists();shutil.copyfile(src,target)
with Path('/tmp/t75-final-'+NAME+'-r4-original-path.txt').open('x') as out:out.write(str(original)+'\n')
print('Actual complete',MODE,'PASS, frozen1933source/30contract unchanged, original',original)
