# T75 complete validation after the inventory reader correction

The independently reviewed [five-file correction](../inventory-read-bound/README.md)
changes the r3 source identity. `source-and-contract-inputs.json` freezes the
1,933 source and 30 contract inputs for the new complete host verification and
four-JDK matrix. The serial command retains each run's actual result and copies
its original reports before another build can overwrite them.

The host verification actually exited 0, running from 2026-09-13 14:10:40.767506
UTC to 14:42:42.486856 UTC. All ten reactor modules succeeded. Its 87 class
results report 1,507 tests, zero failures, zero errors and four unchanged default
skips. All 115 Native extraction tests passed; the inventory module includes
the three new reader regressions. The four skips remain three unselected opt-in
Worker scale profiles and one offline T30 raster profile.

`host-full-verify.tar.xz` retains 184 original files, including 177 reports.
All 87 XML class results match the complete original host log and observed
Java 17 runtime. Every archive member was compared byte-for-byte with its
original; adjacent command, result, log, receipt and archive identities preserve
the observations. The source and contract input sets remain unchanged.

The four-JDK matrix is running. Independent review of the host evidence is
separate from the actual command result, and matrix completion, fresh candidate
staging, all 48 new certification tuples and final delivery remain required.
