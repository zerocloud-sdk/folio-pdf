import datetime,hashlib,json,pathlib,subprocess,sys
out=pathlib.Path(__file__).parent
argv=['python3','-B',str(out/'audit-r4-host-v2.py')]
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
process=subprocess.run(argv,cwd='/home/ubuntu/IdeaProjects/open-pdf',stdout=subprocess.PIPE,stderr=subprocess.PIPE)
for kind,data in [('stdout',process.stdout),('stderr',process.stderr)]:
    with (out/'commands'/('host-audit-v2.'+kind)).open('xb') as f:f.write(data)
result={'argv':argv,'cwd':'/home/ubuntu/IdeaProjects/open-pdf','started-utc':start,'finished-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'returncode':process.returncode,'stdout-sha256':hashlib.sha256(process.stdout).hexdigest(),'stderr-sha256':hashlib.sha256(process.stderr).hexdigest()}
with (out/'commands/host-audit-v2-result.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
sys.stdout.buffer.write(process.stdout);sys.stderr.buffer.write(process.stderr);print('Actual review reader exit:',process.returncode)
sys.exit(process.returncode)
