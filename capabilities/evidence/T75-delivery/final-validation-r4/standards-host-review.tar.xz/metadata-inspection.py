import pathlib,json
r=pathlib.Path('/home/ubuntu/IdeaProjects/open-pdf/capabilities/evidence/T75-delivery')
for rel in ['final-validation-r4/host-full-verify-archive-identity.json','final-validation-r4/host-full-verify-receipt.json','inventory-read-bound/independent-review-closure.json','inventory-read-bound/five-file-source-delta.json','inventory-read-bound/input-delta-from-original-full-review.json','inventory-read-bound/standards-review-receipt.json']:
 p=r/rel;d=json.loads(p.read_text());print('FILE',rel)
 for k,v in d.items():
  print(k,repr(v)[:1800] if not isinstance(v,(list,dict)) or len(v)<8 else type(v).__name__+' '+str(len(v))+' sample '+repr(next(iter(v.items())) if isinstance(v,dict) else v[0])[:900])
for rel in ['inventory-read-bound/standards-review-report.md','inventory-read-bound/spec-review-report.md']:
 print('REPORT',rel);print((r/rel).read_text())
