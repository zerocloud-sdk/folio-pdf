import hashlib,json,pathlib,subprocess,datetime,re
OUT=pathlib.Path(__file__).parent
REPO=pathlib.Path('/home/ubuntu/IdeaProjects/open-pdf')
DATA=OUT/'attempt-v2'
def digest(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def emit(name,data):
    with (OUT/name).open('x') as f:json.dump(data,f,indent=2);f.write('\n')
commands=[]
for label,argv in [('head',['git','rev-parse','HEAD']),('commit-list',['git','log','--format=%H','5b1603c435f11c40368f75b7b9a2777c9c5e9761..HEAD'])]:
    p=subprocess.run(argv,cwd=REPO,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    for kind,raw in [('stdout',p.stdout),('stderr',p.stderr)]:
        with (OUT/'commands'/('closing-'+label+'.'+kind)).open('xb') as f:f.write(raw)
    commands.append({'argv':argv,'returncode':p.returncode,'stdout-sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr-sha256':hashlib.sha256(p.stderr).hexdigest()})
    assert p.returncode==0
    assert p.stdout.strip()==(b'5b1603c435f11c40368f75b7b9a2777c9c5e9761' if label=='head' else b'')
freeze=json.loads((DATA/'sources/evidence/final-validation-r4/source-and-contract-inputs.json').read_text())
input_errors=[x['path'] for key in ['inputs','contract-inputs'] for x in freeze[key] if digest(REPO/x['path'])!=x['sha256']]
assert not input_errors
archive_records=[json.loads((DATA/'host-archive-byte-audit.json').read_text())]+json.loads((DATA/'independent-new-closure-archive-audit.json').read_text())
assert all(digest(REPO/x['archive'])==x['archive-sha256'] and digest(REPO/x['identity'])==x['identity-sha256'] for x in archive_records)
copies=json.loads((DATA/'copied-source-identities.json').read_text());copy_errors=[x['copy'] for x in copies if digest(DATA/x['copy'])!=x['sha256']];assert not copy_errors
raw_recipe=(DATA/'sources/original-retention/t75-retain-complete-validation-r4.py').read_text()
raw_wrapper=(DATA/'sources/original-retention/t75-run-retained.py').read_text()
summary={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source-input-count':len(freeze['inputs']),'contract-input-count':len(freeze['contract-inputs']),'current-input-mismatches':input_errors,'all-three-original-archive-and-manifest-identities-unchanged':True,'retained-source-copy-errors':copy_errors,'read-only-git-commands':commands,'retention-recipe-sha256':digest(DATA/'sources/original-retention/t75-retain-complete-validation-r4.py'),'original-command-wrapper-sha256':digest(DATA/'sources/original-retention/t75-run-retained.py'),'matrix-stage-certification-read-or-executed':False,'reader-diagnostics-preserved':['metadata-inspection-result.json preserves the initial list/dict schema error; metadata-inspection-v2 passed.','host-audit-result.json preserves the initial dotted-reactor-label assumption; host-audit-v2 passed in a separate exclusively created output directory.']}
emit('closing-input-and-archive-identities.json',summary)
print(json.dumps({'final-source-inputs':len(freeze['inputs']),'final-contract-inputs':len(freeze['contract-inputs']),'current-mismatches':input_errors,'source-copy-mismatches':copy_errors,'host-and-two-review-archives-unchanged':True},indent=2))
