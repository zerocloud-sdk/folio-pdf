import pathlib,json
r=pathlib.Path('/home/ubuntu/IdeaProjects/open-pdf/capabilities/evidence/T75-delivery')
for rel in ['inventory-read-bound/five-file-source-delta.json','inventory-read-bound/input-delta-from-original-full-review.json','inventory-read-bound/standards-review-receipt.json']:
 p=r/rel;d=json.loads(p.read_text());print('FILE',rel)
 if isinstance(d,list):print('list',len(d),str(d)[:2400]);continue
 for k,v in d.items():
  print(k,repr(v)[:1800] if not isinstance(v,(list,dict)) or len(v)<8 else type(v).__name__+' '+str(len(v))+' sample '+repr(next(iter(v.items())) if isinstance(v,dict) else v[0])[:900])
for rel in ['inventory-read-bound/standards-review-report.md','inventory-read-bound/spec-review-report.md','final-validation-r4/t75-final-full-verify-r4-command.json','final-validation-r4/t75-final-full-verify-r4-result.json']:
 print('TEXT',rel);print((r/rel).read_text())
