import pathlib,json,re
r=pathlib.Path('/home/ubuntu/IdeaProjects/open-pdf/capabilities/evidence/T75-delivery')
d=json.loads((r/'final-validation-r4/host-full-verify-archive-identity.json').read_text());print('Nonreport members',json.dumps([x for x in d['members'] if '/target/' not in x['path']],indent=2))
for n in ['standards-review-archive-identity.json','spec-review-archive-identity.json']:
 d=json.loads((r/'inventory-read-bound'/n).read_text());print(n,{k:v for k,v in d.items() if k!='members'});print('members',len(d['members']),'bytes',sum(x['size'] for x in d['members']))
log=(r/'final-validation-r4/t75-final-full-verify-r4.log').read_text();print('TESTRESULTS')
for line in log.splitlines():
 if ('Tests run:' in line and ('FoundationReadiness' in line or 'TextStructureExtraction' in line or ' - in ' not in line)) or any(x in line for x in ['BUILD SUCCESS','Total time:','Finished at:','HarfBuzz']):print(line)
print('prior host audit keys');p=pathlib.Path('/tmp/t75-final-standards-host-r3-3s6o831d')
for name in ['XML-result-identities.json','log-XML-audit.json','source-continuity-audit.json']:
 d=json.loads((p/name).read_text());print(name,type(d).__name__,list(d)[:20] if isinstance(d,dict) else len(d))
