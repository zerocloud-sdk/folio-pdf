import datetime,hashlib,json,pathlib
OUT=pathlib.Path(__file__).parent
DATA=OUT/'attempt-v2'
def digest(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def emit(name,data):
    with (OUT/name).open('x') as f:json.dump(data,f,indent=2);f.write('\n')
report="""Hard documented-standard violations: 0. Open judgement findings: 0.

This independent closure covers only the completed r4 host verification, against fixed baseline/unchanged HEAD 5b1603c435f11c40368f75b7b9a2777c9c5e9761. CONTRIBUTING.md requires full Maven verification; the Goal additionally requires fresh evidence after identity-affecting changes. Historical r3 success is not treated as current certification.

The original ./mvnw -B -ntp verify command actually exited 0, from 2026-09-13 14:10:40.767506 UTC to 14:42:42.486856 UTC. The complete log and all 87 XML class results have exactly equal multisets: 1,507 reported tests, zero failures/errors, and four unchanged opt-in skips. All ten reactor modules succeeded. Native extraction passed 115 tests in 4.423 seconds; the inventory module passed 17, including the three new reader regressions. The skipped cases remain the same three unselected Worker scale tests and one offline T30 raster test; they are not execution/certification claims.

Every one of the host archive's 184 members matches its recorded digest and frozen original, including all 177 reports and original command/result/log files. All 87 XML suites identify Java 17.0.9. The explicitly configured HarfBuzz helper matches the retained SHA-256, 169389e19e28bc96e3e878a9468671c31ccc6d5e7abbc3d38c4b8470526cdc65.

Both new independent five-file source reviews were read; their 504 archived members also match original bytes. Independently enumerated current source/contract paths and hashes match the r4 freeze: 1,933 sources and 30 contracts, exactly five source changes from r3 and no contract change. Recomputed continuity to the original full review is 26 changed source inputs plus one contract, each covered by the original and retained incremental reviews.

The completed evidence and current README preserve these limits. Matrix completion, fresh staging, all 48 fresh certifications, inventory and final delivery remain open. No Maven, tests, certifier, environment observer or project code ran during this review; no repository/index/authority changed. Live target reports and historical raw r3 certification trees were not read. Two standalone-reader assumptions were corrected with original diagnostics preserved; they were not project failures.
"""
assert len(report.split())<400
with (OUT/'report.md').open('x') as f:f.write(report)
archive=json.loads((DATA/'host-archive-byte-audit.json').read_text())
log=json.loads((DATA/'host-log-XML-audit.json').read_text())
continuity=json.loads((DATA/'source-contract-continuity-audit.json').read_text())
record={'reviewer':'/root/final_standards','axis':'Standards','scope':'r4 complete host verification evidence only','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseline':'5b1603c435f11c40368f75b7b9a2777c9c5e9761','head':'5b1603c435f11c40368f75b7b9a2777c9c5e9761','commits':[],'report-sha256':digest(OUT/'report.md'),'report-word-count':len(report.split()),'hard-breaches':[],'open-judgement-findings':[],'host-actual-returncode':0,'host-results':log['totals'],'host-archive':archive,'host-Java-versions':log['java-version-counts'],'new-inventory-regression-methods':log['added-inventory-regression-methods'],'new-independent-source-review-archive-member-count':504,'source-input-count':1933,'contract-input-count':30,'source-delta-from-r3':5,'contract-delta-from-r3':0,'cumulative-source-delta':26,'cumulative-contract-delta':1,'frozen-input-receipt-sha256':continuity['frozen-input-receipt-sha256'],'source-current-mismatches':[],'matrix-reviewed':False,'fresh-stage-reviewed':False,'fresh-candidate-certification-approved':False,'final-delivery-approved':False,'completion-criteria-marked':False,'project-execution':False,'environment-observation':False,'repository-or-Git-index-or-authority-writes':False,'writes':'Exclusively created files under this fresh /tmp directory.','diagnostic-retention':['commands/metadata-inspection-result.json','commands/metadata-inspection.stderr','commands/metadata-inspection-v2-result.json','commands/host-audit-result.json','commands/host-audit.stderr','reader-reactor-method-correction.txt','commands/host-audit-v2-result.json'],'manifest-boundary':'Artifact manifest excludes itself and the three subsequent finalization stdout/stderr/result files to avoid circular hashes; those original finalization outputs are retained separately.','detailed-audits':{str(x.relative_to(OUT)):digest(x) for x in sorted(DATA.glob('*.json'))},'closing-input-and-archive-identities-sha256':digest(OUT/'closing-input-and-archive-identities.json')}
emit('review-record.json',record)
excluded={'artifact-identities.json','commands/finalization.stdout','commands/finalization.stderr','commands/finalization-result.json'}
rows=[{'path':x.relative_to(OUT).as_posix(),'bytes':x.stat().st_size,'sha256':digest(x)} for x in sorted(OUT.rglob('*')) if x.is_file() and x.relative_to(OUT).as_posix() not in excluded]
emit('artifact-identities.json',{'excludes':sorted(excluded),'files':rows})
assert all(digest(OUT/x['path'])==x['sha256'] for x in rows)
print(json.dumps({'archive-ready-directory':str(OUT),'report-sha256':digest(OUT/'report.md'),'review-record-sha256':digest(OUT/'review-record.json'),'artifact-identities-sha256':digest(OUT/'artifact-identities.json'),'manifested-file-count':len(rows),'separately-retained-finalization-files':3,'report-word-count':len(report.split())},indent=2))
