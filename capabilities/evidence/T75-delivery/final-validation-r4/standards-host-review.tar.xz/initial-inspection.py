import pathlib,json
r=pathlib.Path('/home/ubuntu/IdeaProjects/open-pdf')
for group in ['inventory-read-bound','final-validation-r4']:
 d=r/'capabilities/evidence/T75-delivery'/group
 print('GROUP',group)
 for p in sorted(d.iterdir()):
  if p.is_file():print(p.name,p.stat().st_size)
 p=d/'README.md'
 if p.exists():print(p.read_text())
