import collections,datetime,hashlib,json,pathlib,re,tarfile,xml.etree.ElementTree as ET,yaml
REPO=pathlib.Path('/home/ubuntu/IdeaProjects/open-pdf')
OUT=pathlib.Path(__file__).parent
BASE='5b1603c435f11c40368f75b7b9a2777c9c5e9761'
DELIVERY=REPO/'capabilities/evidence/T75-delivery'
HOST=DELIVERY/'final-validation-r4'
BOUND=DELIVERY/'inventory-read-bound'
COPY_RECORDS=[]

def sha(raw):return hashlib.sha256(raw).hexdigest()
def file_sha(path):
    with pathlib.Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(path):return json.loads(pathlib.Path(path).read_text())
def write_json(name,data):
    with (OUT/name).open('x') as f:json.dump(data,f,indent=2);f.write('\n')
def keep(original,name):
    original=pathlib.Path(original);raw=original.read_bytes();target=OUT/name;target.parent.mkdir(parents=True,exist_ok=True)
    with target.open('xb') as f:f.write(raw)
    COPY_RECORDS.append({'original':str(original),'copy':name,'bytes':len(raw),'sha256':sha(raw)})
    return raw

def archive_audit(identity_path,collect=False):
    identity=read(identity_path);archive=identity_path.parent/identity['archive']
    assert file_sha(archive)==identity['sha256']
    expected={x['path']:x for x in identity['members']};assert len(expected)==len(identity['members'])
    actual={};selected={};errors=[]
    with tarfile.open(archive,'r|*') as handle:
        for member in handle:
            assert member.isfile() and member.name not in actual
            assert not member.name.startswith('/') and '..' not in pathlib.PurePosixPath(member.name).parts
            with handle.extractfile(member) as stream:raw=stream.read()
            digest=sha(raw);actual[member.name]={'size':len(raw),'sha256':digest}
            original=pathlib.Path(identity['original'])/member.name
            if not original.is_file() or file_sha(original)!=digest:errors.append({'member':member.name,'error':'frozen original differs or missing'})
            if member.name not in expected or expected[member.name]['sha256']!=digest or expected[member.name]['size']!=len(raw):errors.append({'member':member.name,'error':'manifest mismatch'})
            if collect:selected[member.name]=raw
    assert set(actual)==set(expected)
    assert not errors,errors
    return {'identity':str(identity_path.relative_to(REPO)),'identity-sha256':file_sha(identity_path),'archive':str(archive.relative_to(REPO)),'archive-sha256':identity['sha256'],'member-count':len(actual),'uncompressed-bytes':sum(x['size'] for x in actual.values()),'every-frozen-original-and-manifest-byte-identity-matches':True,'errors':errors},selected

host_audit,members=archive_audit(HOST/'host-full-verify-archive-identity.json',True)
assert host_audit['member-count']==184
report_members={name:raw for name,raw in members.items() if '/target/' in name}
assert len(report_members)==177
receipt=read(HOST/'host-full-verify-receipt.json')
assert sha(members['receipt.json'])==file_sha(HOST/'host-full-verify-receipt.json')
expected_reports={x['path']:x['sha256'] for x in receipt['reports']}
assert expected_reports=={name:sha(raw) for name,raw in report_members.items()}
for file in ['source-and-contract-inputs.json','t75-final-full-verify-r4-command.json','t75-final-full-verify-r4-result.json','t75-final-full-verify-r4.log']:
    assert sha(members[file])==file_sha(HOST/file)
for name in ['t75-final-full-verify-r4-command.json','t75-final-full-verify-r4-result.json','t75-final-full-verify-r4.log']:
    assert sha(members[name])==file_sha(pathlib.Path('/tmp')/name)
    keep(pathlib.Path('/tmp')/name,'original-process/'+name)
command=read(HOST/'t75-final-full-verify-r4-command.json');result=read(HOST/'t75-final-full-verify-r4-result.json')
assert all(result.get(k)==v for k,v in command.items())
assert result['command']==['./mvnw','-B','-ntp','verify'] and result['returncode']==0
assert result==receipt['actual-result']
start=datetime.datetime.fromisoformat(result['started-utc']);end=datetime.datetime.fromisoformat(result['completed-utc'])
assert start.isoformat()=='2026-09-13T14:10:40.767506+00:00' and end.isoformat()=='2026-09-13T14:42:42.486856+00:00'
log=members['t75-final-full-verify-r4.log'].decode()
assert receipt['log-sha256']==sha(members['t75-final-full-verify-r4.log'])
pattern=re.compile(r'Tests run: (\d+), Failures: (\d+), Errors: (\d+), Skipped: (\d+), Time elapsed: ([\d,.]+) s\s+--?\s+in ([\w.$]+)')
log_rows=[{'class':m.group(6),'tests':int(m.group(1)),'failures':int(m.group(2)),'errors':int(m.group(3)),'skipped':int(m.group(4)),'time-seconds':float(m.group(5).replace(',',''))} for m in pattern.finditer(log)]
assert len(log_rows)==87
counts=['tests','failures','errors','skipped']
totals={k:sum(x[k] for x in log_rows) for k in counts}
assert totals=={'tests':1507,'failures':0,'errors':0,'skipped':4}
assert receipt['runs'][0]['totals']==totals and receipt['runs'][0]['class-results']==len(log_rows)
reactor=[line for line in log.splitlines() if re.match(r'\[INFO\] Folio PDF .*\.{2,}.* SUCCESS \[',line)]
assert len(reactor)==10 and reactor==receipt['runs'][0]['reactor-results']
assert log.count('[INFO] BUILD SUCCESS')==1 and '[INFO] BUILD FAILURE' not in log
assert '[INFO] Finished at: 2026-09-13T22:42:42+08:00' in log
xml_rows=[];skips=[];java_specs=collections.Counter();java_versions=collections.Counter();vendors=collections.Counter();inventory_methods=[]
for name,raw in report_members.items():
    if not pathlib.PurePosixPath(name).name.startswith('TEST-') or not name.endswith('.xml'):continue
    root=ET.fromstring(raw);assert root.tag=='testsuite'
    props={x.attrib['name']:x.attrib.get('value','') for x in root.findall('properties/property')}
    row={'report':name,'sha256':sha(raw),'class':root.attrib['name'],**{k:int(root.attrib[k]) for k in counts},'time-seconds':float(root.attrib['time']),'java-specification-version':props.get('java.specification.version'),'java-version':props.get('java.version'),'java-vendor':props.get('java.vendor'),'testcase-names':[x.attrib.get('name') for x in root.findall('testcase')]}
    assert len(root.findall('testcase'))==row['tests']
    assert not root.findall('testcase/failure') and not root.findall('testcase/error')
    assert len(root.findall('testcase/skipped'))==row['skipped']
    xml_rows.append(row);java_specs[row['java-specification-version']]+=1;java_versions[row['java-version']]+=1;vendors[row['java-vendor']]+=1
    for case in root.findall('testcase'):
        for skip in case.findall('skipped'):skips.append({'report':name,'class':case.attrib.get('classname',root.attrib['name']),'method':case.attrib['name'],'message':skip.attrib.get('message','')})
    if root.attrib['name']=='net.zerocloud.pdf.tools.inventory.FoundationReadinessCommandTest':inventory_methods=row['testcase-names']
def key(row):return tuple([row['class']]+[row[k] for k in counts])
assert len(xml_rows)==87 and collections.Counter(map(key,xml_rows))==collections.Counter(map(key,log_rows))
assert java_specs=={'17':87} and java_versions=={'17.0.9':87}
assert sorted(skips,key=lambda x:(x['class'],x['method']))==sorted(receipt['skipped-cases'],key=lambda x:(x['class'],x['method']))
previous_host=pathlib.Path('/tmp/t75-final-standards-host-r3-3s6o831d')
previous_log_audit=read(previous_host/'log-XML-audit.json')
previous_skips=previous_log_audit['skipped-testcases']
def skip_key(row):return tuple(row[k] for k in ['class','method','message'])
assert collections.Counter(map(skip_key,skips))==collections.Counter(map(skip_key,previous_skips))
previous_inventory_xml=None
with tarfile.open(DELIVERY/'final-validation-r3/host-full-verify.tar.xz','r:*') as handle:
    for member in handle.getmembers():
        if member.name.endswith('/TEST-net.zerocloud.pdf.tools.inventory.FoundationReadinessCommandTest.xml'):
            previous_inventory_xml=handle.extractfile(member).read();break
assert previous_inventory_xml is not None
previous_inventory_root=ET.fromstring(previous_inventory_xml);previous_methods=[x.attrib['name'] for x in previous_inventory_root.findall('testcase')]
assert len(previous_methods)==7 and len(inventory_methods)==10
added_inventory_methods=sorted(set(inventory_methods)-set(previous_methods));assert len(added_inventory_methods)==3 and set(previous_methods)<=set(inventory_methods)
inventory_rows=[x for x in log_rows if x['class'].startswith('net.zerocloud.pdf.tools.inventory.')]
assert sum(x['tests'] for x in inventory_rows)==17
native=[x for x in log_rows if x['class']=='net.zerocloud.pdf.consumer.TextStructureExtractionWorkflowTest'];assert len(native)==1 and native[0]['tests']==115 and native[0]['time-seconds']==4.423
helper=pathlib.Path(result['explicit-environment']['FOLIO_HARFBUZZ_HELPER']);helper_hash=file_sha(helper)
assert helper_hash==receipt['helper-sha256']=='169389e19e28bc96e3e878a9468671c31ccc6d5e7abbc3d38c4b8470526cdc65'

write_json('host-archive-byte-audit.json',host_audit)
write_json('XML-result-identities.json',xml_rows)
write_json('host-log-XML-audit.json',{'log-sha256':sha(members['t75-final-full-verify-r4.log']),'retained-report-count':177,'XML-class-results':87,'log-class-results':87,'exact-multiset-match':True,'totals':totals,'java-specification-version-counts':dict(java_specs),'java-version-counts':dict(java_versions),'java-vendor-counts':dict(vendors),'reactor-successes':reactor,'build-success-count':1,'native-extraction-result':native[0],'inventory-class-results':inventory_rows,'added-inventory-regression-methods':added_inventory_methods,'four-skipped-cases':skips,'same-four-preexisting-opt-in-skips':True})
write_json('original-process-and-helper-audit.json',{'original-command':command,'original-result':result,'all-durable-original-bytes-match':True,'actual-returncode':0,'elapsed-wall-seconds':(end-start).total_seconds(),'helper-path':str(helper),'helper-sha256':helper_hash,'method':'Retained original explicit helper configuration plus read-only file hashing; no environment observer or helper execution.'})

review_archives=[]
for name in ['standards-review-archive-identity.json','spec-review-archive-identity.json']:
    row,_=archive_audit(BOUND/name);review_archives.append(row)
closure=read(BOUND/'independent-review-closure.json');standards=read(BOUND/'standards-review-receipt.json')
assert closure['standards-closed'] and closure['spec-closed'] and not standards['hard_findings'] and not standards['open_judgement_findings']
assert standards['reviewer']=='clean-context child /root/inventory_bound_standards'
assert file_sha(BOUND/'standards-review-report.md')==closure['standards-report-sha256']
assert file_sha(BOUND/'spec-review-report.md')==closure['spec-report-sha256']
five=read(BOUND/'five-file-source-delta.json');assert five==closure['source-delta']
assert {x['path']:x['current-sha256'] for x in five}=={x['path']:x['sha256'] for x in standards['closing_source_identities']}
freeze=read(HOST/'source-and-contract-inputs.json');r3=read(DELIVERY/'final-validation-r3/source-and-contract-inputs.json')
def mapping(rows):
    result={x['path']:x['sha256'] for x in rows};assert len(result)==len(rows);return result
sources=mapping(freeze['inputs']);contracts=mapping(freeze['contract-inputs']);before=mapping(r3['inputs'])
assert len(sources)==1933 and len(contracts)==30 and before.keys()==sources.keys()
assert mapping(r3['contract-inputs'])==contracts
changed=[{'path':name,'r3-sha256':before[name],'current-sha256':sources[name]} for name in sorted(sources) if before[name]!=sources[name]]
assert changed==[{k:row[k] for k in ['path','r3-sha256','current-sha256']} for row in five]
current_errors=[name for name,digest in {**sources,**contracts}.items() if file_sha(REPO/name)!=digest];assert not current_errors
foundation=yaml.safe_load((REPO/'capabilities/foundation-release.yaml').read_text());source_paths=set()
for name in foundation['source-roots']:
    root=REPO/name
    for path in root.rglob('*') if root.is_dir() else [root]:
        if path.is_file() and '__pycache__' not in path.parts:
            assert not path.is_symlink();source_paths.add(path.relative_to(REPO).as_posix())
source_paths.difference_update(foundation['source-exclusions']);assert source_paths==set(sources)
contract_paths={'capabilities/foundation-release.yaml','capabilities/capability-matrix.yaml','capabilities/facade-surface.yaml',foundation['requirements'],foundation['environments'],foundation['platform-decision']}
contract_paths.update(x['profile-contract'] for x in foundation['obligations']);assert contract_paths==set(contracts)
original_path=DELIVERY/'final-candidate/build-inputs.json';original=read(original_path);delta=read(BOUND/'input-delta-from-original-full-review.json')
assert file_sha(original_path)==delta['original-full-review-receipt']['sha256']
assert file_sha(REPO/delta['prior-reviewed-delta']['path'])==delta['prior-reviewed-delta']['sha256']
latest_reviewed={};prior_records=[]
for dirname in ['/tmp/t75-final-standards-crosspage-vb_0jzxw','/tmp/t75-final-standards-observer-budget-029hl0q1','/tmp/t75-final-standards-worker-batch-pcz6savo']:
    path=pathlib.Path(dirname)/'review-record.json';record=read(path);assert record['baseline']==BASE
    for row in record['source-files']:latest_reviewed[row['path']]=row.get('current-sha256',row.get('sha256'))
    prior_records.append({'path':str(path),'sha256':file_sha(path)})
for row in five:latest_reviewed[row['path']]=row['current-sha256']
recomputed={}
for label,old,new in [('inputs',mapping(original['candidate']['inputs']),sources),('contract-inputs',mapping(original['contract-inputs']),contracts)]:
    assert old.keys()==new.keys()
    rows=[{'path':name,'before':old[name],'after':new[name]} for name in sorted(old) if old[name]!=new[name]]
    assert rows==[{k:row[k] for k in ['path','before','after']} for row in delta[label]]
    assert all(latest_reviewed[row['path']]==row['after'] for row in rows)
    recomputed[label]=rows
assert len(recomputed['inputs'])==26 and len(recomputed['contract-inputs'])==1
write_json('independent-new-closure-archive-audit.json',review_archives)
write_json('source-contract-continuity-audit.json',{'frozen-input-receipt-sha256':file_sha(HOST/'source-and-contract-inputs.json'),'source-input-count':1933,'contract-input-count':30,'complete-current-path-sets-match':True,'current-byte-mismatches':current_errors,'exact-five-source-change-over-r3':changed,'all30-contract-inputs-unchanged':True,'original-complete-review-receipt-sha256':file_sha(original_path),'prior-independent-closure-records':prior_records,'new-independent-closure-sha256':file_sha(BOUND/'independent-review-closure.json'),'new-independent-reviewer':standards['reviewer'],'recomputed-original-review-delta':recomputed,'original-to-current-source-delta':26,'original-to-current-contract-delta':1,'new-candidate-or-certification-approved':False})

for group in ['final-validation-r4','inventory-read-bound']:
    for path in sorted((DELIVERY/group).iterdir()):
        if path.is_file() and not path.name.endswith(('.tar.xz','.tar.gz')):keep(path,'sources/evidence/'+group+'/'+path.name)
for row in five:keep(REPO/row['path'],'sources/current/'+row['path'])
for name in ['AGENTS.md','CONTRIBUTING.md','capabilities/foundation-release.yaml','capabilities/foundation-requirements.yaml','scripts/verify-jdk-matrix.sh']:keep(REPO/name,'sources/standards/'+name)
keep('/home/ubuntu/.codex/attachments/77353239-0dda-4ee1-b4bb-ce7fb3fa0f9b/pasted-text-1.txt','sources/standards/original-goal.txt')
for path in ['t75-retain-complete-validation-r4.py','t75-run-retained.py']:
    frozen=pathlib.Path(read(HOST/'host-full-verify-archive-identity.json')['original'])/path
    keep(frozen,'sources/original-retention/'+path)
for dirname in ['/tmp/t75-final-standards-xpr84_u3','/tmp/t75-final-standards-crosspage-vb_0jzxw','/tmp/t75-final-standards-observer-budget-029hl0q1','/tmp/t75-final-standards-worker-batch-pcz6savo','/tmp/t75-final-standards-host-r3-3s6o831d']:
    for name in ['report.md','review-record.json']:keep(pathlib.Path(dirname)/name,'sources/prior-independent-reviews/'+pathlib.Path(dirname).name+'/'+name)
keep(original_path,'sources/evidence/original-full-review-build-inputs.json')
keep(DELIVERY/'final-validation-r3/source-and-contract-inputs.json','sources/evidence/r3-source-and-contract-inputs.json')
write_json('copied-source-identities.json',COPY_RECORDS)
print(json.dumps({'host-archive-members':host_audit['member-count'],'new-closure-archive-members':sum(x['member-count'] for x in review_archives),'tests':totals,'actual-exit':result['returncode'],'source-inputs':len(sources),'contract-inputs':len(contracts),'r3-source-delta':len(changed),'original-source-delta':26,'original-contract-delta':1,'original-copies':len(COPY_RECORDS),'findings':[]},indent=2))
