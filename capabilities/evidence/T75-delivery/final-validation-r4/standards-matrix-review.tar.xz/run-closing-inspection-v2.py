import datetime,json,pathlib,subprocess,sys
OUT=pathlib.Path(__file__).parent
command=['python3','-B',str(OUT/'closing-inspection-v2.py')]
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
result=subprocess.run(command,cwd='/home/ubuntu/IdeaProjects/open-pdf',stdout=subprocess.PIPE,stderr=subprocess.PIPE)
for suffix,raw in [('stdout',result.stdout),('stderr',result.stderr)]:
    with (OUT/'commands'/('closing-inspection-v2.'+suffix)).open('xb') as f:f.write(raw)
with (OUT/'commands/closing-inspection-v2-result.json').open('x') as f:
    json.dump({'command':command,'cwd':'/home/ubuntu/IdeaProjects/open-pdf','started-utc':started,'completed-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'returncode':result.returncode},f,indent=2);f.write('\n')
sys.stdout.buffer.write(result.stdout);sys.stderr.buffer.write(result.stderr);sys.exit(result.returncode)
