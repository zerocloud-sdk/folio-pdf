import pathlib,json
r=pathlib.Path('/home/ubuntu/IdeaProjects/open-pdf')
for name in ['scripts/verify-jdk-matrix.sh','capabilities/foundation-environments.yaml']:
    print('SOURCE',name);print((r/name).read_text())
log=(r/'capabilities/evidence/T75-delivery/final-validation-r4/t75-final-jdk-matrix-r4.log').read_text()
print('RAW IMAGE HEADERS')
for line in log.splitlines():
    if 'docker.io/library/eclipse-temurin' in line:print(line)
identity=json.loads((r/'capabilities/evidence/T75-delivery/final-validation-r4/jdk-matrix-archive-identity.json').read_text())
print('NONREPORT ARCHIVE MEMBERS',json.dumps([x for x in identity['members'] if '/target/' not in x['path']],indent=2))
host=pathlib.Path('/tmp/t75-standards-host-r4-ad7uhgyj/attempt-v2')
for name in ['host-log-XML-audit.json','source-contract-continuity-audit.json']:
    d=json.loads((host/name).read_text());print('HOST KEYS',name,list(d));print('ADDED METHODS',d.get('added-inventory-regression-methods'))
