import datetime,hashlib,json,pathlib,subprocess
OUT=pathlib.Path(__file__).parent
REPO=pathlib.Path('/home/ubuntu/IdeaProjects/open-pdf')
PACKAGE=REPO/'capabilities/evidence/T75-delivery/final-validation-r4'
def sha(path):
    with pathlib.Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def emit(name,value):
    with (OUT/name).open('x') as f:json.dump(value,f,indent=2);f.write('\n')
def capture(name,command):
    started=datetime.datetime.now(datetime.timezone.utc).isoformat()
    result=subprocess.run(command,cwd=REPO,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    for suffix,raw in [('stdout',result.stdout),('stderr',result.stderr)]:
        with (OUT/'commands'/(name+'.'+suffix)).open('xb') as f:f.write(raw)
    emit('commands/'+name+'-result.json',{'command':command,'cwd':str(REPO),'started-utc':started,'completed-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'returncode':result.returncode})
    assert result.returncode==0
    return result.stdout
baseline='5b1603c435f11c40368f75b7b9a2777c9c5e9761'
head=capture('closing-v2-git-head',['git','rev-parse','HEAD']).decode().strip();assert head==baseline
commits=capture('closing-v2-git-commit-list',['git','log','--oneline',baseline+'..HEAD']);assert not commits
canonical=capture('closing-v2-git-three-dot-diff',['git','diff',baseline+'...HEAD']);assert not canonical
freeze=json.loads((PACKAGE/'source-and-contract-inputs.json').read_text())
checked=[{'kind':kind,'path':row['path'],'sha256':sha(REPO/row['path'])} for kind in ['inputs','contract-inputs'] for row in freeze[kind]]
assert all(a['sha256']==b['sha256'] for a,b in zip(checked,freeze['inputs']+freeze['contract-inputs']))
archive=json.loads((PACKAGE/'jdk-matrix-archive-identity.json').read_text());assert sha(PACKAGE/archive['archive'])==archive['sha256']
readme=(PACKAGE/'README.md').read_bytes();assert readme==(OUT/'sources/matrix/README.md').read_bytes()
assert b'1,507' in readme and b'184' in readme and b'17:00:34.619670 UTC' in readme
copies=json.loads((OUT/'copied-source-identities.json').read_text())
for row in copies:
    assert sha(OUT/row['copy'])==row['sha256']
    assert sha(row['original'])==row['sha256']
result={'checked-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'HEAD':head,'baseline':baseline,'commit-list-empty':True,'canonical-three-dot-diff-empty':True,'current-source-count':len(freeze['inputs']),'current-contract-count':len(freeze['contract-inputs']),'every-current-source-and-contract-hash-still-matches':True,'freeze-sha256':sha(PACKAGE/'source-and-contract-inputs.json'),'matrix-archive-sha256':archive['sha256'],'matrix-archive-identity-sha256':sha(PACKAGE/'jdk-matrix-archive-identity.json'),'README-sha256':sha(PACKAGE/'README.md'),'README-copy-equals-current':True,'copied-source-count':len(copies),'all-copied-source-identities-still-match':True}
emit('closing-v2-readonly-check.json',result)
emit('closing-v2-current-input-identities.json',checked)
print(json.dumps(result,indent=2))
print('\nCURRENT README\n'+readme.decode())
print('\nORIGINAL RETAINED PROCESS WRAPPER\n'+(OUT/'sources/frozen-originals/t75-run-retained.py').read_text())
print('\nAPPLICABLE STANDARDS EXCERPTS')
for name in ['CONTRIBUTING.md','docs/foundation-readiness.md']:
    lines=(REPO/name).read_text().splitlines()
    for i,line in enumerate(lines):
        if any(term in line.lower() for term in ['mvnw -b','jdk-matrix','jdk 8','certification','not certify','does not certify']):
            print(f'{name}:{i+1}: {line}')
