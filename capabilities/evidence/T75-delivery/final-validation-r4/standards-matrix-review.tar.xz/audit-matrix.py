import collections,datetime,hashlib,json,pathlib,re,tarfile,xml.etree.ElementTree as ET,yaml
OUT=pathlib.Path(__file__).parent
REPO=pathlib.Path('/home/ubuntu/IdeaProjects/open-pdf')
PACKAGE=REPO/'capabilities/evidence/T75-delivery/final-validation-r4'
PRIOR=pathlib.Path('/tmp/t75-standards-host-r4-ad7uhgyj')
HOST=PRIOR/'attempt-v2'
COPIES=[]
def sha(raw):return hashlib.sha256(raw).hexdigest()
def digest(path):
    with pathlib.Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(path):return json.loads(pathlib.Path(path).read_text())
def emit(name,data):
    with (OUT/name).open('x') as f:json.dump(data,f,indent=2);f.write('\n')
def keep(source,name):
    source=pathlib.Path(source);raw=source.read_bytes();target=OUT/name;target.parent.mkdir(parents=True,exist_ok=True)
    with target.open('xb') as f:f.write(raw)
    COPIES.append({'original':str(source),'copy':name,'bytes':len(raw),'sha256':sha(raw)})
    return raw

identity=read(PACKAGE/'jdk-matrix-archive-identity.json')
assert digest(PACKAGE/identity['archive'])==identity['sha256']
expected={x['path']:x for x in identity['members']};assert len(expected)==184
members={};member_records=[]
with tarfile.open(PACKAGE/identity['archive'],'r|*') as handle:
    for member in handle:
        assert member.isfile() and member.name not in members
        assert not member.name.startswith('/') and '..' not in pathlib.PurePosixPath(member.name).parts
        raw=handle.extractfile(member).read();members[member.name]=raw
        record={'path':member.name,'bytes':len(raw),'sha256':sha(raw)}
        assert expected[member.name]['size']==len(raw) and expected[member.name]['sha256']==sha(raw)
        frozen=pathlib.Path(identity['original'])/member.name
        assert frozen.is_file() and digest(frozen)==sha(raw)
        member_records.append(record)
assert set(members)==set(expected)
receipt=read(PACKAGE/'jdk-matrix-receipt.json')
assert sha(members['receipt.json'])==digest(PACKAGE/'jdk-matrix-receipt.json')
reports={k:v for k,v in members.items() if '/target/' in k};assert len(reports)==177
assert {x['path']:x['sha256'] for x in receipt['reports']}=={name:sha(raw) for name,raw in reports.items()}
for name in ['source-and-contract-inputs.json','t75-final-jdk-matrix-r4-command.json','t75-final-jdk-matrix-r4-result.json','t75-final-jdk-matrix-r4.log']:
    assert digest(PACKAGE/name)==sha(members[name])
for name in ['t75-final-jdk-matrix-r4-command.json','t75-final-jdk-matrix-r4-result.json','t75-final-jdk-matrix-r4.log']:
    assert digest(pathlib.Path('/tmp')/name)==sha(members[name])
    keep(pathlib.Path('/tmp')/name,'original-process/'+name)
command=read(PACKAGE/'t75-final-jdk-matrix-r4-command.json');result=read(PACKAGE/'t75-final-jdk-matrix-r4-result.json')
assert result==receipt['actual-result'] and all(result.get(k)==v for k,v in command.items())
assert result['command']==['./scripts/verify-jdk-matrix.sh'] and result['returncode']==0 and result['command-pid']==3880151
start=datetime.datetime.fromisoformat(result['started-utc']);end=datetime.datetime.fromisoformat(result['completed-utc'])
assert start.isoformat()=='2026-09-13T14:42:45.357683+00:00' and end.isoformat()=='2026-09-13T17:00:34.619670+00:00'
log=members['t75-final-jdk-matrix-r4.log'].decode();assert sha(members['t75-final-jdk-matrix-r4.log'])==receipt['log-sha256']
headers=list(re.finditer(r'^==> Verifying Folio PDF on JDK (\d+) \(([^\n]+)\)$',log,re.M));assert [int(x.group(1)) for x in headers]==[8,11,17,21]
environments=yaml.safe_load((REPO/'capabilities/foundation-environments.yaml').read_text())
pins={x['identity']['jdk-major']:x['identity'] for x in environments['profiles']}
fields=['tests','failures','errors','skipped']
pattern=re.compile(r'Tests run: (\d+), Failures: (\d+), Errors: (\d+), Skipped: (\d+), Time elapsed: ([\d,.]+) s\s+--?\s+in ([\w.$]+)')
def case_key(row):return tuple([row['class']]+[row[x] for x in fields])
host_xml=read(HOST/'XML-result-identities.json');host_counter=collections.Counter(map(case_key,host_xml));host_log=read(HOST/'host-log-XML-audit.json')
sections=[]
for index,head in enumerate(headers):
    jdk=int(head.group(1));image=head.group(2);assert image==pins[jdk]['image']
    text=log[head.start():headers[index+1].start() if index+1<len(headers) else len(log)]
    rows=[{'class':m.group(6),**{field:int(m.group(i+1)) for i,field in enumerate(fields)},'time-seconds':float(m.group(5).replace(',',''))} for m in pattern.finditer(text)]
    assert len(rows)==87 and collections.Counter(map(case_key,rows))==host_counter
    totals={field:sum(x[field] for x in rows) for field in fields};assert totals=={'tests':1507,'failures':0,'errors':0,'skipped':4}
    reactors=[line for line in text.splitlines() if re.match(r'\[INFO\] Folio PDF .+ SUCCESS \[',line)]
    recorded=receipt['runs'][index]
    assert recorded['jdk-major']==jdk and recorded['header']==f'{jdk} ({image})' and recorded['totals']==totals and recorded['class-results']==87
    assert len(reactors)==10 and reactors==recorded['reactor-results']
    assert text.count('[INFO] BUILD SUCCESS')==1 and '[INFO] BUILD FAILURE' not in text
    native=[x for x in rows if x['class']=='net.zerocloud.pdf.consumer.TextStructureExtractionWorkflowTest'];assert len(native)==1 and native[0]['tests']==115
    inventory=[x for x in rows if x['class'].startswith('net.zerocloud.pdf.tools.inventory.')];assert sum(x['tests'] for x in inventory)==17
    assert [x['tests'] for x in inventory if x['class'].endswith('.FoundationReadinessCommandTest')]==[10]
    finished=re.findall(r'^\[INFO\] Finished at: (.+)$',text,re.M);assert len(finished)==1
    sections.append({'jdk-major':jdk,'header':head.group(0),'pinned-image':image,'totals':totals,'class-results':rows,'reactor-successes':reactors,'build-success-count':1,'finished-at':finished[0],'native-extraction-result':native[0],'inventory-results':inventory,'exact-host-class-result-multiset-match':True})
assert log.count('[INFO] BUILD SUCCESS')==4 and '[INFO] BUILD FAILURE' not in log
xml_rows=[];skips=[];java=collections.defaultdict(collections.Counter)
for name,raw in reports.items():
    if not pathlib.PurePosixPath(name).name.startswith('TEST-') or not name.endswith('.xml'):continue
    root=ET.fromstring(raw);assert root.tag=='testsuite'
    props={x.attrib['name']:x.attrib.get('value','') for x in root.findall('properties/property')}
    row={'report':name,'sha256':sha(raw),'class':root.attrib['name'],**{x:int(root.attrib[x]) for x in fields},'time-seconds':float(root.attrib['time']),'testcase-names':[x.attrib['name'] for x in root.findall('testcase')],'java-properties':{k:props.get(k) for k in ['java.specification.version','java.version','java.runtime.version','java.vendor','java.vm.version']}}
    assert len(root.findall('testcase'))==row['tests'] and len(root.findall('testcase/skipped'))==row['skipped']
    assert not root.findall('testcase/error') and not root.findall('testcase/failure')
    for key,value in row['java-properties'].items():java[key][value]+=1
    for case in root.findall('testcase'):
        for skip in case.findall('skipped'):skips.append({'report':name,'class':case.attrib.get('classname',root.attrib['name']),'method':case.attrib['name'],'message':skip.attrib.get('message','')})
    xml_rows.append(row)
assert len(xml_rows)==87 and collections.Counter(map(case_key,xml_rows))==collections.Counter(map(case_key,sections[-1]['class-results']))
assert java['java.specification.version']=={'21':87}
assert java['java.runtime.version']=={pins[21]['jdk-build']:87} and java['java.vendor']=={pins[21]['jdk-vendor']:87}
def skip_key(row):return tuple(row[k] for k in ['class','method','message'])
assert collections.Counter(map(skip_key,skips))==collections.Counter(map(skip_key,receipt['skipped-cases']))==collections.Counter(map(skip_key,host_log['four-skipped-cases']))
inventory_xml=[x for x in xml_rows if x['class'].endswith('.FoundationReadinessCommandTest')];assert len(inventory_xml)==1 and inventory_xml[0]['tests']==10
assert set(host_log['added-inventory-regression-methods'])<=set(inventory_xml[0]['testcase-names'])
assert set(inventory_xml[0]['testcase-names'])==set(next(x for x in host_xml if x['class'].endswith('.FoundationReadinessCommandTest'))['testcase-names'])
helper=pathlib.Path(result['explicit-environment']['FOLIO_HARFBUZZ_HELPER']);helper_sha=digest(helper)
assert helper_sha==receipt['helper-sha256']=='169389e19e28bc96e3e878a9468671c31ccc6d5e7abbc3d38c4b8470526cdc65'

emit('archive-member-identities.json',member_records)
emit('archive-byte-audit.json',{'archive':str((PACKAGE/identity['archive']).relative_to(REPO)),'archive-sha256':identity['sha256'],'archive-identity-sha256':digest(PACKAGE/'jdk-matrix-archive-identity.json'),'members':184,'retained-report-files':177,'original-frozen-directory':identity['original'],'every-member-byte-matches-original-and-manifest':True,'uncompressed-bytes':sum(len(x) for x in members.values())})
emit('original-process-audit.json',{'command':command,'actual-result':result,'actual-returncode':0,'elapsed-wall-seconds':(end-start).total_seconds(),'durable-command-result-log-match-archive':True,'configured-helper-path':str(helper),'helper-sha256':helper_sha,'helper-scope':'Explicit retained configuration plus read-only file hash; no helper or environment observer was executed.'})
emit('four-log-section-audit.json',sections)
emit('final-JDK21-XML-audit.json',{'class-results':xml_rows,'runtime-property-counts':{k:dict(v) for k,v in java.items()},'exact-final-log-class-result-multiset-match':True,'four-unchanged-opt-in-skips':skips,'three-new-inventory-regressions':host_log['added-inventory-regression-methods'],'earlier-three-JDK-XML-retained-or-inspected':False})

freeze=read(PACKAGE/'source-and-contract-inputs.json');host_input=HOST/'sources/evidence/final-validation-r4/source-and-contract-inputs.json'
assert digest(PACKAGE/'source-and-contract-inputs.json')==digest(host_input)=='50988226c0db8a0eddd622ec3d9656d5ad6eb1e25328f22a067ee0e54add392d'
def mapping(rows):
    result={x['path']:x['sha256'] for x in rows};assert len(result)==len(rows);return result
sources=mapping(freeze['inputs']);contracts=mapping(freeze['contract-inputs']);assert len(sources)==1933 and len(contracts)==30
assert not [name for name,value in {**sources,**contracts}.items() if digest(REPO/name)!=value]
foundation=yaml.safe_load((REPO/'capabilities/foundation-release.yaml').read_text());enumerated=set()
for name in foundation['source-roots']:
    root=REPO/name
    for path in root.rglob('*') if root.is_dir() else [root]:
        if path.is_file() and '__pycache__' not in path.parts:
            assert not path.is_symlink();enumerated.add(path.relative_to(REPO).as_posix())
enumerated.difference_update(foundation['source-exclusions']);assert enumerated==set(sources)
contract_paths={'capabilities/foundation-release.yaml','capabilities/capability-matrix.yaml','capabilities/facade-surface.yaml',foundation['requirements'],foundation['environments'],foundation['platform-decision']}
contract_paths.update(x['profile-contract'] for x in foundation['obligations']);assert contract_paths==set(contracts)
host_continuity=read(HOST/'source-contract-continuity-audit.json')
original=read(REPO/'capabilities/evidence/T75-delivery/final-candidate/build-inputs.json')
recomputed={}
for key,before,after in [('inputs',mapping(original['candidate']['inputs']),sources),('contract-inputs',mapping(original['contract-inputs']),contracts)]:
    assert before.keys()==after.keys()
    recomputed[key]=[{'path':name,'before':before[name],'after':after[name]} for name in sorted(before) if before[name]!=after[name]]
assert recomputed==host_continuity['recomputed-original-review-delta']
assert len(recomputed['inputs'])==26 and len(recomputed['contract-inputs'])==1
new_closure=REPO/'capabilities/evidence/T75-delivery/inventory-read-bound/independent-review-closure.json'
assert digest(new_closure)==host_continuity['new-independent-closure-sha256']
for prior in host_continuity['prior-independent-closure-records']:assert digest(pathlib.Path(prior['path']))==prior['sha256']
host_archive=read(HOST/'host-archive-byte-audit.json')
assert digest(REPO/host_archive['archive'])==host_archive['archive-sha256'] and digest(REPO/host_archive['identity'])==host_archive['identity-sha256']
assert digest(PRIOR/'report.md')=='60e938ec4c240863ad7464abe820ac74f26f40ddbd6a0ed2110fd79d2a6c148f'
assert digest(PRIOR/'review-record.json')=='aad8ba5015f3cdabc49933dee9aecddb8945779b21fab144af50984cd1531322'
emit('source-contract-and-review-continuity.json',{'source-count':1933,'contract-count':30,'freeze-sha256':digest(PACKAGE/'source-and-contract-inputs.json'),'all-current-input-paths-and-bytes-match-frozen-host-and-matrix':True,'source-delta-from-original-full-review':26,'contract-delta-from-original-full-review':1,'recomputed-delta':recomputed,'prior-host-report-sha256':digest(PRIOR/'report.md'),'prior-host-receipt-sha256':digest(PRIOR/'review-record.json'),'prior-host-complete-archive-and-manifest-unchanged':True,'new-five-file-and-earlier-independent-review-identities-unchanged':True})
for name in ['README.md','jdk-matrix-archive-identity.json','jdk-matrix-receipt.json','source-and-contract-inputs.json','t75-final-jdk-matrix-r4-command.json','t75-final-jdk-matrix-r4-result.json','t75-final-jdk-matrix-r4.log']:
    keep(PACKAGE/name,'sources/matrix/'+name)
for name in ['receipt.json','t75-retain-complete-validation-r4.py','t75-run-retained.py']:keep(pathlib.Path(identity['original'])/name,'sources/frozen-originals/'+name)
for name in ['AGENTS.md','CONTRIBUTING.md','capabilities/foundation-release.yaml','capabilities/foundation-environments.yaml','capabilities/foundation-requirements.yaml','scripts/verify-jdk-matrix.sh','docs/foundation-readiness.md']:
    keep(REPO/name,'sources/standards/'+name)
keep('/home/ubuntu/.codex/attachments/77353239-0dda-4ee1-b4bb-ce7fb3fa0f9b/pasted-text-1.txt','sources/standards/original-goal.txt')
for name in ['report.md','review-record.json','artifact-identities.json']:keep(PRIOR/name,'sources/prior-host/'+name)
for name in ['source-contract-continuity-audit.json','host-log-XML-audit.json','XML-result-identities.json','host-archive-byte-audit.json']:keep(HOST/name,'sources/prior-host/'+name)
for name in ['README.md','independent-review-closure.json','input-delta-from-original-full-review.json','standards-review-report.md','spec-review-report.md']:
    keep(REPO/'capabilities/evidence/T75-delivery/inventory-read-bound'/name,'sources/inventory-closure/'+name)
emit('copied-source-identities.json',COPIES)
print(json.dumps({'matrix-original-members':len(members),'four-JDK-totals':[{'jdk-major':x['jdk-major'],**x['totals']} for x in sections],'class-results-each':87,'reactor-successes-each':10,'actual-outer-exit':result['returncode'],'retained-last-JDK-reports':177,'last-JDK-XML':87,'last-JDK-runtime':dict(java['java.runtime.version']),'source-inputs':len(sources),'contract-inputs':len(contracts),'cumulative-delta':[26,1],'source-copies':len(COPIES),'findings':[]},indent=2))
