import pathlib,json
p=pathlib.Path('/home/ubuntu/IdeaProjects/open-pdf/capabilities/evidence/T75-delivery/final-validation-r4')
for name in ['README.md','jdk-matrix-archive-identity.json','jdk-matrix-receipt.json','t75-final-jdk-matrix-r4-command.json','t75-final-jdk-matrix-r4-result.json']:
    q=p/name;print('FILE',name,q.stat().st_size)
    if q.suffix=='.md':print(q.read_text());continue
    data=json.loads(q.read_text())
    for key,value in data.items():
        if isinstance(value,(list,dict)) and len(value)>5:print(key,type(value).__name__,len(value),'sample',repr(next(iter(value.items())) if isinstance(value,dict) else value[0])[:900])
        else:print(key,repr(value)[:5000])
print('log section headings')
log=(p/'t75-final-jdk-matrix-r4.log').read_text()
for line in log.splitlines():
    if any(term in line for term in ['===','Running ./mvnw','BUILD SUCCESS','Finished at:','Total time:','TextStructureExtractionWorkflowTest','FoundationReadinessCommandTest']):print(line)
