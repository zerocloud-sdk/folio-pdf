import datetime,hashlib,json,pathlib
OUT=pathlib.Path(__file__).parent
REPO=pathlib.Path('/home/ubuntu/IdeaProjects/open-pdf')
def digest(path):
    with pathlib.Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(name):return json.loads((OUT/name).read_text())
def emit(name,value):
    with (OUT/name).open('x') as f:json.dump(value,f,indent=2);f.write('\n')
report="""Independent Standards closure of the completed r4 four-JDK matrix, against fixed baseline and unchanged HEAD `5b1603c435f11c40368f75b7b9a2777c9c5e9761`.

**Hard violations: 0.** Original command/result/log bytes substantiate the actual outer exit 0 of `./scripts/verify-jdk-matrix.sh`, from 2026-09-13 14:42:45.357683 UTC to 17:00:34.619670 UTC. Each JDK 8/11/17/21 section contains 87 class results, 1,507 tests, zero failures/errors, four unchanged opt-in skips, and ten successful reactor modules. Each includes 115 Native extraction and 17 inventory cases.

All 184 archive members match their manifest and frozen originals byte-for-byte. The 177 retained reports belong only to final JDK 21. Its 87 XML class-result multiset exactly matches that complete log section; every XML records Java 21 and runtime `21.0.12+8-LTS`. The XML preserves all three new inventory reader regressions and the same four skipped methods as the reviewed r4 host run. Earlier JDK XML is neither retained nor claimed. All four log class-result multisets match that host run. Image headers match the frozen environment contract, and the configured HarfBuzz helper hash is unchanged.

The complete 1,933 source and 30 contract path/hash sets still equal the reviewed r4 host freeze. The recomputed cumulative 26-source/one-contract delta matches the original full review plus retained closures, including the independently reviewed five-file inventory correction. Latest README bytes correctly separate matrix validation, staging, and outstanding certification/delivery.

**Heuristic findings: 0 open.** No additional structural change is warranted for this evidence increment. One reviewer-only README literal assertion failed on number/timestamp formatting; its original diagnostic and separate successful correction are preserved.

This read-only closure covers matrix evidence and review continuity only. Fresh candidate validation, all 48 certifications, final inventory/index and delivery gates remain separate. No project tests, certifiers, environment observers, or live target reports were executed or read; no repository state was changed.
"""
with (OUT/'report.md').open('x') as f:f.write(report)
assert len(report.split())<400
closing=read('closing-v2-readonly-check.json')
archive=read('archive-byte-audit.json')
process=read('original-process-audit.json')
sections=read('four-log-section-audit.json')
xml=read('final-JDK21-XML-audit.json')
continuity=read('source-contract-and-review-continuity.json')
assert digest(REPO/'capabilities/evidence/T75-delivery/final-validation-r4/README.md')==closing['README-sha256']
freeze=json.loads((OUT/'sources/matrix/source-and-contract-inputs.json').read_text())
assert all(digest(REPO/row['path'])==row['sha256'] for kind in ['inputs','contract-inputs'] for row in freeze[kind])
assert digest(REPO/archive['archive'])==archive['archive-sha256']
exclusions=['artifact-identities.json','commands/finalization.stdout','commands/finalization.stderr','commands/finalization-result.json']
standards=[]
for name,ranges in [('CONTRIBUTING.md',[(41,55)]),('docs/foundation-readiness.md',[(34,58)])]:
    source=OUT/'sources/standards'/name;lines=source.read_text().splitlines()
    standards.append({'source':str(source.relative_to(OUT)),'sha256':digest(source),'excerpts':[{'first-line':a,'last-line':b,'text':'\n'.join(lines[a-1:b])} for a,b in ranges]})
receipt={
    'reviewer':'/root/final_standards; independent Standards reviewer, no implementation work in this increment',
    'review-kind':'bounded completed r4 four-JDK matrix evidence closure',
    'sealed-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'repository':str(REPO),'fixed-baseline':closing['baseline'],'HEAD':closing['HEAD'],
    'commit-list-empty':True,'canonical-three-dot-diff-empty':True,
    'review-point':'Retained WIP validation artifacts and current frozen r4 inputs; not an empty diff interpreted as no work.',
    'hard-violations':[],'open-heuristic-findings':[],
    'normative-sources':standards,
    'original-goal':{'copy':'sources/standards/original-goal.txt','sha256':digest(OUT/'sources/standards/original-goal.txt')},
    'fowler-heuristic-baseline':['Mysterious Name','Duplicated Code','Feature Envy','Data Clumps','Primitive Obsession','Repeated Switches','Shotgun Surgery','Divergent Change','Speculative Generality','Message Chains','Middle Man','Refused Bequest'],
    'heuristic-application':'Judgement only, repository rules prevail; this increment changes retained validation evidence, while prior full-source and incremental reviews remain identity-bound. No new code hunk or open smell is introduced.',
    'original-process':process,
    'archive-byte-audit':archive,
    'matrix-runs':[{'jdk-major':x['jdk-major'],'header':x['header'],'totals':x['totals'],'class-result-count':len(x['class-results']),'reactor-success-count':len(x['reactor-successes']),'native-extraction':x['native-extraction-result'],'inventory-results':x['inventory-results'],'exact-reviewed-host-class-result-multiset-match':True} for x in sections],
    'final-JDK21-reports':{'report-files':177,'XML-class-results':87,'runtime-property-counts':xml['runtime-property-counts'],'exact-log-result-multiset-match':True,'four-skips':xml['four-unchanged-opt-in-skips'],'three-inventory-regressions':xml['three-new-inventory-regressions'],'earlier-three-JDK-XML-retained-or-inspected':False,'earlier-JDK-boundary':'Complete original per-class log results and frozen test inputs were checked; no claim of retaining earlier XML or observing earlier XML runtime properties.'},
    'review-continuity':continuity,
    'closing-readonly-check':closing,
    'reviewer-diagnostics':[{'original-script':'closing-inspection.py','original-result':'commands/closing-inspection-result.json','returncode':1,'reason':'Reviewer expected literal 1507 and a Z timestamp. The correct README uses 1,507 and UTC. This is a reviewer interpretation error, not a project test or evidence failure.','literal-inspection':'commands/readme-literal-diagnostic.stdout','corrected-script':'closing-inspection-v2.py','corrected-result':'commands/closing-inspection-v2-result.json','corrected-returncode':0,'all-originals-preserved':True}],
    'latest-README':{'copy':'sources/matrix/README.md','sha256':closing['README-sha256'],'scope-accurate':True,'stage-boundary':'README records fresh stage exit 0. Stage artifacts were not reviewed by this matrix-only closure.','certification-boundary':'All 48 fresh certification tuples and their independent reviews, final inventory and delivery remain separately required.'},
    'scope-limitations':['No project execution or evidence-authority mutation.','No live target reports read; all report checks used completed originals or archive bytes.','Not a fresh candidate, certification, final inventory, index, tracker, or delivery approval.','Previous full-source closures are retained and identity-verified, not silently represented as a new full source rereview.'],
    'packet-preservation':{'exclusive-creation':True,'repository-writes':False,'original-process-records':'original-process/','source-identities':'copied-source-identities.json','all-archive-member-identities':'archive-member-identities.json','full-current-input-identities':'closing-v2-current-input-identities.json','manifest':'artifact-identities.json','manifest-exclusions':exclusions,'exclusion-reason':'The manifest cannot hash itself; its executing wrapper writes the finalization output/error/result afterward. All four excluded files remain in the completed packet for the parent to hash during archival.'},
    'report':{'path':'report.md','sha256':digest(OUT/'report.md'),'word-count':len(report.split())}
}
emit('review-record.json',receipt)
files=[]
for path in sorted(OUT.rglob('*')):
    if path.is_file() and path.relative_to(OUT).as_posix() not in exclusions:
        assert not path.is_symlink();files.append({'path':path.relative_to(OUT).as_posix(),'bytes':path.stat().st_size,'sha256':digest(path)})
emit('artifact-identities.json',{'created-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':files,'file-count':len(files),'exclusions':exclusions})
for row in files:assert digest(OUT/row['path'])==row['sha256']
print(json.dumps({'packet':str(OUT),'report':{'path':str(OUT/'report.md'),'sha256':digest(OUT/'report.md')},'receipt':{'path':str(OUT/'review-record.json'),'sha256':digest(OUT/'review-record.json')},'manifest':{'path':str(OUT/'artifact-identities.json'),'sha256':digest(OUT/'artifact-identities.json')},'manifested-files':len(files),'report-words':len(report.split()),'hard-violations':0,'open-heuristic-findings':0,'README-sha256':closing['README-sha256'],'matrix-archive-sha256':archive['archive-sha256'],'scope':'Completed r4 matrix only; candidate, certification, final inventory/index/delivery are separate.'},indent=2))
