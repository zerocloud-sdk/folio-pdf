import pathlib,subprocess,datetime,hashlib,json,sys
out=pathlib.Path(__file__).parent
argv=['python3','-B',str(out/'initial-inspection.py')]
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
p=subprocess.run(argv,cwd='/home/ubuntu/IdeaProjects/open-pdf',stdout=subprocess.PIPE,stderr=subprocess.PIPE)
for kind,data in [('stdout',p.stdout),('stderr',p.stderr)]:
    with (out/'commands'/('initial-inspection.'+kind)).open('xb') as f:f.write(data)
with (out/'commands/initial-inspection-result.json').open('x') as f:json.dump({'argv':argv,'cwd':'/home/ubuntu/IdeaProjects/open-pdf','started-utc':start,'finished-utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'returncode':p.returncode,'stdout-sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr-sha256':hashlib.sha256(p.stderr).hexdigest()},f,indent=2);f.write('\n')
sys.stdout.buffer.write(p.stdout);sys.stderr.buffer.write(p.stderr);sys.exit(p.returncode)
