#!/usr/bin/env python3
"""Serially validate and stage the independently reviewed five-file correction."""
from datetime import datetime,timezone
import hashlib,importlib.util,json,os,subprocess,sys
from pathlib import Path
import yaml
ROOT=Path('/home/ubuntu/IdeaProjects/open-pdf');os.chdir(ROOT)
REVIEW=Path('/tmp/t75-inventory-read-bound-reviewed-r4.json');review=json.loads(REVIEW.read_bytes())
assert review['standards-closed'] and review['spec-closed']
for item in review['source-delta']:
    assert hashlib.sha256((ROOT/item['path']).read_bytes()).hexdigest()==item['current-sha256']
archive=json.loads(Path('/tmp/t75-historical-r3-raw-archive-result.json').read_bytes());assert archive['returncode']==0
module=json.loads(Path('/tmp/t75-inventory-read-bound-module-verify-r4-result.json').read_bytes());assert module['returncode']==0
DEST=ROOT/'capabilities/evidence/T75-delivery/final-validation-r4';DEST.mkdir(exist_ok=False)
spec=importlib.util.spec_from_file_location('queue_inputs',ROOT/'scripts/t03-foundation.py');f=importlib.util.module_from_spec(spec);spec.loader.exec_module(f);contract=yaml.safe_load((ROOT/'capabilities/foundation-release.yaml').read_bytes())
frozen=f.capture_build_inputs(ROOT,contract);assert len(frozen['inputs'])==1933 and len(frozen['contract-inputs'])==30
(DEST/'source-and-contract-inputs.json').write_text(json.dumps(frozen,indent=2)+'\n')
env=dict(os.environ);env['FOLIO_HARFBUZZ_HELPER']=str(ROOT/'.build-cache/harfbuzz/10.2.0-final/bin/folio-harfbuzz')
def command(name,args):
    assert f.capture_build_inputs(ROOT,contract)==frozen
    print(datetime.now(timezone.utc).isoformat(),'Starting',name,flush=True)
    subprocess.run([sys.executable,'-B','/tmp/t75-run-retained.py','--name','/tmp/'+name,'--']+args,cwd=ROOT,env=env,check=True)
    result=json.loads(Path('/tmp/'+name+'-result.json').read_bytes());assert result['returncode']==0
    assert f.capture_build_inputs(ROOT,contract)==frozen
    print(datetime.now(timezone.utc).isoformat(),name,'actual exit0; source/contract unchanged',flush=True)
command('t75-final-full-verify-r4',['./mvnw','-B','-ntp','verify'])
subprocess.run([sys.executable,'-B','/tmp/t75-retain-complete-validation-r4.py','host'],cwd=ROOT,env=env,check=True)
command('t75-final-jdk-matrix-r4',['./scripts/verify-jdk-matrix.sh'])
subprocess.run([sys.executable,'-B','/tmp/t75-retain-complete-validation-r4.py','matrix'],cwd=ROOT,env=env,check=True)
command('t75-final-stage-r4',[sys.executable,'scripts/t03-foundation.py','stage','--obligation','text'])
subprocess.run([sys.executable,'-B','/tmp/t75-retain-stage-r4.py'],cwd=ROOT,env=env,check=True)
print('Complete host verification, four-JDK matrix and fresh stage actually passed and their originals are retained. Certification remains a separate required next step.',flush=True)
