from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,tempfile
repo=Path('/home/ubuntu/IdeaProjects/open-pdf');prior=Path('/tmp/t75-spec-cache-selection.suazqkke');freeze=Path('/tmp/t75-qpdf-wrapper-identity-freeze-nd011uo3')
base=Path(tempfile.mkdtemp(prefix='t75-spec-wrapper-link-closure.'));shutil.copy2(__file__,base/'probe.py')
source=base/'observer-snapshot';shutil.copytree(freeze,source)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
frozen=json.loads((source/'identities.json').read_text());assert all(sha(source/n)==h for n,h in frozen.items())
cp=Path('/tmp/t75-syntax-review-classpath.txt').read_text().strip();(base/'classpath.txt').write_text(cp)
classes={}
for n in ['T13IndependentEvidence','T13EvidenceCommand']:
    p=repo/'pdf-acceptance/target/classes/net/zerocloud/pdf/acceptance'/f'{n}.class';classes[str(p)]=sha(p);shutil.copy2(p,source/p.name)
(base/'class-identities-before.json').write_text(json.dumps(classes,indent=2))
inputs=base/'inputs';shutil.copytree(prior/'inputs',inputs);output=base/'observations';output.mkdir();rows=[]

def observe(name,kind,root,pdf,cache,expected):
    out=output/name;env=os.environ.copy();env.pop('QPDF_CACHE_DIRECTORY',None)
    if cache is not None:env['QPDF_CACHE_DIRECTORY']=cache
    if kind=='java':cmd=['java','-cp',cp,'net.zerocloud.pdf.acceptance.T13EvidenceCommand','syntax',str(root),str(pdf),str(out),'test'];key='syntax'
    else:
        file='t13-program-standards.py' if kind=='program' else 't13-semantics.py';scope='cmaps' if kind=='program' else 'embedded-font-kinds';key='standards' if kind=='program' else 'semantic';cmd=[sys.executable,str(source/file),str(root),str(pdf),scope,str(out)]
    p=subprocess.run(cmd,cwd=prior/'launcher',env=env,capture_output=True,text=True,timeout=45)
    props=dict(line.split('=',1) for line in (out/'result.properties').read_text().splitlines() if '=' in line and not line.startswith('#')) if (out/'result.properties').exists() else {}
    row={'case':name,'argv':cmd,'cwd':str(prior/'launcher'),'QPDF_CACHE_DIRECTORY':cache,'expected':expected,'result':props.get(key),'matched':props.get(key)==expected,'exit-code':p.returncode,'input-sha256':sha(pdf),'properties':props,'output':str(out)}
    rows.append(row);(base/(name+'.command.json')).write_text(json.dumps(row,indent=2));(base/(name+'.stdout.txt')).write_text(p.stdout);(base/(name+'.stderr.txt')).write_text(p.stderr);print(json.dumps({k:row[k] for k in ['case','expected','result','matched']}),flush=True)

# Original wrapper symlink and original malformed PDF retained without any layout changes.
originalroot=prior/'checked-root';truncated=inputs/'truncated.pdf';positive=inputs/'embedded-font-kinds.pdf';genuine=repo/'.build-cache/qpdf'
for kind,bad in [('java','fail'),('program','indeterminate'),('semantic','indeterminate')]:
    for label,cache in [('unset',None),('empty','')]:observe(kind+'-original-wrapper-'+label,kind,originalroot,truncated,cache,bad)
    observe(kind+'-original-wrapper-positive',kind,originalroot,positive,None,'pass')
observe('semantic-original-wrapper-explicit-cache','semantic',originalroot,truncated,str(genuine),'indeterminate')

# Directory link retains identical wrapper bytes but changes the pin read through parent/../ syntax.
checked=base/'directory-link-root';shutil.copytree(originalroot,checked,symlinks=True)
wrapperdir=checked/'scripts/container-bin';(wrapperdir/'qpdf').unlink();wrapperdir.rmdir()
owner=base/'directory-owner';(owner/'scripts/container-bin').mkdir(parents=True)
for n in ['qpdf-pin.properties','container-bin/qpdf']:shutil.copy2(repo/'scripts'/n,owner/'scripts'/n)
(owner/'.build-cache').mkdir();(owner/'.build-cache/qpdf').symlink_to(prior/'fake-cache',target_is_directory=True)
wrapperdir.symlink_to(owner/'scripts/container-bin',target_is_directory=True)
loaded=wrapperdir/'..'/'qpdf-pin.properties';declared=checked/'scripts/qpdf-pin.properties';original_pin=loaded.read_bytes()
layout={'wrapper':str(wrapperdir/'qpdf'),'resolved-wrapper':str((wrapperdir/'qpdf').resolve()),'declared-pin':str(declared),'loaded-pin-spelling':str(loaded),'loaded-pin-resolved':str(loaded.resolve()),'declared-sha256':sha(declared),'loaded-sha256':sha(loaded)}
(base/'directory-layout.json').write_text(json.dumps(layout,indent=2))
for kind,bad in [('java','fail'),('program','indeterminate'),('semantic','indeterminate')]:
    observe(kind+'-directory-link-positive',kind,checked,positive,'','pass')
    observe(kind+'-directory-link-truncated',kind,checked,truncated,'',bad)

# Only the pin actually sourced by the wrapper changes; root's declared pin stays authentic.
loaded.write_bytes(original_pin+b'QPDF_CACHE_DIRECTORY='+str(prior/'fake-cache').encode()+b'\n');shutil.copy2(loaded,base/'changed-loaded-qpdf-pin.properties')
for kind in ['java','program','semantic']:observe(kind+'-directory-link-changed-loaded-pin',kind,checked,truncated,str(genuine),'indeterminate')
loaded.unlink()
for kind in ['java','program','semantic']:observe(kind+'-directory-link-missing-loaded-pin',kind,checked,positive,str(genuine),'indeterminate')
loaded.symlink_to(declared)
for kind in ['java','program','semantic']:observe(kind+'-directory-link-authentic-pin-link',kind,checked,positive,None,'pass')

after={str(p):sha(p) for p in map(Path,classes)};(base/'class-identities-after.json').write_text(json.dumps(after,indent=2))
summary={'directory':str(base),'classes-unchanged':classes==after,'snapshot-unchanged':all(sha(source/n)==h for n,h in frozen.items()),'rows':rows};(base/'summary.json').write_text(json.dumps(summary,indent=2));print(str(base),flush=True)
