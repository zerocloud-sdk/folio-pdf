# Independent incremental T13 syntax Standards review

All PDF authoring and synthetic installation/configuration changes are confined to this directory. No repository source, real tool installation or compiled target was changed. Java processes used the existing classpath from /tmp/t75-syntax-review-classpath.txt and public T13EvidenceCommand syntax route. Processes were independently limited to 45 seconds; none exceeded two seconds.

## Reproduction and identities

- `probe.py`: independent stdlib driver; exact argument arrays and results are retained in `results.json` and `results.jsonl`.
- `after-identity-probe.py`: deterministic after-start identity-change control, monitoring all JVM task children; command, observed qpdf child and mutation time are in `post-tool-pin-change-r2-result.json`.
- `identity.json` / `identity-after.json`: original wrapper, pin, Java and compiled-class identities. Real repository class/config identities were unchanged across this review.
- Each result directory retains its exact observed `extraction.pdf`, public result properties and all recorder reports produced. Driver stdout and stderr are adjacent files.

## Established findings

1. `redirected-pin-substitute-truncated-output`: FAIL control becomes false PASS. An identical reviewed wrapper and a real default qpdf installation are retained, but a copied pin appends QPDF_CACHE_DIRECTORY pointing to a substitute checker. Java verifies the real default binary while the wrapper sources the additional assignment and executes the substitute. The malformed truncated original PDF is accepted; syntax.txt records `INDEPENDENT SUBSTITUTE CHECKER RAN`. Before/after pin and verified binary identities remain stable, and result.properties advertises the real binary SHA. `clone-real-tool-truncated-output` confirms FAIL with the otherwise identical copied installation and original pin; `version-only-wrapper-output` confirms the existing wrapper-byte guard returns INDET.

2. `post-tool-pin-change-r2-output`: after the genuine qpdf --check process started, only a comment was appended to its copied pin. result.properties becomes INDET, but syntax.txt is replaced with a generic finding instead of retaining raw stdout/stderr, while syntax.md still declares PASS. The recorded child executable is the real qpdf reached through a cache symlink. Source/extraction SHA remain equal.

## Controls and probe correction

`original-output` passes the existing project-owned source. `truncated-output` fails. `post-tool-pin-change-output` is a valid large original PDF positive, PASS: the first driver's leader-thread-only child monitor did not observe the JVM child, so it did not mutate the pin and is not evidence of an after-identity test. The corrected r2 monitor observes children of all JVM tasks and records the actual mutation before qpdf completion. This correction and both original raw runs are retained.

The large PDF is original stdlib-authored flat syntax: catalog, pages, page and 120000 repeated surplus dictionaries. The short truncated PDF is an original negative. The small legal source is copied byte-for-byte from the repository's project-owned nested-split-type3.pdf. Synthetic shell checker and pin additions were written independently only to expose tool-selection mismatch, not imported from any external product.

These are incremental implementation findings. No full T13/#75 certification or pending scope completeness conclusion is made.
