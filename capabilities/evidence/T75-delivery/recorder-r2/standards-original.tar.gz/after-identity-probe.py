from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
ROOT=Path('/home/ubuntu/IdeaProjects/open-pdf');HERE=Path(__file__).resolve().parent
CLASSPATH=Path('/tmp/t75-syntax-review-classpath.txt').read_text().strip()
clone=HERE/'changing-clone-r2';(clone/'scripts/container-bin').mkdir(parents=True);(clone/'.build-cache').mkdir()
(clone/'.build-cache/qpdf').symlink_to(ROOT/'.build-cache/qpdf',target_is_directory=True)
for relative in ['scripts/qpdf-pin.properties','scripts/container-bin/qpdf']:
 shutil.copy2(ROOT/relative,clone/relative)
pdf=HERE/'post-tool-pin-change.pdf';out=HERE/'post-tool-pin-change-r2-output';pin=clone/'scripts/qpdf-pin.properties'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
env=dict(os.environ);env.pop('QPDF_CACHE_DIRECTORY',None)
command=[shutil.which('java'),'-cp',CLASSPATH,'net.zerocloud.pdf.acceptance.T13EvidenceCommand','syntax',str(clone),str(pdf),str(out),'test']
row={'command':command,'input_sha256':sha(pdf),'pin_before':sha(pin),'identity_changed_during_check':False,'probe_sha256':sha(Path(__file__))}
start=time.monotonic()
with (HERE/'post-tool-pin-change-r2.stdout').open('wb') as stdout,(HERE/'post-tool-pin-change-r2.stderr').open('wb') as stderr:
 proc=subprocess.Popen(command,stdout=stdout,stderr=stderr,env=env)
 while proc.poll() is None and time.monotonic()-start<40:
  ids=set()
  for task in (Path('/proc')/str(proc.pid)/'task').glob('*'):
   try:ids.update((task/'children').read_text().split())
   except FileNotFoundError:pass
  for child in ids:
   try:cmdline=(Path('/proc')/child/'cmdline').read_bytes().split(bytes([0]))
   except (FileNotFoundError,PermissionError):continue
   if b'--check' in cmdline and cmdline[0].endswith(b'qpdf'):
    pin.write_bytes(pin.read_bytes()+bytes([10])+b'# Independent after-start identity-change control'+bytes([10]))
    row['identity_changed_during_check']=True;row['observed_child']={'pid':child,'command':[x.decode() for x in cmdline if x]};row['mutation_elapsed']=time.monotonic()-start;break
  if row['identity_changed_during_check']:break
  time.sleep(.001)
 try:row['exit']=proc.wait(timeout=max(1,45-(time.monotonic()-start)))
 except subprocess.TimeoutExpired:proc.kill();row['exit']=proc.wait();row['timed_out']=True
row['elapsed']=time.monotonic()-start;row['pin_after']=sha(pin)
row['files']={str(f.relative_to(out)):sha(f) for f in out.glob('*') if f.is_file()}
row['result_properties']=(out/'result.properties').read_text() if (out/'result.properties').exists() else None
(HERE/'post-tool-pin-change-r2-result.json').write_text(json.dumps(row,indent=2)+bytes([10]).decode())
print(json.dumps({k:v for k,v in row.items() if k!='command'},indent=2))
for name in ['syntax.txt','syntax.md']:
 print(name+':');print((out/name).read_text())
