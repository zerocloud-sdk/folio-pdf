from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time
ROOT=Path('/home/ubuntu/IdeaProjects/open-pdf');HERE=Path(__file__).resolve().parent
CLASSPATH=Path('/tmp/t75-syntax-review-classpath.txt').read_text().strip()
JAVA=shutil.which('java');BASE=(ROOT/'capabilities/profiles/T13-text/fixtures/nested-split-type3.pdf').read_bytes()
PIN=(ROOT/'scripts/qpdf-pin.properties').read_bytes();WRAPPER=(ROOT/'scripts/container-bin/qpdf').read_bytes()
ENV=dict(os.environ);ENV.pop('QPDF_CACHE_DIRECTORY',None)

def fake_root(label,redirect=False,fake_wrapper=False):
 root=HERE/label;(root/'scripts/container-bin').mkdir(parents=True);(root/'.build-cache').mkdir()
 (root/'.build-cache/qpdf').symlink_to(ROOT/'.build-cache/qpdf',target_is_directory=True)
 (root/'scripts/container-bin/qpdf').write_bytes(WRAPPER if not fake_wrapper else b'#!/bin/sh\nprintf "qpdf version 12.4.0\\n"\n')
 (root/'scripts/container-bin/qpdf').chmod(0o755)
 pin=PIN
 if redirect:
  cache=HERE/'substitute-cache';home=cache/'12.4.0';(home/'bin').mkdir(parents=True)
  (home/'bin/qpdf').write_bytes(b'#!/bin/sh\nif [ "$1" = "--version" ]; then printf "qpdf version 12.4.0\\n"; else printf "INDEPENDENT SUBSTITUTE CHECKER RAN\\n"; fi\nexit 0\n')
  (home/'bin/qpdf').chmod(0o755)
  values=dict(line.split('=',1) for line in PIN.decode().splitlines() if line and not line.startswith('#'))
  (home/'.archive-sha256').write_text(values['QPDF_ARCHIVE_SHA256']+'\n');(home/'.binary-sha256').write_text(values['QPDF_BINARY_SHA256']+'\n')
  pin+=b'\n# Independent tool-selection substitution control\nQPDF_CACHE_DIRECTORY='+str(cache).encode()+b'\n'
 (root/'scripts/qpdf-pin.properties').write_bytes(pin)
 return root

def big_pdf():
 # Independent original flat PDF; surplus dictionaries give the real --check a visible bounded duration.
 parts=[b'<< /Type /Catalog /Pages 2 0 R >>',b'<< /Type /Pages /Kids [3 0 R] /Count 1 >>',b'<< /Type /Page /Parent 2 0 R /MediaBox [0 0 10 10] /Resources << >> >>']
 parts += [b'<< /Review (original syntax control) >>']*120000
 data=bytearray(b'%PDF-2.0\n');offsets=[0]
 for n,body in enumerate(parts,1):
  offsets.append(len(data));data.extend(str(n).encode()+b' 0 obj\n'+body+b'\nendobj\n')
 xref=len(data);data.extend(b'xref\n0 '+str(len(offsets)).encode()+b'\n0000000000 65535 f \n')
 for off in offsets[1:]:data.extend(('%010d 00000 n \n'%off).encode())
 data.extend(b'trailer\n<< /Size '+str(len(offsets)).encode()+b' /Root 1 0 R >>\nstartxref\n'+str(xref).encode()+b'\n%%EOF\n');return bytes(data)

def properties(path):
 if not path.exists():return None
 return dict(line.split('=',1) for line in path.read_text().splitlines() if line and not line.startswith(('#','!')))

records=[]
def run(label,data,root,change_identity=False):
 pdf=HERE/(label+'.pdf');pdf.write_bytes(data);out=HERE/(label+'-output')
 pin=root/'scripts/qpdf-pin.properties';before=hashlib.sha256(pin.read_bytes()).hexdigest()
 command=[JAVA,'-cp',CLASSPATH,'net.zerocloud.pdf.acceptance.T13EvidenceCommand','syntax',str(root),str(pdf),str(out),'test']
 start=time.monotonic();changed=False;observed_child=None
 with (HERE/(label+'.stdout')).open('wb') as stdout,(HERE/(label+'.stderr')).open('wb') as stderr:
  proc=subprocess.Popen(command,stdout=stdout,stderr=stderr,env=ENV)
  if change_identity:
   while proc.poll() is None and time.monotonic()-start<40:
    children=Path('/proc')/str(proc.pid)/'task'/str(proc.pid)/'children'
    try:ids=children.read_text().split()
    except FileNotFoundError:ids=[]
    for child in ids:
     try:cmdline=(Path('/proc')/child/'cmdline').read_bytes().split(b'\0')
     except FileNotFoundError:continue
     if b'--check' in cmdline and cmdline[0].endswith(b'qpdf'):
      pin.write_bytes(pin.read_bytes()+b'\n# Independent after-start identity-change control\n')
      changed=True;observed_child={'pid':child,'command':[x.decode() for x in cmdline if x]};break
    if changed:break
    time.sleep(.001)
  try:code=proc.wait(timeout=max(1,45-(time.monotonic()-start)))
  except subprocess.TimeoutExpired:proc.kill();code=proc.wait()
 result=properties(out/'result.properties')
 row=dict(label=label,command=command,exit=code,elapsed=round(time.monotonic()-start,3),input_sha256=hashlib.sha256(data).hexdigest(),pin_before=before,pin_after=hashlib.sha256(pin.read_bytes()).hexdigest(),identity_changed_during_check=changed,observed_child=observed_child,result=result,files={str(f.relative_to(out)):hashlib.sha256(f.read_bytes()).hexdigest() for f in out.glob('*') if f.is_file()} if out.exists() else {})
 if result:assert result['input-sha256']==hashlib.sha256(data).hexdigest()
 records.append(row);print(label,code,result.get('syntax') if result else None,'changed='+str(changed),flush=True)
 with (HERE/'results.jsonl').open('a') as dest:dest.write(json.dumps(row)+'\n')

truncated=b'%PDF-2.0\n1 0 obj\n'
run('original',BASE,ROOT)
run('truncated',truncated,ROOT)
run('clone-real-tool-truncated',truncated,fake_root('legitimate-clone'))
run('redirected-pin-substitute-truncated',truncated,fake_root('redirected-clone',redirect=True))
run('version-only-wrapper',truncated,fake_root('version-only-clone',fake_wrapper=True))
run('post-tool-pin-change',big_pdf(),fake_root('changing-clone'),change_identity=True)
(HERE/'results.json').write_text(json.dumps(records,indent=2)+'\n')
identities={'classpath':CLASSPATH,'java-executable':str(Path(JAVA).resolve()),'java-sha256':hashlib.sha256(Path(JAVA).resolve().read_bytes()).hexdigest(),'source-wrapper-sha256':hashlib.sha256(WRAPPER).hexdigest(),'source-pin-sha256':hashlib.sha256(PIN).hexdigest(),'probe-sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
for name in ['T13EvidenceCommand','T13IndependentEvidence','QpdfSyntaxRecorder','QpdfSyntaxRecorder$Profile','QpdfPin','PinProperties','ExternalProcess','EvidenceFiles']:
 path=ROOT/'pdf-acceptance/target/classes/net/zerocloud/pdf/acceptance'/(name+'.class');identities[name+'.class']=hashlib.sha256(path.read_bytes()).hexdigest()
(HERE/'identity.json').write_text(json.dumps(identities,indent=2)+'\n')
