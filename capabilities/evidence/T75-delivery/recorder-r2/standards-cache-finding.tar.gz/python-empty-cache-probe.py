from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time
ROOT=Path('/home/ubuntu/IdeaProjects/open-pdf');HERE=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
env=dict(os.environ);env.pop('QPDF_CACHE_DIRECTORY',None)
source=ROOT/'capabilities/profiles/T13-text/fixtures/nested-split-type3.pdf'
command=[str(ROOT/'scripts/container-bin/qpdf'),'--json=2','--json-stream-data=inline','--decode-level=all',str(source)]
with (HERE/'source-qpdf.json').open('wb') as stdout,(HERE/'source-qpdf.stderr').open('wb') as stderr:
 code=subprocess.run(command,stdout=stdout,stderr=stderr,env=env,timeout=30).returncode
assert code==0 and not (HERE/'source-qpdf.stderr').stat().st_size
root=HERE/'python-empty-root';(root/'scripts/container-bin').mkdir(parents=True)
for rel in ['scripts/qpdf-pin.properties','scripts/container-bin/qpdf','scripts/t13-qpdf-runtime.sha256','capabilities/profiles/T13-text/corpus.json','capabilities/profiles/T13-text/fixtures/nested-split-type3.pdf']:
 target=root/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/rel,target)
home=root/'.build-cache/qpdf/12.4.0';(home/'bin').mkdir(parents=True)
exe=home/'bin/qpdf';exe.write_text('#!/bin/sh\nif [ "$1" = "--version" ]; then printf "qpdf version 12.4.0\\n"; else cat '+str(HERE/'source-qpdf.json')+'; fi\n');exe.chmod(0o755)
for marker in ['.archive-sha256','.binary-sha256']:shutil.copy2(ROOT/'.build-cache/qpdf/12.4.0'/marker,home/marker)
cwd=HERE/'empty-launcher';pdf=HERE/'empty-cache.pdf'
identities={str(p):sha(p) for p in [ROOT/'scripts/t13-program-standards.py',ROOT/'scripts/t13-semantics.py',root/'capabilities/profiles/T13-text/corpus.json',exe,Path(sys.executable).resolve(),pdf,HERE/'source-qpdf.json']}
records=[]
for script,scope,field in [('t13-program-standards.py','cmaps','standards'),('t13-semantics.py','nested-split-type3','semantic')]:
 for mode in ['empty','absolute-genuine']:
  out=HERE/(script.replace('.py','')+'-'+mode+'-output')
  arguments=[sys.executable,str(ROOT/'scripts'/script),str(root),str(pdf),scope,str(out)]
  configured='' if mode=='empty' else str(ROOT/'.build-cache/qpdf')
  started=time.monotonic()
  with (HERE/(out.name+'.stdout')).open('wb') as stdout,(HERE/(out.name+'.stderr')).open('wb') as stderr:
   result=subprocess.run(arguments,cwd=cwd,env=dict(env,QPDF_CACHE_DIRECTORY=configured),stdout=stdout,stderr=stderr,timeout=45)
  values=dict(line.split('=',1) for line in (out/'result.properties').read_text().splitlines() if line and not line.startswith(('#','!'))) if (out/'result.properties').exists() else None
  row={'command':arguments,'cwd':str(cwd),'QPDF_CACHE_DIRECTORY':configured,'exit':result.returncode,'elapsed':time.monotonic()-started,'result':values,'files':{str(p.relative_to(out)):sha(p) for p in out.iterdir() if p.is_file()}}
  records.append(row);print(script,mode,result.returncode,values.get(field) if values else None,flush=True)
after={p:sha(Path(p)) for p in identities};record={'probe-sha256':sha(Path(__file__)),'source-json-command':command,'source-json-exit':code,'identities-before':identities,'identities-after':after,'identities-unchanged':identities==after,'results':records}
(HERE/'python-empty-cache-result.json').write_text(json.dumps(record,indent=2)+'\n')
print('Identities unchanged:',identities==after)
