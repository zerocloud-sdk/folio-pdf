# Independent incremental T13 syntax identity closure

Public CLI probes only; no repository source, shared compiled target or original runtime was modified. Exact argument arrays, cwd, QPDF_CACHE_DIRECTORY, input/report identities and process results are preserved in results.json, per-case result JSON, python-empty-cache-result.json and the raw per-case output directories. Every Java/Python process was bounded by an independent 45-second timeout. All exited normally, under 2.5 seconds each. Sources/classes and the original 11 runtime library paths remained byte-identical over the nine Java probes; Python scripts and copied corpus authorities remained identical over their four probes.

## Original findings closed

- Original nested-split-type3 source remains PASS; original independently authored truncated PDF remains FAIL under the genuine installation.
- The original pin-append cache redirection control now returns INDETERMINATE before invoking an unqualified tool.
- After the genuine qpdf --check starts on the original large flat PDF, a comment appended to the temporary pin causes INDETERMINATE. Raw qpdf-syntax.txt retains stdout/stderr and its pre-final result, qpdf-syntax.md is retained; final syntax.txt/syntax.md and result.properties consistently report INDETERMINATE and explain the identity failure.
- The neighboring after-start source input mutation also returns INDETERMINATE with raw output preserved and consistent final reports.

## New adjacent tool-selection finding

The verified path and executed path still differ for configured relative and empty cache values.

1. Java, relative cache: cwd is relative/launcher and QPDF_CACHE_DIRECTORY=../cache. Java resolves the real installation at relative/cache. Its qpdf child runs with cwd relative/substitute/observation, so the unchanged shell wrapper resolves relative/substitute/cache containing the independent substitute. The truncated PDF returns PASS and raw output states INDEPENDENT SUBSTITUTE CHECKER RAN. Absolute real cache gives FAIL; absolute substitute cache gives INDETERMINATE.

2. Java, empty cache: Java Paths("") resolves cwd/12.4.0 to the genuine installation. The unchanged wrapper's ${QPDF_CACHE_DIRECTORY:-default} uses the temporary root's default cache containing the substitute. The same truncated PDF returns PASS.

3. Both Python observers, empty cache: Path("") likewise verifies the genuine cwd-relative installation, while the wrapper executes the temporary default substitute. The substitute returns a retained, independently captured qpdf JSON graph of the original Source for both reference and observed arguments. The malformed truncated PDF returns program standards=pass and semantic=pass. Absolute genuine cache controls return indeterminate because the actual malformed input is observed. Both observations nevertheless record the pinned genuine binary and runtime identities.

The copied pins and wrappers are byte-identical to the originals in these adjacent controls. No pin assignment is injected. The 11 declared runtime paths are checked on the genuine installation; this demonstrates a tool-selection mismatch independent of the library-byte fix.

The relevant code locations are T13IndependentEvidence.java:78-79 (also ExternalProcess.java:35-36), t13-program-standards.py:1040, t13-semantics.py:174, and the wrapper's default expression scripts/container-bin/qpdf:11. These outcomes violate docs/t13-certification.md:315-317 and :334. Normalize and bind the exact resolved cache into the launched environment, or explicitly reject empty/relative configured paths. Changing only Java's local path to an absolute path cannot fix the child's inherited environment.

## Provenance

The small legal source and malformed PDFs are exact copies of the prior independent review cases in /tmp/t75-syntax-standards-review-0z9bgvtq. The large PDF was independently authored in that review with catalog/pages/page and 120000 surplus flat dictionaries. All substitute shell programs and launch configurations are independent controls authored here. source-qpdf.json is actual genuine qpdf output for the original project-owned nested-split-type3 Source; its capture command, identities and stderr are retained. No generator/product internals were used to determine results.

This is an incremental closure/adjacent review, not the final T13/#75 qualification gate. No additional actionable smell was identified in the bounded report-separation refactor.
