# T75 qpdf syntax evidence

Capability: `document.text-structure.extract`

Acceptance Profile: `T13-text-logical-structure`

Profile record: `capabilities/evidence/T13-text-logical-structure.md`

Release train: `test`

Chain: `syntax`

Result: `pass`

Producer kind: `external-tool`

Producer: `qpdf`

Producer version: `12.4.0`

Tool distribution SHA-256: `a3bca240f3bb61efdc3a90be89d1da4ed5e125326c3458c4e62df53ff4f153e3`

Input exact SHA-256: `35344c33fea055f5b0aa6caed579b105d6f2322ce0253caf107b9b1cfa7491b4`

Input hash policy: `SHA-256 of the exact unmodified PDF bytes`

Final determination: `pass`

## Findings and artifact

- Product: [`extraction.pdf`](extraction.pdf)
- qpdf findings: [`qpdf-syntax.txt`](qpdf-syntax.txt)
- qpdf completed `--check` for the T75 product with exit code `0`.

This syntax chain does not establish PDF standards conformance.
