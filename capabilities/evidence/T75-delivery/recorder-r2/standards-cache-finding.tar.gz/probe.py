from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
ROOT=Path('/home/ubuntu/IdeaProjects/open-pdf');HERE=Path(__file__).resolve().parent
PRIOR=Path('/tmp/t75-syntax-standards-review-0z9bgvtq')
CP=Path('/tmp/t75-syntax-review-classpath.txt').read_text().strip()
ENV=dict(os.environ);ENV.pop('QPDF_CACHE_DIRECTORY',None)
JAVA=shutil.which('java');records=[]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
IDENTITY_PATHS=[ROOT/'scripts'/p for p in ['qpdf-pin.properties','container-bin/qpdf','t13-qpdf-runtime.sha256','t13-program-standards.py','t13-semantics.py']]
for name in ['T13EvidenceCommand','T13IndependentEvidence','QpdfSyntaxRecorder','QpdfSyntaxRecorder$Profile','QpdfPin','PinProperties','ExternalProcess','EvidenceFiles']:
 IDENTITY_PATHS.extend([ROOT/'pdf-acceptance/target/classes/net/zerocloud/pdf/acceptance'/(name+'.class')])
for name in ['T13EvidenceCommand','T13IndependentEvidence']:
 IDENTITY_PATHS.extend([ROOT/'pdf-acceptance/src/main/java/net/zerocloud/pdf/acceptance'/(name+'.java')])
IDENTITY_PATHS += [Path(JAVA).resolve(),ROOT/'.build-cache/qpdf/12.4.0/bin/qpdf']
for line in (ROOT/'scripts/t13-qpdf-runtime.sha256').read_text().splitlines():
 IDENTITY_PATHS.append(ROOT/'.build-cache/qpdf/12.4.0'/line.split('  ',1)[1])
identities={str(p):sha(p) for p in IDENTITY_PATHS}
(HERE/'identity-before.json').write_text(json.dumps({'classpath':CP,'files':identities,'probe-sha256':sha(Path(__file__))},indent=2)+'\n')

def clone(name,real_cache=True):
 root=HERE/name;(root/'scripts/container-bin').mkdir(parents=True);(root/'.build-cache').mkdir()
 for rel in ['scripts/qpdf-pin.properties','scripts/container-bin/qpdf','scripts/t13-qpdf-runtime.sha256']:
  shutil.copy2(ROOT/rel,root/rel)
 if real_cache:(root/'.build-cache/qpdf').symlink_to(ROOT/'.build-cache/qpdf',target_is_directory=True)
 return root

def substitute(cache):
 home=cache/'12.4.0';(home/'bin').mkdir(parents=True)
 exe=home/'bin/qpdf';exe.write_text('#!/bin/sh\nif [ "$1" = "--version" ]; then printf "qpdf version 12.4.0\\n"; else printf "INDEPENDENT SUBSTITUTE CHECKER RAN\\n"; fi\nexit 0\n');exe.chmod(0o755)
 for marker in ['.archive-sha256','.binary-sha256']:shutil.copy2(ROOT/'.build-cache/qpdf/12.4.0'/marker,home/marker)
 return cache

def run(label,pdf_source,root,cwd=ROOT,env=None,output=None,change=None):
 pdf=HERE/(label+'.pdf');shutil.copy2(pdf_source,pdf)
 out=output or HERE/(label+'-output');pin=root/'scripts/qpdf-pin.properties'
 command=[JAVA,'-cp',CP,'net.zerocloud.pdf.acceptance.T13EvidenceCommand','syntax',str(root),str(pdf),str(out),'test']
 row={'label':label,'command':command,'cwd':str(cwd),'QPDF_CACHE_DIRECTORY':(env or ENV).get('QPDF_CACHE_DIRECTORY'),'input_before':sha(pdf),'pin_before':sha(pin),'changed':False}
 start=time.monotonic()
 with (HERE/(label+'.stdout')).open('wb') as stdout,(HERE/(label+'.stderr')).open('wb') as stderr:
  proc=subprocess.Popen(command,stdout=stdout,stderr=stderr,env=env or ENV,cwd=cwd)
  if change:
   while proc.poll() is None and time.monotonic()-start<40:
    ids=set()
    for task in (Path('/proc')/str(proc.pid)/'task').glob('*'):
     try:ids.update((task/'children').read_text().split())
     except FileNotFoundError:pass
    for child in ids:
     try:args=(Path('/proc')/child/'cmdline').read_bytes().split(b'\0')
     except FileNotFoundError:continue
     if b'--check' in args and args[0].endswith(b'qpdf'):
      row['observed_child']={'pid':child,'command':[x.decode() for x in args if x]}
      if change=='pin':pin.write_bytes(pin.read_bytes()+b'\n# Independent after-start identity-change control\n')
      elif change=='input':pdf.write_bytes(b'%PDF-2.0\n1 0 obj\n')
      row['changed']=True;row['mutation_elapsed']=time.monotonic()-start;break
    if row['changed']:break
    time.sleep(.001)
  try:row['exit']=proc.wait(timeout=max(1,45-(time.monotonic()-start)))
  except subprocess.TimeoutExpired:proc.kill();row['exit']=proc.wait();row['timed_out']=True
 row.update(elapsed=time.monotonic()-start,pin_after=sha(pin),input_after=sha(pdf))
 prop=out/'result.properties'
 row['result']=dict(line.split('=',1) for line in prop.read_text().splitlines() if line and not line.startswith(('#','!'))) if prop.exists() else None
 row['files']={str(f.relative_to(out)):sha(f) for f in out.glob('*') if f.is_file()}
 row['output']=str(out);records.append(row)
 (HERE/(label+'-result.json')).write_text(json.dumps(row,indent=2)+'\n')
 print(label,row['exit'],row['result'].get('syntax') if row['result'] else None,'changed='+str(row['changed']),flush=True)

run('original',PRIOR/'original.pdf',ROOT)
run('truncated',PRIOR/'truncated.pdf',clone('genuine-clone'))
redirect=clone('redirected-clone');fake=substitute(HERE/'redirected-substitute-cache')
pin=redirect/'scripts/qpdf-pin.properties';pin.write_bytes(pin.read_bytes()+b'\nQPDF_CACHE_DIRECTORY='+str(fake).encode()+b'\n')
run('pin-redirect',PRIOR/'truncated.pdf',redirect)
run('after-pin-change',PRIOR/'post-tool-pin-change.pdf',clone('changing-clone'),change='pin')
run('after-input-change',PRIOR/'post-tool-pin-change.pdf',clone('input-clone'),change='input')
relative=HERE/'relative';(relative/'launcher').mkdir(parents=True);(relative/'substitute').mkdir()
(relative/'cache').symlink_to(ROOT/'.build-cache/qpdf',target_is_directory=True)
fake=substitute(relative/'substitute/cache');relative_root=clone('relative-root')
run('relative-cache',PRIOR/'truncated.pdf',relative_root,cwd=relative/'launcher',env=dict(ENV,QPDF_CACHE_DIRECTORY='../cache'),output=relative/'substitute/observation')
run('absolute-genuine-cache',PRIOR/'truncated.pdf',relative_root,cwd=relative/'launcher',env=dict(ENV,QPDF_CACHE_DIRECTORY=str(relative/'cache')))
run('absolute-substitute-cache',PRIOR/'truncated.pdf',relative_root,cwd=relative/'launcher',env=dict(ENV,QPDF_CACHE_DIRECTORY=str(fake)))
empty_root=clone('empty-root',real_cache=False);substitute(empty_root/'.build-cache/qpdf')
empty_cwd=HERE/'empty-launcher';empty_cwd.mkdir();(empty_cwd/'12.4.0').symlink_to(ROOT/'.build-cache/qpdf/12.4.0',target_is_directory=True)
run('empty-cache',PRIOR/'truncated.pdf',empty_root,cwd=empty_cwd,env=dict(ENV,QPDF_CACHE_DIRECTORY=''))
(HERE/'results.json').write_text(json.dumps(records,indent=2)+'\n')
after={str(p):sha(p) for p in IDENTITY_PATHS};(HERE/'identity-after.json').write_text(json.dumps(after,indent=2)+'\n')
print('Source/class/tool identities unchanged:',identities==after,flush=True)
