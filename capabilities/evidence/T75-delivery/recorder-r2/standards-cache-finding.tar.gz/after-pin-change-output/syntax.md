# T75 syntax observation

Input exact SHA-256: `35344c33fea055f5b0aa6caed579b105d6f2322ce0253caf107b9b1cfa7491b4`

Final determination: `indeterminate`

The qualified qpdf installation identity is unavailable or changed.

Raw qpdf result before final identity checks: `pass`

Original qpdf output: [findings](qpdf-syntax.txt), [tool record](qpdf-syntax.md).
