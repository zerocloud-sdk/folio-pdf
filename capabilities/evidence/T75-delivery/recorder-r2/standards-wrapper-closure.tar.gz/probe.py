from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time
ROOT=Path('/home/ubuntu/IdeaProjects/open-pdf');HERE=Path(__file__).resolve().parent;SNAP=HERE/'snapshot'
PRIOR=Path('/tmp/t75-syntax-standards-review-0z9bgvtq');G=ROOT/'.build-cache/qpdf'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
CP=Path('/tmp/t75-syntax-review-classpath.txt').read_text().strip();JAVA=shutil.which('java')
ENV=dict(os.environ);ENV.pop('QPDF_CACHE_DIRECTORY',None)
expected=json.loads((SNAP/'identities.json').read_text())
for name,identity in expected.items():assert sha(SNAP/name)==identity
for name in ['T13IndependentEvidence.java','T13EvidenceCommand.java']:
 assert sha(ROOT/'pdf-acceptance/src/main/java/net/zerocloud/pdf/acceptance'/name)==expected[name]
files=[p for p in SNAP.iterdir() if p.is_file()]+[Path(JAVA).resolve(),Path(sys.executable).resolve(),G/'12.4.0/bin/qpdf']
for name in ['T13IndependentEvidence','T13EvidenceCommand','QpdfSyntaxRecorder','QpdfSyntaxRecorder$Profile','QpdfPin','PinProperties','ExternalProcess','EvidenceFiles']:
 files.append(ROOT/'pdf-acceptance/target/classes/net/zerocloud/pdf/acceptance'/(name+'.class'))
for name in ['qpdf-pin.properties','container-bin/qpdf','t13-qpdf-runtime.sha256']:files.append(ROOT/'scripts'/name)
for line in (ROOT/'scripts/t13-qpdf-runtime.sha256').read_text().splitlines():files.append(G/'12.4.0'/line.split('  ',1)[1])
identity={str(p):sha(p) for p in files}
(HERE/'identity-before.json').write_text(json.dumps({'classpath':CP,'files':identity,'driver-sha256':sha(Path(__file__))},indent=2)+'\n')
for name in ['original.pdf','truncated.pdf','post-tool-pin-change.pdf']:shutil.copy2(PRIOR/name,HERE/name)
json_command=[str(ROOT/'scripts/container-bin/qpdf'),'--json=2','--json-stream-data=inline','--decode-level=all',str(HERE/'original.pdf')]
with (HERE/'original-qpdf.json').open('wb') as stdout,(HERE/'original-qpdf.stderr').open('wb') as stderr:
 proc=subprocess.run(json_command,env=ENV,stdout=stdout,stderr=stderr,timeout=30)
assert proc.returncode==0 and (HERE/'original-qpdf.stderr').stat().st_size==0
fake=HERE/'substitute-cache/12.4.0';(fake/'bin').mkdir(parents=True)
exe=fake/'bin/qpdf';exe.write_text('#!/bin/sh\nprintf "invoked\\n" >> '+str(HERE/'substitute-invocations.txt')+'\nif [ "$1" = "--version" ]; then printf "qpdf version 12.4.0\\n"; elif [ "$1" = "--check" ]; then printf "INDEPENDENT SUBSTITUTE CHECKER RAN\\n"; else cat '+str(HERE/'original-qpdf.json')+'; fi\n');exe.chmod(0o755)
for marker in ['.archive-sha256','.binary-sha256']:shutil.copy2(G/'12.4.0'/marker,fake/marker)

def roots(label,kind,changed_pin=False):
 root=HERE/(label+'-root');alt=HERE/(label+'-alternate')
 for place,cache in [(root,G),(alt,fake.parent)]:
  (place/'scripts/container-bin').mkdir(parents=True);(place/'.build-cache').mkdir()
  (place/'.build-cache/qpdf').symlink_to(cache,target_is_directory=True)
  for name in ['qpdf-pin.properties','container-bin/qpdf','t13-qpdf-runtime.sha256']:shutil.copy2(ROOT/'scripts'/name,place/'scripts'/name)
 for name in ['corpus.json','fixtures/nested-split-type3.pdf']:
  dest=root/'capabilities/profiles/T13-text'/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/'capabilities/profiles/T13-text'/name,dest)
 wrapper=root/'scripts/container-bin/qpdf';wrapper.unlink()
 if kind=='file':wrapper.symlink_to(alt/'scripts/container-bin/qpdf')
 else:
  wrapper.parent.rmdir();wrapper.parent.symlink_to(alt/'scripts/container-bin',target_is_directory=True)
 if changed_pin:
  pin=alt/'scripts/qpdf-pin.properties';pin.write_bytes(pin.read_bytes()+b'QPDF_CACHE_DIRECTORY='+str(fake.parent).encode()+b'\n')
 return root

rows=[]
def run(label,root,chain,pdf,cache=None,change_loaded_pin=False):
 out=HERE/(label+'-'+chain+'-output');wrapper=root/'scripts/container-bin/qpdf';pin=root/'scripts/qpdf-pin.properties';loaded=wrapper.parent/'..'/'qpdf-pin.properties'
 if chain=='syntax':command=[JAVA,'-cp',CP,'net.zerocloud.pdf.acceptance.T13EvidenceCommand','syntax',str(root),str(pdf),str(out),'test']
 else:
  script,scope=('t13-program-standards.py','cmaps') if chain=='standards' else ('t13-semantics.py','nested-split-type3')
  command=[sys.executable,str(SNAP/script),str(root),str(pdf),scope,str(out)]
 env=dict(ENV)
 if cache is not None:env['QPDF_CACHE_DIRECTORY']=cache
 row={'label':label,'chain':chain,'command':command,'cwd':str(HERE),'QPDF_CACHE_DIRECTORY':cache,'input-sha256':sha(pdf),'outer-pin-before':sha(pin),'loaded-pin-before':sha(loaded),'loaded-pin-realpath':str(loaded.resolve()),'wrapper-realpath':str(wrapper.resolve()),'changed':False}
 started=time.monotonic()
 with (HERE/(label+'-'+chain+'.stdout')).open('wb') as stdout,(HERE/(label+'-'+chain+'.stderr')).open('wb') as stderr:
  process=subprocess.Popen(command,cwd=HERE,env=env,stdout=stdout,stderr=stderr)
  if change_loaded_pin:
   while process.poll() is None and time.monotonic()-started<40:
    ids=set()
    for task in (Path('/proc')/str(process.pid)/'task').glob('*'):
     try:ids.update((task/'children').read_text().split())
     except FileNotFoundError:pass
    for child in ids:
     try:args=(Path('/proc')/child/'cmdline').read_bytes().split(b'\0')
     except FileNotFoundError:continue
     if b'--check' in args and args[0].endswith(b'qpdf'):
      loaded.write_bytes(loaded.read_bytes()+b'\n# Independent live loaded-pin identity control\n')
      row['changed']=True;row['child-command']=[a.decode() for a in args if a];row['mutation-elapsed']=time.monotonic()-started;break
    if row['changed']:break
    time.sleep(.001)
  try:row['exit']=process.wait(timeout=max(1,45-(time.monotonic()-started)))
  except subprocess.TimeoutExpired:process.kill();row['exit']=process.wait();row['timeout']=True
 row['elapsed']=time.monotonic()-started;row['outer-pin-after']=sha(pin);row['loaded-pin-after']=sha(loaded)
 p=out/'result.properties';row['result']=dict(line.split('=',1) for line in p.read_text().splitlines() if line and not line.startswith(('#','!'))) if p.exists() else None
 row['files']={str(p.relative_to(out)):sha(p) for p in out.iterdir() if p.is_file()} if out.exists() else {};rows.append(row)
 (HERE/(label+'-'+chain+'-result.json')).write_text(json.dumps(row,indent=2)+'\n')
 print(label,chain,row['exit'],row['result'].get(chain) if row['result'] else None,'changed='+str(row['changed']),flush=True)

for kind in ['file','directory']:
 for label,pdf in [('truncated',HERE/'truncated.pdf'),('positive',HERE/'original.pdf')]:
  name=kind+'-'+label;root=roots(name,kind)
  for chain in ['syntax','standards','semantic']:run(name,root,chain,pdf,cache='')
root=roots('loaded-pin-redirect','directory',changed_pin=True)
for chain in ['syntax','standards','semantic']:run('loaded-pin-redirect',root,chain,HERE/'truncated.pdf',cache=str(G))
root=roots('loaded-pin-after-check','directory')
run('loaded-pin-after-check',root,'syntax',HERE/'post-tool-pin-change.pdf',change_loaded_pin=True)
after={str(p):sha(p) for p in files}
(HERE/'identity-after.json').write_text(json.dumps(after,indent=2)+'\n')
(HERE/'results.json').write_text(json.dumps({'source-json-command':json_command,'results':rows,'identities-unchanged':identity==after,'substitute-invoked':(HERE/'substitute-invocations.txt').exists()},indent=2)+'\n')
print('Source/class/runtime identities unchanged:',identity==after,'substitute invoked:',(HERE/'substitute-invocations.txt').exists(),flush=True)
