# Independent bounded closure: qpdf wrapper symlink identity

This directory retains 16 public CLI observations for only the wrapper file-link, directory-link and actual sourced-pin identity increment. No repository source or compiled target was edited and no Maven command was run.

The two Python observers were copied unchanged from the parent freeze /tmp/t75-qpdf-wrapper-identity-freeze-nd011uo3 into snapshot/. Their SHA values were checked against identities.json before execution. Java used the existing public T13EvidenceCommand classpath /tmp/t75-syntax-review-classpath.txt and frozen compiled target. The two Java source snapshots match the repository sources checked before the run. identity-before.json/identity-after.json retain script, class, Java/Python executable, wrapper, pin, qpdf binary and all 11 declared library identities.

## Literal results

- Wrapper file symlink to an alternate installation with substitute default cache: original source PASS for syntax, standards and semantic. Truncated PDF syntax FAIL; standards and semantic INDETERMINATE.
- Wrapper directory symlink with the same qualified pin and a substitute alternate default cache: same six outcomes. These controls show that the original invocation path retains its logical default cache instead of resolving the wrapper file to a different installation.
- Wrapper directory symlink with an unqualified actual sourced pin redirecting QPDF_CACHE_DIRECTORY, while the outer pin stays original and the caller explicitly selects the genuine absolute cache: all three entrypoints INDETERMINATE.
- During genuine qpdf --check of the original large flat PDF, append a comment only to the actual sourced pin reached through the directory link. Java final syntax INDETERMINATE; outer pin unchanged; raw qpdf-syntax.txt/md retained with the original raw PASS and stdout/stderr. Final syntax.txt/md and result.properties agree.

The independent substitute checker logs every invocation; its invocation file was never created in any case. Every process exited normally, under the independent 45-second deadline. All input identities match the public records and all checked frozen code/classes/runtime bytes remained unchanged.

## Reproduction and provenance

probe.py contains all original setup and exact public CLI launch logic. results.json and individual result JSON files retain command argument arrays, cwd/cache configuration, input hashes, wrapper target, actual pin target and before/after identities. Every output directory retains the public properties and original reports. validation.txt records literal outcome assertions. The original source qpdf graph capture command/output is retained solely for the substitute negative control.

The legal project-owned original Source and independently authored malformed and large flat PDFs were copied unchanged from /tmp/t75-syntax-standards-review-0z9bgvtq. All synthetic installations, symlinks and substitute checker code were independently authored only within this temporary directory.

No documented-standard defect or actionable smell remains in this bounded cache/symlink increment. This is not a final T13/#75 whole-task gate.
