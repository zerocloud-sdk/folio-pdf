from pathlib import Path
import hashlib,json,os,re,shutil,struct,subprocess,tempfile
repo=Path('/home/ubuntu/IdeaProjects/open-pdf')
base=Path(tempfile.mkdtemp(prefix='t75-spec-syntax.'))
cp=Path('/tmp/t75-syntax-review-classpath.txt').read_text().strip()
(base/'classpath.txt').write_text(cp)
shutil.copy2(__file__,base/'probe.py')
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def identities():
    paths=[repo/'scripts/qpdf-pin.properties',repo/'scripts/container-bin/qpdf',repo/'.build-cache/qpdf/12.4.0/bin/qpdf',repo/'.build-cache/qpdf/12.4.0/lib/libqpdf.so.30.4.0']
    for name in ['T13IndependentEvidence','T13EvidenceCommand','QpdfSyntaxRecorder','QpdfPin','ExternalProcess','PinProperties','EvidenceFiles']:
        paths += [repo/'pdf-acceptance/src/main/java/net/zerocloud/pdf/acceptance'/f'{name}.java', repo/'pdf-acceptance/target/classes/net/zerocloud/pdf/acceptance'/f'{name}.class']
    return {str(p):sha(p) for p in paths}
before=identities(); (base/'identities-before.json').write_text(json.dumps(before,indent=2))
(base/'java-version.txt').write_text(subprocess.run(['java','-version'],capture_output=True,text=True).stderr)
inputs=base/'inputs'; inputs.mkdir(); output=base/'observations';output.mkdir()
products=['nested-split-type3','marked-structure','embedded-font-kinds','embedded-font-inheritance','uncertain-geometry']
for name in products:shutil.copy2(repo/'capabilities/profiles/T13-text/fixtures'/f'{name}.pdf',inputs/f'{name}.pdf')
(inputs/'truncated.pdf').write_bytes(b'%PDF-2.0\n1 0 obj\n')
data=(inputs/'nested-split-type3.pdf').read_bytes()
warn=re.sub(rb'(startxref\s*)\d+',lambda m:m[1]+b'0',data)
assert warn!=data
(inputs/'bad-startxref.pdf').write_bytes(warn)
rows=[]
def run(name,pdf,root=repo,env=None,expected=None):
    out=output/name
    cmd=['java','-cp',cp,'net.zerocloud.pdf.acceptance.T13EvidenceCommand','syntax',str(root),str(pdf),str(out),'test']
    proc=subprocess.run(cmd,capture_output=True,text=True,env=env,timeout=45)
    log=base/(name+'.command.json');log.write_text(json.dumps({'argv':cmd,'environment-overrides':{k:env.get(k) for k in ['QPDF_CACHE_DIRECTORY','LD_LIBRARY_PATH','LD_PRELOAD'] if env is not None and env.get(k)},'input-sha256':sha(pdf),'exit-code':proc.returncode},indent=2))
    (base/(name+'.stdout.txt')).write_text(proc.stdout);(base/(name+'.stderr.txt')).write_text(proc.stderr)
    props={}
    if (out/'result.properties').exists():
        for line in (out/'result.properties').read_text().splitlines():
            if '=' in line and not line.startswith('#'):
                k,v=line.split('=',1);props[k]=v
    row={'case':name,'expected':expected,'result':props.get('syntax'),'exit-code':proc.returncode,'input':str(pdf),'input-sha256':sha(pdf),'output':str(out),'properties':props}
    rows.append(row);print(json.dumps(row),flush=True)
    return row
for name in products:run(name,inputs/f'{name}.pdf',expected='pass')
run('truncated',inputs/'truncated.pdf',expected='fail')
run('bad-startxref',inputs/'bad-startxref.pdf',expected='fail')
def rootcopy(name):
    r=base/name;(r/'scripts/container-bin').mkdir(parents=True)
    shutil.copy2(repo/'scripts/qpdf-pin.properties',r/'scripts/qpdf-pin.properties')
    shutil.copy2(repo/'scripts/container-bin/qpdf',r/'scripts/container-bin/qpdf')
    (r/'.build-cache').mkdir();(r/'.build-cache/qpdf').symlink_to(repo/'.build-cache/qpdf',target_is_directory=True)
    return r
r=rootcopy('substitute-root');(r/'scripts/container-bin/qpdf').write_text("#!/bin/sh\nprintf 'qpdf version 12.4.0\\n'\n");run('substitute-wrapper',inputs/'truncated.pdf',root=r,expected='indeterminate')
r=rootcopy('missing-wrapper-root');(r/'scripts/container-bin/qpdf').unlink();run('missing-wrapper',inputs/'truncated.pdf',root=r,expected='indeterminate')
r=rootcopy('wrong-version-root');pin=r/'scripts/qpdf-pin.properties';pin.write_text(pin.read_text().replace('QPDF_VERSION=12.4.0','QPDF_VERSION=12.4.1'));run('wrong-version',inputs/'truncated.pdf',root=r,expected='indeterminate')
# Independent cache copy: the pinned main executable and wrapper remain byte-identical.
cache=base/'altered-library-cache';shutil.copytree(repo/'.build-cache/qpdf/12.4.0',cache/'12.4.0',symlinks=True)
lib=cache/'12.4.0/lib/libqpdf.so.30.4.0';raw=bytearray(lib.read_bytes());patches=[]
# Resolve the two public exported symbols via ELF tools, convert virtual addresses to file offsets.
nm=subprocess.run(['nm','-D',str(lib)],capture_output=True,text=True,check=True).stdout
phoff=struct.unpack_from('<Q',raw,32)[0];phsize=struct.unpack_from('<H',raw,54)[0];phnum=struct.unpack_from('<H',raw,56)[0]
segments=[]
for i in range(phnum):
    typ,flags,off,vaddr,paddr,size,mem,align=struct.unpack_from('<IIQQQQQQ',raw,phoff+i*phsize)
    if typ==1:segments.append((off,vaddr,size))
for symbol,replacement in [('_ZN7QPDFJob3runEv',bytes.fromhex('f30f1efac3')),('_ZNK7QPDFJob11getExitCodeEv',bytes.fromhex('f30f1efa31c0c3'))]:
    match=re.search(r'^([0-9a-f]+) T '+re.escape(symbol)+r'@@',nm,re.M);assert match,symbol
    address=int(match[1],16);offset=next(off+address-vaddr for off,vaddr,size in segments if vaddr<=address<vaddr+size)
    patches.append({'symbol':symbol,'offset':offset,'before':raw[offset:offset+len(replacement)].hex(),'after':replacement.hex()});raw[offset:offset+len(replacement)]=replacement
lib.write_bytes(raw)
env=os.environ.copy();env['QPDF_CACHE_DIRECTORY']=str(cache)
(base/'library-substitution.json').write_text(json.dumps({'patches':patches,'original-library-sha256':sha(repo/'.build-cache/qpdf/12.4.0/lib/libqpdf.so.30.4.0'),'substitute-library-sha256':sha(lib),'original-main-sha256':sha(repo/'.build-cache/qpdf/12.4.0/bin/qpdf'),'substitute-main-sha256':sha(cache/'12.4.0/bin/qpdf')},indent=2))
for name,args in [('version',['--version']),('truncated-check',['--check',str(inputs/'truncated.pdf')])]:
    cmd=[str(repo/'scripts/container-bin/qpdf')]+args;p=subprocess.run(cmd,env=env,capture_output=True,text=True,timeout=20)
    (base/(name+'.direct.json')).write_text(json.dumps({'argv':cmd,'environment-overrides':{'QPDF_CACHE_DIRECTORY':str(cache)},'exit-code':p.returncode,'stdout':p.stdout,'stderr':p.stderr},indent=2))
run('altered-library',inputs/'truncated.pdf',env=env,expected='indeterminate')
after=identities();(base/'identities-after.json').write_text(json.dumps(after,indent=2))
summary={'directory':str(base),'identity-unchanged':before==after,'rows':rows}
(base/'summary.json').write_text(json.dumps(summary,indent=2));print(str(base),flush=True)
