# T75 qpdf syntax evidence

Capability: `document.text-structure.extract`

Acceptance Profile: `T13-text-logical-structure`

Profile record: `capabilities/evidence/T13-text-logical-structure.md`

Release train: `test`

Chain: `syntax`

Result: `fail`

Producer kind: `external-tool`

Producer: `qpdf`

Producer version: `12.4.0`

Tool distribution SHA-256: `a3bca240f3bb61efdc3a90be89d1da4ed5e125326c3458c4e62df53ff4f153e3`

Input exact SHA-256: `1e195892f5f36151345f5c5c229f5b2b5cf6f7ae410a89148fc3dd43503e8474`

Input hash policy: `SHA-256 of the exact unmodified PDF bytes`

Final determination: `fail`

## Findings and artifact

- Product: [`extraction.pdf`](extraction.pdf)
- qpdf findings: [`syntax.txt`](syntax.txt)
- qpdf reported warnings or errors for a T75 product.

This syntax chain does not establish PDF standards conformance.
