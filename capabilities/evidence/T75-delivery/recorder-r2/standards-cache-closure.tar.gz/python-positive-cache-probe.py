from pathlib import Path
import hashlib,json,os,subprocess,sys,time
ROOT=Path('/home/ubuntu/IdeaProjects/open-pdf');HERE=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pdf=HERE/'original.pdf';cwd=HERE/'empty-launcher';records=[]
files=[ROOT/'scripts/t13-program-standards.py',ROOT/'scripts/t13-semantics.py',ROOT/'scripts/qpdf-pin.properties',ROOT/'scripts/container-bin/qpdf',ROOT/'scripts/t13-qpdf-runtime.sha256',pdf,Path(sys.executable).resolve()]
identities={str(p):sha(p) for p in files}
for script,scope,field in [('t13-program-standards.py','cmaps','standards'),('t13-semantics.py','nested-split-type3','semantic')]:
 for label,cache in [('empty',''),('relative','.')]:
  out=HERE/(script.replace('.py','')+'-genuine-'+label+'-output')
  args=[sys.executable,str(ROOT/'scripts'/script),str(ROOT),str(pdf),scope,str(out)]
  started=time.monotonic()
  with (HERE/(out.name+'.stdout')).open('wb') as stdout,(HERE/(out.name+'.stderr')).open('wb') as stderr:
   observed=subprocess.run(args,cwd=cwd,env=dict(os.environ,QPDF_CACHE_DIRECTORY=cache),stdout=stdout,stderr=stderr,timeout=45)
  result=dict(line.split('=',1) for line in (out/'result.properties').read_text().splitlines() if line and not line.startswith(('#','!')))
  row={'command':args,'cwd':str(cwd),'QPDF_CACHE_DIRECTORY':cache,'exit':observed.returncode,'elapsed':time.monotonic()-started,'result':result,'files':{str(p.relative_to(out)):sha(p) for p in out.iterdir() if p.is_file()}};records.append(row)
  print(script,label,observed.returncode,result[field],flush=True)
after={str(p):sha(p) for p in files}
(HERE/'python-positive-cache-result.json').write_text(json.dumps({'probe-sha256':sha(Path(__file__)),'identities-before':identities,'identities-after':after,'identities-unchanged':identities==after,'results':records},indent=2)+'\n')
print('Identities unchanged:',identities==after)
