# Independent closure: qpdf cache-selection identity

The immediately preceding Java relative/empty cache and Python empty cache false-PASS controls were replayed through the public CLIs, with no source edits or shared build actions. All 16 CLI processes exited normally. Each process had an independent 45-second timeout.

## Results

- Java original legal source: PASS.
- Original Java relative-cache substitute and empty-cache substitute controls: both INDETERMINATE.
- Absolute genuine cache with the original malformed truncated PDF: FAIL; absolute substitute: INDETERMINATE.
- Java genuine empty/default cache, genuine relative cache and relative cache under a symlinked output parent: all PASS on the original legal PDF.
- Both original Python empty-cache substitute-graph controls: INDETERMINATE. Their absolute genuine cache malformed-input controls remain INDETERMINATE.
- Both Python observers with genuine empty/default and relative cache values: all PASS on the original legal PDF.

The concrete tool-selection finding is closed. Java now resolves relative cache paths using the actual child output working directory and matches the wrapper's empty/default handling. Python matches the wrapper's empty/default handling while sharing cwd with its subprocess. The symlink output-parent control directly exercises Java toRealPath behavior. No new documented-standard defect or actionable heuristic smell was found in this bounded path-selection increment.

## Reproduction and artifacts

probe.py contains the independently authored Java public CLI driver. results.json and per-case JSON retain literal argument arrays, cwd, QPDF_CACHE_DIRECTORY, return codes, exact input/report hashes and observations. identity-before.json and identity-after.json bind Java sources/classes, Python scripts, the actual Java executable, qpdf binary, wrapper, pin and all 11 runtime manifest paths. Java source/class/tool identities remained unchanged.

python-empty-cache-probe.py replays the original two-observer empty-value controls; python-empty-cache-result.json retains commands, exact input/output identities, copied corpus authorities, real qpdf graph capture command and script/Python identities. python-positive-cache-probe.py and its result JSON retain the corresponding real-tool positive controls. Both scripts' checked identities remained unchanged.

Every output directory retains the public result.properties and all emitted raw files. All eight Java final syntax.md and syntax.txt reports agree with result.properties. validation.txt records literal outcome and input-hash assertions.

The project-owned original legal PDF and the independently authored malformed truncated PDF were copied unchanged from the retained original review /tmp/t75-syntax-standards-review-0z9bgvtq. Synthetic shell checkers and cache arrangements are original independent controls. The substitute graph is retained actual qpdf output from the genuine Source and is used only as a negative tool-selection control.

This closes only the reported cache-selection finding and its direct path-semantics neighbors. It is not a final T13/#75 whole-task review.
