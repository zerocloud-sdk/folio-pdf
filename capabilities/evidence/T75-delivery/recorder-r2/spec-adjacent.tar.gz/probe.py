from pathlib import Path
import hashlib,json,os,shutil,subprocess,tempfile,time
repo=Path('/home/ubuntu/IdeaProjects/open-pdf');prior=Path('/tmp/t75-spec-syntax.1b1oszsj')
base=Path(tempfile.mkdtemp(prefix='t75-spec-syntax-adjacent.'));shutil.copy2(__file__,base/'probe.py')
cp=Path('/tmp/t75-syntax-review-classpath.txt').read_text().strip();(base/'classpath.txt').write_text(cp)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def identity():return {str(p):sha(p) for p in [repo/'pdf-acceptance/target/classes/net/zerocloud/pdf/acceptance/T13IndependentEvidence.class',repo/'pdf-acceptance/target/classes/net/zerocloud/pdf/acceptance/T13EvidenceCommand.class',repo/'pdf-acceptance/src/main/java/net/zerocloud/pdf/acceptance/T13IndependentEvidence.java',repo/'scripts/qpdf-pin.properties',repo/'scripts/container-bin/qpdf',repo/'.build-cache/qpdf/12.4.0/bin/qpdf',repo/'.build-cache/qpdf/12.4.0/lib/libqpdf.so.30.4.0']}
ids=identity();(base/'identities-before.json').write_text(json.dumps(ids,indent=2));rows=[]
inputs=base/'inputs';inputs.mkdir();shutil.copy2(prior/'inputs/truncated.pdf',inputs/'truncated.pdf');shutil.copy2(prior/'inputs/nested-split-type3.pdf',inputs/'valid.pdf')
def rootcopy(name):
    r=base/name;(r/'scripts/container-bin').mkdir(parents=True)
    shutil.copy2(repo/'scripts/qpdf-pin.properties',r/'scripts/qpdf-pin.properties');shutil.copy2(repo/'scripts/container-bin/qpdf',r/'scripts/container-bin/qpdf')
    (r/'.build-cache').mkdir();(r/'.build-cache/qpdf').symlink_to(repo/'.build-cache/qpdf',target_is_directory=True)
    return r

def start(name,pdf,root=repo):
    out=base/name;cmd=['java','-cp',cp,'net.zerocloud.pdf.acceptance.T13EvidenceCommand','syntax',str(root),str(pdf),str(out),'test']
    proc=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
    return out,cmd,proc

def finish(name,pdf,out,cmd,proc):
    stdout,stderr=proc.communicate(timeout=45);(base/(name+'.stdout.txt')).write_text(stdout);(base/(name+'.stderr.txt')).write_text(stderr)
    props={}
    if (out/'result.properties').exists():
        for line in (out/'result.properties').read_text().splitlines():
            if '=' in line and not line.startswith('#'):
                k,v=line.split('=',1);props[k]=v
    record=(out/'syntax.md').read_text() if (out/'syntax.md').exists() else None
    row={'case':name,'argv':cmd,'exit-code':proc.returncode,'properties':props,'record-pass':record is not None and 'Final determination: `pass`' in record,'input-final-sha256':sha(pdf),'observed-final-sha256':sha(out/'extraction.pdf') if (out/'extraction.pdf').exists() else None}
    rows.append(row);(base/(name+'.command.json')).write_text(json.dumps(row,indent=2));print(json.dumps(row),flush=True)
    return row

# Properties-loader and shell-source must refer to the same executable; unknown shell keys currently alter it.
r=rootcopy('pin-cache-override-root');cache=base/'substitute-cache/12.4.0';(cache/'bin').mkdir(parents=True)
fake=cache/'bin/qpdf';fake.write_text("#!/bin/sh\nif [ \"$1\" = --version ]; then printf 'qpdf version 12.4.0\\n'; fi\nexit 0\n");fake.chmod(0o755)
for n in ['.archive-sha256','.binary-sha256']:shutil.copy2(repo/'.build-cache/qpdf/12.4.0'/n,cache/n)
pin=r/'scripts/qpdf-pin.properties';pin.write_text(pin.read_text()+'QPDF_CACHE_DIRECTORY='+str(cache.parent)+'\n')
(base/'substitute-tool.json').write_text(json.dumps({'checked-binary-sha256':sha(repo/'.build-cache/qpdf/12.4.0/bin/qpdf'),'executed-tool-sha256':sha(fake),'wrapper-sha256':sha(r/'scripts/container-bin/qpdf'),'pin-sha256':sha(pin)},indent=2))
out,cmd,p=start('pin-cache-override',inputs/'truncated.pdf',r);finish('pin-cache-override',inputs/'truncated.pdf',out,cmd,p)

# Race the source only after the observed snapshot has been copied, leaving the original observation intact.
pdf=inputs/'source-changed.pdf';shutil.copy2(inputs/'valid.pdf',pdf);initial=sha(pdf);out,cmd,p=start('source-changed',pdf)
changed=False;deadline=time.monotonic()+10
while p.poll() is None and time.monotonic()<deadline:
    copied=out/'extraction.pdf'
    if copied.exists() and copied.stat().st_size==pdf.stat().st_size:
        pdf.write_bytes((inputs/'truncated.pdf').read_bytes());changed=True;break
    time.sleep(.0001)
row=finish('source-changed',pdf,out,cmd,p);row['changed-after-copy']=changed;row['input-before-sha256']=initial

# Mutate retained observed artifact at the record write boundary, before the final SHA guards finish.
pdf=inputs/'artifact-changed.pdf';shutil.copy2(inputs/'valid.pdf',pdf);out,cmd,p=start('artifact-changed',pdf)
changed=False;deadline=time.monotonic()+10
while p.poll() is None and time.monotonic()<deadline:
    record=out/'syntax.md'
    if record.exists() and record.stat().st_size>0:
        (out/'extraction.pdf').write_bytes((inputs/'truncated.pdf').read_bytes());changed=True;break
    time.sleep(.00001)
row=finish('artifact-changed',pdf,out,cmd,p);row['changed-after-record']=changed

after=identity();(base/'identities-after.json').write_text(json.dumps(after,indent=2));(base/'summary.json').write_text(json.dumps({'directory':str(base),'identity-unchanged':ids==after,'rows':rows},indent=2));print(str(base),flush=True)
