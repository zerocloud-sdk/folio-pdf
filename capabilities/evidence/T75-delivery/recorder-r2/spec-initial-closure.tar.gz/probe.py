from pathlib import Path
import hashlib,json,os,re,shutil,struct,subprocess,sys,tempfile,time,zipfile
repo=Path('/home/ubuntu/IdeaProjects/open-pdf');prior=Path('/tmp/t75-spec-syntax.1b1oszsj');adjacent=Path('/tmp/t75-spec-syntax-adjacent.w2tnza_a')
base=Path(tempfile.mkdtemp(prefix='t75-spec-syntax-closure.'));shutil.copy2(__file__,base/'probe.py')
cp=Path('/tmp/t75-syntax-review-classpath.txt').read_text().strip();(base/'classpath.txt').write_text(cp)
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def identities():
    paths=[repo/'scripts'/p for p in ['qpdf-pin.properties','container-bin/qpdf','t13-qpdf-runtime.sha256','t13-program-standards.py','t13-semantics.py']]
    paths.extend(repo/'pdf-acceptance'/kind/'net/zerocloud/pdf/acceptance'/f'{n}.{suffix}' for kind,suffix in [('src/main/java','java'),('target/classes','class')] for n in ['T13IndependentEvidence','T13EvidenceCommand','QpdfSyntaxRecorder'])
    paths.extend([repo/'.build-cache/qpdf/12.4.0/bin/qpdf',repo/'.build-cache/qpdf/12.4.0/lib/libqpdf.so.30.4.0'])
    return {str(p):sha(p) for p in paths}
ids=identities();(base/'identities-before.json').write_text(json.dumps(ids,indent=2));saved=base/'observer-identity';saved.mkdir()
for p,h in ids.items():
    if Path(p).suffix in ('.java','.class','.py','.sha256','.properties'):shutil.copy2(p,saved/Path(p).name)
inputs=base/'inputs';shutil.copytree(prior/'inputs',inputs)
outputs=base/'observations';outputs.mkdir();rows=[]
# Independently verify the manifest against the exact original release archive.
archive=Path('/tmp/t75-qpdf-runtime-origin.zip');archive_sha=sha(archive);assert archive_sha=='a3bca240f3bb61efdc3a90be89d1da4ed5e125326c3458c4e62df53ff4f153e3'
manifest=repo/'scripts/t13-qpdf-runtime.sha256';checks=[]
with zipfile.ZipFile(archive) as z:
    assert z.read('lib/libqpdf.so.30')==b'libqpdf.so.30.4.0'
    for line in manifest.read_text().splitlines():
        expected,name=line.split('  ',1);entry='lib/libqpdf.so.30.4.0' if name=='lib/libqpdf.so.30' else name
        observed=hashlib.sha256(z.read(entry)).hexdigest();assert observed==expected
        checks.append({'path':name,'archive-entry':entry,'sha256':observed})
(base/'manifest-origin-check.json').write_text(json.dumps({'archive':str(archive),'archive-sha256':archive_sha,'manifest-sha256':sha(manifest),'entries':checks},indent=2))

def parsed(out):
    p=out/'result.properties'
    return dict(line.split('=',1) for line in p.read_text().splitlines() if '=' in line and not line.startswith('#')) if p.exists() else {}

def execute(name,kind,pdf,root=repo,env=None,mutation=None,script=None,scope=None,expected=None):
    out=outputs/name
    if kind=='java':cmd=['java','-cp',cp,'net.zerocloud.pdf.acceptance.T13EvidenceCommand','syntax',str(root),str(pdf),str(out),'test'];key='syntax'
    else:cmd=[sys.executable,str(script),str(root),str(pdf),scope,str(out)];key='standards' if kind=='program' else 'semantic'
    info={'case':name,'argv':cmd,'input-before-sha256':sha(pdf),'expected':expected,'environment-overrides':{k:env[k] for k in ['QPDF_CACHE_DIRECTORY','FOLIO_FONTTOOLS_WHEEL'] if env is not None and k in env}}
    p=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,env=env)
    if mutation is not None:info['mutation']=mutation(p,out)
    stdout,stderr=p.communicate(timeout=50);info.update({'exit-code':p.returncode,'properties':parsed(out),'input-after-sha256':sha(pdf),'output':str(out)})
    info['result']=info['properties'].get(key);info['matched']=info['result']==expected
    if kind=='java':
        for filename in ['syntax.md','syntax.txt','qpdf-syntax.md','qpdf-syntax.txt']:
            record=(out/filename).read_text() if (out/filename).exists() else None
            m=re.search(r'Final determination: `([^`]+)`',record or '')
            info[filename+'-final']=m[1] if m else None
        info['consistent-final-records']=info['syntax.md-final']==info['syntax.txt-final']==info['result']
        info['retained-after-sha256']=sha(out/'extraction.pdf') if (out/'extraction.pdf').exists() else None
    (base/(name+'.stdout.txt')).write_text(stdout);(base/(name+'.stderr.txt')).write_text(stderr);(base/(name+'.command.json')).write_text(json.dumps(info,indent=2));rows.append(info)
    print(json.dumps({k:info.get(k) for k in ['case','result','expected','matched','consistent-final-records','mutation']}),flush=True)
    return info

for name in ['nested-split-type3','marked-structure','embedded-font-kinds','embedded-font-inheritance','uncertain-geometry']:
    execute('java-'+name,'java',inputs/f'{name}.pdf',expected='pass')
for name in ['truncated','bad-startxref']:execute('java-'+name,'java',inputs/f'{name}.pdf',expected='fail')
env=os.environ.copy();env['QPDF_CACHE_DIRECTORY']=str(prior/'altered-library-cache')
execute('java-original-library-substitution','java',inputs/'truncated.pdf',env=env,expected='indeterminate')
redirect=base/'original-pin-redirect-root';shutil.copytree(adjacent/'pin-cache-override-root',redirect,symlinks=True);shutil.copy2(manifest,redirect/'scripts/t13-qpdf-runtime.sha256')
execute('java-original-pin-redirect','java',inputs/'truncated.pdf',root=redirect,expected='indeterminate')

def wait_file(p,path,predicate=lambda p:p.stat().st_size>0):
    deadline=time.monotonic()+10
    while p.poll() is None and time.monotonic()<deadline:
        try:
            if path.is_file() and predicate(path):return True
        except OSError:pass
        time.sleep(.00005)
    return False
for kind in ['source','retained-artifact']:
    pdf=inputs/(kind+'-changes.pdf');shutil.copy2(inputs/'nested-split-type3.pdf',pdf)
    def mutate(p,out,kind=kind,pdf=pdf):
        trigger=out/('extraction.pdf' if kind=='source' else 'qpdf-syntax.md')
        ready=wait_file(p,trigger,(lambda q:q.stat().st_size==pdf.stat().st_size) if kind=='source' else lambda q:q.stat().st_size>0)
        target=pdf if kind=='source' else out/'extraction.pdf'
        result={'trigger':str(trigger),'triggered-while-running':ready,'target':str(target)}
        if ready:result['before-sha256']=sha(target);target.write_bytes((inputs/'truncated.pdf').read_bytes());result['after-sha256']=sha(target)
        return result
    execute('java-'+kind+'-changes','java',pdf,mutation=mutate,expected='indeterminate')

# Each Python observer is invoked through its CLI, with no import of implementation code.
for kind,scriptname,scope in [('program','t13-program-standards.py','fonts'),('semantic','t13-semantics.py','embedded-font-kinds')]:
    execute(kind+'-baseline',kind,inputs/'embedded-font-kinds.pdf',script=repo/'scripts'/scriptname,scope=scope,expected='pass')
    execute(kind+'-original-library-substitution',kind,inputs/'embedded-font-kinds.pdf',script=repo/'scripts'/scriptname,scope=scope,env=env,expected='indeterminate')
# Add current corpus to the retained pin-redirect probe without changing its original pin or substitute tool.
shutil.copytree(repo/'capabilities/profiles/T13-text',redirect/'capabilities/profiles/T13-text')
for kind,scriptname,scope in [('program','t13-program-standards.py','cmaps'),('semantic','t13-semantics.py','embedded-font-kinds')]:
    execute(kind+'-original-pin-redirect',kind,inputs/'embedded-font-kinds.pdf',root=redirect,script=repo/'scripts'/scriptname,scope=scope,expected='indeterminate')

# Isolated genuine installation for changes made only after initial tool validation.
staged=base/'changing-tools-root';(staged/'scripts/container-bin').mkdir(parents=True)
for f in ['qpdf-pin.properties','container-bin/qpdf','t13-qpdf-runtime.sha256','t13-program-standards.py','t13-semantics.py']:shutil.copy2(repo/'scripts'/f,staged/'scripts'/f)
shutil.copytree(repo/'capabilities/profiles/T13-text',staged/'capabilities/profiles/T13-text')
shutil.copytree(repo/'.build-cache/qpdf/12.4.0',staged/'.build-cache/qpdf/12.4.0',symlinks=True)
wheel=repo/'.build-cache/t75-fonttools-4.59.2/fonttools-4.59.2-py3-none-any.whl'
penv=os.environ.copy();penv.pop('QPDF_CACHE_DIRECTORY',None);penv['FOLIO_FONTTOOLS_WHEEL']=str(wheel)

def build_id_change(data):
    raw=bytearray(data);start=struct.unpack_from('<Q',raw,32)[0];size,count=struct.unpack_from('<HH',raw,54)
    for i in range(count):
        typ,flags,off,va,pa,n,mem,align=struct.unpack_from('<IIQQQQQQ',raw,start+i*size)
        if typ!=4:continue
        cursor=off
        while cursor+12<=off+n:
            ns,vs,nt=struct.unpack_from('<III',raw,cursor);value=cursor+12+((ns+3)//4)*4
            if nt==3 and raw[cursor+12:cursor+12+ns]==b'GNU\0':raw[value]^=1;return bytes(raw),value
            cursor=value+((vs+3)//4)*4
    raise AssertionError('GNU build ID not found')

for kind,scriptname,scope in [('program','t13-program-standards.py','fonts'),('semantic','t13-semantics.py','embedded-font-kinds')]:
    for target_kind in ['pin','wrapper','binary','library','observer']:
        paths={'pin':staged/'scripts/qpdf-pin.properties','wrapper':staged/'scripts/container-bin/qpdf','binary':staged/'.build-cache/qpdf/12.4.0/bin/qpdf','library':staged/'.build-cache/qpdf/12.4.0/lib/libqpdf.so.30.4.0','observer':staged/'scripts'/scriptname}
        target=paths[target_kind];old=target.read_bytes();mode=target.stat().st_mode
        if target_kind in ['binary','library']:new,offset=build_id_change(old)
        else:new=old+b'\n# Independent identity probe after initial tool check.\n';offset=len(old)
        def mutate(p,out,target=target,new=new,old=old,offset=offset,mode=mode):
            trigger=out/'qpdf-version.txt';ready=wait_file(p,trigger)
            result={'trigger':str(trigger),'triggered-while-running':ready,'target':str(target),'offset':offset,'before-sha256':hashlib.sha256(old).hexdigest(),'after-sha256':hashlib.sha256(new).hexdigest()}
            if ready:
                temp=target.with_name(target.name+'.review-change');temp.write_bytes(new);temp.chmod(mode);temp.replace(target)
            return result
        try:execute(kind+'-end-'+target_kind,kind,inputs/'embedded-font-kinds.pdf',root=staged,script=staged/'scripts'/scriptname,scope=scope,env=penv,mutation=mutate,expected='indeterminate')
        finally:
            target.write_bytes(old);target.chmod(mode)

after=identities();(base/'identities-after.json').write_text(json.dumps(after,indent=2));summary={'directory':str(base),'identity-unchanged':ids==after,'rows':rows};(base/'summary.json').write_text(json.dumps(summary,indent=2))
print(str(base),flush=True)
