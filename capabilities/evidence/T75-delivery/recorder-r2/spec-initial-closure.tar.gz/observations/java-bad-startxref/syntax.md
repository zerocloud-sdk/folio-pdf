# T75 syntax observation

Input exact SHA-256: `1e195892f5f36151345f5c5c229f5b2b5cf6f7ae410a89148fc3dd43503e8474`

Final determination: `fail`

The qpdf observation retains its final input and tool identity checks.

Raw qpdf result before final identity checks: `fail`

Original qpdf output: [findings](qpdf-syntax.txt), [tool record](qpdf-syntax.md).
