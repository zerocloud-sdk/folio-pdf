from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,tempfile
repo=Path('/home/ubuntu/IdeaProjects/open-pdf');base=Path(tempfile.mkdtemp(prefix='t75-spec-cache-selection.'));shutil.copy2(__file__,base/'probe.py')
cp=Path('/tmp/t75-syntax-review-classpath.txt').read_text().strip();(base/'classpath.txt').write_text(cp)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def identities():
    paths=[repo/'scripts'/f for f in ['qpdf-pin.properties','container-bin/qpdf','t13-qpdf-runtime.sha256','t13-program-standards.py','t13-semantics.py']]
    paths += [repo/'pdf-acceptance'/kind/'net/zerocloud/pdf/acceptance'/f'{n}.{ext}' for kind,ext in [('src/main/java','java'),('target/classes','class')] for n in ['T13IndependentEvidence','T13EvidenceCommand']]
    return {str(p):sha(p) for p in paths}
ids=identities();(base/'identities-before.json').write_text(json.dumps(ids,indent=2));(base/'observer-identity').mkdir()
for p,h in ids.items():shutil.copy2(p,base/'observer-identity'/Path(p).name)
inputs=base/'inputs';inputs.mkdir();original=inputs/'embedded-font-kinds.pdf';shutil.copy2(repo/'capabilities/profiles/T13-text/fixtures/embedded-font-kinds.pdf',original)
truncated=inputs/'truncated.pdf';shutil.copy2('/tmp/t75-spec-syntax.1b1oszsj/inputs/truncated.pdf',truncated)
genuine=repo/'.build-cache/qpdf';fakecache=base/'fake-cache';fakeversion=fakecache/'12.4.0';(fakeversion/'bin').mkdir(parents=True)
fake=fakeversion/'bin/qpdf';fake.write_text('#!/usr/bin/python3\nimport os,sys\nargs=sys.argv[1:]\nif args and args[-1].endswith(".pdf"): args[-1]='+repr(str(original))+'\nos.environ["QPDF_CACHE_DIRECTORY"]='+repr(str(genuine))+'\nexe='+repr(str(repo/'scripts/container-bin/qpdf'))+'\nos.execv(exe,[exe]+args)\n');fake.chmod(0o755)
for name in ['.archive-sha256','.binary-sha256']:shutil.copy2(genuine/'12.4.0'/name,fakeversion/name)
def stage(name,cache):
    r=base/name;(r/'scripts/container-bin').mkdir(parents=True)
    for f in ['qpdf-pin.properties','container-bin/qpdf','t13-qpdf-runtime.sha256']:shutil.copy2(repo/'scripts'/f,r/'scripts'/f)
    (r/'.build-cache').mkdir();(r/'.build-cache/qpdf').symlink_to(cache,target_is_directory=True)
    return r
root=stage('checked-root',genuine);shutil.copytree(repo/'capabilities/profiles/T13-text',root/'capabilities/profiles/T13-text')
other=stage('wrapper-owner-root',fakecache)
launcher=base/'launcher';launcher.mkdir();(launcher/' cache ').symlink_to(genuine,target_is_directory=True);(launcher/'relative-cache').symlink_to(genuine,target_is_directory=True)
outputs=base/'observations';outputs.mkdir();rows=[]
def observe(name,kind,pdf,cache,expected,out=None,cwd=launcher):
    out=out or outputs/name
    env=os.environ.copy();env.pop('QPDF_CACHE_DIRECTORY',None)
    if cache is not None:env['QPDF_CACHE_DIRECTORY']=cache
    if kind=='java':cmd=['java','-cp',cp,'net.zerocloud.pdf.acceptance.T13EvidenceCommand','syntax',str(root),str(pdf),str(out),'test'];key='syntax'
    else:
        script='t13-program-standards.py' if kind=='program' else 't13-semantics.py';scope='cmaps' if kind=='program' else 'embedded-font-kinds';key='standards' if kind=='program' else 'semantic';cmd=[sys.executable,str(repo/'scripts'/script),str(root),str(pdf),scope,str(out)]
    p=subprocess.run(cmd,cwd=cwd,env=env,capture_output=True,text=True,timeout=45)
    props=dict(line.split('=',1) for line in (out/'result.properties').read_text().splitlines() if '=' in line and not line.startswith('#')) if (out/'result.properties').exists() else {}
    row={'case':name,'argv':cmd,'cwd':str(cwd),'cache-environment':cache,'expected':expected,'result':props.get(key),'exit-code':p.returncode,'input-sha256':sha(pdf),'properties':props,'output':str(out),'matched':props.get(key)==expected}
    rows.append(row);(base/(name+'.command.json')).write_text(json.dumps(row,indent=2));(base/(name+'.stdout.txt')).write_text(p.stdout);(base/(name+'.stderr.txt')).write_text(p.stderr);print(json.dumps({k:row[k] for k in ['case','expected','result','matched']}),flush=True)
for kind in ['java','program','semantic']:
    for label,cache in [('unset',None),('empty',''),('absolute',str(genuine))]:observe(kind+'-'+label,kind,original,cache,'pass')
    if kind=='java':
        # A future output directory's relative parent cache is distinct from the launcher's cache.
        (outputs/'cache with spaces').symlink_to(genuine,target_is_directory=True)
        cache='../cache with spaces'
    else:cache=' cache '
    observe(kind+'-spaces-relative',kind,original,cache,'pass')
    observe(kind+'-relative-missing',kind,truncated,'missing-cache','indeterminate')
# Symlinked output parent: ../cache belongs to the real process directory.
physical=base/'physical-output';physical.mkdir();(physical/'cache').symlink_to(genuine,target_is_directory=True)
logical=base/'logical-output';logical.mkdir();(logical/'cache').symlink_to(fakecache,target_is_directory=True)
(logical/'link').symlink_to(physical,target_is_directory=True)
observe('java-symlink-output-cwd','java',original,'../cache','pass',out=logical/'link/result')
# Equivalent wrapper bytes, but semantics resolves the wrapper symlink before execution.
wrapper=root/'scripts/container-bin/qpdf';wrapper.unlink();wrapper.symlink_to(other/'scripts/container-bin/qpdf')
(base/'wrapper-cache-layout.json').write_text(json.dumps({'checked-root':str(root),'checked-default-cache':str(genuine),'wrapper-argument':str(wrapper),'resolved-wrapper':str(wrapper.resolve()),'resolved-wrapper-default-cache':str(fakecache),'wrapper-sha256':sha(wrapper),'genuine-main-sha256':sha(genuine/'12.4.0/bin/qpdf'),'substitute-main-sha256':sha(fake)},indent=2))
for kind,expected in [('java','fail'),('program','indeterminate'),('semantic','indeterminate')]:
    for label,cache in [('unset',None),('empty','')]:observe(kind+'-linked-wrapper-'+label,kind,truncated,cache,expected)
# Explicit absolute selection removes the two wrapper roots' differing defaults.
observe('semantic-linked-wrapper-explicit-cache','semantic',truncated,str(genuine),'indeterminate')
after=identities();(base/'identities-after.json').write_text(json.dumps(after,indent=2));(base/'summary.json').write_text(json.dumps({'directory':str(base),'identity-unchanged':ids==after,'rows':rows},indent=2));print(str(base),flush=True)
