from pathlib import Path
from io import BytesIO
import hashlib,json,re,subprocess,sys,time
ROOT=Path('/home/ubuntu/IdeaProjects/open-pdf');HERE=Path(__file__).resolve().parent
SCRIPT=ROOT/'scripts/t13-program-standards.py';WHEEL=ROOT/'.build-cache/t75-fonttools-4.59.2/fonttools-4.59.2-py3-none-any.whl'
assert hashlib.sha256(WHEEL.read_bytes()).hexdigest()=='8bd0f759020e87bb5d323e6283914d9bf4ae35a7307dafb2cbd1e379e720ad37'
sys.path.insert(0,str(WHEEL))
from fontTools.ttLib import TTFont
ORIGINAL=(ROOT/'capabilities/profiles/T13-text/fixtures/embedded-font-kinds.pdf').read_bytes()
OBSERVER_SHA=hashlib.sha256(SCRIPT.read_bytes()).hexdigest()
def objects():
    matches=re.findall(rb'(?m)^([0-9]+) 0 obj\n(.*?)\nendobj\n',ORIGINAL,re.S)
    assert [int(n) for n,b in matches]==list(range(1,26));return [b for n,b in matches]
def serialize(parts):
    data=bytearray(b'%PDF-2.0\n');offsets=[0]
    for n,body in enumerate(parts,1):
        offsets.append(len(data));data.extend(str(n).encode()+b' 0 obj\n'+body+b'\nendobj\n')
    xref=len(data);data.extend(b'xref\n0 '+str(len(offsets)).encode()+b'\n0000000000 65535 f \n')
    for off in offsets[1:]:data.extend(('%010d 00000 n \n'%off).encode())
    data.extend(b'trailer\n<< /Size '+str(len(offsets)).encode()+b' /Root 1 0 R >>\nstartxref\n'+str(xref).encode()+b'\n%%EOF\n');return bytes(data)
def replace_font(parts,number,fontbytes):
    encoded=fontbytes.hex().encode()+b'>\n'
    parts[number-1]=b'<< /Length1 '+str(len(fontbytes)).encode()+b' /Filter /ASCIIHexDecode /Length '+str(len(encoded)).encode()+b' >>\nstream\n'+encoded+b'endstream'
def cid_widths(limit):
    parts=objects();assert parts[20].count(b'/W [1 [500]]')==1
    parts[20]=parts[20].replace(b'/W [1 [500]]',('/W [0 '+str(limit-1)+' 500]').encode());return serialize(parts)
def cid_selection(swap):
    parts=objects()
    with TTFont(ROOT/'capabilities/profiles/T13-fonts/FolioT13RectangleCID.ttf') as font:
        font.recalcTimestamp=False;font['hmtx'].metrics['.notdef']=(400,0);font['hmtx'].metrics['A']=(500,0)
        font['post'].isFixedPitch=0;output=BytesIO();font.save(output)
    replace_font(parts,25,output.getvalue());parts[14]=parts[14].replace(b'/Flags 5',b'/Flags 4')
    if swap:parts[20]=parts[20].replace(b'/W [1 [500]]',b'/W [1 [400]]')
    else:parts[20]=parts[20].replace(b'/DW 500',b'/DW 400')
    return serialize(parts)
def fractional_width():
    parts=objects()
    with TTFont(ROOT/'capabilities/profiles/T13-fonts/FolioT13Rectangle.ttf') as font:
        font.recalcTimestamp=False;font['head'].unitsPerEm=1250
        for name in font.getGlyphOrder():font['hmtx'].metrics[name]=(503,0)
        font['hhea'].advanceWidthMax=503;font['OS/2'].xAvgCharWidth=503
        output=BytesIO();font.save(output)
    replace_font(parts,23,output.getvalue())
    parts[6]=parts[6].replace(b'/Widths [500]',b'/Widths [402.4]')
    parts[12]=parts[12].replace(b'/FontBBox [0 0 400 600]',b'/FontBBox [0 0 320 480]').replace(b'/Ascent 600',b'/Ascent 480').replace(b'/CapHeight 600',b'/CapHeight 480').replace(b'/StemV 400',b'/StemV 320')
    return serialize(parts)
def oversized_integer():
    parts=objects();parts[6]=parts[6].replace(b'/Widths [500]',b'/Widths ['+b'1'+b'0'*309+b']');return serialize(parts)
variants=[('original',ORIGINAL),('cid-distinct-glyph-widths',cid_selection(False)),('cid-wrong-glyph-widths',cid_selection(True)),('cid-4096-widths',cid_widths(4096)),('cid-4097-widths',cid_widths(4097)),('exact-fractional-truetype-width',fractional_width()),('oversized-integer-width',oversized_integer())]
records=[]
for label,data in variants:
    pdf=HERE/(label+'.pdf');pdf.write_bytes(data);out=HERE/label
    cmd=[sys.executable,str(SCRIPT),str(ROOT),str(pdf),'font-metrics',str(out)]
    start=time.monotonic();proc=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=40)
    (HERE/(label+'.stdout')).write_bytes(proc.stdout);(HERE/(label+'.stderr')).write_bytes(proc.stderr)
    props=out/'result.properties';values=dict(line.split('=',1) for line in props.read_text().splitlines()) if props.exists() else None
    if values:
        assert values['input-sha256']==hashlib.sha256(data).hexdigest() and values['observer-sha256']==OBSERVER_SHA
        if 'qpdf-json-sha256' in values:
            assert values['qpdf-json-sha256']==hashlib.sha256((out/'qpdf.json').read_bytes()).hexdigest()
    row=dict(label=label,command=cmd,exit=proc.returncode,elapsed=round(time.monotonic()-start,3),input_sha256=hashlib.sha256(data).hexdigest(),observer_sha256=OBSERVER_SHA,result=values,stderr=proc.stderr.decode())
    records.append(row);print(json.dumps(row),flush=True)
assert OBSERVER_SHA==hashlib.sha256(SCRIPT.read_bytes()).hexdigest()
(HERE/'results.json').write_text(json.dumps(records,indent=2)+'\n')
