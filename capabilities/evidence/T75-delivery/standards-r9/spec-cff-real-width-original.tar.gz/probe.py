from pathlib import Path
import re,struct,tempfile,json,subprocess,hashlib,shutil
ROOT=Path('/home/ubuntu/IdeaProjects/open-pdf');OBSERVER=ROOT/'scripts/t13-program-standards.py';DEST=Path(tempfile.mkdtemp(prefix='t75-spec-cff-decimal-width.'));shutil.copyfile(OBSERVER,DEST/'observer.py');shutil.copyfile(__file__,DEST/'probe.py')
ORIGINAL=(ROOT/'capabilities/profiles/T13-text/fixtures/embedded-font-kinds.pdf').read_bytes();OBJECTS={int(m[1]):m[2]for m in re.finditer(rb'(?m)^(\d+) 0 obj\n(.*?)\nendobj\n',ORIGINAL,re.S)};assert len(OBJECTS)==25

def integer(value):return b'\x1d'+struct.pack('>i',value)
def real(text):
 n=[10 if c=='.' else int(c)for c in text]+[15]
 if len(n)%2:n.append(15)
 return b'\x1e'+bytes(n[i]*16+n[i+1]for i in range(0,len(n),2))
def index(entries):
 if not entries:return b'\0\0'
 offsets=[1]
 for entry in entries:offsets.append(offsets[-1]+len(entry))
 width=1 if offsets[-1]<256 else 2
 return len(entries).to_bytes(2,'big')+bytes([width])+b''.join(offset.to_bytes(width,'big')for offset in offsets)+b''.join(entries)
def font(cid,field,width):
 names=index([b'FolioT13RectangleCID' if cid else b'FolioT13RectangleCFF']);strings=index([b'Folio',b'T13'])if cid else index([]);gsubrs=index([]);charset=bytes.fromhex('000001'if cid else '000022');fdselect=b'\0\0\0'
 if field=='default':private=real(width)+b'\x14';glyph=bytes.fromhex('8b16f824f8ecfc24060e')
 else:private=integer(500)+b'\x14'+real(width)+b'\x15';glyph=bytes.fromhex('8b8b16f824f8ecfc24060e')
 charstrings=index([b'\x0e',glyph])
 def top(offsets):
  r=integer(391)+integer(392)+integer(0)+bytes([12,30])if cid else b'';r+=b''.join(integer(v)for v in(0,0,400,600))+b'\x05'
  if cid:r+=integer(2)+bytes([12,34])+integer(offsets['fdselect'])+bytes([12,37])+integer(offsets['fdarray'])+bytes([12,36])
  else:r+=integer(len(private))+integer(offsets['private'])+b'\x12'
  return r+integer(offsets['charset'])+b'\x0f'+integer(offsets['charstrings'])+b'\x11'
 offsets=dict.fromkeys(('charset','charstrings','private','fdselect','fdarray'),0);cursor=4+len(names)+len(index([top(offsets)]))+len(strings)+len(gsubrs);offsets['charset']=cursor;cursor+=len(charset)
 if cid:offsets['fdselect']=cursor;cursor+=len(fdselect)
 offsets['charstrings']=cursor;cursor+=len(charstrings);offsets['private']=cursor;cursor+=len(private);offsets['fdarray']=cursor;fdarray=index([integer(len(private))+integer(offsets['private'])+b'\x12'])
 return bytes.fromhex('01000404')+names+index([top(offsets)])+strings+gsubrs+charset+(fdselect if cid else b'')+charstrings+private+(fdarray if cid else b'')
def serial(objects):
 data=bytearray(b'%PDF-1.7\n%\xe2\xe3\xcf\xd3\n');offsets=[0]
 for i in range(1,len(objects)+1):offsets.append(len(data));data+=str(i).encode()+b' 0 obj\n'+objects[i]+b'\nendobj\n'
 cursor=len(data);data+=b'xref\n0 '+str(len(objects)+1).encode()+b'\n0000000000 65535 f \n'
 for offset in offsets[1:]:data+=f'{offset:010d} 00000 n \n'.encode()
 return bytes(data)+b'trailer\n<< /Size '+str(len(objects)+1).encode()+b' /Root 1 0 R >>\nstartxref\n'+str(cursor).encode()+b'\n%%EOF\n'
cases=[]
for cid in (False,True):
 for field in ('default','nominal'):
  for width,pdfwidth in (('500.1','500.1'),('500.1','500.2'),('500.5','500.5')):
   objects=dict(OBJECTS);program=font(cid,field,width);encoded=program.hex().encode()+b'>';number=24 if cid else 22;subtype=b'CIDFontType0C'if cid else b'Type1C';objects[number]=b'<< /Length '+str(len(encoded)).encode()+b' /Filter /ASCIIHexDecode /Subtype /'+subtype+b' >>\nstream\n'+encoded+b'\nendstream'
   if cid:
    w=(b'/W [0 ['+pdfwidth.encode()+b' '+pdfwidth.encode()+b']]')if field=='default'else(b'/W [1 ['+pdfwidth.encode()+b']]');objects[18]=objects[18].replace(b'/W [1 [500]]',w)
   else:
    for f in(5,6):objects[f]=objects[f].replace(b'/Widths [500]',b'/Widths ['+pdfwidth.encode()+b']')
   label=('cidcff-'if cid else 'cff-')+field+'-'+width+'-pdf-'+pdfwidth;pdf=DEST/(label+'.pdf');pdf.write_bytes(serial(objects));(DEST/(label+'.cff')).write_bytes(program);command=['python3',str(OBSERVER),str(ROOT),str(pdf),'font-metrics',str(DEST/label)];p=subprocess.run(command,capture_output=True,timeout=25);(DEST/(label+'.stdout')).write_bytes(p.stdout);(DEST/(label+'.stderr')).write_bytes(p.stderr);record=dict(l.split('=',1)for l in(DEST/label/'result.properties').read_text().splitlines());cases.append({'case':label,'command':command,'program-sha256':hashlib.sha256(program).hexdigest(),'expected':'pass'if width==pdfwidth else 'fail','exit':p.returncode,**record})
summary={'observer-sha256':hashlib.sha256((DEST/'observer.py').read_bytes()).hexdigest(),'observer-unchanged':OBSERVER.read_bytes()==(DEST/'observer.py').read_bytes(),'cases':cases};(DEST/'summary.json').write_text(json.dumps(summary,indent=2));print(DEST);print(json.dumps([{k:c[k]for k in('case','expected','standards','finding')}for c in cases],indent=2))
