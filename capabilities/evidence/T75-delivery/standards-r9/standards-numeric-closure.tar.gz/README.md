# Numerical font-bounds incremental closure

Scope is only the prior width/TrueType FontBBox numerical findings and the explicit polygon-only acceptance boundary. No product edits, Maven invocation, or full-font-compliance review was performed.

Seven actual public CLI observations passed their independent expected outcomes:
- Exact polygon FontBBox xmax320.8: PASS.
- Same font, xmax321: PASS.
- Same font, too-small xmax320.7: FAIL font-descriptor-bounds.
- Original width402.4: PASS.
- Neighboring wrong widths402.3 and402.5: FAIL font-widths.
- Fixed original off-curve fixture (SHA a37b0de37ddf90d776135c4c548026ce0276d518490f2a91466a3e7dbf246cda): INDETERMINATE, explicitly Curved TrueType outside exact polygon qualification.

The original boundary/width PDFs are copied byte-for-byte from /tmp/t75-font-metric-numeric-closure-pwhk9dp9. The smaller rectangle is a same-length single literal replacement. The curve PDF is copied byte-for-byte from the fixed repository fixture after checking its SHA. probe.py imports neither product nor observer nor fixture authoring code; it only invokes the public CLI.

All seven invocations return0 and publish complete result.properties. results.jsonl/results.json retain exact commands, outcomes, timings, input/observer/Python/qpdf identities and stderr. The checker hash is constant across the run and checked again afterwards. Every qpdf JSON identity is verified. identity.json binds the probe and result record; raw per-input qpdf and result files are retained.

The implementation checks declared glyph coordinate bounds, explicitly rejects any off-curve flag, and draws the remaining polygons using Fraction scaling. The too-small-box negative confirms that precise containment validation remains active. The original numerical hard finding and prior metric_program duplication judgement are closed. The review separately notified the parent to synchronize README with the new polygon-only boundary; that documentation update is not a new numerical implementation defect.

Reproduce with any retained PDF and a fresh output path, or copy probe.py into a fresh directory and run it. This receipt is incremental only, not whole T13 certification.
