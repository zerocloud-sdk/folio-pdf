from pathlib import Path
import hashlib,json,subprocess,sys,time
ROOT=Path('/home/ubuntu/IdeaProjects/open-pdf');HERE=Path(__file__).resolve().parent
OLD=Path('/tmp/t75-font-metric-numeric-closure-pwhk9dp9');SCRIPT=ROOT/'scripts/t13-program-standards.py'
sha=hashlib.sha256(SCRIPT.read_bytes()).hexdigest()
variants=[]
for label,expected in [('bbox-exact-320.8','pass'),('bbox-margin-321','pass'),('exact-fractional-truetype-width','pass'),('width-too-small','fail'),('width-too-large','fail')]:
 variants.append((label,(OLD/(label+'.pdf')).read_bytes(),'font-metrics',expected))
base=(OLD/'bbox-exact-320.8.pdf').read_bytes();assert base.count(b'/FontBBox [0 0 320.8 480]')==1
variants.append(('bbox-too-small-320.7',base.replace(b'/FontBBox [0 0 320.8 480]',b'/FontBBox [0 0 320.7 480]'),'font-metrics','fail'))
curve=(ROOT/'capabilities/profiles/T13-standards/review-fixtures/ttf-offcurve-bbox-legal.pdf').read_bytes()
assert hashlib.sha256(curve).hexdigest()=='a37b0de37ddf90d776135c4c548026ce0276d518490f2a91466a3e7dbf246cda'
variants.append(('ttf-offcurve-bbox-legal',curve,'fonts','indeterminate'))
records=[]
for label,data,scope,expected in variants:
 pdf=HERE/(label+'.pdf');pdf.write_bytes(data);out=HERE/label
 cmd=[sys.executable,str(SCRIPT),str(ROOT),str(pdf),scope,str(out)]
 start=time.monotonic();proc=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=40)
 (HERE/(label+'.stdout')).write_bytes(proc.stdout);(HERE/(label+'.stderr')).write_bytes(proc.stderr)
 props=out/'result.properties';values=dict(line.split('=',1) for line in props.read_text().splitlines()) if props.exists() else None
 record=dict(label=label,command=cmd,exit=proc.returncode,elapsed=round(time.monotonic()-start,3),expected=expected,result=values,stderr=proc.stderr.decode())
 records.append(record)
 with (HERE/'results.jsonl').open('a') as dest:dest.write(json.dumps(record)+'\n')
 print(label,proc.returncode,values.get('standards') if values else None,flush=True)
 assert proc.returncode==0 and values['standards']==expected
 assert values['input-sha256']==hashlib.sha256(data).hexdigest() and values['observer-sha256']==sha
 assert values['qpdf-json-sha256']==hashlib.sha256((out/'qpdf.json').read_bytes()).hexdigest()
 if label=='ttf-offcurve-bbox-legal':assert 'Curved TrueType' in values['finding']
assert hashlib.sha256(SCRIPT.read_bytes()).hexdigest()==sha
(HERE/'results.json').write_text(json.dumps(records,indent=2)+'\n')
(HERE/'identity.json').write_text(json.dumps({'observer-sha256':sha,'probe-sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'results-sha256':hashlib.sha256((HERE/'results.json').read_bytes()).hexdigest()},indent=2)+'\n')
