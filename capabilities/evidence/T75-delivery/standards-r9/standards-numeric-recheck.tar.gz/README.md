# Width closure and adjacent TrueType FontBBox probe

This evidence concerns only the numerical width correction, the metric_program extraction and the requested adjacent TrueType FontBBox risk. It is not full font or T13 qualification. No repository edits or Maven commands were performed.

All seven original probe PDFs from /tmp/t75-font-metrics-review-k4fhtke4 were copied byte-for-byte and rerun through the public CLI. The original unitsPerEm1250 / advance503 / PDF Widths402.4 case now passes. Two neighboring PDF-only changes to402.3 and402.5 both fail font-widths. Other original controls retain their expected results. The shared descriptor/FontFile validation is now centralized in metric_program, closing the prior Duplicated Code judgement.

The requested adjacent risk remains: bbox-exact-320.8.pdf starts from the same corrected fractional-width fixture. Independent fontTools TTFont authoring changes rectangle xmax400 to401, preserves unitsPerEm1250 and width503, and regenerates the font header/table/whole-file checksums. PDF FontBBox becomes[0 0 320.8 480]; corresponding StemV is adjusted. Exact arithmetic gives401*1000/1250=1604/5=320.8. The pinned API instead produces binary float320.80000000000001136868377216160297393798828125. The Decimal boundary comparison rejects this legal box. The same font with only FontBBox xmax321 passes.

bbox-measurement.json records coordinates read back from the actual qpdf-decoded FontFile2, exact fractional arithmetic and the binary value. The expected value derives from the original authored rectangle and units ratio, not from copying checker output.

All11 actual CLI calls return0 and publish result.properties, with input/checker/Python/qpdf identities checked. results.jsonl/results.json preserve exact commands, results, return codes and timings. Per-label subdirectories preserve raw qpdf output. identity.json binds the evidence. To reproduce, invoke the public CLI on a retained PDF with a fresh output path, or copy probe.py into a fresh directory and run it.

Normative basis: ISO32000-1 9.2.4 (1000-unit PDF glyph space) and Table122 FontBBox (encloses glyph shapes); OpenType head.unitsPerEm/hmtx describe font design units. Source: https://developer.adobe.com/document-services/docs/assets/35e4369068f86065372c18787171a17e/PDF_ISO_32000-1.pdf and https://learn.microsoft.com/en-us/typography/opentype/spec/head .
