from pathlib import Path
from io import BytesIO
import hashlib,json,re,subprocess,sys,time
ROOT=Path('/home/ubuntu/IdeaProjects/open-pdf');HERE=Path(__file__).resolve().parent
OLD=Path('/tmp/t75-font-metrics-review-k4fhtke4');SCRIPT=ROOT/'scripts/t13-program-standards.py'
WHEEL=ROOT/'.build-cache/t75-fonttools-4.59.2/fonttools-4.59.2-py3-none-any.whl'
assert hashlib.sha256(WHEEL.read_bytes()).hexdigest()=='8bd0f759020e87bb5d323e6283914d9bf4ae35a7307dafb2cbd1e379e720ad37'
sys.path.insert(0,str(WHEEL))
from fontTools.ttLib import TTFont
OBSERVER_SHA=hashlib.sha256(SCRIPT.read_bytes()).hexdigest()
BASE=(OLD/'exact-fractional-truetype-width.pdf').read_bytes()
def serialize(parts):
    data=bytearray(b'%PDF-2.0\n');offsets=[0]
    for n,body in enumerate(parts,1):
        offsets.append(len(data));data.extend(str(n).encode()+b' 0 obj\n'+body+b'\nendobj\n')
    xref=len(data);data.extend(b'xref\n0 '+str(len(offsets)).encode()+b'\n0000000000 65535 f \n')
    for off in offsets[1:]:data.extend(('%010d 00000 n \n'%off).encode())
    data.extend(b'trailer\n<< /Size '+str(len(offsets)).encode()+b' /Root 1 0 R >>\nstartxref\n'+str(xref).encode()+b'\n%%EOF\n');return bytes(data)
def bbox_variant(margin):
    matches=re.findall(rb'(?m)^([0-9]+) 0 obj\n(.*?)\nendobj\n',BASE,re.S)
    assert [int(n) for n,b in matches]==list(range(1,26));parts=[b for n,b in matches]
    encoded=parts[22].split(b'\nstream\n')[1].split(b'\nendstream')[0].strip()
    assert encoded.endswith(b'>')
    with TTFont(BytesIO(bytes.fromhex(encoded[:-1].decode()))) as font:
        font.recalcTimestamp=False;glyph=font['glyf']['A']
        assert list(glyph.coordinates)==[(0,0),(400,0),(400,600),(0,600)]
        for index,(x,y) in enumerate(glyph.coordinates):
            glyph.coordinates[index]=(401 if x==400 else x,y)
        glyph.recalcBounds(font['glyf']);assert glyph.xMax==401
        output=BytesIO();font.save(output)
    fontbytes=output.getvalue();encoded=fontbytes.hex().encode()+b'>\n'
    parts[22]=b'<< /Length1 '+str(len(fontbytes)).encode()+b' /Filter /ASCIIHexDecode /Length '+str(len(encoded)).encode()+b' >>\nstream\n'+encoded+b'endstream'
    assert parts[12].count(b'/FontBBox [0 0 320 480]')==1
    parts[12]=parts[12].replace(b'/FontBBox [0 0 320 480]',b'/FontBBox [0 0 '+(b'321' if margin else b'320.8')+b' 480]')
    parts[12]=parts[12].replace(b'/StemV 320',b'/StemV 320.8')
    return serialize(parts)
labels=['original','cid-distinct-glyph-widths','cid-wrong-glyph-widths','cid-4096-widths','cid-4097-widths','exact-fractional-truetype-width','oversized-integer-width']
variants=[(label,(OLD/(label+'.pdf')).read_bytes()) for label in labels]
assert BASE.count(b'/Widths [402.4]')==1
variants += [('width-too-small',BASE.replace(b'/Widths [402.4]',b'/Widths [402.3]')),('width-too-large',BASE.replace(b'/Widths [402.4]',b'/Widths [402.5]')),('bbox-exact-320.8',bbox_variant(False)),('bbox-margin-321',bbox_variant(True))]
records=[]
for label,data in variants:
    pdf=HERE/(label+'.pdf');pdf.write_bytes(data);out=HERE/label
    cmd=[sys.executable,str(SCRIPT),str(ROOT),str(pdf),'font-metrics',str(out)]
    start=time.monotonic();proc=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=40)
    (HERE/(label+'.stdout')).write_bytes(proc.stdout);(HERE/(label+'.stderr')).write_bytes(proc.stderr)
    props=out/'result.properties';values=dict(line.split('=',1) for line in props.read_text().splitlines()) if props.exists() else None
    if values:
        assert values['input-sha256']==hashlib.sha256(data).hexdigest() and values['observer-sha256']==OBSERVER_SHA
        if 'qpdf-json-sha256' in values:assert values['qpdf-json-sha256']==hashlib.sha256((out/'qpdf.json').read_bytes()).hexdigest()
    row=dict(label=label,command=cmd,exit=proc.returncode,elapsed=round(time.monotonic()-start,3),input_sha256=hashlib.sha256(data).hexdigest(),observer_sha256=OBSERVER_SHA,result=values,stderr=proc.stderr.decode())
    records.append(row);print(json.dumps(row),flush=True)
    with (HERE/'results.jsonl').open('a') as destination:destination.write(json.dumps(row)+'\n')
assert OBSERVER_SHA==hashlib.sha256(SCRIPT.read_bytes()).hexdigest()
(HERE/'results.json').write_text(json.dumps(records,indent=2)+'\n')
