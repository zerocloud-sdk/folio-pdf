from pathlib import Path
import re,struct,json,tempfile,subprocess,hashlib,shutil
ROOT=Path('/home/ubuntu/IdeaProjects/open-pdf'); OBSERVER=ROOT/'scripts/t13-program-standards.py'; DEST=Path(tempfile.mkdtemp(prefix='t75-spec-font-metrics.')); shutil.copyfile(OBSERVER,DEST/'observer.py'); shutil.copyfile(__file__,DEST/'probe.py')
PDF=(ROOT/'capabilities/profiles/T13-text/fixtures/embedded-font-kinds.pdf').read_bytes(); OBJECTS={int(m[1]):m[2] for m in re.finditer(rb'(?m)^(\d+) 0 obj\n(.*?)\nendobj\n',PDF,re.S)}; assert len(OBJECTS)==25

def pdf_bytes(objects):
 result=bytearray(b'%PDF-1.7\n%\xe2\xe3\xcf\xd3\n'); offsets=[0]
 for i in range(1,len(objects)+1): offsets.append(len(result)); result+=str(i).encode()+b' 0 obj\n'+objects[i]+b'\nendobj\n'
 pos=len(result); result+=b'xref\n0 '+str(len(objects)+1).encode()+b'\n0000000000 65535 f \n'
 for offset in offsets[1:]: result+=f'{offset:010d} 00000 n \n'.encode()
 result+=b'trailer\n<< /Size '+str(len(objects)+1).encode()+b' /Root 1 0 R >>\nstartxref\n'+str(pos).encode()+b'\n%%EOF\n';return bytes(result)
def stream(objects,number,data):
 old=objects[number]; dictionary=old.split(b'\nstream\n',1)[0]; encoded=data.hex().encode()+b'>'; dictionary=re.sub(rb'/Length \d+',b'/Length '+str(len(encoded)).encode(),dictionary)
 if b'/Length1 ' in dictionary: dictionary=re.sub(rb'/Length1 \d+',b'/Length1 '+str(len(data)).encode(),dictionary)
 objects[number]=dictionary+b'\nstream\n'+encoded+b'\nendstream'
def tt_changed(cid=False,width=501,upem=1000,glyph_b=False):
 name='FolioT13RectangleCID.ttf' if cid else 'FolioT13Rectangle.ttf'; data=bytearray((ROOT/'capabilities/profiles/T13-fonts'/name).read_bytes()); tables={}
 for i in range(int.from_bytes(data[4:6],'big')):
  tag,checksum,start,size=struct.unpack_from('>4sIII',data,12+16*i);tables[tag]=(12+16*i,start,size)
 _,head,_=tables[b'head']; _,hmtx,_=tables[b'hmtx']; _,hhea,_=tables[b'hhea']; _,os2,_=tables[b'OS/2']; _,post,_=tables[b'post']
 data[head+18:head+20]=upem.to_bytes(2,'big');data[hmtx:hmtx+2]=width.to_bytes(2,'big');data[hhea+10:hhea+12]=width.to_bytes(2,'big');data[hhea+14:hhea+16]=(width-400).to_bytes(2,'big');data[os2+2:os2+4]=width.to_bytes(2,'big')
 if glyph_b:
  assert data[post+36:post+38]==bytes.fromhex('0024');data[post+36:post+38]=bytes.fromhex('0025')
 data[head+8:head+12]=b'\0'*4
 for record,start,size in tables.values():
  table=data[start:start+size]+b'\0'*(-size%4);checksum=sum(v for(v,)in struct.iter_unpack('>I',table))&0xffffffff;data[record+4:record+8]=checksum.to_bytes(4,'big')
 checksum=sum(v for(v,)in struct.iter_unpack('>I',data+b'\0'*(-len(data)%4)))&0xffffffff;data[head+8:head+12]=((0xb1b0afba-checksum)&0xffffffff).to_bytes(4,'big');return bytes(data)
def cff_changed(cid=False,width_all=False,cid_two=False,notdef_only=False):
 name='FolioT13RectangleCID.cff' if cid else 'FolioT13Rectangle.cff';data=(ROOT/'capabilities/profiles/T13-fonts'/name).read_bytes()
 if notdef_only: data=data.replace(bytes.fromhex('f8880e'),bytes.fromhex('f8890e'))
 else: data=data.replace(bytes.fromhex('f8888b16'),bytes.fromhex('f8898b16'))
 if width_all: data=data.replace(bytes.fromhex('f8880e'),bytes.fromhex('f8890e')).replace(bytes.fromhex('f88814'),bytes.fromhex('f88914'))
 if cid_two:
  assert data[208:211]==bytes.fromhex('000001'); data=data[:208]+bytes.fromhex('000002')+data[211:]; assert data.count(bytes.fromhex('8d0c22'))==1;data=data.replace(bytes.fromhex('8d0c22'),bytes.fromhex('8e0c22'))
 return data
variants=[('baseline',dict(OBJECTS),'pass')]
objects=dict(OBJECTS)
for cid,num in ((False,23),(True,25)):stream(objects,num,tt_changed(cid=cid))
for cid,num in ((False,22),(True,24)):stream(objects,num,cff_changed(cid=cid,width_all=True))
for i in (5,6,7):objects[i]=objects[i].replace(b'/Widths [500]',b'/Widths [501]')
for i in (18,21):objects[i]=objects[i].replace(b'/DW 500',b'/DW 501').replace(b'/W [1 [500]]',b'/W [1 [501]]')
variants.append(('all-programs-and-pdf-501',objects,'pass'))
for width,expected in ((b'200.4','pass'),(b'200.5','fail')):
 objects=dict(OBJECTS);stream(objects,23,tt_changed(upem=2500));objects[7]=objects[7].replace(b'/Widths [500]',b'/Widths ['+width+b']');objects[13]=objects[13].replace(b'/FontBBox [0 0 400 600]',b'/FontBBox [0 0 160 240]').replace(b'/Ascent 600',b'/Ascent 240').replace(b'/CapHeight 600',b'/CapHeight 240').replace(b'/StemV 400',b'/StemV 160');variants.append(('ttf-rational-'+width.decode(),objects,expected))
objects=dict(OBJECTS);stream(objects,23,tt_changed(glyph_b=True));objects[7]=objects[7].replace(b'/Widths [500]',b'/Widths [501]');variants.append(('ttf-cmap-selects-gid-one-named-B',objects,'pass'))
for cid in (1,2):
 objects=dict(OBJECTS);stream(objects,24,cff_changed(cid=True,cid_two=True));objects[18]=objects[18].replace(b'/W [1 [500]]',f'/W [{cid} [501]]'.encode());variants.append(('cidcff-real-cid-two-W-'+str(cid),objects,'pass' if cid==2 else 'fail'))
for fix in (False,True):
 objects=dict(OBJECTS);stream(objects,24,cff_changed(cid=True,notdef_only=True))
 if fix:objects[18]=objects[18].replace(b'/W [1 [500]]',b'/W [0 [501] 1 [500]]')
 variants.append(('cidcff-notdef-501-'+('matched' if fix else 'mismatched'),objects,'pass' if fix else 'fail'))
objects=dict(OBJECTS);stream(objects,25,tt_changed(cid=True,upem=2500));objects[21]=objects[21].replace(b'/W [1 [500]]',b'/W [0 [200.4 200.4]]');objects[15]=objects[15].replace(b'/FontBBox [0 0 400 600]',b'/FontBBox [0 0 160 240]').replace(b'/Ascent 600',b'/Ascent 240').replace(b'/CapHeight 600',b'/CapHeight 240').replace(b'/StemV 400',b'/StemV 160');variants.append(('cidttf-rational-200.4',objects,'pass'))
cases=[]
for label,objects,expected in variants:
 pdf=DEST/(label+'.pdf');pdf.write_bytes(pdf_bytes(objects));output=DEST/label;command=['python3',str(OBSERVER),str(ROOT),str(pdf),'font-metrics',str(output)];p=subprocess.run(command,capture_output=True,timeout=25);(DEST/(label+'.stdout')).write_bytes(p.stdout);(DEST/(label+'.stderr')).write_bytes(p.stderr);record=dict(line.split('=',1)for line in(output/'result.properties').read_text().splitlines());cases.append({'case':label,'command':command,'expected':expected,'exit':p.returncode,**record})
summary={'observer-sha256':hashlib.sha256((DEST/'observer.py').read_bytes()).hexdigest(),'observer-unchanged':OBSERVER.read_bytes()==(DEST/'observer.py').read_bytes(),'cases':cases};(DEST/'summary.json').write_text(json.dumps(summary,indent=2));print(DEST);print(json.dumps([{k:c[k]for k in('case','expected','standards','finding')}for c in cases],indent=2))
