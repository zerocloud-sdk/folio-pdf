from pathlib import Path
import hashlib, json, os, subprocess, sys, concurrent.futures
D=Path(__file__).resolve().parent
R=Path('/home/ubuntu/IdeaProjects/open-pdf')
O=D/'observer.py'

def stream(program, extras=b''):
    return b'<< '+extras+b' /Length '+str(len(program)).encode()+b' >>\nstream\n'+program+b'\nendstream'

def form(program=b'/P <</MCID 0>> BDC EMC',key=0,whole=False,resources=b'<<>>',type=True):
    return stream(program,(b'/Type /XObject ' if type else b'')+b'/Subtype /Form /BBox [0 0 10 10] /Resources '+resources+(b' /StructParent ' if whole else b' /StructParents ')+str(key).encode())

def pdf(objs):
    result=bytearray(b'%PDF-2.0\n%\xe2\xe3\xcf\xd3\n'); offsets={}
    for n, body in sorted(objs.items()):
        offsets[n]=len(result);result.extend(f'{n} 0 obj\n'.encode()+body+b'\nendobj\n')
    start=len(result);size=max(objs)+1;result.extend(f'xref\n0 {size}\n0000000000 65535 f \n'.encode())
    for n in range(1,size):
        result.extend((f'{offsets[n]:010d} 00000 n \n' if n in offsets else '0000000000 00000 f \n').encode())
    result.extend(f'trailer\n<< /Size {size} /Root 1 0 R >>\nstartxref\n{start}\n%%EOF\n'.encode());return bytes(result)

def page(program_ref,resource=20,annots=None):
    return b'<< /Type /Page /Parent 2 0 R /MediaBox [0 0 100 100] /Resources '+(b'<</XObject <</Fm '+str(resource).encode()+b' 0 R>>>>' if resource else b'<<>>')+b' /Contents '+str(program_ref).encode()+b' 0 R'+(b' /Annots ['+b' '.join(str(n).encode()+b' 0 R' for n in annots)+b']' if annots else b'')+b' >>'

def mcr(f=20,p=3,owner=None,mcid=0):
    return b'<< /Type /MCR /Pg '+str(p).encode()+b' 0 R /Stm '+str(f).encode()+b' 0 R /MCID '+str(mcid).encode()+(b' /StmOwn '+str(owner).encode()+b' 0 R' if owner else b'')+b' >>'

def objr(f=20,p=3):
    return b'<< /Type /OBJR /Pg '+str(p).encode()+b' 0 R /Obj '+str(f).encode()+b' 0 R >>'

def base(children,nums,prog_a=b'',prog_b=b'',fm=None):
    return {1:b'<< /Type /Catalog /Version /2.0 /Pages 2 0 R /StructTreeRoot 5 0 R >>',
            2:b'<< /Type /Pages /Count 2 /Kids [3 0 R 4 0 R] >>',
            3:page(10),4:page(11),5:b'<< /Type /StructTreeRoot /K 6 0 R /ParentTree 7 0 R >>',
            6:b'<< /Type /StructElem /S /P /P 5 0 R /K ['+children+b'] >>',
            7:b'<< /Nums ['+nums+b'] >>',10:stream(prog_a),11:stream(prog_b),20:fm if fm is not None else form()}

def annot(n=20,r=None,down=None,state=False,p=3):
    normal=b'<</On '+str(n).encode()+b' 0 R'+(b' /Off '+str(r).encode()+b' 0 R' if r else b'')+b'>>' if state else str(n).encode()+b' 0 R'
    ap=b'<< /N '+normal+(b' /R '+str(r).encode()+b' 0 R' if r and not state else b'')+(b' /D '+str(down).encode()+b' 0 R' if down else b'')+b' >>'
    return b'<< /Type /Annot /Subtype /Stamp /P '+str(p).encode()+b' 0 R /Rect [0 0 10 10] /AP '+ap+(b' /AS /On' if state else b'')+b' >>'

CASES=[]
def add(name,objs,expected,basis):
    data=pdf(objs) if isinstance(objs,dict) else objs
    f=D/(name+'.pdf');f.write_bytes(data)
    CASES.append({'name':name,'input':str(f),'input_sha256':hashlib.sha256(data).hexdigest(),'expected':expected,'basis':basis})

# Original literal MCR/page relations.
for label,pa,pb,declared,expected in [('single-a',b'/Fm Do',b'',3,'pass'),('single-a-declared-b',b'/Fm Do',b'',4,'fail'),('single-b',b'',b'/Fm Do',4,'pass'),('two-actual-pages',b'/Fm Do',b'/Fm Do',3,'fail')]:
    add('mcr-'+label,base(mcr(p=declared),b'0 [6 0 R]',pa,pb),expected,'ISO1 Table324 Pg; 14.7.4.2 repeated Do')
for declared in [3,4]:
    add('mcr-definition-only-page-'+str(declared),base(mcr(p=declared),b'0 [6 0 R]'),'pass','Existing bounded definition admission; not a new proof of global rendering association')
# Whole references, same and different rendering pages.
for label,pa,pb,children,expected in [('single-a',b'/Fm Do',b'',objr(),'pass'),('single-a-declared-b',b'/Fm Do',b'',objr(p=4),'fail'),('two-pages-only-a',b'/Fm Do',b'/Fm Do',objr(),'fail'),('two-pages-both',b'/Fm Do',b'/Fm Do',objr()+objr(p=4),'pass'),('same-page-repeated',b'/Fm Do /Fm Do',b'',objr(),'pass')]:
    add('whole-'+label,base(children,b'0 6 0 R',pa,pb,form(b'q Q',whole=True)),expected,'ISO1 Table325 Pg and NOTE2 per rendering page')
# Optional Type is not a mechanism selector.
for label,whole in [('mcr',False),('whole',True)]:
    for typed in [True,False]:
        add('optional-type-'+label+'-'+str(typed).lower(),base(objr() if whole else mcr(),b'0 6 0 R' if whole else b'0 [6 0 R]',b'/Fm Do',fm=form(b'q Q' if whole else b'/P <</MCID 0>> BDC EMC',whole=whole,type=typed)),'pass','ISO1 Table95 optional Form Type, Table325 permits complete XObject')
# Proven AP normal relation without page XObject reachability, optional owner declaration.
for explicit in [False,True]:
    o=base(mcr(owner=30 if explicit else None),b'0 [6 0 R]');o[3]=page(10,None,[30]);o[4]=page(11,None);o[30]=annot()
    add('ap-normal-owner-'+str(explicit).lower(),o,'pass','ISO1 Table324 StmOwn optional; 12.5.5/Table168')
# Two referenced alternative appearances have disjoint parent MCIDs outside a shared descendant.
for mode in ['normal-only','rollover-alternative','down-alternative','state-alternative','independent-normal-owners','disjoint-alternatives','same-form-aliases']:
    if mode=='same-form-aliases':
        o=base(mcr(owner=30),b'0 [6 0 R]');o[3]=page(10,None,[30]);o[4]=page(11,None);o[30]=annot(20,20,20)
        add('ap-'+mode,o,'pass','Alternative entries alias one Form; one declared owner');continue
    extra = mode!='normal-only'
    o=base(mcr(owner=30)+ (mcr(21,owner=31 if mode=='independent-normal-owners' else 30) if extra else b'')+mcr(22),b'0 [6 0 R] '+(b'1 [6 0 R] ' if extra else b'')+b'2 [6 0 R]')
    o[20]=form(b'/P <</MCID 0>> BDC EMC /Child Do',resources=b'<</XObject <</Child 22 0 R>>>>')
    o[22]=form(key=2);o[3]=page(10,None,[30,31] if mode=='independent-normal-owners' else [30]);o[4]=page(11,None)
    o[30]=annot(20,21 if mode in ('rollover-alternative','state-alternative','disjoint-alternatives') else None,21 if mode=='down-alternative' else None,state=mode=='state-alternative')
    if extra:o[21]=form(b'/P <</MCID 0>> BDC EMC'+(b'' if mode=='disjoint-alternatives' else b' /Child Do'),key=1,resources=b'<</XObject <</Child 22 0 R>>>>')
    if mode=='independent-normal-owners':o[31]=annot(21)
    expected='fail' if mode=='independent-normal-owners' else 'indeterminate' if mode in ('rollover-alternative','down-alternative','state-alternative') else 'pass'
    add('ap-'+mode,o,expected,'ISO1 Table168 alternative appearances; repeated-Do judgment must not equate alternatives with simultaneous roots')
# Actual declared normal AP root with one/two Do invocations to a structurally linked descendant.
for repeated in [False,True]:
    o=base(mcr(22),b'2 [6 0 R]');o[3]=page(10,None,[30]);o[4]=page(11,None);o[30]=annot(20)
    o[20]=stream(b'/Child Do'+(b' /Child Do' if repeated else b''),b'/Type /XObject /Subtype /Form /BBox [0 0 10 10] /Resources <</XObject <</Child 22 0 R>>>>')
    o[22]=form(key=2)
    add('ap-unclaimed-root-'+('two' if repeated else 'one')+'-child-calls',o,'fail' if repeated else 'pass','ISO1 12.5.5 normal AP rendering and 14.7.4.2 repeated actual Do; StmOwn optional')
# Whole Form invokes another whole Form, no MCID overlap ambiguity.
for child_page in [3,4]:
    for reverse in [False,True]:
        a=objr(20,3);b=objr(21,child_page)
        o=base((b+a) if reverse else (a+b),b'0 6 0 R 1 6 0 R',b'/Fm Do',fm=form(b'/Child Do',whole=True,resources=b'<</XObject <</Child 21 0 R>>>>'))
        o[21]=form(b'q Q',key=1,whole=True)
        add('whole-nested-child-page-'+str(child_page)+'-reverse-'+str(reverse).lower(),o,'fail','ISO1 14.7.4.1 content-item leaf; child page does not erase observed object rendering on A')
# Independently literal exact count: two page Contents plus 126 or 127 Form programs.
for n in [126,127]:
    o=base(mcr(20),b'0 [6 0 R]')
    for i in range(n):
        last=i==n-1
        program=(b'/P <</MCID 0>> BDC EMC ' if i==0 else b'')+(b'q Q' if last else b'/Next Do')
        extras=b'/Type /XObject /Subtype /Form /BBox [0 0 10 10] /Resources '+(b'<<>>' if last else b'<</XObject <</Next '+str(21+i).encode()+b' 0 R>>>>')+(b' /StructParents 0' if i==0 else b'')
        o[20+i]=stream(program,extras)
    add('definition-count-'+str(n+2),o,'pass' if n==126 else 'indeterminate','Declared total 128 content stream occurrences (two page streams + Form chain)')
# Required original Sources remain positive, copied byte for byte.
for source in sorted((R/'capabilities/profiles/T13-text/fixtures').glob('*.pdf')):
    add('source-'+source.stem,source.read_bytes(),'pass','Required original corpus identity, existing literal source expectations')

(D/'inputs.json').write_text(json.dumps(CASES,indent=2)+'\n')
env=os.environ.copy();env.pop('QPDF_CACHE_DIRECTORY',None)
def run(case):
    output=D/(case['name']+'-out');command=[sys.executable,str(O),str(R),case['input'],'structure-content',str(output)]
    completed=subprocess.run(command,env=env,cwd=D,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=40)
    (D/(case['name']+'.stdout')).write_bytes(completed.stdout);(D/(case['name']+'.stderr')).write_bytes(completed.stderr)
    report=output/'result.properties';props=dict(line.split('=',1) for line in report.read_text().splitlines() if '=' in line) if report.exists() else {}
    result={**case,'command':command,'returncode':completed.returncode,'result':props,'matches':props.get('standards')==case['expected'],'observer_after':hashlib.sha256(O.read_bytes()).hexdigest(),'input_after':hashlib.sha256(Path(case['input']).read_bytes()).hexdigest()}
    (D/(case['name']+'.run.json')).write_text(json.dumps(result,indent=2)+'\n')
    return result
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    results=list(pool.map(run,CASES))
(D/'summary.json').write_text(json.dumps(results,indent=2)+'\n')
for item in results:
    print(item['name'],item['expected'],'=>',item['result'].get('standards'),item['result'].get('finding'),flush=True)
print('TOTAL',len(results),'MISMATCH',sum(not r['matches'] for r in results))
