from pathlib import Path
import concurrent.futures, hashlib, json, os, subprocess, sys
D=Path(__file__).resolve().parent
helper=(D/'probe.py').read_text().split('CASES=[]')[0]
exec(compile(helper,str(D/'probe.py'), 'exec'))
cases=[]
def add(name,objs,expected,basis):
 p=D/(name+'.pdf');p.write_bytes(pdf(objs));cases.append({'name':name,'input':str(p),'input_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'expected':expected,'basis':basis})
# Actual page Do plus a normal AP's independent Do cannot be counted as one.
o=base(mcr(),b'0 [6 0 R]',b'/Fm Do');o[3]=page(10,20,[30]);o[30]=annot(21)
o[21]=stream(b'/Child Do',b'/Subtype /Form /BBox [0 0 10 10] /Resources <</XObject <</Child 20 0 R>>>>')
add('adj-page-and-normal-ap-child',o,'fail','Two actual Do positions: page and one normal AP; ISO1 14.7.4.2')
# Same known child reached through two ordinary normal AP parents.
o=base(mcr(),b'0 [6 0 R]');o[3]=page(10,None,[30,31]);o[4]=page(11,None);o[30]=annot(21);o[31]=annot(22)
for n in [21,22]:o[n]=stream(b'/Child Do',b'/Subtype /Form /BBox [0 0 10 10] /Resources <</XObject <</Child 20 0 R>>>>')
add('adj-two-ordinary-normal-ap-parents',o,'fail','Two distinct simultaneous normal AP parents each invoke the structural Form')
# Optional Type variants and an indirect present Type.
for label,decl in [('null',b'/Type null '),('indirect',b'/Type 40 0 R ')]:
 o=base(objr(),b'0 6 0 R',b'/Fm Do',fm=form(b'q Q',whole=True,type=False));o[20]=o[20].replace(b'/Subtype /Form',decl+b'/Subtype /Form');o[40]=b'/XObject'
 add('adj-whole-type-'+label,o,'pass','ISO1 Table95 optional Type; null-valued optional dictionary entry means omission')
o=base(objr(),b'0 6 0 R',fm=form(b'q Q',whole=True,type=False));o[3]=page(10,None,[30]);o[4]=page(11,None);o[30]=annot()
add('adj-whole-untagged-type-normal-ap',o,'pass','Whole Form whose optional Type is omitted still belongs to the normal AP page')
# Known unexecuted AP root: same leaf rule, selected independent of K order.
for enclosed in [True,False]:
 body=b'/P <</MCID 0>> BDC '+(b'/Child Do EMC' if enclosed else b'EMC /Child Do')
 o=base(mcr(owner=30)+objr(21),b'0 [6 0 R] 1 6 0 R',fm=form(body,resources=b'<</XObject <</Child 21 0 R>>>>'))
 o[21]=form(b'q Q',key=1,whole=True);o[3]=page(10,None,[30]);o[4]=page(11,None);o[30]=annot()
 add('adj-unexecuted-ap-'+('nested' if enclosed else 'separate')+'-whole-child',o,'fail' if enclosed else 'pass','ISO1 14.7.4.1 MCR ancestor versus separate whole item')
# Unexecuted whole AP must not invoke a whole structural child.
o=base(objr()+objr(21),b'0 6 0 R 1 6 0 R',fm=form(b'/Child Do',whole=True,resources=b'<</XObject <</Child 21 0 R>>>>'));o[21]=form(b'q Q',key=1,whole=True);o[3]=page(10,None,[30]);o[4]=page(11,None);o[30]=annot()
add('adj-unexecuted-whole-ap-whole-child',o,'fail','ISO1 14.7.4.1 applies to parsed unexecuted definitions too')
# Literal reverse ordering does not turn same-page coverage into a new content owner.
o=base(objr(p=4)+objr(p=3),b'0 6 0 R',b'/Fm Do',b'/Fm Do',form(b'q Q',whole=True))
add('adj-whole-two-pages-k-reversed',o,'pass','ISO1 Table325 NOTE2 requires one OBJR per rendering page, K order does not affect coverage')
o=base(mcr().replace(b'/MCID 0',b'/MCID 40 0 R'),b'0 [6 0 R]',b'/Fm Do');o[40]=b'0'
add('adj-indirect-mcid-in-reference',o,'pass','MCR MCID is an integer value; no direct-only requirement')
(D/'adjacent-inputs.json').write_text(json.dumps(cases,indent=2)+'\n')
env=os.environ.copy();env.pop('QPDF_CACHE_DIRECTORY',None)
def run(case):
 out=D/(case['name']+'-out');cmd=[sys.executable,str(O),str(R),case['input'],'structure-content',str(out)]
 c=subprocess.run(cmd,cwd=D,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=40)
 (D/(case['name']+'.stdout')).write_bytes(c.stdout);(D/(case['name']+'.stderr')).write_bytes(c.stderr)
 props=dict(line.split('=',1) for line in (out/'result.properties').read_text().splitlines() if '=' in line)
 r={**case,'command':cmd,'returncode':c.returncode,'result':props,'matches':props.get('standards')==case['expected'],'observer_after':hashlib.sha256(O.read_bytes()).hexdigest(),'input_after':hashlib.sha256(Path(case['input']).read_bytes()).hexdigest()}
 (D/(case['name']+'.run.json')).write_text(json.dumps(r,indent=2)+'\n');return r
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(run,cases))
(D/'adjacent-summary.json').write_text(json.dumps(results,indent=2)+'\n')
for i in results:print(i['name'],i['expected'],'=>',i['result']['standards'],i['result'].get('finding'),flush=True)
print('TOTAL',len(results),'MISMATCH',sum(not r['matches'] for r in results))
