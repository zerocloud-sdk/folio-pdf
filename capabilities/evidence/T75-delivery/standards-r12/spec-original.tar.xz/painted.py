from pathlib import Path
import concurrent.futures,hashlib,json,os,subprocess,sys
D=Path(__file__).resolve().parent
exec(compile((D/'probe.py').read_text().split('CASES=[]')[0],str(D/'probe.py'),'exec'))
cases=[]
ink=b'BT /F1 10 Tf 1 0 0 1 1 1 Tm (A) Tj ET'
font_resources=b'<</Font <</F1 100 0 R>>>>'
def inkfont(o):
 o[100]=b'<</Type /Font /Subtype /Type3 /Name /F1 /FontBBox [0 0 400 600] /FontMatrix [.001 0 0 .001 0 0] /FirstChar 65 /LastChar 65 /Widths [500] /Encoding <</Type /Encoding /Differences [65 /A]>> /CharProcs <</A 101 0 R>> /Resources <<>> /FontDescriptor 102 0 R>>'
 o[101]=stream(b'500 0 d0 0 0 400 600 re f')
 o[102]=b'<</Type /FontDescriptor /FontName /F1 /Flags 33 /FontBBox [0 0 400 600] /ItalicAngle 0 /Ascent 600 /Descent 0 /CapHeight 600 /StemV 400>>'
 return o

def add(name,o,expected,basis):
 p=D/(name+'.pdf');p.write_bytes(pdf(inkfont(o)));cases.append({'name':name,'input':str(p),'input_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'expected':expected,'basis':basis,'original_font':'One original Type3 rectangle 400x600, declared width500, matrix0.001; glyph65/A, no third-party font program'})
for label,declared,typed,expected in [('correct-a',3,True,'pass'),('wrong-b',4,True,'fail'),('no-optional-type',3,False,'pass')]:
 o=base(objr(p=declared),b'0 6 0 R',b'/Fm Do',fm=form(ink,whole=True,resources=font_resources,type=typed))
 add('painted-whole-'+label,o,expected,'ISO1 Table325 page rendering / Table95 optional Type')
for repeats in [1,2]:
 o=base(mcr(),b'0 [6 0 R]',fm=form(b'/P <</MCID 0>> BDC '+ink+b' EMC',resources=font_resources));o[3]=page(10,None,[30]);o[4]=page(11,None);o[30]=annot(21)
 o[21]=stream(b' '.join([b'/Child Do']*repeats),b'/Type /XObject /Subtype /Form /BBox [0 0 10 10] /Resources <</XObject <</Child 20 0 R>>>>')
 add('painted-normal-ap-'+str(repeats)+'-child-calls',o,'pass' if repeats==1 else 'fail','ISO1 12.5.5 actual normal appearance containing one/two Do invocations, 14.7.4.2')
o=base(mcr(owner=30)+mcr(21,owner=30)+mcr(22),b'0 [6 0 R] 1 [6 0 R] 2 [6 0 R]');o[3]=page(10,None,[30]);o[4]=page(11,None);o[30]=annot(20,21)
for n,key in [(20,0),(21,1)]:o[n]=form(b'/P <</MCID 0>> BDC '+ink+b' EMC /Child Do',key=key,resources=b'<</Font <</F1 100 0 R>> /XObject <</Child 22 0 R>>>>')
o[22]=form(b'/P <</MCID 0>> BDC '+ink+b' EMC',key=2,resources=font_resources)
add('painted-normal-rollover-alternatives',o,'indeterminate','Table168 alternatives; two candidate roots do not establish simultaneous repeat')
(D/'painted-inputs.json').write_text(json.dumps(cases,indent=2)+'\n')
env=os.environ.copy();env.pop('QPDF_CACHE_DIRECTORY',None)
def run(case):
 out=D/(case['name']+'-out');cmd=[sys.executable,str(O),str(R),case['input'],'structure-content',str(out)]
 c=subprocess.run(cmd,cwd=D,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=40)
 (D/(case['name']+'.stdout')).write_bytes(c.stdout);(D/(case['name']+'.stderr')).write_bytes(c.stderr)
 props=dict(line.split('=',1) for line in (out/'result.properties').read_text().splitlines() if '=' in line)
 result={**case,'command':cmd,'returncode':c.returncode,'result':props,'matches':props.get('standards')==case['expected'],'observer_after':hashlib.sha256(O.read_bytes()).hexdigest(),'input_after':hashlib.sha256(Path(case['input']).read_bytes()).hexdigest()}
 (D/(case['name']+'.run.json')).write_text(json.dumps(result,indent=2)+'\n');return result
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(run,cases))
(D/'painted-summary.json').write_text(json.dumps(results,indent=2)+'\n')
for r in results:print(r['name'],r['expected'],'=>',r['result']['standards'],r['result'].get('finding'))
