# Incremental T13 structure-content Spec review

Frozen observer: 1b73ff6d9a424973f15ffbfb89d7fa84e26d611782ccc52544779abb9da5660b. 53 public CLI calls; four finding families, including one conditional-appearance qualification boundary. No Native algorithm source read, repository edit, Maven or compilation.

1. Whole Form OBJRs do not cover actual rendering pages, permitting false PASS and a cross-page escape from whole-content leaf checks (observer1516-1522,1563-1574; ISO1 Table325 NOTE2/14.7.4.1).
2. Omitting the legal optional Form Type routes the object into annotation validation and causes false FAIL (1518-1520; ISO1 Table95, PDF2 Arlington Type Required=FALSE).
3. Alternative N/R, N/D and On/Off roots of one annotation are summed as simultaneous invocations; the shared-descendant case needs an explicit INDETERMINATE boundary instead of a normative repeat failure (1547-1562; ISO1 Table168).
4. A normal AP ancestor outside K is not observed even when it invokes the linked child twice, adds an invocation to actual page content, or supplies a second independent normal appearance (1494-1500,1547-1551; ISO1 12.5.5/14.7.4.2).

All five required Sources, 128/129 stream bounds, same-page repeated whole objects, reverse K ordering and known unexecuted leaf controls behave as expected. MCR A-executed/B-declared is already rejected by this snapshot. Optional StmOwn and AP-only resource-independent positive controls pass. Six additional original Type3 painted fixtures confirm that the four findings do not depend on empty marked sequences/forms.

Use assessment.json for each witness/control/source boundary, summary.json + adjacent-summary.json + painted-summary.json for all calls, *.run.json for exact public CLI commands and observations, and sources/ for original primary excerpts and source identities. This is not the final #75 review gate.
