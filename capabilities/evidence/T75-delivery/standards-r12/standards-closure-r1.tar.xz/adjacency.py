from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time
ROOT=Path('/home/ubuntu/IdeaProjects/open-pdf');HERE=Path(__file__).resolve().parent
SHA='27377172a2552a30855ff216ad166d03c0cc9829a7ddbe339f206b020564a689'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert sha(HERE/'observer.py')==SHA
ENV=dict(os.environ);ENV.pop('QPDF_CACHE_DIRECTORY',None)
files=[HERE/'observer.py',HERE/'contract.md',Path(sys.executable).resolve(),ROOT/'.build-cache/qpdf/12.4.0/bin/qpdf']+[ROOT/'scripts'/x for x in ['qpdf-pin.properties','container-bin/qpdf','t13-qpdf-runtime.sha256']]
for line in (ROOT/'scripts/t13-qpdf-runtime.sha256').read_text().splitlines():files.append(ROOT/'.build-cache/qpdf/12.4.0'/line.split('  ',1)[1])
identities={str(p):sha(p) for p in files};rows=[]
def stream(dictionary=b'<<>>',data=b''):
 assert dictionary.endswith(b'>>')
 return dictionary[:-2]+b'/Length '+str(len(data)).encode()+b'>>\nstream\n'+data+b'\nendstream'
def objects():
 return [b'<</Type/Catalog/Pages 2 0 R/StructTreeRoot 4 0 R/MarkInfo<</Marked true>>>>',b'<</Type/Pages/Kids[3 0 R]/Count 1>>',b'<</Type/Page/Parent 2 0 R/MediaBox[0 0 100 100]/Resources<<>>/Contents 7 0 R/StructParents 0>>',b'<</Type/StructTreeRoot/K 5 0 R/ParentTree 6 0 R/ParentTreeNextKey 1>>',b'<</Type/StructElem/S/P/P 4 0 R/Pg 3 0 R/K 0/Lang(en)>>',b'<</Nums[0[5 0 R]]>>',stream(data=b'/P<</MCID 0>>BDC EMC'),b'null']
def pdf(parts):
 data=bytearray(b'%PDF-2.0\n');offsets=[0]
 for i,body in enumerate(parts,1):offsets.append(len(data));data.extend(str(i).encode()+b' 0 obj\n'+body+b'\nendobj\n')
 xref=len(data);data.extend(b'xref\n0 '+str(len(offsets)).encode()+b'\n0000000000 65535 f \n')
 for off in offsets[1:]:data.extend(('%010d 00000 n \n'%off).encode())
 data.extend(b'trailer\n<</Size '+str(len(offsets)).encode()+b'/Root 1 0 R>>\nstartxref\n'+str(xref).encode()+b'\n%%EOF\n');return data

def run(label,parts,scope):
 path=HERE/(label+'.pdf');data=pdf(parts);path.write_bytes(data);out=HERE/(label+'-'+scope+'-output');args=[sys.executable,str(HERE/'observer.py'),str(ROOT),str(path),scope,str(out)];started=time.monotonic()
 with (HERE/(out.name+'.stdout')).open('wb') as stdout,(HERE/(out.name+'.stderr')).open('wb') as stderr:
  p=subprocess.run(args,cwd=HERE,env=ENV,stdout=stdout,stderr=stderr,timeout=40)
 prop=out/'result.properties';result=dict(line.split('=',1) for line in prop.read_text().splitlines() if line and not line.startswith(('#','!'))) if prop.exists() else None
 row={'label':label,'scope':scope,'command':args,'cwd':str(HERE),'exit':p.returncode,'elapsed':time.monotonic()-started,'input-sha256':sha(path),'result':result,'files':{str(f.relative_to(out)):sha(f) for f in out.iterdir() if f.is_file()}}
 rows.append(row);(HERE/(label+'-'+scope+'-result.json')).write_text(json.dumps(row,indent=2)+'\n');print(label,scope,p.returncode,result.get('standards') if result else None,result.get('finding') if result else None,flush=True)


def change(num, before, after):
 p=objects();assert p[num-1].count(before)==1;p[num-1]=p[num-1].replace(before,after);return p
def emit(label,p,scope='structure-content'):
 run(label,p,scope)


expectations={}
def observe(label,parts,expected):
 expectations[label]=expected;emit(label,parts)
 assert rows[-1]['result']['standards']==expected,(label,rows[-1]['result'])
def whole_form():
 p=objects();p[2]=p[2].replace(b'/Resources<<>>',b'/Resources<</XObject<</Fm 8 0 R>>>>').replace(b'/StructParents 0',b'')
 p[4]=p[4].replace(b'/K 0',b'/K<</Type/OBJR/Obj 8 0 R>>');p[5]=b'<</Nums[0 5 0 R]>>';p[6]=stream(data=b'/Fm Do')
 p[7]=stream(b'<</Subtype/Form/BBox[0 0 10 10]/Resources<<>>/StructParent 0>>',b'q Q');return p
def appearance():
 p=whole_form();p[2]=p[2][:-2]+b'/Annots[9 0 R]>>';p[6]=stream(data=b'q Q');p.append(b'<</Type/Annot/Subtype/Text/Rect[0 0 10 10]/P 3 0 R/AP<</N 8 0 R>>>>');return p
for label,kind,expected in [('appearance-optional-form-type','omitted','pass'),('appearance-null-form-type','null','pass'),('appearance-single-state','state','pass'),('appearance-aliased-states','alias','pass'),('appearance-distinct-states','distinct','indeterminate'),('appearance-ap-stream','ap-stream','fail'),('appearance-state-not-stream','state-dict','indeterminate')]:
 p=appearance()
 if kind=='null':p[7]=p[7].replace(b'/Subtype/Form',b'/Type null/Subtype/Form')
 elif kind=='state':p[8]=p[8].replace(b'/N 8 0 R',b'/N<</On 8 0 R>>')
 elif kind=='alias':p[8]=p[8].replace(b'/N 8 0 R',b'/N<</On 8 0 R/Off 8 0 R>>')
 elif kind=='distinct':p[8]=p[8].replace(b'/N 8 0 R',b'/N<</On 8 0 R/Off 10 0 R>>');p.append(stream(b'<</Subtype/Form/BBox[0 0 10 10]/Resources<<>>>>',b'q Q'))
 elif kind=='ap-stream':p[8]=p[8].replace(b'/AP<</N 8 0 R>>',b'/AP 10 0 R');p.append(stream(b'<</N 8 0 R>>'))
 elif kind=='state-dict':p[8]=p[8].replace(b'/N 8 0 R',b'/N<</On 10 0 R>>');p.append(b'<</Subtype/Form/BBox[0 0 10 10]/Resources<<>>>>')
 observe(label,p,expected)
for label,repeat,declared,expected in [('whole-form-two-pages-uncovered',False,False,'fail'),('whole-form-two-pages-covered',False,True,'pass'),('whole-form-repeat-same-page',True,False,'pass')]:
 p=whole_form()
 if repeat:p[6]=stream(data=b'/Fm Do /Fm Do')
 else:
  p[1]=b'<</Type/Pages/Kids[3 0 R 9 0 R]/Count 2>>';p.append(p[2])
  if declared:p[4]=p[4].replace(b'/K<</Type/OBJR/Obj 8 0 R>>',b'/K[<</Type/OBJR/Obj 8 0 R>><</Type/OBJR/Pg 9 0 R/Obj 8 0 R>>]')
 observe(label,p,expected)
for n in (127,128):
 p=objects()[:7];annots=[]
 for i in range(n):
  owner=len(p)+1;form=owner+1;annots.append(str(owner).encode()+b' 0 R')
  p.append(b'<</Type/Annot/Subtype/Text/Rect[0 0 10 10]/P 3 0 R/AP<</N '+str(form).encode()+b' 0 R>>>>')
  p.append(stream(b'<</Subtype/Form/BBox[0 0 10 10]/Resources<<>>>>',b'q Q'))
 p[2]=p[2][:-2]+b'/Annots['+b' '.join(annots)+b']>>'
 observe('appearance-count-'+str(n),p,'pass' if n==127 else 'indeterminate')
p=appearance();p[4]=p[4].replace(b'/Type/OBJR/Obj 8 0 R',b'/Type/MCR/Stm 8 0 R/MCID 0');p[5]=b'<</Nums[0[5 0 R]]>>';p[7]=stream(b'<</Subtype/Form/BBox[0 0 10 10]/Resources<<>>/StructParents 0>>',b'/P<</MCID 0>>BDC EMC');p[2]=p[2].replace(b'/Annots[9 0 R]',b'/Annots[9 0 R 10 0 R]');p.append(p[8]);observe('two-annotation-owners-one-structured-form',p,'fail')
p=appearance();p[4]=p[4].replace(b'/K<</Type/OBJR/Obj 8 0 R>>',b'/K[<</Type/OBJR/Obj 8 0 R>><</Type/OBJR/Obj 9 0 R>>]');p[5]=b'<</Nums[0 5 0 R 1 5 0 R]>>';p[3]=p[3].replace(b'/ParentTreeNextKey 1',b'/ParentTreeNextKey 2');p[8]=p[8][:-2]+b'/StructParent 1>>';observe('whole-annotation-appearance-overlap',p,'indeterminate')

after={str(p):sha(p) for p in files};assert after==identities;(HERE/'adjacency-identity.json').write_text(json.dumps({'before':identities,'after':after,'unchanged':identities==after,'probe-sha256':sha(Path(__file__))},indent=2)+'\n');(HERE/'adjacency-results.json').write_text(json.dumps(rows,indent=2)+'\n');(HERE/'adjacency-expectations.json').write_text(json.dumps(expectations,indent=2)+'\n');print('COMPLETE',len(rows),'identities unchanged',identities==after,flush=True)
