# Bounded structure-content Standards closure

CLEAN for this incremental closure; not the final #75 clean-context review or a complete Tagged PDF conformance claim. Fixed overall baseline remains `5b1603c435f11c40368f75b7b9a2777c9c5e9761`. No repository edits, Maven, target builds, or Native algorithm oracle.

The three immutable files from `standards-r12` were copied and verified before review:

- observer.py: `27377172a2552a30855ff216ad166d03c0cc9829a7ddbe339f206b020564a689`
- contract.md: `4d59e4dc362e53ba84006f2ab51d5efb180824ec5d90a8546f975da853d18daf`
- structure-tests.py: `9c3a83c0969d2a94b3d65db71d0d8c96539cff4dceb4ebb0c948cc3a4a24d62e`

Only the copied observer.py was executed. CONTRIBUTING, CONTEXT, ADR-0029/0035/0040 and the code-review skill's documented-rule-over-heuristic smell baseline were applied. The changes between the previously reviewed observer and this copy were inspected; live observer changes were excluded.

## Closed findings

The original OBJR Type classification finding is closed. Stream-kind discrimination preserves legal optional/null Form Type; the exact executed original false-FAIL inputs now PASS. The isolated ordinary dictionary masquerading as an image XObject now reports INDETERMINATE, without manufacturing a declaration-level FAIL in this relationship scope. Additional actual AP-associated whole Form controls with omitted/null Type PASS.

The former unused executions ledger has a real consumer: `(page, Form)` observations check every page-content rendering against whole OBJR declarations. Independent two-page incomplete coverage FAILs, complete coverage PASSes, and repeated same-page rendering with one OBJR PASSes. The earlier Speculative Generality suggestion is closed; no new actionable smell is asserted.

The contract now explicitly limits the ParentTree predicate to every K content item's parent slot and excludes reverse completeness of extra non-null slots. The original extra-slot observations remain PASS and are not presented as exhaustive reverse-backlink qualification.

## Actual controls and expected contract changes

`replay.py` copied and replayed all 48 original valid CLI observations byte for byte. All preserved input hashes match their original records. `replay-expectations.json` documents every expected outcome, including 7 changed outcomes. In particular, a valid unexecuted Form without observed page-content or AP association is now INDETERMINATE under the tightened relationship contract. The historically named `xobject-stream-positive` was an exploratory input containing an image stream inside Annots, not an isolated legal image fixture; new Annots dictionary-position checking correctly FAILs it. The original isolated `whole-image-without-do` control remains PASS within the limited typed-object predicate.

`adjacency.py` authors 14 new original minimal PDF controls using only Python stdlib. It does not import the product, corpus generator, or observer. These check optional/null Form Type under AP association; same-owner single/aliased and distinct alternative states; AP dictionaries versus streams and non-stream state targets; whole OBJR coverage across two actual pages; same-page repetition; appearance-root 128-stream first-excess admission; independent owners sharing an internally structured Form; and whole annotation/internal appearance overlap. Their literal expected results are retained in adjacency-expectations.json. Distinct alternative states and whole-annotation overlap report INDETERMINATE. Single/aliased states PASS. Two separate owners of one internally structured Form FAIL. One page plus 127 appearance Form definitions PASSes; one page plus 128 is INDETERMINATE. The original executed chain and exponential-work bounds also remain correct.

All 62 public CLI observations returned a record and exit 0, with asserted expected result categories and exact input, observer and pinned qpdf/runtime identities. This means 62 checked observations, not 62 valid documents or 62 PASS classifications. Status counts appear in validation.txt. Raw PDFs, CLI stdout/stderr, qpdf version/JSON/stderr, result.properties, exact argv/cwd and file hashes remain per case. Before/after/final identities bind copied sources, Python executable, qpdf wrapper, full pin, binary, runtime manifest and all eleven library paths. No harness error occurred in this closure. The previous review's separate import-shadowing error remains in its original archive and is not replayed.

## Reproduce

Each `*-result.json` contains the exact public CLI command and cwd. Run against a fresh output directory; never reuse an existing result directory. `all-observations.json` aggregates the 48 replays and 14 new cases. Original minimal authoring came from this independent reviewer and the prior original review helper, under the repository's clean-room provenance rules. Public ISO 32000-1 Table 95 supplied the optional Type rule; the prior normative-reference.json was copied here unchanged.
