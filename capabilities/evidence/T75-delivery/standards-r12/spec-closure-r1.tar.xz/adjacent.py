from pathlib import Path
import concurrent.futures,hashlib,json,os,re,subprocess,sys
D=Path(__file__).resolve().parent
OLD=Path('/tmp/t75-spec-structure-content.453_lsec')
exec(compile((OLD/'probe.py').read_text().split('CASES=[]')[0],str(OLD/'probe.py'),'exec'))
cases=[]
def read_original(name):
 data=(OLD/(name+'.pdf')).read_bytes()
 pairs=re.findall(rb'(?m)^(\d+) 0 obj\n(.*?)\nendobj\n',data,re.S)
 return {int(number):body for number,body in pairs}
def add(name,o,expected,basis):
 p=D/(name+'.pdf');p.write_bytes(pdf(o));cases.append({'name':name,'input':str(p),'input_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'expected':expected,'basis':basis})
# Preserve the literal stream-count programs while providing an actual AP relationship.
for total in [128,129]:
 o=read_original('definition-count-'+str(total))
 assert 200 not in o
 o[3]=page(10,20,[200]);o[200]=annot(20)
 add('closure-associated-count-'+str(total),o,'pass' if total==128 else 'indeterminate','Exactly two page Contents plus 126/127 Form programs. Only an annotation dictionary relationship is added, no stream.')
# Unassociated definitions still reveal a concrete missing MCID before association qualification ends.
o=base(mcr(mcid=1),b'0 [null 6 0 R]')
add('closure-unassociated-missing-mcid',o,'fail','The contract retains definition failures before an unobserved association becomes IND.')
# Qualified boundary for whole-annotation/AP overlap, preserving definite definition failure.
for missing in [False,True]:
 o=base(mcr(owner=30,mcid=1 if missing else 0)+objr(30),b'0 '+(b'[null 6 0 R]' if missing else b'[6 0 R]')+b' 1 6 0 R')
 o[3]=page(10,None,[30]);o[4]=page(11,None);o[30]=annot().replace(b'/Subtype /Stamp',b'/Subtype /Stamp /StructParent 1')
 add('closure-whole-annotation-'+('missing-mcid' if missing else 'internal-ap'),o,'fail' if missing else 'indeterminate','Explicit frozen annotation/AP leaf boundary; a concrete nonexistent MCID remains a failure.')
# A newly discovered ordinary AP owner is used as page-association evidence.
for mode in ['matching','absent','wrong']:
 o=read_original('ap-unclaimed-root-one-child-calls')
 if mode=='absent':o[30]=o[30].replace(b'/P 3 0 R',b'')
 elif mode=='wrong':o[30]=o[30].replace(b'/P 3 0 R',b'/P 4 0 R')
 add('closure-normal-owner-p-'+mode,o,'fail' if mode=='wrong' else 'pass','ISO1 Table164 P defines the page associated with an annotation; the frozen scope qualifies optional P agreement.')
# Hidden AP is not proof of another rendered invocation: base PDF Hidden suppresses screen and print.
for hidden in [False,True]:
 o=read_original('adj-page-and-normal-ap-child')
 o[30]=o[30].replace(b'/Subtype /Stamp',b'/Subtype /Stamp /F '+(b'2' if hidden else b'0'))
 add('closure-hidden-ap-'+str(hidden).lower(),o,'indeterminate' if hidden else 'fail','ISO1 Table165 Hidden bit2 prevents display/print. Visibility is outside this qualified appearance model, so it cannot prove simultaneous repetition.')
# Reusing a page execution context must not supply an AP with unknown inherited text state.
ink=b'BT 1 0 0 1 1 1 Tm (A) Tj ET'
for mode,has_do,has_ap,explicit_tf,expected in [('page-only',True,False,False,'pass'),('ap-only-unknown-font',False,True,False,'indeterminate'),('page-and-ap-unknown-font',True,True,False,'indeterminate'),('page-and-ap-explicit-font',True,True,True,'pass')]:
 o=read_original('painted-whole-correct-a')
 o[20]=form(ink.replace(b'BT ',b'BT /F1 10 Tf ') if explicit_tf else ink,whole=True,resources=b'<</Font <</F1 100 0 R>>>>')
 o[10]=stream(b'BT /F1 10 Tf ET'+(b' /Fm Do' if has_do else b''))
 o[3]=b'<</Type /Page /Parent 2 0 R /MediaBox [0 0 100 100] /Resources <</Font <</F1 100 0 R>> /XObject <</Fm 20 0 R>>>> /Contents 10 0 R'+(b' /Annots [30 0 R]' if has_ap else b'')+b'>>'
 if has_ap:o[30]=annot()
 add('closure-inherited-state-'+mode,o,expected,'Frozen contract: an unexecuted Form needing unknown inherited font state is IND. Prior page Do validation cannot establish the initial text state of a separate AP entry point.')
(D/'adjacent-inputs.json').write_text(json.dumps(cases,indent=2)+'\n')
env=os.environ.copy();env.pop('QPDF_CACHE_DIRECTORY',None)
def run(case):
 out=D/(case['name']+'-out');cmd=[sys.executable,str(O),str(R),case['input'],'structure-content',str(out)]
 c=subprocess.run(cmd,cwd=D,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=40)
 (D/(case['name']+'.stdout')).write_bytes(c.stdout);(D/(case['name']+'.stderr')).write_bytes(c.stderr)
 report=out/'result.properties';props=dict(line.split('=',1) for line in report.read_text().splitlines() if '=' in line) if report.exists() else {}
 result={**case,'command':cmd,'returncode':c.returncode,'result':props,'matches':props.get('standards')==case['expected'],'observer_after':hashlib.sha256(O.read_bytes()).hexdigest(),'input_after':hashlib.sha256(Path(case['input']).read_bytes()).hexdigest()}
 (D/(case['name']+'.run.json')).write_text(json.dumps(result,indent=2)+'\n');return result
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(run,cases))
(D/'adjacent-summary.json').write_text(json.dumps(results,indent=2)+'\n')
for r in results:print(r['name'],r['expected'],'=>',r['result'].get('standards'),r['result'].get('finding'),flush=True)
print('TOTAL',len(results),'MISMATCH',sum(not r['matches'] for r in results))
