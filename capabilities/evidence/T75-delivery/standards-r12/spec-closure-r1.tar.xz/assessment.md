# Incremental structure-content closure

Observer27377172a2552a30855ff216ad166d03c0cc9829a7ddbe339f206b020564a689; contract4d59e4dc362e53ba84006f2ab51d5efb180824ec5d90a8546f975da853d18daf.

The original four finding families are CLOSED: all53 byte-identical PDFs satisfy the frozen contract after4 documented expectation tightenings. All5 Sources PASS. Adding only an AP dictionary association to the original count fixtures gives128 PASS and129 limit INDETERMINATE.

14 immediate adjacent controls produced3 new findings:

- Ordinary AP root P is not checked unless its owner appears in K/StmOwn. A.Annots plus P=B incorrectly PASS (observer1210-1219; ISO1 Table164).
- Hidden(F=2) AP is counted as simultaneous rendering with a page Do and incorrectly causes hard failure. Hidden prevents display and printing; retain an explicit visibility boundary (1219,1581-1592; ISO1 Table165).
- A page+stream context already validated with a selected page font suppresses independent AP validation. A Form without Tf becomes false PASS as an AP only when a page Do was also present; AP-only remains correctly IND and explicit Tf PASS (1235-1241; frozen unknown-inherited-state contract and ISO1 8.10.1).

No product changes, Native algorithm review or Maven. All67 calls and tool/input/observer identities retained. See assessment.json, replay-summary.json, adjacent-summary.json and individual *.run.json / *-out. This is not a final clean-context gate.
