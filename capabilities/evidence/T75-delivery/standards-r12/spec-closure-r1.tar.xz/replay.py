from pathlib import Path
import concurrent.futures,hashlib,json,os,subprocess,sys
D=Path(__file__).resolve().parent
OLD=Path('/tmp/t75-spec-structure-content.453_lsec')
R=Path('/home/ubuntu/IdeaProjects/open-pdf')
O=D/'observer.py'
changes={
 'mcr-definition-only-page-3':('indeterminate','New frozen contract: bare Pg/Form definition without proven page Do/AP association is unqualified.'),
 'mcr-definition-only-page-4':('indeterminate','New frozen contract: bare Pg/Form definition without proven page Do/AP association is unqualified.'),
 'definition-count-128':('indeterminate','Original 128-stream graph has no page Do/AP entry; exact-limit countercheck will add only an AP dictionary relationship.'),
 'ap-disjoint-alternatives':('indeterminate','New frozen contract makes all distinct alternatives of one owner unqualified for counting, including disjoint descendants.')}
prior=[]
for name in ['summary.json','adjacent-summary.json','painted-summary.json']:prior.extend(json.loads((OLD/name).read_text()))
assert len(prior)==53
cases=[]
for p in prior:
 f=D/Path(p['input']).name;b=Path(p['input']).read_bytes();assert hashlib.sha256(b).hexdigest()==p['input_sha256'];f.write_bytes(b)
 expected,note=changes.get(p['name'],(p['expected'],'Original normative/profile expectation unchanged.'))
 cases.append({'name':p['name'],'input':str(f),'original_input':p['input'],'input_sha256':p['input_sha256'],'prior_expectation':p['expected'],'prior_observed':p['result']['standards'],'expected':expected,'expectation_note':note})
(D/'replay-inputs.json').write_text(json.dumps(cases,indent=2)+'\n')
env=os.environ.copy();env.pop('QPDF_CACHE_DIRECTORY',None)
def run(case):
 out=D/(case['name']+'-out');cmd=[sys.executable,str(O),str(R),case['input'],'structure-content',str(out)]
 c=subprocess.run(cmd,env=env,cwd=D,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=40)
 (D/(case['name']+'.stdout')).write_bytes(c.stdout);(D/(case['name']+'.stderr')).write_bytes(c.stderr)
 report=out/'result.properties';props=dict(line.split('=',1) for line in report.read_text().splitlines() if '=' in line) if report.exists() else {}
 result={**case,'command':cmd,'returncode':c.returncode,'result':props,'matches':props.get('standards')==case['expected'],'observer_after':hashlib.sha256(O.read_bytes()).hexdigest(),'input_after':hashlib.sha256(Path(case['input']).read_bytes()).hexdigest()}
 (D/(case['name']+'.run.json')).write_text(json.dumps(result,indent=2)+'\n');return result
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(run,cases))
(D/'replay-summary.json').write_text(json.dumps(results,indent=2)+'\n')
for r in results:print(r['name'],r['expected'],'=>',r['result'].get('standards'),r['result'].get('finding'),flush=True)
print('TOTAL',len(results),'MISMATCH',sum(not r['matches'] for r in results))
