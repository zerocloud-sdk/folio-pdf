from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time
ROOT=Path('/home/ubuntu/IdeaProjects/open-pdf');HERE=Path(__file__).resolve().parent
SHA='1b73ff6d9a424973f15ffbfb89d7fa84e26d611782ccc52544779abb9da5660b'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert sha(HERE/'observer.py')==SHA
ENV=dict(os.environ);ENV.pop('QPDF_CACHE_DIRECTORY',None)
files=[HERE/'observer.py',HERE/'contract.md',Path(sys.executable).resolve(),ROOT/'.build-cache/qpdf/12.4.0/bin/qpdf']+[ROOT/'scripts'/x for x in ['qpdf-pin.properties','container-bin/qpdf','t13-qpdf-runtime.sha256']]
for line in (ROOT/'scripts/t13-qpdf-runtime.sha256').read_text().splitlines():files.append(ROOT/'.build-cache/qpdf/12.4.0'/line.split('  ',1)[1])
identities={str(p):sha(p) for p in files};rows=[]
def stream(dictionary=b'<<>>',data=b''):
 assert dictionary.endswith(b'>>')
 return dictionary[:-2]+b'/Length '+str(len(data)).encode()+b'>>\nstream\n'+data+b'\nendstream'
def objects():
 return [b'<</Type/Catalog/Pages 2 0 R/StructTreeRoot 4 0 R/MarkInfo<</Marked true>>>>',b'<</Type/Pages/Kids[3 0 R]/Count 1>>',b'<</Type/Page/Parent 2 0 R/MediaBox[0 0 100 100]/Resources<<>>/Contents 7 0 R/StructParents 0>>',b'<</Type/StructTreeRoot/K 5 0 R/ParentTree 6 0 R/ParentTreeNextKey 1>>',b'<</Type/StructElem/S/P/P 4 0 R/Pg 3 0 R/K 0/Lang(en)>>',b'<</Nums[0[5 0 R]]>>',stream(data=b'/P<</MCID 0>>BDC EMC'),b'null']
def pdf(parts):
 data=bytearray(b'%PDF-2.0\n');offsets=[0]
 for i,body in enumerate(parts,1):offsets.append(len(data));data.extend(str(i).encode()+b' 0 obj\n'+body+b'\nendobj\n')
 xref=len(data);data.extend(b'xref\n0 '+str(len(offsets)).encode()+b'\n0000000000 65535 f \n')
 for off in offsets[1:]:data.extend(('%010d 00000 n \n'%off).encode())
 data.extend(b'trailer\n<</Size '+str(len(offsets)).encode()+b'/Root 1 0 R>>\nstartxref\n'+str(xref).encode()+b'\n%%EOF\n');return data

def run(label,parts,scope):
 path=HERE/(label+'.pdf');data=pdf(parts);path.write_bytes(data);out=HERE/(label+'-'+scope+'-output');args=[sys.executable,str(HERE/'observer.py'),str(ROOT),str(path),scope,str(out)];started=time.monotonic()
 with (HERE/(out.name+'.stdout')).open('wb') as stdout,(HERE/(out.name+'.stderr')).open('wb') as stderr:
  p=subprocess.run(args,cwd=HERE,env=ENV,stdout=stdout,stderr=stderr,timeout=40)
 prop=out/'result.properties';result=dict(line.split('=',1) for line in prop.read_text().splitlines() if line and not line.startswith(('#','!'))) if prop.exists() else None
 row={'label':label,'scope':scope,'command':args,'cwd':str(HERE),'exit':p.returncode,'elapsed':time.monotonic()-started,'input-sha256':sha(path),'result':result,'files':{str(f.relative_to(out)):sha(f) for f in out.iterdir() if f.is_file()}}
 rows.append(row);(HERE/(label+'-'+scope+'-result.json')).write_text(json.dumps(row,indent=2)+'\n');print(label,scope,p.returncode,result.get('standards') if result else None,result.get('finding') if result else None,flush=True)


def change(num, before, after):
 p=objects();assert p[num-1].count(before)==1;p[num-1]=p[num-1].replace(before,after);return p
def emit(label,p,scope='structure-content'):
 run(label,p,scope)


def form_objects(typed=True, body=b'q Q'):
 p=objects();p[2]=p[2].replace(b'/Resources<<>>',b'/Resources<</XObject<</Fm 8 0 R>>>>').replace(b'/StructParents 0',b'')
 p[4]=p[4].replace(b'/K 0',b'/K<</Type/OBJR/Obj 8 0 R>>');p[5]=b'<</Nums[0 5 0 R]>>';p[6]=stream(data=b'/Fm Do')
 p[7]=stream((b'<</Type/XObject' if typed else b'<<')+b'/Subtype/Form/BBox[0 0 10 10]/Resources<<>>/StructParent 0>>',body);return p
for name,typed in [('whole-form-typed',True),('whole-form-optional-type',False)]:
 emit(name,form_objects(typed))
 p=form_objects(typed);p[6]=stream(data=b'q Q');emit(name+'-unexecuted',p)
for name,p in [
 ('whole-form-type-null',form_objects()),
 ('whole-form-type-indirect',form_objects()),
 ('whole-image-without-do',form_objects()),
 ('dictionary-image-without-do',form_objects())]:
 if name.endswith('null'):p[7]=p[7].replace(b'/Type/XObject',b'/Type null')
 elif name.endswith('indirect'):p[7]=p[7].replace(b'/Type/XObject',b'/Type 9 0 R');p.append(b'/XObject')
 else:
  p[6]=stream(data=b'q Q')
  dictionary=b'<</Type/XObject/Subtype/Image/Width 1/Height 1/ColorSpace/DeviceGray/BitsPerComponent 8/StructParent 0>>'
  p[7]=stream(dictionary,b'\x00') if name.startswith('whole') else dictionary
 emit(name,p)
for name,body,slots in [
 ('defined-unused-mcid-null-slot',b'/P<</MCID 0>>BDC EMC /Span<</MCID 1>>BDC EMC',b'0[5 0 R null]'),
 ('defined-unused-mcid-claimed-slot',b'/P<</MCID 0>>BDC EMC /Span<</MCID 1>>BDC EMC',b'0[5 0 R 5 0 R]'),
 ('undefined-mcid-extra-slot',b'/P<</MCID 0>>BDC EMC',b'0[5 0 R 5 0 R]')]:
 p=objects();p[6]=stream(data=body);p[5]=b'<</Nums['+slots+b']>>';emit(name,p)
for name,page in [('direct-null-element-pg',b'null'),('indirect-null-element-pg',b'8 0 R')]:
 p=change(5,b'/Pg 3 0 R',b'/Pg '+page);p[4]=p[4].replace(b'/K 0',b'/K<</Type/MCR/Pg 3 0 R/MCID 0>>');emit(name,p)
for name,ids in [('mcr-direct-null-stmown',b'null'),('mcr-indirect-null-stmown',b'8 0 R')]:
 p=change(5,b'/K 0',b'/K<</Type/MCR/MCID 0/StmOwn '+ids+b'>>');emit(name,p)

after={str(p):sha(p) for p in files};(HERE/'adjacency-identity.json').write_text(json.dumps({'before':identities,'after':after,'unchanged':identities==after,'probe-sha256':sha(Path(__file__))},indent=2)+'\n');(HERE/'adjacency-results.json').write_text(json.dumps(rows,indent=2)+'\n');print(HERE,'identities unchanged',identities==after,flush=True)
