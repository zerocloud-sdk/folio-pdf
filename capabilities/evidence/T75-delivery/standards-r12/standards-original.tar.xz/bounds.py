from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time
ROOT=Path('/home/ubuntu/IdeaProjects/open-pdf');HERE=Path(__file__).resolve().parent
SHA='1b73ff6d9a424973f15ffbfb89d7fa84e26d611782ccc52544779abb9da5660b'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert sha(HERE/'observer.py')==SHA
ENV=dict(os.environ);ENV.pop('QPDF_CACHE_DIRECTORY',None)
files=[HERE/'observer.py',HERE/'contract.md',Path(sys.executable).resolve(),ROOT/'.build-cache/qpdf/12.4.0/bin/qpdf']+[ROOT/'scripts'/x for x in ['qpdf-pin.properties','container-bin/qpdf','t13-qpdf-runtime.sha256']]
for line in (ROOT/'scripts/t13-qpdf-runtime.sha256').read_text().splitlines():files.append(ROOT/'.build-cache/qpdf/12.4.0'/line.split('  ',1)[1])
identities={str(p):sha(p) for p in files};rows=[]
def stream(dictionary=b'<<>>',data=b''):
 assert dictionary.endswith(b'>>')
 return dictionary[:-2]+b'/Length '+str(len(data)).encode()+b'>>\nstream\n'+data+b'\nendstream'
def objects():
 return [b'<</Type/Catalog/Pages 2 0 R/StructTreeRoot 4 0 R/MarkInfo<</Marked true>>>>',b'<</Type/Pages/Kids[3 0 R]/Count 1>>',b'<</Type/Page/Parent 2 0 R/MediaBox[0 0 100 100]/Resources<<>>/Contents 7 0 R/StructParents 0>>',b'<</Type/StructTreeRoot/K 5 0 R/ParentTree 6 0 R/ParentTreeNextKey 1>>',b'<</Type/StructElem/S/P/P 4 0 R/Pg 3 0 R/K 0/Lang(en)>>',b'<</Nums[0[5 0 R]]>>',stream(data=b'/P<</MCID 0>>BDC EMC'),b'null']
def pdf(parts):
 data=bytearray(b'%PDF-2.0\n');offsets=[0]
 for i,body in enumerate(parts,1):offsets.append(len(data));data.extend(str(i).encode()+b' 0 obj\n'+body+b'\nendobj\n')
 xref=len(data);data.extend(b'xref\n0 '+str(len(offsets)).encode()+b'\n0000000000 65535 f \n')
 for off in offsets[1:]:data.extend(('%010d 00000 n \n'%off).encode())
 data.extend(b'trailer\n<</Size '+str(len(offsets)).encode()+b'/Root 1 0 R>>\nstartxref\n'+str(xref).encode()+b'\n%%EOF\n');return data

def run(label,parts,scope):
 path=HERE/(label+'.pdf');data=pdf(parts);path.write_bytes(data);out=HERE/(label+'-'+scope+'-output');args=[sys.executable,str(HERE/'observer.py'),str(ROOT),str(path),scope,str(out)];started=time.monotonic()
 with (HERE/(out.name+'.stdout')).open('wb') as stdout,(HERE/(out.name+'.stderr')).open('wb') as stderr:
  p=subprocess.run(args,cwd=HERE,env=ENV,stdout=stdout,stderr=stderr,timeout=40)
 prop=out/'result.properties';result=dict(line.split('=',1) for line in prop.read_text().splitlines() if line and not line.startswith(('#','!'))) if prop.exists() else None
 row={'label':label,'scope':scope,'command':args,'cwd':str(HERE),'exit':p.returncode,'elapsed':time.monotonic()-started,'input-sha256':sha(path),'result':result,'files':{str(f.relative_to(out)):sha(f) for f in out.iterdir() if f.is_file()}}
 rows.append(row);(HERE/(label+'-'+scope+'-result.json')).write_text(json.dumps(row,indent=2)+'\n');print(label,scope,p.returncode,result.get('standards') if result else None,result.get('finding') if result else None,flush=True)


def change(num, before, after):
 p=objects();assert p[num-1].count(before)==1;p[num-1]=p[num-1].replace(before,after);return p
def emit(label,p,scope='structure-content'):
 run(label,p,scope)


def chain(total,executed=True,invalid=False):
 p=objects();form_refs=list(range(8,8+total));last=form_refs[-1]
 p[2]=p[2].replace(b'/Resources<<>>',b'/Resources<</XObject<</Fm 8 0 R>>>>').replace(b'/StructParents 0',b'')
 p[4]=p[4].replace(b'/K 0',b'/K<</Type/MCR/Stm '+str(last).encode()+b' 0 R/MCID 0>>');p[6]=stream(data=b'/Fm Do' if executed else b'q Q');p=p[:7]
 for ref in form_refs:
  tail=ref==last;body=b'/P<</MCID 0>>BDC EMC' if tail else b'/Next Do'
  if invalid and tail:body=b'/P<</MCID 1>>BDC EMC'
  resources=b'<<>>' if tail else b'<</XObject<</Next '+str(ref+1).encode()+b' 0 R>>>>'
  dictionary=b'<</Type/XObject/Subtype/Form/BBox[0 0 10 10]/Resources '+resources+(b'/StructParents 0' if tail else b'')+b'>>'
  p.append(stream(dictionary,body))
 return p
for n in (126,127,128):emit('executed-form-chain-'+str(n),chain(n))
# The whole unexecuted entry Form and its descendant are independently referenced; only the leaf owns MCIDs.
for name,body in [('unexecuted-whole-definition-missing-mcid',b'/P<</MCID 1>>BDC EMC'),('unexecuted-whole-definition-valid-mcid',b'/P<</MCID 0>>BDC EMC')]:
 p=chain(2,False);p[3]=p[3].replace(b'/ParentTreeNextKey 1',b'/ParentTreeNextKey 2')
 p[4]=p[4].replace(b'/K<</Type/MCR/Stm 9 0 R/MCID 0>>',b'/K[<</Type/MCR/Stm 9 0 R/MCID 0>><</Type/OBJR/Obj 8 0 R>>]')
 p[5]=b'<</Nums[0[5 0 R]1 5 0 R]>>';p[7]=p[7].replace(b'/Length ',b'/StructParent 1/Length ');p[8]=stream(b'<</Type/XObject/Subtype/Form/BBox[0 0 10 10]/Resources<<>>/StructParents 0>>',body)
 emit(name,p)
# Constant graph with each definition invoking the following Form twice must stop under 128 parsed stream occurrences.
p=chain(12);p[4]=p[4].replace(b'/K<</Type/MCR/Stm 19 0 R/MCID 0>>',b'/K<</Type/OBJR/Obj 8 0 R>>');p[5]=b'<</Nums[0 5 0 R]>>';p[7]=p[7].replace(b'/Length ',b'/StructParent 0/Length ');p[-1]=p[-1].replace(b'/StructParents 0',b'')
for i in range(7,len(p)-1):p[i]=p[i].replace(b'/Length 8',b'/Length 17').replace(b'/Next Do\nendstream',b'/Next Do /Next Do\nendstream')
emit('definition-exponential-bounded',p)

after={str(p):sha(p) for p in files};(HERE/'bounds-identity.json').write_text(json.dumps({'before':identities,'after':after,'unchanged':identities==after,'probe-sha256':sha(Path(__file__))},indent=2)+'\n');(HERE/'bounds-results.json').write_text(json.dumps(rows,indent=2)+'\n');print(HERE,'identities unchanged',identities==after,flush=True)
