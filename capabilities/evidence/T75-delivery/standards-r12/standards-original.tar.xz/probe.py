from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time
ROOT=Path('/home/ubuntu/IdeaProjects/open-pdf');HERE=Path(__file__).resolve().parent
SHA='1b73ff6d9a424973f15ffbfb89d7fa84e26d611782ccc52544779abb9da5660b'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert sha(HERE/'observer.py')==SHA
ENV=dict(os.environ);ENV.pop('QPDF_CACHE_DIRECTORY',None)
files=[HERE/'observer.py',HERE/'contract.md',Path(sys.executable).resolve(),ROOT/'.build-cache/qpdf/12.4.0/bin/qpdf']+[ROOT/'scripts'/x for x in ['qpdf-pin.properties','container-bin/qpdf','t13-qpdf-runtime.sha256']]
for line in (ROOT/'scripts/t13-qpdf-runtime.sha256').read_text().splitlines():files.append(ROOT/'.build-cache/qpdf/12.4.0'/line.split('  ',1)[1])
identities={str(p):sha(p) for p in files};rows=[]
def stream(dictionary=b'<<>>',data=b''):
 assert dictionary.endswith(b'>>')
 return dictionary[:-2]+b'/Length '+str(len(data)).encode()+b'>>\nstream\n'+data+b'\nendstream'
def objects():
 return [b'<</Type/Catalog/Pages 2 0 R/StructTreeRoot 4 0 R/MarkInfo<</Marked true>>>>',b'<</Type/Pages/Kids[3 0 R]/Count 1>>',b'<</Type/Page/Parent 2 0 R/MediaBox[0 0 100 100]/Resources<<>>/Contents 7 0 R/StructParents 0>>',b'<</Type/StructTreeRoot/K 5 0 R/ParentTree 6 0 R/ParentTreeNextKey 1>>',b'<</Type/StructElem/S/P/P 4 0 R/Pg 3 0 R/K 0/Lang(en)>>',b'<</Nums[0[5 0 R]]>>',stream(data=b'/P<</MCID 0>>BDC EMC'),b'null']
def pdf(parts):
 data=bytearray(b'%PDF-2.0\n');offsets=[0]
 for i,body in enumerate(parts,1):offsets.append(len(data));data.extend(str(i).encode()+b' 0 obj\n'+body+b'\nendobj\n')
 xref=len(data);data.extend(b'xref\n0 '+str(len(offsets)).encode()+b'\n0000000000 65535 f \n')
 for off in offsets[1:]:data.extend(('%010d 00000 n \n'%off).encode())
 data.extend(b'trailer\n<</Size '+str(len(offsets)).encode()+b'/Root 1 0 R>>\nstartxref\n'+str(xref).encode()+b'\n%%EOF\n');return data

def run(label,parts,scope):
 path=HERE/(label+'.pdf');data=pdf(parts);path.write_bytes(data);out=HERE/(label+'-'+scope+'-output');args=[sys.executable,str(HERE/'observer.py'),str(ROOT),str(path),scope,str(out)];started=time.monotonic()
 with (HERE/(out.name+'.stdout')).open('wb') as stdout,(HERE/(out.name+'.stderr')).open('wb') as stderr:
  p=subprocess.run(args,cwd=HERE,env=ENV,stdout=stdout,stderr=stderr,timeout=40)
 prop=out/'result.properties';result=dict(line.split('=',1) for line in prop.read_text().splitlines() if line and not line.startswith(('#','!'))) if prop.exists() else None
 row={'label':label,'scope':scope,'command':args,'cwd':str(HERE),'exit':p.returncode,'elapsed':time.monotonic()-started,'input-sha256':sha(path),'result':result,'files':{str(f.relative_to(out)):sha(f) for f in out.iterdir() if f.is_file()}}
 rows.append(row);(HERE/(label+'-'+scope+'-result.json')).write_text(json.dumps(row,indent=2)+'\n');print(label,scope,p.returncode,result.get('standards') if result else None,result.get('finding') if result else None,flush=True)


def change(num, before, after):
 p=objects();assert p[num-1].count(before)==1;p[num-1]=p[num-1].replace(before,after);return p
def emit(label,p,scope='structure-content'):
 run(label,p,scope)

emit('page-mcid-original',objects())
for name,k in [
 ('mcr-implicit-stm',b'<</Type/MCR/MCID 0>>'),
 ('mcr-direct-null-stm',b'<</Type/MCR/MCID 0/Stm null>>'),
 ('mcr-indirect-null-stm',b'<</Type/MCR/MCID 0/Stm 8 0 R>>'),
 ('mcr-dangling-stm',b'<</Type/MCR/MCID 0/Stm 99 0 R>>'),
 ('mcr-direct-null-pg',b'<</Type/MCR/MCID 0/Pg null>>'),
 ('mcr-indirect-null-pg',b'<</Type/MCR/MCID 0/Pg 8 0 R>>'),
 ('mcr-real-id',b'<</Type/MCR/MCID 0.0>>'),
 ('mcr-wrong-obj-type',b'<</Type/MCR/MCID 0/Stm 3 0 R>>')]:emit(name,change(5,b'/K 0',b'/K '+k))
for name,replace in [('other-parent-null',b'/StructParent null'),('other-parent-indirect-null',b'/StructParent 8 0 R')]:
 emit(name,change(3,b'/StructParents 0',b'/StructParents 0'+replace))
for name,slot in [('extra-parent-slot',b'5 0 R'),('unused-parent-null-slot',b'null')]:
 emit(name,change(6,b'0[5 0 R]',b'0[5 0 R '+slot+b']'))

def annotated(obj=b'<</Type/Annot/Subtype/Text/Rect[0 0 10 10]/P 3 0 R/StructParent 0>>'):
 p=objects();p[2]=p[2].replace(b'/StructParents 0',b'/Annots[8 0 R]');p[4]=p[4].replace(b'/K 0',b'/K<</Type/OBJR/Obj 8 0 R>>');p[5]=b'<</Nums[0 5 0 R]>>';p[6]=stream(data=b'q Q');p[7]=obj;return p
for name,obj in [
 ('annotation-original',b'<</Type/Annot/Subtype/Text/Rect[0 0 10 10]/P 3 0 R/StructParent 0>>'),
 ('annotation-missing-p',b'<</Type/Annot/Subtype/Text/Rect[0 0 10 10]/StructParent 0>>'),
 ('annotation-direct-null-p',b'<</Type/Annot/Subtype/Text/Rect[0 0 10 10]/P null/StructParent 0>>'),
 ('annotation-indirect-null-p',b'<</Type/Annot/Subtype/Text/Rect[0 0 10 10]/P 9 0 R/StructParent 0>>'),
 ('annotation-dictionary-as-stream',stream(b'<</Type/Annot/Subtype/Text/Rect[0 0 10 10]/P 3 0 R/StructParent 0>>')),
 ('xobject-dictionary-not-stream',b'<</Type/XObject/Subtype/Image/Width 1/Height 1/ColorSpace/DeviceGray/BitsPerComponent 8/StructParent 0>>'),
 ('xobject-stream-positive',stream(b'<</Type/XObject/Subtype/Image/Width 1/Height 1/ColorSpace/DeviceGray/BitsPerComponent 8/StructParent 0>>',b'\x00'))]:
 p=annotated(obj);p.append(b'null');emit(name,p)

after={str(p):sha(p) for p in files};(HERE/'identity.json').write_text(json.dumps({'before':identities,'after':after,'unchanged':identities==after,'probe-sha256':sha(Path(__file__))},indent=2)+'\n');(HERE/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(HERE,'identities unchanged',identities==after,flush=True)
