# AP closure r2 (incremental)

CLEAN for the three bounded behavioral findings.31/31 actual public CLI observations match expectations:15 PASS,6 intended FAIL,10 explicit INDETERMINATE. Observer b016df86f5cf2735aa272d539b721a288da42ba2edc00192db084c9cf7fce8e6 and all tool/source/input identities remained unchanged.

- Ordinary discovered AP owner P now agrees with its containing page; matching/omitted/null P pass, wrong page/numeric P fail.
- Historical Hidden(F2) input is now honestly IND. One-byte F2-to-F0 variants distinguish single-call PASS from repeated-call FAIL; Invisible/NoView/ToggleNoView retain IND while Print/ReadOnly positives pass.
- A previous page-selected font no longer validates an AP by cache reuse. Unknown AP state is IND; explicit local Tf and a real AP parent Tf followed by child Do remain supported.

All5 byte-identical Sources pass. AP-associated128-stream graph passes;129 is a stream-limit IND. Missing-MCID controls remain FAIL; whole-annotation/AP overlap remains IND.

Minor documentation citation correction reported separately: ISO1 Table164 belongs to12.5.2;Table165 to12.5.3. It does not reopen a behavioral finding.

All31 PDFs, argv/environment, raw reports, qpdf graphs and identities are retained. No repository edit, Native algorithm review, Maven or shared compilation. Not the final clean-context #75 gate.
