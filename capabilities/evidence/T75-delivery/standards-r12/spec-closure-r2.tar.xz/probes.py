from pathlib import Path
import concurrent.futures,hashlib,json,os,re,subprocess,sys
D=Path(__file__).resolve().parent
PRIOR=Path('/tmp/t75-spec-structure-content-closure.xo706wc1')
ORIGINAL=Path('/tmp/t75-spec-structure-content.453_lsec')
exec(compile((ORIGINAL/'probe.py').read_text().split('CASES=[]')[0],str(ORIGINAL/'probe.py'),'exec'))
cases=[]
def add(name,data,expected,provenance):
 if isinstance(data,dict):data=pdf(data)
 p=D/(name+'.pdf');p.write_bytes(data)
 cases.append({'name':name,'input':str(p),'input_sha256':hashlib.sha256(data).hexdigest(),'expected':expected,'provenance':provenance})
def objects(name):
 data=(PRIOR/(name+'.pdf')).read_bytes()
 return {int(n):body for n,body in re.findall(rb'(?m)^(\d+) 0 obj\n(.*?)\nendobj\n',data,re.S)}
# Exact originals include all three findings, their contrasts, and AP-associated 128/129 limits.
for prior in json.loads((PRIOR/'adjacent-summary.json').read_text()):
 data=Path(prior['input']).read_bytes();assert hashlib.sha256(data).hexdigest()==prior['input_sha256']
 add(prior['name'],data,prior['expected'],{'original_path':prior['input'],'original_sha256':prior['input_sha256'],'previous_observed':prior['result']['standards'],'byte_identical':True})
for prior in json.loads((PRIOR/'replay-summary.json').read_text()):
 if prior['name'].startswith('source-'):
  data=Path(prior['input']).read_bytes();assert hashlib.sha256(data).hexdigest()==prior['input_sha256']
  add(prior['name'],data,'pass',{'original_path':prior['input'],'original_sha256':prior['input_sha256'],'byte_identical':True})
# Historical F2 negative becomes IND; the only byte changed in its F0 derivative is 2 -> 0.
historical=(PRIOR/'closure-hidden-ap-true.pdf').read_bytes()
assert historical.count(b'/F 2')==1
normal=historical.replace(b'/F 2',b'/F 0')
assert len(normal)==len(historical) and sum(a!=b for a,b in zip(normal,historical))==1
add('r2-original-f2-to-f0-repeat',normal,'fail',{'source':str(PRIOR/'closure-hidden-ap-true.pdf'),'source_sha256':hashlib.sha256(historical).hexdigest(),'mutation':'Only one byte: annotation /F 2 -> /F 0; xref/Length unchanged.','byte_differences':1})
# A newly authored F2 positive counterpart, then its one-byte F0 mutation.
o=objects('closure-normal-owner-p-matching');o[30]=o[30].replace(b'/Subtype /Stamp',b'/Subtype /Stamp /F 2')
hidden_single=pdf(o);normal_single=hidden_single.replace(b'/F 2',b'/F 0')
assert hidden_single.count(b'/F 2')==1 and sum(a!=b for a,b in zip(hidden_single,normal_single))==1
add('r2-single-call-hidden-f2',hidden_single,'indeterminate',{'source':str(PRIOR/'closure-normal-owner-p-matching.pdf'),'mutation':'Add F2 to the original ordinary owner; one normal AP child Do, no page Do.'})
add('r2-single-call-f2-to-f0',normal_single,'pass',{'source':'r2-single-call-hidden-f2.pdf','source_sha256':hashlib.sha256(hidden_single).hexdigest(),'mutation':'Only one byte: /F 2 -> /F 0.','byte_differences':1})
# Only the visibility flags added by this increment and unaffected simple flags.
for name,flags,expected in [('invisible',1,'indeterminate'),('no-view',32,'indeterminate'),('toggle-no-view',256,'indeterminate'),('print',4,'pass'),('read-only',64,'pass')]:
 o=objects('closure-normal-owner-p-matching');o[30]=o[30].replace(b'/Subtype /Stamp',b'/Subtype /Stamp /F '+str(flags).encode())
 add('r2-flag-'+name,o,expected,{'basis':'ISO1 Table165 and the exact frozen visibility boundary; ordinary AP-only one invocation.'})
# Direct adjacency to discovered optional owner P validation.
for name,value,expected in [('null',b'null','pass'),('numeric',b'3','fail')]:
 o=objects('closure-normal-owner-p-matching');assert o[30].count(b'/P 3 0 R')==1;o[30]=o[30].replace(b'/P 3 0 R',b'/P '+value)
 add('r2-owner-p-'+name,o,expected,{'basis':'Table164 P is an optional indirect page reference; null equals omission, a direct number is not a page reference.'})
# The separate AP root may establish the child font through a real parent Do context.
for selected in [False,True]:
 o=objects('closure-inherited-state-page-and-ap-unknown-font')
 o[30]=annot(21)
 o[21]=stream((b'BT /F1 10 Tf ET ' if selected else b'')+b'/Child Do',b'/Type /XObject /Subtype /Form /BBox [0 0 10 10] /Resources <</Font <</F1 100 0 R>> /XObject <</Child 20 0 R>>>>')
 add('r2-nested-ap-'+('selected-font' if selected else 'unknown-font'),o,'pass' if selected else 'indeterminate',{'basis':'The AP root is independently validated; its own Tf can establish the font inherited by its child Do. A cached page font cannot do so.'})
assert len(cases)==31,len(cases)
(D/'inputs.json').write_text(json.dumps(cases,indent=2)+'\n')
env=os.environ.copy();env.pop('QPDF_CACHE_DIRECTORY',None)
def run(case):
 out=D/(case['name']+'-out');cmd=[sys.executable,str(O),str(R),case['input'],'structure-content',str(out)]
 c=subprocess.run(cmd,env=env,cwd=D,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=40)
 (D/(case['name']+'.stdout')).write_bytes(c.stdout);(D/(case['name']+'.stderr')).write_bytes(c.stderr)
 report=out/'result.properties';props=dict(line.split('=',1) for line in report.read_text().splitlines() if '=' in line) if report.exists() else {}
 result={**case,'argv':cmd,'cwd':str(D),'environment_note':'QPDF_CACHE_DIRECTORY removed; all other environment inherited unchanged.','returncode':c.returncode,'result':props,'matches':props.get('standards')==case['expected'],'observer_after':hashlib.sha256(O.read_bytes()).hexdigest(),'input_after':hashlib.sha256(Path(case['input']).read_bytes()).hexdigest()}
 (D/(case['name']+'.run.json')).write_text(json.dumps(result,indent=2)+'\n');return result
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(run,cases))
(D/'summary.json').write_text(json.dumps(results,indent=2)+'\n')
for r in results:print(r['name'],r['expected'],'=>',r['result'].get('standards'),r['result'].get('finding'),flush=True)
print('TOTAL',len(results),'MISMATCH',sum(not r['matches'] for r in results))
