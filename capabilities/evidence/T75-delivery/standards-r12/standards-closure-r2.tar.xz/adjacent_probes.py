from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time
ROOT=Path('/home/ubuntu/IdeaProjects/open-pdf');HERE=Path(__file__).resolve().parent
SHA='b016df86f5cf2735aa272d539b721a288da42ba2edc00192db084c9cf7fce8e6'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert sha(HERE/'observer.py')==SHA
ENV=dict(os.environ);ENV.pop('QPDF_CACHE_DIRECTORY',None)
files=[HERE/'observer.py',HERE/'contract.md',Path(sys.executable).resolve(),ROOT/'.build-cache/qpdf/12.4.0/bin/qpdf']+[ROOT/'scripts'/x for x in ['qpdf-pin.properties','container-bin/qpdf','t13-qpdf-runtime.sha256']]
for line in (ROOT/'scripts/t13-qpdf-runtime.sha256').read_text().splitlines():files.append(ROOT/'.build-cache/qpdf/12.4.0'/line.split('  ',1)[1])
identities={str(p):sha(p) for p in files};rows=[]
def stream(dictionary=b'<<>>',data=b''):
 assert dictionary.endswith(b'>>')
 return dictionary[:-2]+b'/Length '+str(len(data)).encode()+b'>>\nstream\n'+data+b'\nendstream'
def objects():
 return [b'<</Type/Catalog/Pages 2 0 R/StructTreeRoot 4 0 R/MarkInfo<</Marked true>>>>',b'<</Type/Pages/Kids[3 0 R]/Count 1>>',b'<</Type/Page/Parent 2 0 R/MediaBox[0 0 100 100]/Resources<<>>/Contents 7 0 R/StructParents 0>>',b'<</Type/StructTreeRoot/K 5 0 R/ParentTree 6 0 R/ParentTreeNextKey 1>>',b'<</Type/StructElem/S/P/P 4 0 R/Pg 3 0 R/K 0/Lang(en)>>',b'<</Nums[0[5 0 R]]>>',stream(data=b'/P<</MCID 0>>BDC EMC'),b'null']
def pdf(parts):
 data=bytearray(b'%PDF-2.0\n');offsets=[0]
 for i,body in enumerate(parts,1):offsets.append(len(data));data.extend(str(i).encode()+b' 0 obj\n'+body+b'\nendobj\n')
 xref=len(data);data.extend(b'xref\n0 '+str(len(offsets)).encode()+b'\n0000000000 65535 f \n')
 for off in offsets[1:]:data.extend(('%010d 00000 n \n'%off).encode())
 data.extend(b'trailer\n<</Size '+str(len(offsets)).encode()+b'/Root 1 0 R>>\nstartxref\n'+str(xref).encode()+b'\n%%EOF\n');return data

def run(label,parts,scope,observer='observer.py'):
 path=HERE/(label+'.pdf');data=pdf(parts);path.write_bytes(data);out=HERE/(label+'-'+scope+'-output');args=[sys.executable,str(HERE/observer),str(ROOT),str(path),scope,str(out)];started=time.monotonic()
 with (HERE/(out.name+'.stdout')).open('wb') as stdout,(HERE/(out.name+'.stderr')).open('wb') as stderr:
  p=subprocess.run(args,cwd=HERE,env=ENV,stdout=stdout,stderr=stderr,timeout=40)
 prop=out/'result.properties';result=dict(line.split('=',1) for line in prop.read_text().splitlines() if line and not line.startswith(('#','!'))) if prop.exists() else None
 row={'label':label,'scope':scope,'command':args,'cwd':str(HERE),'exit':p.returncode,'elapsed':time.monotonic()-started,'input-sha256':sha(path),'result':result,'files':{str(f.relative_to(out)):sha(f) for f in out.iterdir() if f.is_file()}}
 rows.append(row);(HERE/(label+'-'+scope+'-result.json')).write_text(json.dumps(row,indent=2)+'\n');print(label,scope,p.returncode,result.get('standards') if result else None,result.get('finding') if result else None,flush=True)


def change(num, before, after):
 p=objects();assert p[num-1].count(before)==1;p[num-1]=p[num-1].replace(before,after);return p
def emit(label,p,scope='structure-content'):
 run(label,p,scope)


expectations={}
def observe(label,parts,expected,observer='observer.py'):
 expectations[label]=expected;run(label,parts,'structure-content',observer)
 assert rows[-1]['result']['standards']==expected,(label,rows[-1]['result'])
def ap_form(mcid=False,invoked=False,flags=None):
 p=objects();p[2]=p[2].replace(b'/Resources<<>>',b'/Resources<</XObject<</Fm 8 0 R>>>>').replace(b'/StructParents 0',b'/Annots[9 0 R]')
 child=b'<</Type/MCR/Stm 8 0 R/MCID 0>>' if mcid else b'<</Type/OBJR/Obj 8 0 R>>'
 p[4]=p[4].replace(b'/K 0',b'/K'+child);p[5]=b'<</Nums[0[5 0 R]]>>' if mcid else b'<</Nums[0 5 0 R]>>';p[6]=stream(data=b'/Fm Do' if invoked else b'q Q')
 dictionary=b'<</Subtype/Form/BBox[0 0 10 10]/Resources<<>>'+(b'/StructParents 0' if mcid else b'/StructParent 0')+b'>>'
 p[7]=stream(dictionary,b'/P<</MCID 0>>BDC EMC' if mcid else b'q Q')
 p.append(b'<</Type/Annot/Subtype/Text/Rect[0 0 10 10]/P 3 0 R/AP<</N 8 0 R>>'+(b'' if flags is None else b'/F '+str(flags).encode())+b'>>');return p
for invoked in (False,True):
 label='page-and-appearance' if invoked else 'appearance-only';p=ap_form(True,invoked,2)
 observe('old-hidden-'+label,p,'fail' if invoked else 'pass','observer-before.py')
 observe('current-hidden-'+label,p,'indeterminate')
 p0=list(p);assert p0[8].count(b'/F 2')==1;p0[8]=p0[8].replace(b'/F 2',b'/F 0')
 assert len(pdf(p))==len(pdf(p0)) and sum(a!=b for a,b in zip(pdf(p),pdf(p0)))==1
 observe('only-f2-to-f0-'+label,p0,'fail' if invoked else 'pass')
for flag,expected in [(1,'indeterminate'),(32,'indeterminate'),(256,'indeterminate'),(4,'pass'),(64,'pass'),(6,'indeterminate')]:observe('annotation-flag-'+str(flag),ap_form(True,False,flag),expected)
p=ap_form(True,False);p[8]=p[8][:-2]+b'/F 10 0 R>>';p.append(b'2');observe('indirect-hidden-flag',p,'indeterminate')
for name,entry,expected in [('omitted',b'','pass'),('null',b'/P null','pass'),('wrong',b'/P 2 0 R','fail')]:
 p=ap_form(True,False,0);p[8]=p[8].replace(b'/P 3 0 R',entry);observe('discovered-owner-page-'+name,p,expected)
for name,invoked,local,appearance,expected in [
 ('inherited-page-and-ap',True,False,True,'indeterminate'),
 ('local-page-and-ap',True,True,True,'pass'),
 ('inherited-ap-only',False,False,True,'indeterminate'),
 ('local-ap-only',False,True,True,'pass'),
 ('inherited-page-without-ap',True,False,False,'pass')]:
 p=ap_form(False,invoked,0);p[2]=p[2].replace(b'/Resources<<',b'/Resources<</Font<</F1 10 0 R>>');p[6]=stream(data=b'BT/F1 10 Tf ET'+(b' /Fm Do' if invoked else b''))
 body=b'BT'+(b'/F1 10 Tf' if local else b'')+b'(A)Tj ET'
 p[7]=stream(b'<</Subtype/Form/BBox[0 0 10 10]/Resources<</Font<</F1 10 0 R>>>>/StructParent 0>>',body);p.append(b'<</Type/Font/Subtype/Type1/BaseFont/Courier>>')
 if not appearance:p[8]=p[8].replace(b'/AP<</N 8 0 R>>',b'')
 if name=='inherited-page-and-ap':observe('old-'+name,p,'pass','observer-before.py')
 observe('current-'+name,p,expected)
for n in (126,127):
 p=ap_form(False,True,0);p[6]=stream(data=b' '.join([b'/Fm Do']*n));observe('page-occurrences-plus-independent-ap-'+str(n),p,'pass' if n==126 else 'indeterminate')

after={str(p):sha(p) for p in files};assert after==identities;(HERE/'adjacent-identity.json').write_text(json.dumps({'before':identities,'after':after,'unchanged':identities==after,'probe-sha256':sha(Path(__file__))},indent=2)+'\n');(HERE/'adjacent-results.json').write_text(json.dumps(rows,indent=2)+'\n');(HERE/'adjacent-expectations.json').write_text(json.dumps(expectations,indent=2)+'\n');print('COMPLETE',len(rows),'identities unchanged',identities==after,flush=True)
