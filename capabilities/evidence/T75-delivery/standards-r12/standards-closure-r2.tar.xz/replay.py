from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time
ROOT=Path('/home/ubuntu/IdeaProjects/open-pdf');HERE=Path(__file__).resolve().parent
OLD=Path('/tmp/t75-content-standards-closure-s1ehv2u2')
SHA='b016df86f5cf2735aa272d539b721a288da42ba2edc00192db084c9cf7fce8e6'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert sha(HERE/'observer.py')==SHA
ENV=dict(os.environ);ENV.pop('QPDF_CACHE_DIRECTORY',None)
files=[HERE/'observer.py',HERE/'contract.md',HERE/'structure-tests.py',Path(sys.executable).resolve(),ROOT/'.build-cache/qpdf/12.4.0/bin/qpdf']+[ROOT/'scripts'/x for x in ['qpdf-pin.properties','container-bin/qpdf','t13-qpdf-runtime.sha256']]
for line in (ROOT/'scripts/t13-qpdf-runtime.sha256').read_text().splitlines():files.append(ROOT/'.build-cache/qpdf/12.4.0'/line.split('  ',1)[1])
identities={str(p):sha(p) for p in files};rows=[]
(HERE/'identity-before.json').write_text(json.dumps(identities,indent=2)+'\n')
selected = {'appearance-optional-form-type','appearance-null-form-type','appearance-aliased-states','appearance-distinct-states','appearance-ap-stream','appearance-state-not-stream','appearance-count-127','appearance-count-128','two-annotation-owners-one-structured-form','whole-annotation-appearance-overlap'}
for old in json.loads((OLD/'all-observations.json').read_text()):
 if old['label'] not in selected: continue
 label=old['label'];scope=old['scope'];pdf=HERE/(label+'.pdf');shutil.copyfile(OLD/(label+'.pdf'),pdf);assert sha(pdf)==old['input-sha256']
 output=HERE/(label+'-'+scope+'-output');command=[sys.executable,str(HERE/'observer.py'),str(ROOT),str(pdf),scope,str(output)];started=time.monotonic()
 with (HERE/(output.name+'.stdout')).open('wb') as stdout,(HERE/(output.name+'.stderr')).open('wb') as stderr:
  proc=subprocess.run(command,cwd=HERE,env=ENV,stdout=stdout,stderr=stderr,timeout=40)
 result=dict(line.split('=',1) for line in (output/'result.properties').read_text().splitlines());assert proc.returncode==0;assert result['observer-sha256']==SHA;assert result['input-sha256']==sha(pdf)
 row={'label':label,'scope':scope,'command':command,'cwd':str(HERE),'exit':proc.returncode,'elapsed':time.monotonic()-started,'input-sha256':sha(pdf),'old-result':old['result'],'result':result,'files':{f.name:sha(f) for f in output.iterdir() if f.is_file()}}
 assert result['standards']==old['result']['standards'],row
 rows.append(row);(HERE/(label+'-'+scope+'-result.json')).write_text(json.dumps(row,indent=2)+'\n');print(label,old['result']['standards'],'=>',result['standards'],result['finding'],flush=True)
after={str(p):sha(p) for p in files};assert after==identities;(HERE/'identity.json').write_text(json.dumps({'before':identities,'after':after,'unchanged':identities==after,'probe-sha256':sha(Path(__file__))},indent=2)+'\n');(HERE/'replay-results.json').write_text(json.dumps(rows,indent=2)+'\n');print('COMPLETE',len(rows),'identities unchanged',after==identities,flush=True)
